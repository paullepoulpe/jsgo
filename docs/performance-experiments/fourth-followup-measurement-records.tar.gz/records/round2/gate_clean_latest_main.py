import json,os,subprocess,sys
from pathlib import Path
sys.path.insert(0,'/workspace/jsgo-cli-next/tools/bench')
import bench
binary=sys.argv[1] if len(sys.argv)>1 else '/workspace/jsgo-results/round2/bin/jsgo-combined'
root=Path('/workspace/jsgo-results/round2')/(sys.argv[2] if len(sys.argv)>2 else 'gates')
thread_counts=tuple(map(int,sys.argv[3].split(','))) if len(sys.argv)>3 else (1,2)
env={k:v for k,v in os.environ.items() if k not in bench.GO_ENV_DROP and not k.startswith('JSGO_EXPERIMENT_')}
env.update(LC_ALL='C.UTF-8')
if len(sys.argv)>4:
 env.update(json.loads(sys.argv[4]))
for threads in thread_counts:
 for task in bench.load_tasks(['typed-app','bundle','downlevel-whitespace','downlevel-simple','checks-only']):
  name=task['name'];ws=root/f'threads-{threads}'/name
  bench.make_workspace(str(ws),'/workspace/jsgo/.cache')
  args=bench.task_jobs(task,str(ws))[0]+[f'--num_parallel_threads={threads}']
  with (ws/'stdout').open('wb') as stdout,(ws/'stderr').open('wb') as stderr:
   p=subprocess.run([binary]+args,cwd=ws,env=env,stdout=stdout,stderr=stderr,timeout=600)
  (ws/'exit').write_text(str(p.returncode)+'\n')
  ref=Path('/workspace/jsgo-results/round2/baseline')/name/'java-cold/run-1'
  arts=bench.artifacts(task,str(ws),0,True)
  bad=[k for k,v in arts.items() if not bench.same_file(str(ref/k),v)]
  print(f'{name} N={threads}: exit={p.returncode}, mismatches={bad}',flush=True)
  if bad or p.returncode != 0:sys.exit(1)
