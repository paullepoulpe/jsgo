package jscomp

import (
 "testing"
 "github.com/paullepoulpe/jsgo/internal/rhino"
)

// nodeTraversalTestCallback is an anonymous NodeTraversal.Callback.
type nodeTraversalTestCallback struct {
	shouldTraverse func(t *NodeTraversal, n, parent *rhino.Node) bool
	visit          func(t *NodeTraversal, n, parent *rhino.Node)
}

func (c *nodeTraversalTestCallback) ShouldTraverse(t *NodeTraversal, n, parent *rhino.Node) bool {
	if c.shouldTraverse == nil {
		return true
	}
	return c.shouldTraverse(t, n, parent)
}

func (c *nodeTraversalTestCallback) Visit(t *NodeTraversal, n, parent *rhino.Node) {
	if c.visit != nil {
		c.visit(t, n, parent)
	}
}

// nodeTraversalTestScopedCallback is an anonymous NodeTraversal.ScopedCallback.
type nodeTraversalTestScopedCallback struct {
	nodeTraversalTestCallback
	enterScope func(t *NodeTraversal)
	exitScope  func(t *NodeTraversal)
}

func (c *nodeTraversalTestScopedCallback) EnterScope(t *NodeTraversal) {
	if c.enterScope != nil {
		c.enterScope(t)
	}
}

func (c *nodeTraversalTestScopedCallback) ExitScope(t *NodeTraversal) {
	if c.exitScope != nil {
		c.exitScope(t)
	}
}

func scopeTestParse(t *testing.T, compiler *Compiler, js string) *rhino.Node {
	t.Helper()
	n := compiler.ParseTestCode(js)
	if errors := compiler.GetErrors(); len(errors) != 0 {
		t.Fatalf("parse errors: %v", errors)
	}
	rhino.IR_Root(n)
	return n
}
