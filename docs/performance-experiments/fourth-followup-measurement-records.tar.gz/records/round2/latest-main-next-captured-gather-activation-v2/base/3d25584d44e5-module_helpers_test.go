// Port of test/com/google/javascript/jscomp/deps/ModuleLoaderTest.java @ closure-compiler v20261015

/*
 * Copyright 2016 The Closure Compiler Authors.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package jscomp

import "github.com/paullepoulpe/jsgo/internal/jutil"

func jsaMlInputs(names ...string) []DependencyInfo {
	builder := []DependencyInfo{}
	for _, name := range names {
		builder = append(builder, jsaMlInput(name))
	}
	return builder
}

func jsaMlInput(name string) DependencyInfo {
	return NewCompilerInputWithIsExtern(SourceFile_FromCode(name, ""), false)
}

func jsaMlPACKAGE_JSON_MAIN_ENTRIES() *jutil.LinkedHashMap[string, string] {
	return jsaMap(
		"/B/package.json", "/B/lib/b",
		"/node_modules/B/package.json", "/node_modules/B/lib/b.js")
}

func jsaMap(kv ...string) *jutil.LinkedHashMap[string, string] {
	m := jutil.NewLinkedHashMap[string, string]()
	for i := 0; i < len(kv); i += 2 {
		m.Put(kv[i], kv[i+1])
	}
	return m
}
