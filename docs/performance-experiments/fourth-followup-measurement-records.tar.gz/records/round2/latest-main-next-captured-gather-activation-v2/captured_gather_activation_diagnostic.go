// Diagnostic-only numeric state: excluded from production, race and timed binaries.
package jscomp

import (
	"reflect"
	"sync"
)

var capturedValidationActivationProbe *arrayRecipeValuesProbe
var nextActivationCounters = struct {
	sync.Mutex
	gather, use map[string]int64
	passes      int64
}{gather: make(map[string]int64), use: make(map[string]int64)}

func nextActivationAdd(dst map[string]int64, probe any) {
	value := reflect.ValueOf(probe)
	if value.IsNil() {
		return
	}
	value = value.Elem()
	fields := value.Type()
	for i := 0; i < value.NumField(); i++ {
		name, n := fields.Field(i).Name, value.Field(i).Int()
		if name == "MaxDenseBytes" {
			dst[name] = max(dst[name], n)
		} else {
			dst[name] += n
		}
	}
}
func nextActivationGatherRetire(gather *nativeFSIVGatherProbe, use *nativeUseCardinalityStats) {
	nextActivationCounters.Lock()
	defer nextActivationCounters.Unlock()
	nextActivationCounters.passes++
	nextActivationAdd(nextActivationCounters.gather, gather)
	nextActivationAdd(nextActivationCounters.use, use)
}
func nextActivationGatherReset() {
	nextActivationCounters.Lock()
	defer nextActivationCounters.Unlock()
	clear(nextActivationCounters.gather)
	clear(nextActivationCounters.use)
	nextActivationCounters.passes = 0
}
func nextActivationGatherSnapshot() map[string]int64 {
	nextActivationCounters.Lock()
	defer nextActivationCounters.Unlock()
	out := make(map[string]int64, len(nextActivationCounters.gather)+1)
	out["CompletedFSIVPasses"] = nextActivationCounters.passes
	for key, value := range nextActivationCounters.gather {
		out[key] = value
	}
	return out
}
func nextActivationUseSnapshot() map[string]int64 {
	nextActivationCounters.Lock()
	defer nextActivationCounters.Unlock()
	out := make(map[string]int64, len(nextActivationCounters.use))
	for key, value := range nextActivationCounters.use {
		out[key] = value
	}
	return out
}
