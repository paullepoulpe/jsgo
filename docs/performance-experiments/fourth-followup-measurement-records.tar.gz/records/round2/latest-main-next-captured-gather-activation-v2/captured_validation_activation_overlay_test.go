package jscomp

import (
	"bytes"
	"encoding/json"
	"fmt"
	"github.com/paullepoulpe/jsgo/internal/jutil"
	"os"
	"path/filepath"
	"testing"
)

func TestCapturedValidationRealCLIActivation(t *testing.T) {
	argsPath := os.Getenv("JSGO_CAPTURED_ACTIVATION_ARGS")
	resultDir := os.Getenv("JSGO_CAPTURED_ACTIVATION_OUT")
	if argsPath == "" || resultDir == "" {
		t.Skip("activation args/output not supplied")
	}
	data, err := os.ReadFile(argsPath)
	if err != nil {
		t.Fatal(err)
	}
	if cwd := os.Getenv("JSGO_CAPTURED_ACTIVATION_CWD"); cwd != "" {
		previous, e := os.Getwd()
		if e != nil {
			t.Fatal(e)
		}
		if e = os.Chdir(cwd); e != nil {
			t.Fatal(e)
		}
		defer func() {
			if e := os.Chdir(previous); e != nil {
				t.Error(e)
			}
		}()
	}
	var args []string
	if err = json.Unmarshal(data, &args); err != nil {
		t.Fatal(err)
	}
	nextActivationGatherReset()
	capturedValidationActivationProbe = &arrayRecipeValuesProbe{}
	defer func() { capturedValidationActivationProbe = nil }()
	var stdout, stderr bytes.Buffer
	runner := NewCommandLineRunnerWithOutAndErr(args, jutil.NewPrintStream(&stdout), jutil.NewPrintStream(&stderr))
	status := runner.DoRun()
	probe := capturedValidationActivationProbe
	counts := map[string]any{"status": status, "activated": probe.Activated, "calls": probe.Calls,
		"recipe_seeds": probe.ArrayRecipeSeeds, "recipe_hits": probe.ArrayRecipeHits, "recipe_fallbacks": probe.ArrayRecipeFallbacks,
		"shared_hits": probe.ArraySharedResolvedHits, "captured_seeds": probe.CapturedValidationSeeds,
		"captured_hits": probe.CapturedValidationHits, "captured_fallbacks": probe.CapturedValidationFallbacks,
		"boundary_checks": probe.BoundaryChecks, "full_scope_checks": probe.FullScopeChecks, "fast_scope_checks": probe.FastScopeChecks,
		"lease_closed": !nativeCLILeaseActive(runner.GetCompiler())}
	counts["gather"] = nextActivationGatherSnapshot()
	counts["lazy_use"] = nextActivationUseSnapshot()
	if err = os.MkdirAll(resultDir, 0700); err != nil {
		t.Fatal(err)
	}
	for name, payload := range map[string][]byte{"stdout": stdout.Bytes(), "stderr": stderr.Bytes(), "status": []byte(fmt.Sprint(status)), "exit": []byte(fmt.Sprintln(status))} {
		if err = os.WriteFile(filepath.Join(resultDir, name), payload, 0600); err != nil {
			t.Fatal(err)
		}
	}
	payload, err := json.MarshalIndent(counts, "", "  ")
	if err != nil {
		t.Fatal(err)
	}
	if err = os.WriteFile(filepath.Join(resultDir, "activation.json"), payload, 0600); err != nil {
		t.Fatal(err)
	}
	fmt.Println(string(payload))
	if status != 0 {
		t.Fatalf("actual stock CLI failed: %d\n%s", status, stderr.String())
	}
}
