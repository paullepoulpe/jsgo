package jscomp

import (
	"os"

	"github.com/paullepoulpe/jsgo/internal/rhino"
)

func nativeArrayUnknownRecipeEnabled() bool {
	return os.Getenv("JSGO_EXPERIMENT_ARRAY_UNKNOWN_RECIPE") == "1"
}

func nativeArrayCapturedValidationEnabled() bool {
	return os.Getenv("JSGO_EXPERIMENT_ARRAY_CAPTURED_VALIDATION") == "1"
}

func nativeArraySharedResolvedEnabled() bool {
	return os.Getenv("JSGO_EXPERIMENT_ARRAY_SHARED_RESOLVED") == "1"
}

type arrayRecipeValuesMode struct {
	owner                *Compiler
	lease                *nativeCLILease
	options              *CompilerOptions
	root                 *rhino.Node
	creator              *TypedScopeCreator
	registry             *rhino.JSTypeRegistry
	errorManager         ErrorManager
	errorCounter         *arrayRecipeErrorCounter
	probe                *arrayRecipeValuesProbe
	ready                bool
	slowChecks           bool
	arrayRecipeEnabled   bool
	arraySharedResolved  bool
	arrayRecipeTried     bool
	arrayRecipe          *rhino.NativeArrayUnknownRecipe
	capturedValidation   bool
	capturedSession      *rhino.NativeArrayUnknownSession
	observingConstructor bool
}

type arrayRecipeValuesProbe struct {
	Activated, Calls, BoundaryChecks, FullScopeChecks, FastScopeChecks           int
	ArrayRecipeSeeds, ArrayRecipeHits, ArrayRecipeFallbacks                      int
	ArraySharedResolvedHits                                                      int
	CapturedValidationSeeds, CapturedValidationHits, CapturedValidationFallbacks int
	// beforeConstruct is an adversarial diagnostic observer; it always disables
	// captured validation and nested observer calls use the original factory.
	beforeConstruct func(*TypeInference)
	// Independent pre-V2 admission oracle for differential tests only.
	legacyScopeChecks bool
	Scopes            []arrayRecipeValuesScopeAdmission
}

type arrayRecipeValuesScopeAdmission struct {
	node     *rhino.Node
	errors   int
	accepted bool
}

func newArrayRecipeValuesMode(p *TypeInferencePass, root *rhino.Node) *arrayRecipeValuesMode {
 if capturedValidationActivationProbe!=nil {p.arrayRecipeProbe=capturedValidationActivationProbe} // numeric observation only
	owner := p.compiler.(*Compiler) // The full entry guard already checked this.
	mode := &arrayRecipeValuesMode{owner: owner, lease: owner.nativeCLILease, options: owner.GetOptions(), root: root, creator: p.scopeCreator,
		registry: p.registry, errorManager: owner.errorManager, probe: p.arrayRecipeProbe,
		arrayRecipeEnabled:  nativeArrayUnknownRecipeEnabled(),
		arraySharedResolved: nativeArraySharedResolvedEnabled(),
		capturedValidation:  nativeArrayCapturedValidationEnabled()}
	mode.errorCounter = newArrayRecipeErrorCounter(mode.errorManager)
	mode.slowChecks = mode.errorCounter == nil ||
		mode.probe != nil && mode.probe.legacyScopeChecks
	return mode
}

func (m *arrayRecipeValuesMode) matches(p *TypeInferencePass) bool {
	owner, ok := p.compiler.(*Compiler)
	if !ok || owner != m.owner || owner.nativeCLILease != m.lease || !nativeCLILeaseActive(owner) || owner.GetOptions() != m.options || p.scopeCreator != m.creator || p.registry != m.registry ||
		owner.GetRoot() != m.root || owner.typeRegistry != m.registry || owner.errorManager != m.errorManager {
		return false
	}
	creatorOwner, ok := m.creator.compiler.(*Compiler)
	return ok && creatorOwner == owner
}

// Scope construction can report errors. Revalidate once after it finishes,
// before the unchanged second traversal.
// The stock CLI has no callback that changes these admitted identities/hooks
// during inference. The private probe path below keeps the original full check.
func (p *TypeInferencePass) finishArrayRecipeScopeBuilding(root *rhino.Node) {
	if mode := p.arrayRecipeValues; mode != nil {
		if mode.probe != nil {
			mode.probe.BoundaryChecks++
		}
		mode.ready = root == mode.root && mode.matches(p) && arrayRecipeValuesSafe(p, root)
	}
}

func (p *TypeInferencePass) currentArrayRecipeValues(n *rhino.Node) *arrayRecipeValuesMode {
	mode := p.arrayRecipeValues
	if mode == nil {
		return nil
	}
	full := mode.slowChecks
	accepted, errors := false, -1
	if full {
		// The diagnostic oracle retains full per-scope validation.
		if owner, ok := p.compiler.(*Compiler); ok {
			accepted = arrayRecipeValuesSafe(p, owner.GetRoot())
			if mode.probe != nil {
				errors = owner.GetErrorCount()
			}
		}
	} else if mode.matches(p) {
		// Report has returned before each private stock InferScope boundary.
		// Reading through the same mutex preserves concurrent Report exclusion
		// without the reentrant monitor's two runtime.Stack walks per scope.
		errors = mode.errorCounter.read()
		accepted = mode.ready && errors == 0
	}
	if probe := mode.probe; probe != nil {
		if full {
			probe.FullScopeChecks++
		} else {
			probe.FastScopeChecks++
		}
		probe.Scopes = append(probe.Scopes, arrayRecipeValuesScopeAdmission{n, errors, accepted})
	}
	if accepted {
		return mode
	}
	return nil
}

// The plan captures only exact callback-free counter implementations. Every
// delegate is checked before any cold lock is acquired, including cycle/depth
// limits. Delegation is constructor-owned and never changes during stock CLI.
// An unknown/malformed chain retains the original per-scope admission path.
type arrayRecipeErrorCounter struct {
	manager  ErrorManager
	wrappers []*ThreadSafeDelegatingErrorManager
	leaf     *SortingErrorManagerBase
}

func newArrayRecipeErrorCounter(manager ErrorManager) *arrayRecipeErrorCounter {
	// The stock compiler always installs this synchronized outer wrapper.
	// Bare managers keep their original public path; a private leaf read must
	// always be protected by at least the same mutex as public Report.
	if _, wrapped := manager.(*ThreadSafeDelegatingErrorManager); !wrapped {
		return nil
	}
	plan := &arrayRecipeErrorCounter{manager: manager}
	current := manager
	for depth := 0; depth <= 16; depth++ {
		switch m := current.(type) {
		case *ThreadSafeDelegatingErrorManager:
			if m == nil {
				return nil
			}
			for _, previous := range plan.wrappers {
				if previous == m {
					return nil
				}
			}
			plan.wrappers = append(plan.wrappers, m)
			current = m.delegated
		case *LoggerErrorManager:
			if m == nil {
				return nil
			}
			plan.leaf = &m.SortingErrorManagerBase
			return plan
		case *PrintStreamErrorManager:
			if m == nil {
				return nil
			}
			plan.leaf = &m.SortingErrorManagerBase
			return plan
		case *SortingErrorManagerBase:
			if m == nil {
				return nil
			}
			plan.leaf = m
			return plan
		default:
			return nil
		}
	}
	return nil
}

func (p *arrayRecipeErrorCounter) read() int {
	locked := 0
	unlock := func() {
		for locked > 0 {
			locked--
			p.wrappers[locked].monitor.UnlockNonReentrant()
		}
	}
	defer unlock()
	for _, wrapper := range p.wrappers {
		if !wrapper.monitor.TryLockNonReentrant() {
			// Release every cold outer lock BEFORE calling the original getter.
			// This preserves reentry even when an inner public monitor was
			// already held by this goroutine, and excludes unknown callbacks
			// from running under a cold outer lock.
			unlock()
			return p.manager.GetErrorCount()
		}
		locked++
	}
	// This concrete base method sums two integers. It never dispatches through
	// self, prints, resolves source maps, or calls a report generator.
	return p.leaf.GetErrorCount()
}

func (ti *TypeInference) createTemplatizedType(base rhino.ObjectType, types ...rhino.JSType) *rhino.TemplatizedType {
	if mode := ti.arrayRecipeValues; mode != nil {
		if probe := mode.probe; probe != nil {
			if probe.beforeConstruct != nil {
				if mode.observingConstructor {
					return ti.registry.CreateTemplatizedType(base, types...)
				}
				mode.observingConstructor = true
				defer func() { mode.observingConstructor = false }()
				// Observer code may mutate source bindings or reenter the factory. Retire
				// any session before invoking it; the ordinary full validator runs below.
				mode.capturedSession = nil
				mode.capturedValidation = false // An observer retires the lifetime proof permanently.
				probe.beforeConstruct(ti)
			}
			probe.Calls++
		}
		if mode.arrayRecipeEnabled && len(types) == 1 {
			array, arrayOK := base.(*rhino.InstanceObjectType)
			unknown, unknownOK := types[0].(*rhino.UnknownType)
			if arrayOK && array != nil && unknownOK && unknown != nil &&
				rhino.JSType(array) == ti.registry.GetNativeType(rhino.JSTypeNative_ARRAY_TYPE) &&
				rhino.JSType(unknown) == ti.registry.GetNativeType(rhino.JSTypeNative_UNKNOWN_TYPE) {
				if mode.arrayRecipe != nil {
					var result *rhino.TemplatizedType
					captured := mode.capturedValidation && mode.ready && !mode.slowChecks &&
						mode.creator.stage == TypedScopeCreator_Stage_FROZEN &&
						(mode.probe == nil || mode.probe.beforeConstruct == nil)
					if captured && mode.capturedSession == nil {
						mode.capturedSession = mode.arrayRecipe.NewCapturedValidationSession()
						if mode.probe != nil && mode.capturedSession != nil {
							mode.probe.CapturedValidationSeeds++
						}
					}
					if captured && mode.capturedSession != nil {
						result = mode.capturedSession.TryNew(mode.arraySharedResolved)
						if mode.probe != nil {
							if result != nil {
								mode.probe.CapturedValidationHits++
							} else {
								mode.probe.CapturedValidationFallbacks++
							}
						}
					} else if mode.arraySharedResolved {
						result = mode.arrayRecipe.TryNewSharedResolved()
					} else {
						result = mode.arrayRecipe.TryNew()
					}
					if result != nil {
						if mode.probe != nil {
							mode.probe.ArrayRecipeHits++
							if mode.arraySharedResolved {
								mode.probe.ArraySharedResolvedHits++
							}
						}
						return result
					}
					mode.arrayRecipe = nil
					mode.capturedSession = nil
					mode.arrayRecipeTried = false
					if mode.probe != nil {
						mode.probe.ArrayRecipeFallbacks++
					}
				}
				// Seed from the first actual ORIGINAL construction, not an unobserved
				// extra exemplar. Unsupported shapes stay on this original factory.
				result := ti.registry.CreateTemplatizedType(base, types...)
				if !mode.arrayRecipeTried {
					mode.arrayRecipeTried = true
					mode.arrayRecipe = rhino.CaptureNativeArrayUnknownRecipe(ti.registry, result)
					if mode.probe != nil && mode.arrayRecipe != nil {
						mode.probe.ArrayRecipeSeeds++
					}
				}
				return result
			}
		}
	}
	return ti.registry.CreateTemplatizedType(base, types...)
}
