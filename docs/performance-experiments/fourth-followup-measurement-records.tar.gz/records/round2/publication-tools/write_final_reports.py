import json,re
from pathlib import Path
r=Path('/workspace/jsgo-results/round2')
s=json.loads((r/'latest-main-final-design-screen/summary.json').read_text())
lines=['# Final clean-main candidate screen (round20)','',
'Frozen source `baf328cba812a7ebadd2eb3f9912107382805e8a`, descended from main `ff06ac15`. This adds the inline-scope retention repair, captured Array validation and private CFG-local gathering to the earlier compact4 integration. Ordinary fresh CLI, Go 1.27.2 standard inlining, shipped main PGO, default runtime GC/GOMAXPROCS, CPUs 0,1 and compiler N=1. No worker or extern reuse. Build-only resource controls are recorded separately and were cleared for measurement. No builds, tests, profiles or archiving overlapped timings.','',
'Five variants × five tasks × three observations =75 timed runs. `control_next` disables all optional factors; `gather` enables only the private gather walker; `recipe_shared` enables the Array recipe/shared-vector group; `recipe_captured` additionally enables captured validation; `compound` combines captured recipe/sharing, gather, and cardinality/projected/scalar use analysis. Parser and CommonJS factors are off. All variants use the same binary; the unconditional compact-stack/retention changes are in their common control. This is NOT a paired stock-main comparison or an additional whole-main speed claim.','',
'|Task|Variant|Go seconds [min,max]|Change vs control|Peak RSS MiB [min,max]|Java/Go time|Java/Go RSS|','|---|---|---:|---:|---:|---:|---:|']
for task,row in s.items():
 b=row['variants']['control_next']['median_s']
 for label,v in row['variants'].items():
  runs=json.loads((r/'latest-main-final-design-screen'/task/label/'jsgo.json').read_text())['runs']
  rss=[x['rss_mb'] for x in runs]
  assert len(runs)==3 and all(x['exits']==[0] for x in runs) and v['all_outputs_match']
  lines.append(f"|{task}|{label}|{v['median_s']:.3f} [{v['min_s']:.3f},{v['max_s']:.3f}]|{100*(v['median_s']/b-1):+.2f}%|{v['median_peak_rss_mb']:.1f} [{min(rss):.1f},{max(rss):.1f}]|{v['speed_vs_java_warm']:.3f}|{v['memory_ratio_java_over_go']:.2f}|")
lines += ['',
'Negative time changes mean less elapsed time. All75 measured exits/artifact digests match pinned Java. Ratios are Java/Go; above1 favors Go. Java uses the stored warm-JVM reference with fresh compiler and reparsed externs per iteration. These are not fresh paired Java confidence data or settled-JIT proof. Go RSS is the median fresh-process lifetime peak; Java RSS is the warm-JVM lifetime peak including warmup. Repetition ranges and inactive-workload variation limit conclusions; modeled buffer savings and cumulative allocation profiles are not peak RSS.','',
'Compatibility evidence: the plain focused race run passes205 test/subtest records with one optional Angular fixture skipped because its input environment was absent. Running only that fixture with the pinned input passes separately, bringing exercised passing records to206 across the two runs. No failures/data races. All15 CLI gates match at N=1/2/4. Real-input diagnostic runs match all stdout/stderr/exit/JS/map digests and prove actual gather/captured execution; see `latest-main-next-activation-report.md`. These cover exercised behavior, not the entire port.','',
'The frozen source bundle published before these tests correctly labels this integration unvalidated at its capture time; these later records supersede that status without rewriting the published archive. The source commit is unchanged. Raw source/build/overlay/test/activation/timing commands and identities are retained.','',
'No broad default promotion, exhaustive search or fixed theoretical maximum is inferred. The report and open-idea notes distinguish a measured negative from an unimplemented design. Any future attempt to improve the new backends should profile admission/staging/dispatch and allocation costs on the current binary rather than assume object elimination guarantees speed. Fresh paired stock-main/Java confirmation is required before claiming parity or a broad win.']
(r/'latest-main-final-design-round20.md').write_text('\n'.join(lines)+'\n')
lines=['# Latest-main CommonJS run-pool thread screen (round21)','',
'Same frozen `baf328cb` standard binary as round20. Whitespace task only, ordinary fresh CLI, default runtime GC/GOMAXPROCS, CPUs0,1/two-CPU quota. Five alternating observations per variant at each compiler N=1/2/4,30 timed runs total. `control` has all factors off; `run_pool` enables only parallel CommonJS, exact-TRUE admission and the persistent pool within one pass/run. It is not a persistent compiler worker. N=1 parallel dispatch is inactive. Other algorithm/parser/type factors remain off.','',
'Each N uses its OWN matched stored warm-Java N cohort and artifact reference. Do not substitute the separate N=1 all-task denominator. Java is warm JVM with fresh compiler/extern parsing per iteration; memory windows differ as documented. This is not fresh paired Java confidence data.','',
'|Compiler N|Variant|Go seconds [min,max]|Go peak RSS MiB [min,max]|Time vs same-N control|Java seconds / RSS MiB|Java/Go time|Java/Go RSS|','|---|---|---:|---:|---:|---:|---:|---:|']
for n in [1,2,4]:
 out=r/f'latest-main-runpool-threads-{n}'; row=json.loads((out/'summary.json').read_text())['downlevel-whitespace']; base=row['variants']['control']['median_s']
 for label,v in row['variants'].items():
  runs=json.loads((out/'downlevel-whitespace'/label/'jsgo.json').read_text())['runs']; rss=[x['rss_mb'] for x in runs]
  assert len(runs)==5 and all(x['exits']==[0] for x in runs) and v['all_outputs_match']
  lines.append(f"|{n}|{label}|{v['median_s']:.3f} [{v['min_s']:.3f},{v['max_s']:.3f}]|{v['median_peak_rss_mb']:.1f} [{min(rss):.1f},{max(rss):.1f}]|{100*(v['median_s']/base-1):+.2f}%|{row['java_warm_s']:.3f} / {row['java_peak_rss_mb']:.1f}|{v['speed_vs_java_warm']:.3f}|{v['memory_ratio_java_over_go']:.2f}|")
lines += ['',
'All30 measured exits/artifact digests match Java. Ratios are Java/Go; above1 favors Go. Peak RSS is measured, not estimated. Source-only node admission is not parallel CPU coverage. Compiler N bounds concurrent phase jobs; it does not set GOMAXPROCS or cap all goroutines/OS threads. Runtime/GC goroutines continue normally. N=4 is oversubscribed on this two-CPU host, so it does not establish four-core scaling. More-core throughput/latency and memory results remain open.','',
'The N=2 actual-DoRun diagnostics from round18 prove that the exact-TRUE/maximal-run design admits862 whitespace scripts including Angular; stock-factory/lifecycle eligibility is retained in this source. Those diagnostics are not timed scaling data. The original round15 pool measurements used a different historical substrate and must not be mixed with these current-main results.']
(r/'latest-main-runpool-round21.md').write_text('\n'.join(lines)+'\n')
print('Final reports written')
