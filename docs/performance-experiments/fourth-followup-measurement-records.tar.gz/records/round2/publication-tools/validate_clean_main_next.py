import json,os,subprocess
from pathlib import Path
r=Path('/workspace/jsgo-results/round2'); binary=Path('/tmp/jsgo-latest-main-next-binaries/jscomp-latest-main-next-focused-race.test')
env={k:v for k,v in os.environ.items() if not k.startswith('JSGO_EXPERIMENT_') and k not in ['GOGC','GOMEMLIMIT','GODEBUG','GOMAXPROCS']}
cmd=[str(binary),'-test.v','-test.timeout=300s']
(r/'tests-latest-main-next-focused-race-command.json').write_text(json.dumps({'command':cmd,'source':'baf328cba812a7ebadd2eb3f9912107382805e8a','cwd':'/workspace/jsgo-main-next-integration/internal/jscomp','runtime':'default GC/GOMAXPROCS; all inherited JSGO_EXPERIMENT_* cleared; tests set their own factors'},indent=2)+'\n')
with (r/'tests-latest-main-next-focused-race.log').open('w') as f:
 p=subprocess.run(cmd,env=env,cwd='/workspace/jsgo-main-next-integration/internal/jscomp',stdout=f,stderr=subprocess.STDOUT)
print('RACE EXIT',p.returncode,flush=True)
raise SystemExit(p.returncode)
