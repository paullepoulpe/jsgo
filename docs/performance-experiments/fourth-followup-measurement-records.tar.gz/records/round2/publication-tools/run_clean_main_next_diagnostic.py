from pathlib import Path
import json,os,subprocess
r=Path('/workspace/jsgo-results/round2'); d=r/'latest-main-next-captured-gather-activation-v3'; root=Path('/workspace/jsgo-main-next-integration')
removed=[]
for p in Path('/workspace/toolchains/cache').rglob('*-d'):
 if p.is_file() and p.stat().st_size>100*1024*1024:
  removed.append({'path':str(p),'bytes':p.stat().st_size}); p.unlink()
(r/'cache-prune-completed-race-before-next-diagnostic.json').write_text(json.dumps({'scope':'No Go builds active; completed generated cache archives only. All binaries/source/results retained.','removed':removed},indent=2)+'\n')
env={k:v for k,v in os.environ.items() if not k.startswith('JSGO_EXPERIMENT_') and k not in ['GOGC','GOMEMLIMIT','GODEBUG','GOMAXPROCS']}
env.update(GOCACHE='/workspace/toolchains/cache',GOPATH='/workspace/toolchains/gopath',GOTOOLCHAIN='local',PATH='/workspace/toolchains/go1.27.2/bin:/workspace/toolchains/bin:'+env['PATH'])
command=json.loads((d/'build-command.json').read_text())
with (r/'build-latest-main-next-diagnostic.log').open('w') as f:
 subprocess.run(command['argv'],cwd=command['cwd'],env=env|{'GOGC':'20','GOMAXPROCS':'1'},stdout=f,stderr=subprocess.STDOUT,check=True)
print('DIAGNOSTIC BUILD COMPLETE',flush=True)
for run in json.loads((d/'run-commands.json').read_text()):
 with Path(run['log']).open('w') as f:
  subprocess.run(run['argv'],cwd=run['cwd'],env=env|run['env'],stdout=f,stderr=subprocess.STDOUT,check=True)
 print('DIAGNOSTIC CASE COMPLETE',run['cwd'],flush=True)
print('ALL DIAGNOSTICS COMPLETE',flush=True)
