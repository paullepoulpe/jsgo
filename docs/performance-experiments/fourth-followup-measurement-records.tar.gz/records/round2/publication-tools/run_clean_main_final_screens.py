import os,json,subprocess
from pathlib import Path
r=Path('/workspace/jsgo-results/round2'); binary='/tmp/jsgo-latest-main-next-binaries/jsgo-latest-main-next-standard'
env={k:v for k,v in os.environ.items() if not k.startswith('JSGO_EXPERIMENT_') and k not in ['GOGC','GOMEMLIMIT','GODEBUG','GOMAXPROCS']}
env['PATH']='/workspace/toolchains/go1.27.2/bin:/workspace/toolchains/bin:'+env['PATH']
recipe={'JSGO_EXPERIMENT_ARRAY_UNKNOWN_RECIPE':'1','JSGO_EXPERIMENT_ARRAY_SHARED_RESOLVED':'1'}
captured=recipe|{'JSGO_EXPERIMENT_ARRAY_CAPTURED_VALIDATION':'1'}
gather={'JSGO_EXPERIMENT_FSIV_NATIVE_GATHER':'1'}
scalar={k:'1' for k in ['JSGO_EXPERIMENT_FSIV_USE_CARDINALITY','JSGO_EXPERIMENT_FSIV_USE_PROJECTION','JSGO_EXPERIMENT_FSIV_USE_SCALAR']}
base=['/usr/bin/taskset','-c','0,1','/usr/bin/python3','-I','-u','/workspace/jsgo-structural-bitset-template/tools/bench/experiments.py']
cmd=base+['--reference',str(r/'baseline'),'--out',str(r/'latest-main-final-design-screen'),'--runs','3','--seed','20261020','--cache','/workspace/jsgo/.cache']
for label,flags in [('control_next',{}),('gather',gather),('recipe_shared',recipe),('recipe_captured',captured),('compound',captured|gather|scalar)]:
 cmd+=['--variant',label+'='+binary,'--variant-env',label+'='+json.dumps(flags)]
(r/'latest-main-final-design-screen-command.json').write_text(json.dumps(cmd,indent=2)+'\n')
with (r/'latest-main-final-design-screen.log').open('w') as f:
 subprocess.run(cmd,env=env,cwd='/workspace/jsgo-structural-bitset-template',stdout=f,stderr=subprocess.STDOUT,check=True)
print('FINAL DESIGN SCREEN COMPLETE',flush=True)
for n in [1,2,4]:
 cmd=base+['--reference',str(r/f'commonjs-matched-thread-reference/threads-{n}'),'--out',str(r/f'latest-main-runpool-threads-{n}'),'--tasks','downlevel-whitespace','--runs','5','--seed',str(20261020+n),'--cache','/workspace/jsgo/.cache']
 for label,flags in [('control',{}),('run_pool',{k:'1' for k in ['JSGO_EXPERIMENT_PARALLEL_COMMONJS','JSGO_EXPERIMENT_COMMONJS_EXACT_TRUE_GUARD','JSGO_EXPERIMENT_COMMONJS_RUN_POOL']})]:
  cmd+=['--variant',label+'='+binary,'--variant-env',label+'='+json.dumps(flags)]
 (r/f'latest-main-runpool-threads-{n}-command.json').write_text(json.dumps(cmd,indent=2)+'\n')
 with (r/f'latest-main-runpool-threads-{n}.log').open('w') as f:
  subprocess.run(cmd,env=env,cwd='/workspace/jsgo-structural-bitset-template',stdout=f,stderr=subprocess.STDOUT,check=True)
 print('THREAD SCREEN COMPLETE',n,flush=True)
print('ALL FINAL SCREENS COMPLETE',flush=True)
