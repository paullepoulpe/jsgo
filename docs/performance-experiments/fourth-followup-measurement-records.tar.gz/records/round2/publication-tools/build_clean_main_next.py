import os,json,subprocess
from pathlib import Path
r=Path('/workspace/jsgo-results/round2'); root=Path('/workspace/jsgo-main-next-integration'); out=Path('/tmp/jsgo-latest-main-next-binaries'); out.mkdir(exist_ok=True)
env={k:v for k,v in os.environ.items() if not k.startswith('JSGO_EXPERIMENT_') and k not in ['GOGC','GOMEMLIMIT','GODEBUG','GOMAXPROCS']}
env.update(GOGC='20',GOMAXPROCS='1',GOCACHE='/workspace/toolchains/cache',GOPATH='/workspace/toolchains/gopath',GOTOOLCHAIN='local',GOTMPDIR='/tmp',PATH='/workspace/toolchains/go1.27.2/bin:/workspace/toolchains/bin:'+env['PATH'])
go='/workspace/toolchains/go1.27.2/bin/go'
commands={'source':subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip(),'cwd':str(root),'build_only_memory_controls':{'GOGC':'20','GOMAXPROCS':'1'},'timed_runtime':'defaultGC; no GOMAXPROCS override','cli':[go,'build','-p=1','-buildvcs=false','-o',str(out/'jsgo-latest-main-next-standard'),'./cmd/jsgo'],'race':[go,'test','-p=1','-pgo=off','-buildvcs=false','-overlay='+str(r/'focused-latest-main-next-overlay/overlay.json'),'-race','-c','-o',str(out/'jscomp-latest-main-next-focused-race.test'),'./internal/jscomp']}
(r/'latest-main-next-build-commands.json').write_text(json.dumps(commands,indent=2)+'\n')
for name in ['cli','race']:
 with (r/f'build-latest-main-next-{name}.log').open('w') as f:
  subprocess.run(commands[name],env=env,cwd=root,stdout=f,stderr=subprocess.STDOUT,check=True)
 print('BUILD COMPLETE',name,flush=True)
print('ALL BUILDS COMPLETE',flush=True)
