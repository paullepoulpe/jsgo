#!/usr/bin/env python3
"""Freeze an untimed stock-CLI captured-validation/gather diagnostic overlay.

No Go build or compiler invocation occurs. Original admission/flags stay intact.
Use a NEW --out every time; this does not change an existing/plain overlay.
"""
import argparse, ast, hashlib, importlib.util, json, os, subprocess, sys
from pathlib import Path

TASKS=['typed-app','bundle','downlevel-whitespace','downlevel-simple','checks-only']
HELPER=r'''// Diagnostic-only numeric state: excluded from production, race and timed binaries.
package jscomp
import("reflect";"sync")
var capturedValidationActivationProbe *arrayRecipeValuesProbe
var nextActivationCounters=struct{sync.Mutex;gather,use map[string]int64;passes int64}{gather:make(map[string]int64),use:make(map[string]int64)}
func nextActivationAdd(dst map[string]int64,probe any){
 value:=reflect.ValueOf(probe)
 if value.IsNil(){return}
 value=value.Elem();fields:=value.Type()
 for i:=0;i<value.NumField();i++ {
  name,n:=fields.Field(i).Name,value.Field(i).Int()
  if name=="MaxDenseBytes" {dst[name]=max(dst[name],n)} else {dst[name]+=n}
 }
}
func nextActivationGatherRetire(gather *nativeFSIVGatherProbe,use *nativeUseCardinalityStats){
 nextActivationCounters.Lock();defer nextActivationCounters.Unlock()
 nextActivationCounters.passes++
 nextActivationAdd(nextActivationCounters.gather,gather)
 nextActivationAdd(nextActivationCounters.use,use)
}
func nextActivationGatherReset(){
 nextActivationCounters.Lock();defer nextActivationCounters.Unlock()
 clear(nextActivationCounters.gather);clear(nextActivationCounters.use);nextActivationCounters.passes=0
}
func nextActivationGatherSnapshot()map[string]int64{
 nextActivationCounters.Lock();defer nextActivationCounters.Unlock()
 out:=make(map[string]int64,len(nextActivationCounters.gather)+1)
 out["CompletedFSIVPasses"]=nextActivationCounters.passes
 for key,value:=range nextActivationCounters.gather {out[key]=value};return out
}
func nextActivationUseSnapshot()map[string]int64{
 nextActivationCounters.Lock();defer nextActivationCounters.Unlock()
 out:=make(map[string]int64,len(nextActivationCounters.use))
 for key,value:=range nextActivationCounters.use {out[key]=value};return out
}
'''

def sha(data):return hashlib.sha256(data).hexdigest()
def patch(text,before,after):
 if text.count(before)!=1:raise SystemExit('source drift: expected exactly one '+repr(before))
 return text.replace(before,after,1)
def write(path,data):
 path.parent.mkdir(parents=True,exist_ok=True)
 if isinstance(data,str):data=data.encode()
 path.write_bytes(data)
 return sha(data)
def main():
 p=argparse.ArgumentParser(description=__doc__)
 p.add_argument('--root',required=True,type=Path)
 p.add_argument('--out',required=True,type=Path)
 p.add_argument('--base-overlay',required=True,type=Path)
 p.add_argument('--captured-generator',type=Path,default=Path('/workspace/jsgo-results/round2/captured-validation-activation-generator/prepare.py'))
 p.add_argument('--reference',type=Path,default=Path('/workspace/jsgo-results/round2/baseline'))
 p.add_argument('--cache',type=Path,default=Path('/workspace/jsgo/.cache'))
 p.add_argument('--parser-ascii',action='store_true',help='optional independent parser factor; default explicitly off')
 p.add_argument('--gofmt',type=Path,default=Path('/workspace/toolchains/go1.27.2/bin/gofmt'))
 p.add_argument('--binary',type=Path,default=Path('/workspace/jsgo-results/round2/bin/jscomp-latest-main-next-captured-gather-activation.test'))
 a=p.parse_args();root=a.root.resolve();out=a.out.resolve();package=root/'internal/jscomp'
 if out.exists():p.error('--out must be new; generated inputs are immutable')
 commit=subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip()
 base=json.loads(a.base_overlay.read_text())
 if not all(Path(k).name.endswith('_test.go') for k in base['Replace']):p.error('base must be the plain test-only focused overlay')
 out.mkdir(parents=True)
 sources={};generated={};replacements={};base_targets={}
 generator=Path(__file__).resolve();generator_bytes=generator.read_bytes();sources[str(generator)]=sha(generator_bytes)
 generated['prepare-frozen.py']=write(out/'prepare-frozen.py',generator_bytes)
 generated['provenance/base-overlay.json']=write(out/'provenance/base-overlay.json',a.base_overlay.read_bytes())
 for key,target in base['Replace'].items():
  if not target:replacements[key]='';continue
  target=Path(target).resolve()
  if target not in base_targets:
   data=target.read_bytes();digest=sha(data);frozen=out/'base'/f'{digest[:12]}-{target.name}'
   generated[str(frozen.relative_to(out))]=write(frozen,data)
   base_targets[target]=frozen;sources[str(target)]=digest
  replacements[key]=str(base_targets[target])
 captured_source=a.captured_generator.read_bytes();sources[str(a.captured_generator.resolve())]=sha(captured_source)
 tree=ast.parse(captured_source)
 templates=[n.args[0].value for n in ast.walk(tree) if isinstance(n,ast.Call) and isinstance(n.func,ast.Attribute) and n.func.attr=='write_text' and isinstance(n.func.value,ast.Name) and n.func.value.id=='test' and n.args and isinstance(n.args[0],ast.Constant) and isinstance(n.args[0].value,str)]
 if len(templates)!=1:raise SystemExit('captured generator test template seam changed')
 harness=patch(templates[0],'var capturedValidationActivationProbe *arrayRecipeValuesProbe\n','')
 harness=patch(harness,'capturedValidationActivationProbe=&arrayRecipeValuesProbe{}','nextActivationGatherReset()\n capturedValidationActivationProbe=&arrayRecipeValuesProbe{}')
 harness=patch(harness,'data,err:=os.ReadFile(argsPath);if err!=nil{t.Fatal(err)}','data,err:=os.ReadFile(argsPath);if err!=nil{t.Fatal(err)}\n if cwd:=os.Getenv("JSGO_CAPTURED_ACTIVATION_CWD");cwd!="" {previous,e:=os.Getwd();if e!=nil{t.Fatal(e)};if e=os.Chdir(cwd);e!=nil{t.Fatal(e)};defer func(){if e:=os.Chdir(previous);e!=nil{t.Error(e)}}()}')
 harness=patch(harness,'if err=os.MkdirAll(resultDir,0700);err!=nil{t.Fatal(err)}','counts["gather"]=nextActivationGatherSnapshot()\n counts["lazy_use"]=nextActivationUseSnapshot()\n if err=os.MkdirAll(resultDir,0700);err!=nil{t.Fatal(err)}')
 harness=patch(harness,'"status":[]byte(fmt.Sprint(status))','"status":[]byte(fmt.Sprint(status)),"exit":[]byte(fmt.Sprintln(status))')
 harness=patch(harness,'fmt.Println(string(payload))','fmt.Println(string(payload))\n if status!=0 {t.Fatalf("actual stock CLI failed: %d\\n%s",status,stderr.String())}')
 mode=package/'native_array_recipe_mode.go';text=mode.read_text();sources[str(mode)]=sha(text.encode())
 needle='func newArrayRecipeValuesMode(p *TypeInferencePass, root *rhino.Node) *arrayRecipeValuesMode {'
 text=patch(text,needle,needle+'\n if capturedValidationActivationProbe!=nil {p.arrayRecipeProbe=capturedValidationActivationProbe} // numeric observation only')
 lazy=package/'fsiv_use_lazy.go';lazytext=lazy.read_text();sources[str(lazy)]=sha(lazytext.encode())
 lazytext=patch(lazytext,'f := NewFlowSensitiveInlineVariables(compiler)','f := NewFlowSensitiveInlineVariables(compiler)\n f.nativeGatherProbe=&nativeFSIVGatherProbe{}\n f.useCardinalityProbe=&nativeUseCardinalityStats{} // numeric observation only')
 flow=package/'flow_sensitive_inline_variables.go';flowtext=flow.read_text();sources[str(flow)]=sha(flowtext.encode())
 needle='func (f *FlowSensitiveInlineVariables) Process(externs *rhino.Node, root *rhino.Node) {'
 flowtext=patch(flowtext,needle,needle+'\n defer nextActivationGatherRetire(f.nativeGatherProbe,f.useCardinalityProbe)')
 for original,name,content in [(mode,'native_array_recipe_mode.go',text),(lazy,'fsiv_use_lazy.go',lazytext),(flow,'flow_sensitive_inline_variables.go',flowtext),(package/'captured_gather_activation_diagnostic.go','captured_gather_activation_diagnostic.go',HELPER),(package/'captured_validation_activation_overlay_test.go','captured_validation_activation_overlay_test.go',harness)]:
  target=out/name
  content=subprocess.check_output([str(a.gofmt)],input=content.encode()).decode()
  generated[name]=write(target,content)
  if str(original) in replacements:raise SystemExit('diagnostic hook conflicts with base overlay: '+str(original))
  replacements[str(original)]=str(target)
 sys.dont_write_bytecode=True
 bench_path=root/'tools/bench/bench.py';sources[str(bench_path)]=sha(bench_path.read_bytes())
 sys.path.insert(0,str(bench_path.parent))
 spec=importlib.util.spec_from_file_location('captured_gather_bench_workspace',bench_path);bench=importlib.util.module_from_spec(spec);spec.loader.exec_module(bench)
 flags={'JSGO_EXPERIMENT_ARRAY_UNKNOWN_RECIPE':'1','JSGO_EXPERIMENT_ARRAY_SHARED_RESOLVED':'1','JSGO_EXPERIMENT_ARRAY_CAPTURED_VALIDATION':'1','JSGO_EXPERIMENT_FSIV_NATIVE_GATHER':'1','JSGO_EXPERIMENT_FSIV_USE_CARDINALITY':'1','JSGO_EXPERIMENT_FSIV_USE_PROJECTION':'1','JSGO_EXPERIMENT_FSIV_USE_SCALAR':'1','JSGO_EXPERIMENT_PARSER_ASCII_SOURCE':'1' if a.parser_ascii else '0','JSGO_EXPERIMENT_PARALLEL_COMMONJS':'0','JSGO_EXPERIMENT_COMMONJS_EXACT_TRUE_GUARD':'0','JSGO_EXPERIMENT_COMMONJS_RUN_POOL':'0'}
 cases=[];commands=[]
 for task in TASKS:
  jobs_path=a.reference/task/'jobs.json';jobs_raw=jobs_path.read_bytes();sources[str(jobs_path.resolve())]=sha(jobs_raw);jobs=json.loads(jobs_raw)
  artifact_path=a.reference/task/'java-cold.json';artifact_raw=artifact_path.read_bytes();sources[str(artifact_path.resolve())]=sha(artifact_raw);artifact_record=json.loads(artifact_raw)
  workspace=out/'cases'/task/'threads-2';bench.make_workspace(str(workspace),str(a.cache.resolve()))
  for index,original_args in enumerate(jobs):
   args=[];skip=False
   for value in original_args:
    if skip:skip=False;continue
    if value=='--num_parallel_threads':skip=True;continue
    if value.startswith('--num_parallel_threads='):continue
    args.append(value)
   args.append('--num_parallel_threads=2')
   args_path=workspace/f'args-{index}.json';result=workspace/f'artifacts-{index}';result.mkdir()
   generated[str(args_path.relative_to(out))]=write(args_path,json.dumps(args,indent=2)+'\n')
   missing=[]
   for n,value in enumerate(args[:-1]):
    if value in ('--js','--externs') and not (workspace/args[n+1]).is_file():missing.append(args[n+1])
   if missing:raise SystemExit('missing pinned inputs: '+repr(missing[:5]))
   case={'task':task,'job':index,'workspace':str(workspace),'args_json':str(args_path),'output':str(result),'baseline_jobs':str(jobs_path.resolve()),'baseline_args_sha256':sha(json.dumps(original_args,separators=(',',':')).encode()),'args_sha256':sha(json.dumps(args,separators=(',',':')).encode()),'compiler_threads':2,'workspace_symlinks':{str(x.relative_to(workspace)):str(x.resolve()) for x in workspace.rglob('*') if x.is_symlink()}}
   case['baseline_artifact_record']=str(artifact_path.resolve())
   case['expected_digests']=artifact_record['runs'][0]['digests'][index]
   cases.append(case)
   env=dict(flags,JSGO_CAPTURED_ACTIVATION_ARGS=str(args_path),JSGO_CAPTURED_ACTIVATION_OUT=str(result),JSGO_CAPTURED_ACTIVATION_CWD=str(workspace))
   commands.append({'cwd':str(workspace),'argv':['taskset','-c','0,1',str(a.binary.resolve()),'-test.run=^TestCapturedValidationRealCLIActivation$','-test.v'],'env':env,'unset_environment':['GOGC','GOMAXPROCS','GOMEMLIMIT','GODEBUG'],'log':str(workspace/f'activation-{index}.log')})
 overlay={'Replace':replacements};generated['overlay.json']=write(out/'overlay.json',json.dumps(overlay,indent=2)+'\n')
 build={'cwd':str(root),'argv':[str(a.gofmt.parent/'go'),'test','-p=1','-pgo=off','-buildvcs=false','-overlay='+str(out/'overlay.json'),'-c','-o',str(a.binary.resolve()),'./internal/jscomp'],'build_only':True,'diagnostic_only':True,'not_for_race_or_timing':True}
 generated['build-command.json']=write(out/'build-command.json',json.dumps(build,indent=2)+'\n')
 for key,filename in [('cases','cases.json'),('commands','run-commands.json')]:generated[filename]=write(out/filename,json.dumps(cases if key=='cases' else commands,indent=2)+'\n')
 manifest={'root':str(root),'source_commit':commit,'base_overlay':str(a.base_overlay.resolve()),'base_overlay_sha256':sha(a.base_overlay.read_bytes()),'base_targets_copied_immutable':True,'captured_generator_reused':str(a.captured_generator.resolve()),'source_sha256':sources,'generated_sha256':generated,'production_hooks':['numeric captured-validation constructor probe','numeric stock FSIV factory gather/use probe','numeric FSIV Process completion aggregation'],'ordinary_package_helper':'captured_gather_activation_diagnostic.go','run_regex':'^TestCapturedValidationRealCLIActivation$','flags':flags,'parser_ascii':a.parser_ascii,'compiler_threads':2,'cpu_affinity':[0,1],'cases':str(out/'cases.json'),'run_commands':str(out/'run-commands.json'),'timed':False,'race':False,'admission_forced':False,'warning':'Diagnostic counters/model bytes are not speed or RSS; use normal production/race binaries for gates and timed runs.'}
 manifest['gofmt']=str(a.gofmt.resolve())
 manifest['build_command']=str(out/'build-command.json')
 manifest['binary']=str(a.binary.resolve())
 manifest['generator_frozen_copy']=str(out/'prepare-frozen.py')
 write(out/'manifest.json',json.dumps(manifest,indent=2)+'\n')
 print(json.dumps({'overlay':str(out/'overlay.json'),'manifest':str(out/'manifest.json'),'cases':len(cases),'production_hooks':3,'source_commit':commit},indent=2))
if __name__=='__main__':main()
