package jscomp

import (
	"bytes"
	"crypto/sha256"
	"encoding/hex"
	"encoding/json"
	"fmt"
	"os"
	"path/filepath"
	"sync"
	"testing"

	"github.com/paullepoulpe/jsgo/internal/jutil"
)

type arraySharedResolvedDiagnosticCounts struct {
	Passes          int `json:"passes"`
	Activated       int `json:"activated"`
	Calls           int `json:"constructor_calls"`
	Seeds           int `json:"original_seeds"`
	Hits            int `json:"fresh_recipe_hits"`
	SharedHits      int `json:"shared_resolved_hits"`
	Fallbacks       int `json:"native_mutation_fallbacks"`
	FastScopeChecks int `json:"fast_scope_checks"`
	FullScopeChecks int `json:"full_scope_checks"`
	BoundaryChecks  int `json:"boundary_checks"`
}

func TestArraySharedResolvedDiagnosticPinnedTasks(t *testing.T) {
	path := os.Getenv("JSGO_ARRAY_SHARED_DIAGNOSTIC_JOBS")
	if path == "" {
		t.Skip("untimed diagnostic only; manifest not provided")
	}
	data, err := os.ReadFile(path)
	if err != nil {
		t.Fatal(err)
	}
	var manifest struct {
		Root      string `json:"root"`
		Reference string `json:"reference"`
		Tasks     []struct {
			Name string `json:"name"`
			Jobs []struct {
				Directory string            `json:"directory"`
				Args      []string          `json:"args"`
				Expected  map[string]string `json:"expected"`
			} `json:"jobs"`
		} `json:"tasks"`
	}
	if err := json.Unmarshal(data, &manifest); err != nil {
		t.Fatal(err)
	}
	for _, task := range manifest.Tasks {
		t.Run(task.Name, func(t *testing.T) {
			var totals arraySharedResolvedDiagnosticCounts
			for index, job := range task.Jobs {
				t.Run(fmt.Sprint(index), func(t *testing.T) {
					t.Chdir(job.Directory)
					for artifact := range job.Expected {
						if err := os.Remove(artifact); err != nil && !os.IsNotExist(err) {
							t.Fatal(err)
						}
					}
					var counts arraySharedResolvedDiagnosticCounts
					var mu sync.Mutex
					restore := arraySharedResolvedDiagnosticSetObserver(func(p *freshTemplateValuesProbe) {
						mu.Lock()
						defer mu.Unlock()
						counts.Passes++
						counts.Activated += p.Activated
						counts.Calls += p.Calls
						counts.Seeds += p.ArrayRecipeSeeds
						counts.Hits += p.ArrayRecipeHits
						counts.SharedHits += p.ArraySharedResolvedHits
						counts.Fallbacks += p.ArrayRecipeFallbacks
						counts.FastScopeChecks += p.FastScopeChecks
						counts.FullScopeChecks += p.FullScopeChecks
						counts.BoundaryChecks += p.BoundaryChecks
					})
					defer restore()
					var stdout, stderr bytes.Buffer
					runner := NewCommandLineRunnerWithOutAndErr(job.Args, jutil.NewPrintStream(&stdout), jutil.NewPrintStream(&stderr))
					status := runner.DoRun()
					// Only the real CLI chooses options, loaders and private admission. No
					// test-mode runner, synthetic owner or experimental flag is injected.
					for name, data := range map[string][]byte{"stdout": stdout.Bytes(), "stderr": stderr.Bytes(), "exit": []byte(fmt.Sprintln(status))} {
						if err := os.WriteFile(name, data, 0600); err != nil {
							t.Fatal(err)
						}
					}
					for name, want := range job.Expected {
						data, err := os.ReadFile(filepath.Join(job.Directory, name))
						if err != nil {
							t.Fatal(err)
						}
						hash := sha256.Sum256(data)
						got := hex.EncodeToString(hash[:])
						if got != want {
							t.Errorf("pinned Java artifact mismatch %s got%s want%s", name, got, want)
						}
					}
					if os.Getenv("JSGO_EXPERIMENT_ARRAY_UNKNOWN_RECIPE") == "1" {
						if counts.Activated == 0 || counts.Seeds == 0 || counts.Hits == 0 {
							t.Errorf("actual native recipe did not activate: %+v", counts)
						}
						if os.Getenv("JSGO_EXPERIMENT_ARRAY_SHARED_RESOLVED") == "1" {
							if counts.SharedHits != counts.Hits {
								t.Errorf("sharing factor did not dispatch on every native hit: %+v", counts)
							}
						} else if counts.SharedHits != 0 {
							t.Errorf("disabled sharing factor activated: %+v", counts)
						}
					} else if counts.Seeds != 0 || counts.Hits != 0 || counts.SharedHits != 0 {
						t.Errorf("disabled recipe activated: %+v", counts)
					}
					encoded, err := json.MarshalIndent(counts, "", "  ")
					if err != nil {
						t.Fatal(err)
					}
					if err := os.WriteFile("array-shared-resolved-counts.json", append(encoded, 10), 0600); err != nil {
						t.Fatal(err)
					}
					mu.Lock()
					totals.Passes += counts.Passes
					totals.Activated += counts.Activated
					totals.Calls += counts.Calls
					totals.Seeds += counts.Seeds
					totals.Hits += counts.Hits
					totals.SharedHits += counts.SharedHits
					totals.Fallbacks += counts.Fallbacks
					totals.FastScopeChecks += counts.FastScopeChecks
					totals.FullScopeChecks += counts.FullScopeChecks
					totals.BoundaryChecks += counts.BoundaryChecks
					mu.Unlock()
				})
			}
			report := struct {
				Kind               string                              `json:"kind"`
				Task               string                              `json:"task"`
				ArrayRecipeFlag    string                              `json:"array_recipe_flag"`
				SharedResolvedFlag string                              `json:"shared_resolved_flag"`
				FreshVectorFlag    string                              `json:"fresh_vector_flag"`
				CLIOwnershipFlag   string                              `json:"cli_ownership_flag"`
				Counts             arraySharedResolvedDiagnosticCounts `json:"counts"`
			}{"untimed-array-shared-resolved-dispatch", task.Name, os.Getenv("JSGO_EXPERIMENT_ARRAY_UNKNOWN_RECIPE"), os.Getenv("JSGO_EXPERIMENT_ARRAY_SHARED_RESOLVED"), os.Getenv("JSGO_EXPERIMENT_FRESH_TEMPLATE_VALUES"), os.Getenv("JSGO_EXPERIMENT_CLI_SOURCE_LOCK"), totals}
			encoded, err := json.Marshal(report)
			if err != nil {
				t.Fatal(err)
			}
			t.Log("ARRAY_SHARED_RESOLVED_DIAGNOSTIC " + string(encoded))
		})
	}
}
