package jscomp

import "sync"

// Added only by the untimed overlay. No observer is installed in ordinary
// focused tests; the dedicated diagnostic test owns each collector.
var arraySharedResolvedDiagnosticMu sync.Mutex
var arraySharedResolvedDiagnosticObserver func(*freshTemplateValuesProbe)

func arraySharedResolvedDiagnosticSetObserver(observer func(*freshTemplateValuesProbe)) func() {
	arraySharedResolvedDiagnosticMu.Lock()
	previous := arraySharedResolvedDiagnosticObserver
	arraySharedResolvedDiagnosticObserver = observer
	arraySharedResolvedDiagnosticMu.Unlock()
	return func() {
		arraySharedResolvedDiagnosticMu.Lock()
		arraySharedResolvedDiagnosticObserver = previous
		arraySharedResolvedDiagnosticMu.Unlock()
	}
}

func arraySharedResolvedDiagnosticAttach(p *TypeInferencePass) func() {
	arraySharedResolvedDiagnosticMu.Lock()
	observer := arraySharedResolvedDiagnosticObserver
	arraySharedResolvedDiagnosticMu.Unlock()
	if observer == nil || p.freshTemplateProbe != nil {
		return nil
	}
	previous := p.freshTemplateProbe
	probe := &freshTemplateValuesProbe{}
	p.freshTemplateProbe = probe
	// Registered before the factory's original cleanup defer: its private
	// mode/creator window is restored before this observer runs, including panic.
	return func() { p.freshTemplateProbe = previous; observer(probe) }
}
