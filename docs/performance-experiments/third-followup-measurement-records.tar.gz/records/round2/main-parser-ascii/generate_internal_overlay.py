from pathlib import Path
import json,re
root=Path('/workspace/jsgo-main-parser-ascii/internal/parsing')
out=Path('/tmp/jsgo-main-ascii-legacy-overlay');out.mkdir(exist_ok=True)
replace={};rewritten=[]
for p in root.glob('*_test.go'):
 source=p.read_text()
 if re.search(r'^package parsing_test\b',source,re.M) or p.name=='parser_owned_ascii_test.go':continue
 modified=source.replace('ParserRunner_Parse(', 'ownedASCIILegacyRunner(')
 if p.name=='parsing_util_test.go':
  modified=modified.replace('import (','import (\n "os"\n "sync/atomic"',1)
  modified+='''
// Test-only legacy dispatch overlay, never linked into product builds.
var ownedASCIILegacyCounters struct { queries,backed,bytes atomic.Int64 }
func ownedASCIILegacyRunner(file rhino.StaticSourceFile,source string,config *Config,reporter rhino.ErrorReporter)*ParserRunner_ParseResult {
 ownedASCIILegacyCounters.queries.Add(1)
 if os.Getenv("JSGO_TEST_OWNED_ASCII")=="1" {
  var observation OwnedASCIIParseObservation
  result:=ParserRunner_ParseOwnedASCII(file,source,config,reporter,&observation)
  if observation.ASCIIBacked {ownedASCIILegacyCounters.backed.Add(1);ownedASCIILegacyCounters.bytes.Add(int64(observation.SourceBytes))}
  return result
 }
 return ParserRunner_Parse(file,source,config,reporter)
}
func TestMain(m *testing.M) {
 status:=m.Run()
 fmt.Printf("ASCII_LEGACY_DISPATCH queries=%d backed=%d bytes=%d\\n",ownedASCIILegacyCounters.queries.Load(),ownedASCIILegacyCounters.backed.Load(),ownedASCIILegacyCounters.bytes.Load())
 if os.Getenv("JSGO_TEST_OWNED_ASCII")=="1"&&ownedASCIILegacyCounters.backed.Load()==0 {fmt.Println("ASCII legacy test overlay failed actual backing activation");status=2}
 os.Exit(status)
}
'''
 if modified!=source:
  target=out/p.name;target.write_text(modified);replace[str(p)]=str(target);rewritten.append(p.name)
(out/'overlay.json').write_text(json.dumps({'Replace':replace},indent=2))
files=sorted(p.name for p in root.glob('*.go') if not re.search(r'^package parsing_test\b',p.read_text(),re.M))
(out/'files.json').write_text(json.dumps(files))
print('Rewritten:',', '.join(rewritten));print('Excluded:',', '.join(p.name for p in root.glob('*.go') if p.name not in files))
