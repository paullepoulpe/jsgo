#!/usr/bin/env python3
"""Plain reduced jscomp tests: untouched production, original test/helper declarations."""
import argparse, hashlib, json, re, subprocess
from pathlib import Path
parser=argparse.ArgumentParser()
parser.add_argument('--root',type=Path,default=Path('/workspace/jsgo-main-traversal-stack4'))
args=parser.parse_args()
root=args.root.resolve(); out=Path(__file__).resolve().parent; package=root/'internal/jscomp'
if (out/'overlay.json').exists(): raise SystemExit('Refusing to overwrite frozen overlay')
commit=subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip()
changed=subprocess.check_output(['git','diff','--name-only','ff06ac15',commit,'--','internal/jscomp/*_test.go'],cwd=root,text=True).splitlines()
keep={Path(name).name for name in changed}|{'truth_test.go','reaching_use_def_tester_test.go'}
for name in keep:
 if not (package/name).is_file(): raise SystemExit('Missing test: '+name)
stub=out/'excluded_test.go'; stub.write_text('package jscomp\n')
source_path=package/'deps_module_loader_test.go'; source=source_path.read_text(); declarations={}
for name in ['jsaMlInputs','jsaMlInput','jsaMlPACKAGE_JSON_MAIN_ENTRIES','jsaMap']:
 match=re.search(r'^func '+name+r'\([\s\S]*?^}\n',source,re.M)
 if match is None: raise SystemExit('Missing helper: '+name)
 declarations[name]=match.group()
helper=out/'module_helpers_test.go'
helper.write_text(source[:source.index('package jscomp')]+'package jscomp\n\nimport "github.com/paullepoulpe/jsgo/internal/jutil"\n\n'+'\n'.join(declarations.values()))
replacements={str(p):str(stub) for p in sorted(package.glob('*_test.go')) if p.name not in keep}
replacements[str(source_path)]=str(helper)
# Copy only the exact original declarations needed by the retained new traversal
# tests. No production source or original helper behavior is changed.
traversal_source_path=package/'node_traversal_test.go'
traversal_source=traversal_source_path.read_text()
callback_prefix=traversal_source[traversal_source.index('// nodeTraversalTestCallback is'):traversal_source.index('// nodeTraversalTest_ErrorManager is')]
assert len(re.findall(r'^type nodeTraversalTest(?:Scoped)?Callback struct',callback_prefix,re.M))==2
assert len(re.findall(r'^func \(c \*nodeTraversalTest(?:Scoped)?Callback\)',callback_prefix,re.M))==4
scope_source_path=package/'scope_test_helpers_test.go'
scope_source=scope_source_path.read_text()
match=re.search(r'^func scopeTestParse\([\s\S]*?^}\n',scope_source,re.M)
if match is None: raise SystemExit('Missing scopeTestParse')
scope_parse=match.group()
traversal_helper=out/'traversal_helpers_test.go'
traversal_helper.write_text('package jscomp\n\nimport (\n "testing"\n "github.com/paullepoulpe/jsgo/internal/rhino"\n)\n\n'+callback_prefix+scope_parse)
replacements[str(scope_source_path)]=str(traversal_helper)
assert all(Path(p).name.endswith('_test.go') for p in replacements)
for p in replacements:
 if Path(p).name in keep: raise SystemExit('Kept test replaced: '+p)
(out/'overlay.json').write_text(json.dumps({'Replace':replacements},indent=2)+'\n')
sha=lambda data:hashlib.sha256(data).hexdigest()
manifest={'root':str(root),'source_commit':commit,'base_commit':'ff06ac15','package_import_path':'github.com/paullepoulpe/jsgo/internal/jscomp','production_replacements':0,'test_replacements':len(replacements),'all_replacement_keys_are_test_go':True,'retained_original_tests':sorted(keep),'retained_test_sha256':{n:sha((package/n).read_bytes()) for n in sorted(keep)},'module_helper_source_sha256':sha(source.encode()),'module_helper_declarations_sha256':{n:sha(s.encode()) for n,s in declarations.items()},'module_helpers_copied_verbatim':True,'reaching_helpers_retained_as_original_entire_utility_file':True}
manifest['traversal_helpers_copied_verbatim']=True
manifest['traversal_helper_source_sha256']={'node_traversal_test.go':sha(traversal_source.encode()),'scope_test_helpers_test.go':sha(scope_source.encode())}
manifest['traversal_helper_declarations_sha256']={'callback_contiguous_prefix':sha(callback_prefix.encode()),'scopeTestParse':sha(scope_parse.encode())}
manifest['traversal_helper_output_sha256']=sha(traversal_helper.read_bytes())
manifest['previous_frozen_overlay_not_modified']='/workspace/jsgo-results/round2/focused-latest-main-stack4-overlay'
(out/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
(out/'README.md').write_text('Plain focused overlay for latest-main compiler designs.\n\nEvery production source remains unchanged. All new jscomp tests since ff06ac15 are retained verbatim, together with original ReachingUseDefTester and Truth utility files. Four original ModuleLoader helper declarations are copied verbatim into an overlay-only test file, replacing only their original test file. The exact original scopeTestParse function and contiguous nodeTraversalTestCallback/nodeTraversalTestScopedCallback type+four-method prefix are copied verbatim into another overlay-only helper replacing scope_test_helpers_test.go. All other original jscomp test files become a package-only stub. The original package/import path remains unchanged. Manifest records source and declaration SHA-256 provenance. No diagnostic hooks, counters, synchronization, admission changes, or mocks are injected.\n\nGenerate with `python3 prepare.py --root /path/to/worktree`; do not regenerate files while a build uses this overlay.\n')
print(json.dumps({'source_commit':commit,'production_replacements':0,'retained_tests':len(keep),'test_replacements':len(replacements),'manifest_sha256':sha((out/'manifest.json').read_bytes()),'overlay_sha256':sha((out/'overlay.json').read_bytes())},indent=2))
