import os,json,subprocess,sys
from pathlib import Path
r=Path('/workspace/jsgo-results/round2')
flags={k:'1' for k in ['JSGO_EXPERIMENT_ARRAY_UNKNOWN_RECIPE','JSGO_EXPERIMENT_ARRAY_SHARED_RESOLVED','JSGO_EXPERIMENT_PARSER_ASCII_SOURCE','JSGO_EXPERIMENT_PARALLEL_COMMONJS','JSGO_EXPERIMENT_COMMONJS_EXACT_TRUE_GUARD','JSGO_EXPERIMENT_COMMONJS_RUN_POOL','JSGO_EXPERIMENT_FSIV_USE_CARDINALITY','JSGO_EXPERIMENT_FSIV_USE_PROJECTION','JSGO_EXPERIMENT_FSIV_USE_SCALAR']}
env={k:v for k,v in os.environ.items() if not k.startswith('JSGO_EXPERIMENT_') and k not in ['GOGC','GOMEMLIMIT','GODEBUG','GOMAXPROCS']}
env['PATH']='/workspace/toolchains/go1.27.2/bin:/workspace/toolchains/bin:'+env['PATH']
commands=[]
for i in range(5):
 case=r/f'latest-main-commonjs-ascii-activation/cases/case-{i}.json'
 cmd=['taskset','-c','0,1',str(r/'bin/jscomp-latest-main-composed-activation.test'),'-test.run=^TestParallelCommonJSMainBenchmarkActivation$','-test.v']
 commands.append({'command':cmd,'case':str(case),'env':flags})
 with (r/f'latest-main-composed-activation-{i}.log').open('w') as f:
  subprocess.run(cmd,env=env|flags|{'JSGO_COMMONJS_ACTIVATION_CASE':str(case)},cwd='/workspace/jsgo-latest-main-designs/internal/jscomp',stdout=f,stderr=subprocess.STDOUT,check=True)
 report=json.loads(Path(json.loads(case.read_text())['report']).read_text())
 print('ACTIVATION',report['task'],report['exit'],json.dumps(report.get('extras',{})),flush=True)
(r/'latest-main-composed-activation-run-commands.json').write_text(json.dumps(commands,indent=2)+'\n')
cmd=['/usr/bin/taskset','-c','0,1','/usr/bin/python3','-I','-u','/workspace/jsgo-structural-bitset-template/tools/bench/experiments.py','--reference',str(r/'baseline'),'--out',str(r/'latest-main-design-screen'),'--runs','2','--cache','/workspace/jsgo/.cache']
for label,binary,settings in [('stock_main','jsgo-latest-main-standard',{}),('control16','jsgo-latest-main-designs-standard',{}),('compact4','jsgo-latest-main-stack4-standard',{}),('compound4','jsgo-latest-main-stack4-standard',flags)]:
 cmd += ['--variant',f'{label}={r}/bin/{binary}','--variant-env',label+'='+json.dumps(settings)]
(r/'latest-main-design-screen-command.json').write_text(json.dumps(cmd,indent=2)+'\n')
with (r/'latest-main-design-screen.log').open('w') as f:
 subprocess.run(cmd,env=env,cwd='/workspace/jsgo-structural-bitset-template',stdout=f,stderr=subprocess.STDOUT,check=True)
print('SCREEN COMPLETE',flush=True)
