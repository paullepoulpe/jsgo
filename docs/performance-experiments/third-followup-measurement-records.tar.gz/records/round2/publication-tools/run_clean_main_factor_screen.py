import json,os,subprocess
from pathlib import Path
r=Path('/workspace/jsgo-results/round2')
env={k:v for k,v in os.environ.items() if not k.startswith('JSGO_EXPERIMENT_') and k not in ['GOGC','GOMEMLIMIT','GODEBUG','GOMAXPROCS']}
env['PATH']='/workspace/toolchains/go1.27.2/bin:/workspace/toolchains/bin:'+env['PATH']
parser={'JSGO_EXPERIMENT_PARSER_ASCII_SOURCE':'1'}
recipe={'JSGO_EXPERIMENT_ARRAY_UNKNOWN_RECIPE':'1','JSGO_EXPERIMENT_ARRAY_SHARED_RESOLVED':'1'}
fsiv={k:'1' for k in ['JSGO_EXPERIMENT_FSIV_USE_CARDINALITY','JSGO_EXPERIMENT_FSIV_USE_PROJECTION','JSGO_EXPERIMENT_FSIV_USE_SCALAR']}
cmd=['taskset','-c','0,1','python3','-I','-u','/workspace/jsgo-structural-bitset-template/tools/bench/experiments.py','--reference',str(r/'baseline'),'--out',str(r/'latest-main-factor-screen'),'--runs','2','--seed','20261019','--cache','/workspace/jsgo/.cache']
for label,flags in [('control4',{}),('parser4',parser),('recipe_shared4',recipe),('use_scalar4',fsiv),('compound4',parser|recipe|fsiv)]:
 cmd += ['--variant',f'{label}={r}/bin/jsgo-latest-main-stack4-standard','--variant-env',label+'='+json.dumps(flags)]
(r/'latest-main-factor-screen-command.json').write_text(json.dumps(cmd,indent=2)+'\n')
with (r/'latest-main-factor-screen.log').open('w') as f:
 subprocess.run(cmd,env=env,stdout=f,stderr=subprocess.STDOUT,cwd='/workspace/jsgo-structural-bitset-template',check=True)
print('FACTOR SCREEN COMPLETE')
