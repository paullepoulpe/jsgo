#!/usr/bin/env python3
"""Plain reduced jscomp tests: untouched production, original test/helper declarations."""
import argparse, hashlib, json, re, subprocess
from pathlib import Path
parser=argparse.ArgumentParser()
parser.add_argument('--root',type=Path,default=Path('/workspace/jsgo-latest-main-designs'))
args=parser.parse_args()
root=args.root.resolve(); out=Path(__file__).resolve().parent; package=root/'internal/jscomp'
commit=subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip()
changed=subprocess.check_output(['git','diff','--name-only','ff06ac15',commit,'--','internal/jscomp/*_test.go'],cwd=root,text=True).splitlines()
keep={Path(name).name for name in changed}|{'truth_test.go','reaching_use_def_tester_test.go'}
for name in keep:
 if not (package/name).is_file(): raise SystemExit('Missing test: '+name)
stub=out/'excluded_test.go'; stub.write_text('package jscomp\n')
source_path=package/'deps_module_loader_test.go'; source=source_path.read_text(); declarations={}
for name in ['jsaMlInputs','jsaMlInput','jsaMlPACKAGE_JSON_MAIN_ENTRIES','jsaMap']:
 match=re.search(r'^func '+name+r'\([\s\S]*?^}\n',source,re.M)
 if match is None: raise SystemExit('Missing helper: '+name)
 declarations[name]=match.group()
helper=out/'module_helpers_test.go'
helper.write_text(source[:source.index('package jscomp')]+'package jscomp\n\nimport "github.com/paullepoulpe/jsgo/internal/jutil"\n\n'+'\n'.join(declarations.values()))
replacements={str(p):str(stub) for p in sorted(package.glob('*_test.go')) if p.name not in keep}
replacements[str(source_path)]=str(helper)
assert all(Path(p).name.endswith('_test.go') for p in replacements)
for p in replacements:
 if Path(p).name in keep: raise SystemExit('Kept test replaced: '+p)
(out/'overlay.json').write_text(json.dumps({'Replace':replacements},indent=2)+'\n')
sha=lambda data:hashlib.sha256(data).hexdigest()
manifest={'root':str(root),'source_commit':commit,'base_commit':'ff06ac15','package_import_path':'github.com/paullepoulpe/jsgo/internal/jscomp','production_replacements':0,'test_replacements':len(replacements),'all_replacement_keys_are_test_go':True,'retained_original_tests':sorted(keep),'retained_test_sha256':{n:sha((package/n).read_bytes()) for n in sorted(keep)},'module_helper_source_sha256':sha(source.encode()),'module_helper_declarations_sha256':{n:sha(s.encode()) for n,s in declarations.items()},'module_helpers_copied_verbatim':True,'reaching_helpers_retained_as_original_entire_utility_file':True}
(out/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
(out/'README.md').write_text('Plain focused overlay for latest-main compiler designs.\n\nEvery production source remains unchanged. All new jscomp tests since ff06ac15 are retained verbatim, together with original ReachingUseDefTester and Truth utility files. Four original ModuleLoader helper declarations are copied verbatim into an overlay-only test file, replacing only their original test file. All other original jscomp test files become a package-only stub. The original package/import path remains unchanged. Manifest records source and declaration SHA-256 provenance. No diagnostic hooks, counters, synchronization, admission changes, or mocks are injected.\n\nGenerate with `python3 prepare.py --root /path/to/worktree`; do not regenerate files while a build uses this overlay.\n')
print(json.dumps({'source_commit':commit,'production_replacements':0,'retained_tests':len(keep),'test_replacements':len(replacements),'manifest_sha256':sha((out/'manifest.json').read_bytes()),'overlay_sha256':sha((out/'overlay.json').read_bytes())},indent=2))
