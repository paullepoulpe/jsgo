#!/usr/bin/env python3
"""Untimed only, root-owned scheduling. Exact pinned Java artifact gates required."""
import hashlib,json,os,subprocess,sys
from pathlib import Path
OUT=Path(__file__).resolve().parent
M=json.loads((OUT/'manifest.json').read_text());SRC=Path(M['source_root']);BIN=OUT/'bin/jsgo-depth-diagnostic';REF=OUT.parent/'baseline'
sys.dont_write_bytecode=True;sys.path.insert(0,str(SRC/'tools/bench'));import bench
h=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def frozen():
 assert subprocess.check_output(['git','-C',str(SRC),'rev-parse','HEAD'],text=True).strip()==M['source_commit']
 for f in M['files']:
  assert h(Path(f['replacement']))==f['replacement_sha256']
  if f['original_sha256']:assert h(Path(f['original']))==f['original_sha256']
 assert h(Path(M['overlay']))==M['overlay_sha256']
 assert h(SRC/'cmd/jsgo/default.pgo')==M['pgo_sha256']
frozen();runroot=OUT/'runs';runroot.mkdir()
env={k:v for k,v in os.environ.items() if not k.startswith('JSGO') and k not in {'GOGC','GOMEMLIMIT','GOMAXPROCS','GODEBUG'}};env['LC_ALL']='C.UTF-8'
report={'kind':'untimed traversal depth histogram','source':M['source_commit'],'binary_sha256':h(BIN),'runtime_settings':'default, all experiments off','jobs':[]}
for task in ['typed-app','bundle','downlevel-whitespace','downlevel-simple','checks-only']:
 work=runroot/task;jobs=json.loads((REF/task/'jobs.json').read_text());reference=json.loads((REF/task/'java-cold.json').read_text())['runs'][0]
 assert len(jobs)==1 and reference['exits']==[0]
 bench.make_workspace(str(work),'/workspace/jsgo/.cache');frozen();jobenv=dict(env,JSGO_TRAVERSAL_DEPTH_DIAGNOSTIC=str(work/'depth.json'))
 with (work/'stdout').open('wb')as stdout,(work/'stderr').open('wb')as stderr:
  status=subprocess.run(['taskset','-c','0,1',str(BIN),*jobs[0]],cwd=work,env=jobenv,stdout=stdout,stderr=stderr,timeout=300).returncode
 (work/'exit').write_text(str(status)+'\n');actual={k:h(work/k)if(work/k).exists()else None for k in reference['digests'][0]};assert status==0 and actual==reference['digests'][0],('artifact gate',task)
 counts=json.loads((work/'depth.json').read_text())['Callbacks'];total=0;hist=[0]*257
 for kind,row in counts.items():
  assert sum(row['MaxLiveDepth'])==row['Constructors'];total+=row['Constructors'];hist=[a+b for a,b in zip(hist,row['MaxLiveDepth'])]
 assert total>0
 result={'task':task,'artifact_gates':'all pinned Java digests match','constructors':total,'max_live_depth_histogram':hist,'would_exceed_capacity':{str(n):sum(hist[n+1:])for n in (4,8,16)},'callback_histogram_sha256':h(work/'depth.json')}
 report['jobs'].append(result);(OUT/'partial-summary.json').write_text(json.dumps(report,indent=2)+'\n');print(task,'MATCH constructors',total,'overflow',result['would_exceed_capacity'],flush=True)
(OUT/'summary.json').write_text(json.dumps(report,indent=2)+'\n')
