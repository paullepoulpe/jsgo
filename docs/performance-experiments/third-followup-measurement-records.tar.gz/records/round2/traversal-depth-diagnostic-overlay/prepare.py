#!/usr/bin/env python3
"""Prepare immutable diagnostic-only max-live-scope histograms, never a timed binary."""
import hashlib,json,subprocess
from pathlib import Path
SRC=Path('/workspace/jsgo-latest-main-designs');OUT=Path(__file__).resolve().parent;GEN=OUT/'generated'
assert subprocess.check_output(['git','-C',str(SRC),'rev-parse','HEAD'],text=True).strip()=='a3a2f8f3293b293571fb835f6234f7deffc2fac3'
GEN.mkdir()
original=SRC/'internal/jscomp/node_traversal.go';s=original.read_text()
old='mayContainSyntheticBlocks                      bool';assert s.count(old)==1
s=s.replace(old,old+'\n\tdiagnosticMaxScopeDepth uint32 // diagnostic-only, occupies existing alignment padding')
old='\treturn t\n}\n\n// Java: NodeTraversal.throwUnexpectedException';assert s.count(old)==1
s=s.replace(old,'\trecordNodeTraversalDepthConstruction(t)\n'+old)
for old in ['\tt.scopes = append(t.scopes, scopeStackEntry{node: node})','\tt.scopes = append(t.scopes, scopeStackEntry{node: root, scope: s})']:
 assert s.count(old)==1;s=s.replace(old,old+'\n\trecordNodeTraversalDepthPush(t)')
(GEN/'node_traversal.go').write_text(s)
(GEN/'node_traversal_depth_diagnostic.go').write_text('''package jscomp

import (
 "encoding/json"
 "os"
 "reflect"
 "sync"
)

// Untimed overlay only. Global keys are immutable Go type descriptors, never
// traversal/AST/scope/callback objects. Each traversal carries only its max depth.
var nodeTraversalDepthDiagnostic = struct {
 sync.Mutex
 counts map[reflect.Type]*nodeTraversalDepthCounts
}{counts: make(map[reflect.Type]*nodeTraversalDepthCounts)}
type nodeTraversalDepthCounts struct {
 Constructors uint64
 MaxLiveDepth [257]uint64 // 256 aggregates every depth >=256
}
func recordNodeTraversalDepthConstruction(t *NodeTraversal) {
 key:=reflect.TypeOf(t.callback)
 nodeTraversalDepthDiagnostic.Lock()
 c:=nodeTraversalDepthDiagnostic.counts[key]
 if c==nil { c=&nodeTraversalDepthCounts{};nodeTraversalDepthDiagnostic.counts[key]=c }
 c.Constructors++;c.MaxLiveDepth[0]++
 nodeTraversalDepthDiagnostic.Unlock()
}
func recordNodeTraversalDepthPush(t *NodeTraversal) {
 depth:=len(t.scopes)
 if depth>256 {depth=256}
 if uint32(depth)<=t.diagnosticMaxScopeDepth {return}
 key:=reflect.TypeOf(t.callback)
 nodeTraversalDepthDiagnostic.Lock()
 c:=nodeTraversalDepthDiagnostic.counts[key]
 c.MaxLiveDepth[t.diagnosticMaxScopeDepth]--
 c.MaxLiveDepth[depth]++
 nodeTraversalDepthDiagnostic.Unlock()
 t.diagnosticMaxScopeDepth=uint32(depth)
}
func WriteNodeTraversalDepthDiagnostic(path string) {
 if path=="" {return}
 snapshot:=make(map[string]nodeTraversalDepthCounts)
 nodeTraversalDepthDiagnostic.Lock()
 for key,value:=range nodeTraversalDepthDiagnostic.counts {snapshot[key.String()]=*value}
 nodeTraversalDepthDiagnostic.Unlock()
 payload,err:=json.MarshalIndent(struct {
  Kind string
  Caveat string
  Callbacks map[string]nodeTraversalDepthCounts
 }{"untimed max-live traversal scope depth histogram","instrumented all pushes, not a performance/RSS measurement; depth256 means >=256; callback keys retain type descriptors only",snapshot},"","  ")
 if err!=nil {panic(err)}
 if err:=os.WriteFile(path,append(payload,'\\n'),0600);err!=nil {panic(err)}
}
''')
main=Path('/workspace/jsgo-results/round2/latest-main-profiles-v2/overlay/main.go').read_text()
needle='\t\tdiagnosticFinished = true\n';assert main.count(needle)==1
main=main.replace(needle,needle+'\t\tjscomp.WriteNodeTraversalDepthDiagnostic(os.Getenv("JSGO_TRAVERSAL_DEPTH_DIAGNOSTIC"))\n')
(GEN/'main.go').write_text(main)
subprocess.run(['/workspace/toolchains/go1.27.2/bin/gofmt','-w',*[str(x)for x in GEN.glob('*.go')]],check=True)
replacement={str(original):str(GEN/'node_traversal.go'),str(SRC/'internal/jscomp/node_traversal_depth_diagnostic.go'):str(GEN/'node_traversal_depth_diagnostic.go'),str(SRC/'cmd/jsgo/main.go'):str(GEN/'main.go')}
ov=OUT/'overlay.json';ov.write_text(json.dumps({'Replace':replacement},indent=2)+'\n')
h=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
manifest={'source_root':str(SRC),'source_commit':'a3a2f8f3293b293571fb835f6234f7deffc2fac3','diagnostic_only':True,'runtime_env':'JSGO_TRAVERSAL_DEPTH_DIAGNOSTIC=/unique/task/depth.json; default runtime GC/settings; flags selected explicitly by root','changes':'one uint32 in unused alignment padding, counters at constructor and both pushes, diagnostic-only typed global histogram by reflect.Type, main exit wrapper to dump before original success exit','nonretention':'global keys are reflect.Type descriptors and pointer-free uint64 histograms; no Node/Scope/traversal/callback instances retained','overlay':str(ov),'overlay_sha256':h(ov),'files':[{'original':a,'original_sha256':h(Path(a)) if Path(a).exists() else None,'replacement':b,'replacement_sha256':h(Path(b))}for a,b in replacement.items()],'pgo_sha256':h(SRC/'cmd/jsgo/default.pgo'),'caveat':'never benchmark this binary; histograms count final maximum live stack length per traversal, not total pushes or scope creations; max>=256 is aggregated; constructor including never-used traversals appears in depth0'}
(OUT/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
print(json.dumps({'overlay':str(ov),'files':len(replacement),'source':manifest['source_commit']},indent=2))
