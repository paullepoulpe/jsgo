// Command jsgo is the Go port of Closure Compiler's command-line front end:
// `jsgo <args>` behaves like `java -jar closure-compiler.jar <args>`
// (CommandLineRunner.main).
package main

import (
	"os"
	"runtime/pprof"

	"github.com/paullepoulpe/jsgo/internal/jscomp"
	"github.com/paullepoulpe/jsgo/internal/jutil"
)

func main() {
	// Untimed diagnostic overlay only. Original Run always exits, including
	// success, so finalize before its original exit receiver. Library sources
	// and the runner execution/catch schedule remain unchanged.
	var diagnosticCPU *os.File
	if path := os.Getenv("JSGO_MAIN_CPU_PROFILE"); path != "" {
		file, err := os.Create(path)
		if err != nil {
			panic(err)
		}
		if err := pprof.StartCPUProfile(file); err != nil {
			file.Close()
			panic(err)
		}
		diagnosticCPU = file
	}
	diagnosticFinished := false
	finishDiagnostic := func() {
		if diagnosticFinished {
			return
		}
		diagnosticFinished = true
		jscomp.WriteNodeTraversalDepthDiagnostic(os.Getenv("JSGO_TRAVERSAL_DEPTH_DIAGNOSTIC"))
		if diagnosticCPU != nil {
			pprof.StopCPUProfile()
			if err := diagnosticCPU.Close(); err != nil {
				panic(err)
			}
		}
		if path := os.Getenv("JSGO_MAIN_ALLOCS_PROFILE"); path != "" {
			file, err := os.Create(path)
			if err != nil {
				panic(err)
			}
			if err := pprof.Lookup("allocs").WriteTo(file, 0); err != nil {
				file.Close()
				panic(err)
			}
			if err := file.Close(); err != nil {
				panic(err)
			}
		}
	}
	// Go-only: language-adapter — the JVM's startup and shutdown around
	// CommandLineRunner.main:
	//   - System.err encodes text with native.encoding (the locale's
	//     codeset; US-ASCII in the C/POSIX locale). System.out is left as
	//     UTF-8: the runner prints only ASCII text to it and writes
	//     everything else as bytes it has already encoded.
	//   - An exception that escapes main is reported by the default
	//     uncaught-exception handler as `Exception in thread "main" ` and
	//     the stack trace on System.err, and the JVM exits with status 1.
	//   - main returning normally exits with status 0.
	jutil.System_SetErr(jutil.NewPrintStreamWithCharset(os.Stderr, jutil.System_NativeCharset()))
	defer func() {
		r := recover()
		if r == nil {
			return
		}
		t, ok := r.(jutil.Throwable)
		if !ok {
			t = jutil.AsThrowable(r)
		}
		err := jutil.System_Err()
		err.Print("Exception in thread \"main\" ")
		jutil.Throwable_PrintStackTrace(t, err)
		err.Flush()
		os.Exit(1)
	}()
	// Exact CommandLineRunner_Main startup, with its public exit receiver
	// wrapped solely to flush diagnostics before the unchanged exit routine.
	if logger := jutil.Logger_GetLogger("com.google.javascript.jscomp.PhaseOptimizer"); logger != nil {
		logger.SetLevel(jutil.Level_OFF)
	}
	runner := jscomp.NewCommandLineRunner(os.Args[1:])
	runner.SetExitCodeReceiver(func(status int) {
		if status == 0 {
			finishDiagnostic()
		}
		jscomp.AbstractCommandLineRunner_SystemExitCodeReceiver_INSTANCE.Apply(status)
	})
	if runner.ShouldRunCompiler() {
		runner.Run()
	}
	if runner.HasErrors() {
		jutil.System_Exit(-1)
	}
	finishDiagnostic()
}
