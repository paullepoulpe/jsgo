package jscomp

import (
	"encoding/json"
	"os"
	"reflect"
	"sync"
)

// Untimed overlay only. Global keys are immutable Go type descriptors, never
// traversal/AST/scope/callback objects. Each traversal carries only its max depth.
var nodeTraversalDepthDiagnostic = struct {
	sync.Mutex
	counts map[reflect.Type]*nodeTraversalDepthCounts
}{counts: make(map[reflect.Type]*nodeTraversalDepthCounts)}

type nodeTraversalDepthCounts struct {
	Constructors uint64
	MaxLiveDepth [257]uint64 // 256 aggregates every depth >=256
}

func recordNodeTraversalDepthConstruction(t *NodeTraversal) {
	key := reflect.TypeOf(t.callback)
	nodeTraversalDepthDiagnostic.Lock()
	c := nodeTraversalDepthDiagnostic.counts[key]
	if c == nil {
		c = &nodeTraversalDepthCounts{}
		nodeTraversalDepthDiagnostic.counts[key] = c
	}
	c.Constructors++
	c.MaxLiveDepth[0]++
	nodeTraversalDepthDiagnostic.Unlock()
}
func recordNodeTraversalDepthPush(t *NodeTraversal) {
	depth := len(t.scopes)
	if depth > 256 {
		depth = 256
	}
	if uint32(depth) <= t.diagnosticMaxScopeDepth {
		return
	}
	key := reflect.TypeOf(t.callback)
	nodeTraversalDepthDiagnostic.Lock()
	c := nodeTraversalDepthDiagnostic.counts[key]
	c.MaxLiveDepth[t.diagnosticMaxScopeDepth]--
	c.MaxLiveDepth[depth]++
	nodeTraversalDepthDiagnostic.Unlock()
	t.diagnosticMaxScopeDepth = uint32(depth)
}
func WriteNodeTraversalDepthDiagnostic(path string) {
	if path == "" {
		return
	}
	snapshot := make(map[string]nodeTraversalDepthCounts)
	nodeTraversalDepthDiagnostic.Lock()
	for key, value := range nodeTraversalDepthDiagnostic.counts {
		snapshot[key.String()] = *value
	}
	nodeTraversalDepthDiagnostic.Unlock()
	payload, err := json.MarshalIndent(struct {
		Kind      string
		Caveat    string
		Callbacks map[string]nodeTraversalDepthCounts
	}{"untimed max-live traversal scope depth histogram", "instrumented all pushes, not a performance/RSS measurement; depth256 means >=256; callback keys retain type descriptors only", snapshot}, "", "  ")
	if err != nil {
		panic(err)
	}
	if err := os.WriteFile(path, append(payload, '\n'), 0600); err != nil {
		panic(err)
	}
}
