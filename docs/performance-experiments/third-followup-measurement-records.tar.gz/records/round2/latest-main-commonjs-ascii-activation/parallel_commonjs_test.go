package jscomp

import (
	"bytes"
	"encoding/json"
	"fmt"
	"os"
	"slices"
	"strings"
	"sync/atomic"
	"testing"
	"time"

	"github.com/paullepoulpe/jsgo/internal/jutil"
	"github.com/paullepoulpe/jsgo/internal/rhino"
)

func newParallelCommonJSFixture(t *testing.T, workers int, mode string, sources ...string) *Compiler {
	t.Helper()
	r := NewCommandLineRunnerWithOutAndErr([]string{
		"--compilation_level=WHITESPACE", "--env=CUSTOM", "--process_common_js_modules",
		"--module_resolution=" + mode, fmt.Sprintf("--num_parallel_threads=%d", workers),
	}, jutil.NewPrintStream(&bytes.Buffer{}), jutil.NewPrintStream(&bytes.Buffer{}))
	r.compiler = r.CreateCompiler()
	options := r.CreateOptions()
	r.SetRunOptions(options)
	options.SetLanguageIn(CompilerOptions_LanguageMode_ECMASCRIPT_NEXT)
	options.SetLanguageOut(CompilerOptions_LanguageMode_ECMASCRIPT5)
	options.SetSourceMapOutputPath(jutil.StringPtr("out.js.map"))
	r.compiler.InitOptions(options)
	files := make([]*SourceFile, len(sources))
	for i, source := range sources {
		files[i] = SourceFile_FromCode(fmt.Sprintf("file%d.js", i), source)
	}
	owned := r.acquireNativeCLILease(nil, files)
	if owned == nil {
		t.Fatal("fixture did not obtain the stock fresh CLI source lifetime")
	}
	t.Cleanup(owned.close)
	c := r.compiler
	c.Init(nil, files, options)
	c.ParseInputs()
	if c.GetErrorCount() != 0 {
		t.Fatalf("CommonJS fixture did not parse: %v", c.GetErrors())
	}
	c.changeTracker.GetChangedScopeNodesForPass("parallel-commonjs-test")
	return c
}

func parallelCommonJSSnapshot(c *Compiler) []string {
	// Compiler.ToSource appends mappings to the existing generator. These
	// fixtures print several revisions, so each snapshot needs a fresh map.
	c.GetSourceMap().Reset()
	result := []string{c.ToSource(), fmt.Sprint(c.changeTracker.GetChangeStamp())}
	var walk func(*rhino.Node)
	walk = func(n *rhino.Node) {
		if n.IsScript() || n.IsFunction() {
			result = append(result, fmt.Sprintf("%s:%d", n.String(), n.GetChangeTime()))
		}
		for child := n.GetFirstChild(); child != nil; child = child.GetNext() {
			walk(child)
		}
	}
	walk(c.GetRoot())
	for _, n := range c.changeTracker.GetChangedScopeNodesForPass("parallel-commonjs-test") {
		result = append(result, n.String())
	}
	for _, warning := range c.GetWarnings() {
		result = append(result, warning.String())
	}
	result = append(result, c.GetRoot().ToStringTree(), fmt.Sprint(c.GetLifeCycleStage()), fmt.Sprint(c.uniqueNameId))
	for _, id := range c.uniqueIdSupplier.ToProto() {
		result = append(result, fmt.Sprintf("unique:%d:%d", id.GetHash(), id.GetCounter()))
	}
	for script := c.GetJsRoot().GetFirstChild(); script != nil; script = script.GetNext() {
		result = append(result, fmt.Sprint(NodeUtil_GetFeatureSetOfScript(script)))
	}
	for _, error := range c.GetErrors() {
		result = append(result, error.String())
	}
	var sourceMap strings.Builder
	name := "out.js"
	c.GetSourceMap().AppendTo(&sourceMap, &name)
	return append(result, sourceMap.String())
}

func parallelCommonJSSource(c *Compiler) string {
	c.GetSourceMap().Reset()
	return c.ToSource()
}

func assertParallelCommonJSEquivalent(t *testing.T, want, got *Compiler) {
	t.Helper()
	a, b := parallelCommonJSSnapshot(want), parallelCommonJSSnapshot(got)
	if !slices.Equal(a, b) || !want.GetRoot().IsEquivalentTo(got.GetRoot()) {
		t.Fatalf("CommonJS output/metadata/reports/names/source maps changed:\ngot %v\nwant %v", b, a)
	}
}

func TestParallelCommonJSDifferentialRealWorkAndCanonicalInputs(t *testing.T) {
	fixtures := [][]string{
		{
			`var dep=require('./file1.js'); module.exports={run:function(value){return dep.value+value;},message:"é😀"};`,
			`exports.value=3; exports.more=function named(value=2){return value;};`,
			`var {value}=require('./file1.js'); exports.result=value;`,
			`class Item {method(){return require('./file1.js').value;}} module.exports=Item;`,
			`var item=require('./file3.js'); module.exports=function(){return new item().method();};`,
		},
		{
			`function shadow(require,exports){exports.value=require('local');} module.exports={shadow:shadow};`,
			`var dep=require('./file0.js'); module.exports={defaultValue:function(){try {return dep.shadow;}catch(error){return error;}}};`,
			`require.ensure([],function(require){var local=require('./file1.js');module.exports=local;});`,
			`/** @type {!Object} */ var original=require('./file1.js'); exports.reference=original;`,
		},
	}
	for fi, sources := range fixtures {
		for _, mode := range []string{"NODE", "BROWSER"} {
			for _, workers := range []int{2, 4} {
				t.Run(fmt.Sprintf("%d/%s/%d", fi, mode, workers), func(t *testing.T) {
					want := newParallelCommonJSFixture(t, 1, mode, sources...)
					got := newParallelCommonJSFixture(t, workers, mode, sources...)
					originalLoader, originalHandler := got.moduleLoader, got.moduleLoader.errorHandler
					originalResolver := originalLoader.moduleResolver
					paths := map[*CompilerInput]*ModuleLoader_ModulePath{}
					for script := got.GetJsRoot().GetFirstChild(); script != nil; script = script.GetNext() {
						input := got.GetInput(script.GetInputId())
						paths[input] = input.GetPath()
					}
					before := parallelCommonJSSource(want)
					NewProcessCommonJSModules(want).Process(want.GetExternsRoot(), want.GetJsRoot())
					jobs, effects := 0, 0
					probe := &parallelCommonJSProbe{
						beforeJobs: func(cohort []*parallelCommonJSJob) {
							jobs += len(cohort)
							if len(cohort) > workers {
								t.Error("intermediate ownership exceeds the existing worker budget")
							}
							for _, job := range cohort {
								c := &job.compiler
								if c.GetInput(c.script.GetInputId()) != c.input || c.input != got.GetInput(c.script.GetInputId()) || c.input.GetPath() != paths[c.input] {
									t.Error("worker replaced the canonical input or its lazy path")
								}
								if c.GetModuleLoader() == originalLoader || c.loader.moduleResolver == originalResolver || c.path.outer != &c.loader {
									t.Error("worker did not isolate resolver/loader headers")
								}
								base, originalBase := c.loader.moduleResolver.GetModuleResolverBase(), originalResolver.GetModuleResolverBase()
								if base == originalBase || base.modulePaths != originalBase.modulePaths || !slices.Equal(base.moduleRootPaths, originalBase.moduleRootPaths) {
									t.Error("resolver copy changed the immutable resolution tables")
								}
								if node, ok := c.loader.moduleResolver.(*NodeModuleResolver); ok {
									originalNode := originalResolver.(*NodeModuleResolver)
									if node.packageJsonMainEntries != originalNode.packageJsonMainEntries || !slices.Equal(node.nodeModulesFolders, originalNode.nodeModulesFolders) {
										t.Error("Node resolver copy changed package aliases/search folders")
									}
								}
								scope := NewSyntacticScopeCreator(c).CreateScope(c.script, nil).(*Scope)
								for variable := range scope.GetVarIterable() {
									if variable.GetInput() != c.input {
										t.Error("scope variable exposes a copied CompilerInput")
									}
								}
							}
						},
						afterJobs: func(cohort []*parallelCommonJSJob) {
							for _, job := range cohort {
								effects += len(job.compiler.events)
							}
							if got.moduleLoader != originalLoader || originalLoader.moduleResolver != originalResolver || originalLoader.errorHandler != originalHandler {
								t.Error("worker changed original loader or handler")
							}
						},
					}
					if !newBuiltinProcessCommonJSModules(got).processScriptCohorts(got.GetExternsRoot(), got.GetJsRoot(), probe) || jobs < 2 || effects == 0 || parallelCommonJSSource(want) == before {
						t.Fatalf("fixture did not execute real independent rewrites: jobs=%d effects=%d", jobs, effects)
					}
					assertParallelCommonJSEquivalent(t, want, got)
				})
			}
		}
	}
}

// Suppression is evaluated before rewriting removes the original assignment's
// JSDoc. Reapplying the guard only at buffered-publication time would leak the
// first warning. The second script proves warnings were not simply discarded.
func TestParallelCommonJSDiagnosticLevelsBeforeAncestorRewrite(t *testing.T) {
	sources := []string{
		`/** @suppress {moduleLoad} */ module.exports={x:require.ensure([],3)};`,
		`module.exports={x:require.ensure([],4)};`,
		`var value=require('./file1.js');exports.value=value;`,
		`module.exports={x:require.ensure([],5)};`,
	}
	want := newParallelCommonJSFixture(t, 1, "NODE", sources...)
	got := newParallelCommonJSFixture(t, 2, "NODE", sources...)
	initial := want.GetWarningCount()
	NewProcessCommonJSModules(want).Process(want.GetExternsRoot(), want.GetJsRoot())
	jobs, suppressed, visible := 0, 0, 0
	probe := &parallelCommonJSProbe{beforeJobs: func(cohort []*parallelCommonJSJob) { jobs += len(cohort) }, afterJobs: func(cohort []*parallelCommonJSJob) {
		for _, job := range cohort {
			for _, event := range job.compiler.events {
				if event.diagnostic != nil {
					if event.level.IsOn() {
						visible++
					} else {
						suppressed++
					}
				}
			}
		}
	}}
	if !newBuiltinProcessCommonJSModules(got).processScriptCohorts(got.GetExternsRoot(), got.GetJsRoot(), probe) || jobs != 4 || suppressed == 0 || visible == 0 || want.GetWarningCount() <= initial {
		t.Fatalf("missing real diagnostic/suppression exercise: jobs=%d off=%d on=%d", jobs, suppressed, visible)
	}
	assertParallelCommonJSEquivalent(t, want, got)
}

func TestParallelCommonJSMixedUMDFallbackPreservesGlobalNames(t *testing.T) {
	sources := []string{
		`module.exports=function first(){return 1;};`,
		`exports.second=require('./file0.js');`,
		`(function(){if(typeof module==='object'){module.exports=function wrapped(){return 3;};}})();`,
		`exports.third=require('./file2.js');`,
		`module.exports=function fourth(){return 4;};`,
		`exports.last=require('./file4.js');`,
	}
	want := newParallelCommonJSFixture(t, 1, "NODE", sources...)
	got := newParallelCommonJSFixture(t, 2, "NODE", sources...)
	NewProcessCommonJSModules(want).Process(want.GetExternsRoot(), want.GetJsRoot())
	jobs := 0
	probe := &parallelCommonJSProbe{beforeJobs: func(cohort []*parallelCommonJSJob) {
		jobs += len(cohort)
		for _, job := range cohort {
			if job.compiler.input.GetName() == "file2.js" {
				t.Error("UMD/global-name mutator entered an independent cohort")
			}
		}
	}}
	if !newBuiltinProcessCommonJSModules(got).processScriptCohorts(got.GetExternsRoot(), got.GetJsRoot(), probe) || jobs != 4 {
		t.Fatalf("mixed fixture did not dispatch before/after serial fallback: jobs=%d", jobs)
	}
	assertParallelCommonJSEquivalent(t, want, got)
}

func TestParallelCommonJSRealWorkersOverlapWithinExistingBudget(t *testing.T) {
	sources := []string{`exports.first=1;`, `exports.second=2;`, `exports.third=3;`, `exports.fourth=4;`}
	want := newParallelCommonJSFixture(t, 1, "NODE", sources...)
	got := newParallelCommonJSFixture(t, 2, "NODE", sources...)
	NewProcessCommonJSModules(want).Process(want.GetExternsRoot(), want.GetJsRoot())
	entered, release, done := make(chan string, 4), make(chan struct{}), make(chan any, 1)
	var active, peak atomic.Int32
	probe := &parallelCommonJSProbe{aroundJob: func(job *parallelCommonJSJob, run func()) {
		now := active.Add(1)
		defer active.Add(-1)
		for old := peak.Load(); now > old && !peak.CompareAndSwap(old, now); old = peak.Load() {
		}
		entered <- job.compiler.input.GetName()
		<-release
		run()
	}}
	go func() {
		defer func() { done <- recover() }()
		newBuiltinProcessCommonJSModules(got).processScriptCohorts(got.GetExternsRoot(), got.GetJsRoot(), probe)
	}()
	first := map[string]bool{}
	for range 2 {
		select {
		case name := <-entered:
			first[name] = true
		case <-time.After(10 * time.Second):
			close(release)
			t.Fatal("real CommonJS jobs did not overlap")
		}
	}
	close(release)
	select {
	case failure := <-done:
		if failure != nil {
			panic(failure)
		}
	case <-time.After(10 * time.Second):
		t.Fatal("CommonJS cohort did not join")
	}
	if len(first) != 2 || peak.Load() != 2 {
		t.Fatalf("existing work-item budget was not respected: distinct=%d peak=%d", len(first), peak.Load())
	}
	assertParallelCommonJSEquivalent(t, want, got)
}

type parallelCommonJSCustomResolver struct{ ModuleResolver }

func (*parallelCommonJSCustomResolver) GetModuleResolverBase() *ModuleResolverBase {
	panic("custom resolver accessor must not be called during admission")
}

func TestParallelCommonJSPrivateNodeResolverRetainsPackageAliases(t *testing.T) {
	c := newParallelCommonJSFixture(t, 2, "NODE", `exports.first=1;`, `exports.second=2;`)
	original := ModuleLoader_Builder_().SetErrorHandler(c.AsErrorHandler()).
		SetModuleRoots([]string{}).
		SetInputs(jsaMlInputs("/app.js", "/node_modules/B/package.json", "/node_modules/B/lib/b.js")).
		SetFactory(NewNodeModuleResolver_FactoryWithEntries(jsaMlPACKAGE_JSON_MAIN_ENTRIES())).
		SetPathResolver(ModuleLoader_PathResolver_RELATIVE).Build()
	header := parallelCommonJSCompiler{parallelCommonJSContext: parallelCommonJSContext{owner: c}}
	if !cloneParallelCommonJSLoader(original, &header) {
		t.Fatal("stock Node resolver did not admit a private header")
	}
	privatePath, originalPath := header.loader.Resolve("/app.js"), original.Resolve("/app.js")
	for _, address := range []string{"B", "B/lib/b.js", "./node_modules/B/lib/b.js"} {
		want := originalPath.ResolveJsModule(address, "/app.js", 1, 0)
		got := privatePath.ResolveJsModule(address, "/app.js", 1, 0)
		if want == nil || got == nil || got.String() != want.String() || got.outer != &header.loader {
			t.Fatalf("package alias/search root resolution changed: %q got %v want %v", address, got, want)
		}
	}
	if original.errorHandler != c.AsErrorHandler() || original.moduleResolver.GetModuleResolverBase().errorHandler != c.AsErrorHandler() {
		t.Fatal("private resolver replaced an original diagnostic receiver")
	}
}

func TestParallelCommonJSPublicAndUnknownResolverFallback(t *testing.T) {
	for _, reason := range []string{"public", "oneWorker", "customResolver", "noOwnership"} {
		t.Run(reason, func(t *testing.T) {
			c := newParallelCommonJSFixture(t, 2, "NODE", `exports.first=1;`, `exports.second=2;`)
			p := newBuiltinProcessCommonJSModules(c)
			switch reason {
			case "public":
				p = NewProcessCommonJSModules(c)
			case "oneWorker":
				c.options.SetNumParallelThreads(1)
			case "customResolver":
				c.moduleLoader.moduleResolver = &parallelCommonJSCustomResolver{c.moduleLoader.moduleResolver}
			case "noOwnership":
				for script := c.GetJsRoot().GetFirstChild(); script != nil; script = script.GetNext() {
					input := c.GetInput(script.GetInputId())
					original := input.sourceFile
					input.sourceFile = SourceFile_FromCode(original.GetName(), "")
					t.Cleanup(func() { input.sourceFile = original })
				}
			}
			before := c.GetRoot().ToStringTree()
			if p.processScriptCohorts(c.GetExternsRoot(), c.GetJsRoot(), &parallelCommonJSProbe{beforeJobs: func([]*parallelCommonJSJob) { t.Error("fallback dispatched") }}) || before != c.GetRoot().ToStringTree() {
				t.Fatal("unsupported configuration did not fall back before mutation")
			}
		})
	}
}

func TestParallelCommonJSMainBenchmarkActivation(t *testing.T) {
	path := os.Getenv("JSGO_COMMONJS_ACTIVATION_CASE")
	if path == "" {
		t.Skip("set JSGO_COMMONJS_ACTIVATION_CASE to cwd/args/report case JSON")
	}
	var invocation struct {
		Task   string   `json:"task"`
		Cwd    string   `json:"cwd"`
		Args   []string `json:"args"`
		Report string   `json:"report"`
	}
	data, err := os.ReadFile(path)
	if err != nil {
		t.Fatal(err)
	}
	if err = json.Unmarshal(data, &invocation); err != nil {
		t.Fatal(err)
	}
	previous, err := os.Getwd()
	if err != nil {
		t.Fatal(err)
	}
	if err = os.Chdir(invocation.Cwd); err != nil {
		t.Fatal(err)
	}
	defer func() {
		if err := os.Chdir(previous); err != nil {
			t.Error(err)
		}
	}()
	t.Setenv("JSGO_EXPERIMENT_PARALLEL_COMMONJS", "1")
	commonJSMainActivationPasses = nil
	var output, diagnostics bytes.Buffer
	runner := NewCommandLineRunnerWithOutAndErr(invocation.Args, jutil.NewPrintStream(&output), jutil.NewPrintStream(&diagnostics))
	extras := make(map[string]any)
	asciiProbe := &ownedASCIIParserProbe{}
	runner.ownedASCIIProbe = asciiProbe
	fsivUseActivationReset()
	exit := runner.DoRun()
	extras["ascii_parser"] = map[string]int64{"parses": asciiProbe.parses.Load(), "source_bytes": asciiProbe.sourceBytes.Load(), "backed": asciiProbe.backed.Load(), "backed_bytes": asciiProbe.backedBytes.Load()}
	extras["fsiv"] = fsivUseActivationSnapshot()
	state := "pass-executed"
	if len(commonJSMainActivationPasses) == 0 {
		state = "pass-not-executed"
	}
	report := struct {
		Task        string                        `json:"task"`
		Args        []string                      `json:"args"`
		Exit        int                           `json:"exit"`
		State       string                        `json:"state"`
		Passes      []*commonJSMainActivationPass `json:"passes"`
		Diagnostics string                        `json:"diagnostics"`
		Extras      map[string]any                `json:"extras,omitempty"`
	}{invocation.Task, invocation.Args, exit, state, commonJSMainActivationPasses, diagnostics.String(), extras}
	encoded, err := json.MarshalIndent(report, "", "  ")
	if err != nil {
		t.Fatal(err)
	}
	if err = os.WriteFile(invocation.Report, append(encoded, '\n'), 0600); err != nil {
		t.Fatal(err)
	}
	commonJSMainActivationPasses = nil
	t.Logf("%s: %s exit=%d report=%s", invocation.Task, state, exit, invocation.Report)
	if exit != 0 {
		t.Fatalf("actual CLI failed: %d\n%s", exit, diagnostics.String())
	}
}
