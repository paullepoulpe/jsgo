#!/usr/bin/env python3
import collections,hashlib,json,re,sys
from pathlib import Path
sys.dont_write_bytecode=True
ROOT=Path(__file__).resolve().parent;sys.path.insert(0,str(ROOT.parent))
from pprof_data import load_profile
from label_hotspots import symbols
FAMILIES={'newNodeTraversal':lambda f:'internal/jscomp.newNodeTraversal' in f and 'Builder' not in f,'syntacticScopeCreation':lambda f:'internal/jscomp.(*SyntacticScopeCreator).CreateScope' in f}
EXCLUDE=('NodeTraversal','ReferenceCollector','Compiler','AbstractCompiler','PhaseOptimizer','DefaultPassConfig','SyntacticScopeCreator','ScopeScanner')
OUT={'method':'Existing ff06 sampled allocation profiles, no new runtime. Allocation samples having target ancestry counted ONCE/family; nearest concrete pass Process excludes traversal/collector/pipeline wrappers. Unclassified means available ancestry has no such frame; CPU/alloc ancestry truncation can hide outer pass. Owner and callback tables are different overlapping partitions of the same family bytes.','tasks':{}}
for task in ['typed-app','bundle','downlevel-whitespace','downlevel-simple','checks-only']:
 path=ROOT/task/'profile.allocs.pprof';p=load_profile(path);locs=symbols(p);bi=p.sample_types.index(('alloc_space','bytes'));oi=p.sample_types.index(('alloc_objects','count'));rows={}
 for family,match in FAMILIES.items():
  owners=collections.defaultdict(lambda:[0,0]);callbacks=collections.defaultdict(lambda:[0,0]);stacks=collections.defaultdict(lambda:[0,0]);tot=[0,0]
  for sample in p.samples:
   fs=[f.removeprefix('github.com/paullepoulpe/jsgo/')for l in sample.locations for f in locs[l]]
   indices=[i for i,f in enumerate(fs)if match(f)]
   if not indices:continue
   tail=fs[max(indices)+1:];values=[sample.values[bi],sample.values[oi]]
   candidates=[]
   for f in tail:
    m=re.search(r'internal/jscomp\.\(\*([^)]*)\)\.([^.(]+)',f)
    if m and not any(q in m[1]for q in EXCLUDE):candidates.append((f,m[2]))
   owner=next((f for f,method in candidates if method in ('Process','Optimize','InferAllScopes','ProcessForTesting')),None)
   if owner is None:owner='UNCLASSIFIED available ancestry'
   callback=next((f for f,method in candidates), 'UNCLASSIFIED available ancestry')
   stack='\n'.join(tail[:22])
   for bucket,key in [(owners,owner),(callbacks,callback),(stacks,stack)]:
    for i,v in enumerate(values):bucket[key][i]+=v
   for i,v in enumerate(values):tot[i]+=v
  def result(c,n=40):return [{'owner':f,'bytes':v[0],'MiB':v[0]/1048576,'objects':v[1],'fraction_of_family_bytes':v[0]/tot[0] if tot[0] else 0}for f,v in sorted(c.items(),key=lambda x:x[1][0],reverse=True)[:n]]
  rows[family]={'bytes':tot[0],'objects':tot[1],'MiB':tot[0]/1048576,'nearest_pass':result(owners),'nearest_callback_or_consumer':result(callbacks),'top_stacks':result(stacks,25)}
 OUT['tasks'][task]=rows
(ROOT/'allocation-owners.json').write_text(json.dumps(OUT,indent=2)+'\n')
for task,rows in OUT['tasks'].items():
 print('\n'+task)
 for family,r in rows.items():
  print(family,round(r['MiB'],2),'MiB')
  for x in r['nearest_pass'][:12]:print(' ',round(x['MiB'],2),round(x['fraction_of_family_bytes']*100,1),x['owner'])
