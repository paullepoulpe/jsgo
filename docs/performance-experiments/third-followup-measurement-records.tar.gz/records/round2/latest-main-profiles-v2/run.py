#!/usr/bin/env python3
"""One untimed original-main profile per pinned task. Run only after root's quiet reservation."""
import datetime, hashlib, json, os, subprocess, sys
from pathlib import Path

ROOT=Path('/workspace/jsgo-latest-main-control')
OUT=Path(__file__).resolve().parent
REF=Path('/workspace/jsgo-results/round2/baseline')
BIN=OUT/'bin/jsgo-profile'
TASKS=['typed-app','bundle','downlevel-whitespace','downlevel-simple','checks-only']
sys.dont_write_bytecode=True
sys.path.insert(0,str(ROOT/'tools/bench'))
import bench
h=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def frozen():
 m=json.loads((OUT/'overlay/manifest.json').read_text())
 for path,key in [(m['original'],'original_sha256'),(m['replacement'],'replacement_sha256'),(m['overlay'],'overlay_sha256')]:
  assert h(Path(path))==m[key],('frozen source hash changed',path)
 assert subprocess.check_output(['git','-C',str(ROOT),'rev-parse','HEAD'],text=True).strip()==m['source_commit']
 assert h(ROOT/'cmd/jsgo/default.pgo')==m['pgo_sha256']
 assert subprocess.check_output(['git','-C',str(ROOT),'status','--porcelain'],text=True)==''
 return m

def main():
 if (OUT/'summary.json').exists(): raise SystemExit('refusing to overwrite completed profile inventory')
 manifest=frozen()
 base_env={k:v for k,v in os.environ.items() if not k.startswith('JSGO') and k not in {'GOGC','GOMEMLIMIT','GOMAXPROCS','GODEBUG'}}
 base_env['LC_ALL']='C.UTF-8'
 report={'kind':'untimed-main-profile-inventory','source_commit':manifest['source_commit'],'source_root':str(ROOT),'binary':str(BIN),'binary_sha256':h(BIN),'pgo_sha256':manifest['pgo_sha256'],'runtime_gc':'default; no runtime GC/scheduler/profstackdepth overrides','experiment_flags':{},'affinity':[0,1],'started_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'profile_sampling':'default CPU/default allocs sampling; no forced GC; recent allocation cycles may be incomplete','jobs':[]}
 for name in TASKS:
  jobs=json.loads((REF/name/'jobs.json').read_text())
  reference=json.loads((REF/name/'java-cold.json').read_text())['runs'][0]
  assert len(jobs)==1 and reference['exits']==[0]
  directory=OUT/name
  if directory.exists(): raise SystemExit('refusing to rerun/overwrite profile task '+name)
  bench.make_workspace(str(directory),'/workspace/jsgo/.cache')
  directory=directory.resolve()
  (directory/'args.json').write_text(json.dumps(jobs[0],indent=2)+'\n')
  frozen()
  env=dict(base_env,JSGO_MAIN_CPU_PROFILE=str(directory/'profile.cpu.pprof'),JSGO_MAIN_ALLOCS_PROFILE=str(directory/'profile.allocs.pprof'))
  with (directory/'stdout').open('wb') as stdout,(directory/'stderr').open('wb') as stderr:
   run=subprocess.run(['taskset','-c','0,1',str(BIN),*jobs[0]],cwd=directory,env=env,stdout=stdout,stderr=stderr,timeout=300)
  (directory/'exit').write_text(str(run.returncode)+'\n')
  expected=reference['digests'][0]
  actual={key:h(directory/key) if (directory/key).is_file() else None for key in expected}
  gates={key:actual[key]==wanted for key,wanted in expected.items()}
  cpu,alloc=directory/'profile.cpu.pprof',directory/'profile.allocs.pprof'
  row={'task':name,'directory':str(directory),'exit':run.returncode,'expected':expected,'actual':actual,'gates':gates,'all_artifacts_match':all(gates.values()),'completed_profiles':run.returncode==0 and cpu.is_file() and alloc.is_file() and cpu.stat().st_size>0 and alloc.stat().st_size>0,'profiles':{p.name:{'bytes':p.stat().st_size,'sha256':h(p)}for p in [cpu,alloc] if p.is_file()}}
  (directory/'gate.json').write_text(json.dumps(row,indent=2)+'\n')
  report['jobs'].append(row)
  (OUT/'partial-summary.json').write_text(json.dumps(report,indent=2)+'\n')
  print(name, 'MATCH' if row['all_artifacts_match'] else 'DIFF', 'completed profiles' if row['completed_profiles'] else 'INVALID/MISSING profiles',flush=True)
  if run.returncode!=0 or not row['all_artifacts_match'] or not row['completed_profiles']:raise SystemExit('profile capture gate failed: '+name)
 report['finished_utc']=datetime.datetime.now(datetime.timezone.utc).isoformat()
 (OUT/'summary.json').write_text(json.dumps(report,indent=2)+'\n')
 print('ALL FIVE PINNED JAVA GATES MATCH; fresh untimed CPU+allocs profiles captured',flush=True)
if __name__=='__main__':main()
