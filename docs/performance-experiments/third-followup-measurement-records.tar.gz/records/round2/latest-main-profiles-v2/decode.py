#!/usr/bin/env python3
"""Decode frozen one-shot profiles; cumulative functions/families overlap, never add them."""
import collections,hashlib,json,subprocess,sys
from pathlib import Path
sys.dont_write_bytecode=True
ROOT=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT.parent))
from pprof_data import load_profile
from label_hotspots import symbols
TASKS=['typed-app','bundle','downlevel-whitespace','downlevel-simple','checks-only']
GO='/workspace/toolchains/go1.27.2/bin/go';BIN=ROOT/'bin/jsgo-profile'
FAMILIES={
 'GC/runtime':('runtime.gc','runtime.scan','runtime.mark','runtime.sweep','runtime.greyobject','runtime.findObject','runtime.(*gc','runtime.(*sweep'),
 'AST traversal':('NodeTraversal','Node).GetNext','Node).GetFirstChild','Node).GetParent'),
 'syntactic scopes':('SyntacticScopeCreator','(*Scope).Declare','NewVar','internal/jscomp.(*Scanner).','(*AbstractScopeBase'),
 'typed scopes':('TypedScopeCreator','NewTypedVar','(*TypedScope).'),
 'liveness':('LiveVariables','LiveVariableLattice','CoalesceVariableNames','DeadAssignmentsElimination'),
 'BitSet':('jutil.(*BitSet)','jutil.NewBitSet'),
 'template type family':('CopyFilledWithValues','NewTemplatizedType','CreateTemplatizedType','TemplateTypeMap','TemplateTypeReplacer'),
 'global string pool':('RhinoStringPool','rhinoStringPool','stringPoolCell','InternString'),
 'parser':('/internal/parsing.','/internal/parser.','IRFactory'),
 'monitor':('jutil.(*Monitor)','GoroutineID','runtime.Stack'),
 'flow map':('LinkedFlowScope','HamtPMap'),
 'inverter':('ContextualRenameInverter','VariableInfo'),
 'remove unused':('RemoveUnusedCode',),
}
def main():
 gate=json.loads((ROOT/'summary.json').read_text());assert len(gate['jobs'])==5 and all(r['all_artifacts_match'] and r['completed_profiles'] for r in gate['jobs'])
 result={'source':gate['source_commit'],'binary_sha256':gate['binary_sha256'],'method':'single untimed original-main invocation/task, all Java artifact gates; default CPU/alloc sampling; no forced GC, no phase labels. Cumulative ancestry is stack-depth truncated; functions/families overlap. Profile sample bytes are cumulative estimates, not RSS or runtime MemStats.','tasks':{}}
 for task in TASKS:
  row={}
  for kind,file in [('cpu','profile.cpu.pprof'),('allocs','profile.allocs.pprof')]:
   path=ROOT/task/file;p=load_profile(path);locs=symbols(p);totals=p.totals();sr={}
   targets=[('cpu','nanoseconds')] if kind=='cpu' else [('alloc_space','bytes'),('alloc_objects','count')]
   for sample_type in targets:
    idx=p.sample_types.index(sample_type);total=totals[idx];flat=collections.Counter();cum=collections.Counter();families=collections.Counter()
    for s in p.samples:
     n=s.values[idx];fs=[f for l in s.locations for f in locs[l]]
     if fs:flat[fs[0]]+=n
     for f in set(fs):cum[f]+=n
     for family,patterns in FAMILIES.items():
      if any(any(q in f for q in patterns)for f in fs):families[family]+=n
    def rows(c,limit=100):return [{'function':f.removeprefix('github.com/paullepoulpe/jsgo/'),'value':n,'fraction':n/total if total else 0}for f,n in c.most_common(limit)]
    sr[sample_type[0]]={'unit':sample_type[1],'total':total,'flat':rows(flat),'cumulative':rows(cum),'families_nonadditive':rows(families)}
   row[kind]={'profile_sha256':hashlib.sha256(path.read_bytes()).hexdigest(),'sample_types':p.sample_types,'metrics':sr}
  result['tasks'][task]=row
 (ROOT/'hotspots.json').write_text(json.dumps(result,indent=2)+'\n')
 for task in TASKS:
  for kind,index in [('cpu','cpu'),('allocs','alloc_space'),('allocs','alloc_objects')]:
   for sort in ('flat','cum'):
    cmd=[GO,'tool','pprof','-top','-nodecount=70','-sample_index='+index]
    if sort=='cum':cmd.append('-cum')
    cmd += [str(BIN),str(ROOT/task/('profile.cpu.pprof' if kind=='cpu' else 'profile.allocs.pprof'))]
    run=subprocess.run(cmd,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True,check=True)
    (ROOT/task/(index+'-'+sort+'.txt')).write_text(run.stdout)
 print('Decoded five CPU and five sampled-allocation profiles; hotspots.json and 30 pprof text views saved.')
if __name__=='__main__':main()
