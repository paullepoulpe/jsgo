#!/usr/bin/env python3
"""NON-RACE, untimed numeric activation only. Real guards and compiler work stay unchanged."""
import argparse,hashlib,json,subprocess
from pathlib import Path
p=argparse.ArgumentParser();p.add_argument('--root',type=Path,required=True);p.add_argument('--base-overlay',type=Path);p.add_argument('--out',type=Path)
a=p.parse_args();root=a.root.resolve();out=(a.out or Path(__file__).parent).resolve();out.mkdir(parents=True,exist_ok=True)
replacements={}
if a.base_overlay: replacements.update(json.loads(a.base_overlay.read_text())['Replace'])
source_hashes={}
def replace(name,old,new):
 path=root/'internal/jscomp'/name
 source=path.read_text()
 if str(path) in replacements:
  source=Path(replacements[str(path)]).read_text()
 if source.count(old)!=1:raise SystemExit('hook not unique: '+name)
 dest=out/name;dest.write_text(source.replace(old,new));replacements[str(path)]=str(dest)
 source_hashes[str(path)]=hashlib.sha256(path.read_bytes()).hexdigest()
replace('fsiv_use_lazy.go','f := NewFlowSensitiveInlineVariables(compiler)','f := NewFlowSensitiveInlineVariables(compiler)\n\tf.useCardinalityProbe = &nativeUseCardinalityStats{}')
replace('flow_sensitive_inline_variables.go','func (f *FlowSensitiveInlineVariables) Process(externs *rhino.Node, root *rhino.Node) {','func (f *FlowSensitiveInlineVariables) Process(externs *rhino.Node, root *rhino.Node) {\n\tdefer fsivUseActivationRetire(f.useCardinalityProbe)')
helper=out/'fsiv_activation_diagnostic.go'
helper.write_text('''// Diagnostic overlay ONLY: excluded from production/race/timed binaries.
package jscomp
import ("reflect"; "sync")
var fsivUseActivationCounters = struct { sync.Mutex; totals map[string]int64 }{totals: make(map[string]int64)}
func fsivUseActivationRetire(probe *nativeUseCardinalityStats) {
 if probe == nil { return }
 value := reflect.ValueOf(*probe); names := value.Type()
 fsivUseActivationCounters.Lock(); defer fsivUseActivationCounters.Unlock()
 fsivUseActivationCounters.totals["CompletedPasses"]++
 for i:=0; i<value.NumField(); i++ { name, number := names.Field(i).Name, value.Field(i).Int(); if name == "MaxDenseBytes" { fsivUseActivationCounters.totals[name] = max(fsivUseActivationCounters.totals[name], number) } else { fsivUseActivationCounters.totals[name] += number } }
}
func fsivUseActivationSnapshot() map[string]int64 {
 fsivUseActivationCounters.Lock(); defer fsivUseActivationCounters.Unlock()
 result:=make(map[string]int64,len(fsivUseActivationCounters.totals))
 for key,value:=range fsivUseActivationCounters.totals { result[key]=value }; return result
}
func fsivUseActivationReset() {
 fsivUseActivationCounters.Lock(); defer fsivUseActivationCounters.Unlock(); clear(fsivUseActivationCounters.totals)
}
''')
replacements[str(root/'internal/jscomp/fsiv_activation_diagnostic.go')]=str(helper)
(out/'overlay.json').write_text(json.dumps({'Replace':replacements},indent=2)+'\n')
manifest={'source_commit':subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip(),'root':str(root),'base_overlay':str(a.base_overlay) if a.base_overlay else None,'diagnostic_only':True,'not_for_race_or_timing':True,'admission_changed':False,'source_sha256':source_hashes,'new_hooks':['actual stock FSIV factory numeric probe','actual FSIV Process completion numeric aggregation'],'snapshot_api':'fsivUseActivationSnapshot() map[string]int64','reset_api':'fsivUseActivationReset()'}
(out/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
print(json.dumps(manifest,indent=2))
