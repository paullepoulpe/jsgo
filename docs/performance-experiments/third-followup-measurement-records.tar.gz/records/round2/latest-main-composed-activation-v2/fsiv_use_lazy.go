package jscomp

func newBuiltinFlowSensitiveInlineVariables(compiler AbstractCompiler) *FlowSensitiveInlineVariables {
	f := NewFlowSensitiveInlineVariables(compiler)
	f.useCardinalityProbe = &nativeUseCardinalityStats{}
	f.useOwnedFactory = true
	f.useCardinalityEnabled = nativeUseCardinalityEnabled()
	f.useProjectionEnabled = nativeUseProjectionEnabled()
	f.useScalarEnabled = nativeUseScalarEnabled()
	return f
}

// Preserve main's reordered cheap checks and lazy first-query timing. Earlier
// candidates have only failed (a successful rewrite requires this query), so
// current remaining candidates are a complete immutable future query superset.
func (c *FlowSensitiveInlineVariables_Candidate) hasExactlyOneReachingUse() bool {
	f := c.outer
	if f.useCardinalityEnabled && !f.useAttempted {
		f.useAttempted = true
		f.useCardinality = f.tryUseCardinality(f.escaped, f.allVarsInFn)
	}
	if f.useCardinality != nil {
		return f.useCardinality.exactlyOne(c.varName, c.GetDefCfgNode())
	}
	return c.HasExactlyOne(f.getReachingUses().GetUses(c.varName, c.GetDefCfgNode()))
}
