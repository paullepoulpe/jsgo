// Diagnostic overlay ONLY: excluded from production/race/timed binaries.
package jscomp

import (
	"reflect"
	"sync"
)

var fsivUseActivationCounters = struct {
	sync.Mutex
	totals map[string]int64
}{totals: make(map[string]int64)}

func fsivUseActivationRetire(probe *nativeUseCardinalityStats) {
	if probe == nil {
		return
	}
	value := reflect.ValueOf(*probe)
	names := value.Type()
	fsivUseActivationCounters.Lock()
	defer fsivUseActivationCounters.Unlock()
	fsivUseActivationCounters.totals["CompletedPasses"]++
	for i := 0; i < value.NumField(); i++ {
		name, number := names.Field(i).Name, value.Field(i).Int()
		if name == "MaxDenseBytes" {
			fsivUseActivationCounters.totals[name] = max(fsivUseActivationCounters.totals[name], number)
		} else {
			fsivUseActivationCounters.totals[name] += number
		}
	}
}
func fsivUseActivationSnapshot() map[string]int64 {
	fsivUseActivationCounters.Lock()
	defer fsivUseActivationCounters.Unlock()
	result := make(map[string]int64, len(fsivUseActivationCounters.totals))
	for key, value := range fsivUseActivationCounters.totals {
		result[key] = value
	}
	return result
}
func fsivUseActivationReset() {
	fsivUseActivationCounters.Lock()
	defer fsivUseActivationCounters.Unlock()
	clear(fsivUseActivationCounters.totals)
}
