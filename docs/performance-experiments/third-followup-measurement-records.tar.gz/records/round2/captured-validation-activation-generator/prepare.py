#!/usr/bin/env python3
"""Generate an untimed test overlay; never forces recipe/session admission."""
import argparse,json,pathlib
p=argparse.ArgumentParser()
p.add_argument('--root',required=True,type=pathlib.Path)
p.add_argument('--out',required=True,type=pathlib.Path)
p.add_argument('--base-overlay',type=pathlib.Path)
a=p.parse_args();root=a.root.resolve();out=a.out.resolve()
if out.exists():raise SystemExit('use a new output directory; generated build inputs stay immutable')
out.mkdir(parents=True)
mode=root/'internal/jscomp/native_array_recipe_mode.go'
text=mode.read_text()
needle='func newArrayRecipeValuesMode(p *TypeInferencePass, root *rhino.Node) *arrayRecipeValuesMode {'
if text.count(needle)!=1:raise SystemExit('constructor seam changed')
text=text.replace(needle,needle+'\n if capturedValidationActivationProbe != nil { p.arrayRecipeProbe = capturedValidationActivationProbe } // diagnostic-only numeric probe; no admission override\n')
modeout=out/'native_array_recipe_mode.go';modeout.write_text(text)
test=out/'captured_validation_activation_overlay_test.go'
test.write_text(r'''package jscomp
import("bytes";"encoding/json";"fmt";"os";"path/filepath";"testing";"github.com/paullepoulpe/jsgo/internal/jutil")
var capturedValidationActivationProbe *arrayRecipeValuesProbe
func TestCapturedValidationRealCLIActivation(t *testing.T){
 argsPath:=os.Getenv("JSGO_CAPTURED_ACTIVATION_ARGS")
 resultDir:=os.Getenv("JSGO_CAPTURED_ACTIVATION_OUT")
 if argsPath==""||resultDir==""{t.Skip("activation args/output not supplied")}
 data,err:=os.ReadFile(argsPath);if err!=nil{t.Fatal(err)}
 var args []string;if err=json.Unmarshal(data,&args);err!=nil{t.Fatal(err)}
 capturedValidationActivationProbe=&arrayRecipeValuesProbe{}
 defer func(){capturedValidationActivationProbe=nil}()
 var stdout,stderr bytes.Buffer
 runner:=NewCommandLineRunnerWithOutAndErr(args,jutil.NewPrintStream(&stdout),jutil.NewPrintStream(&stderr))
 status:=runner.DoRun()
 probe:=capturedValidationActivationProbe
 counts:=map[string]any{"status":status,"activated":probe.Activated,"calls":probe.Calls,
 "recipe_seeds":probe.ArrayRecipeSeeds,"recipe_hits":probe.ArrayRecipeHits,"recipe_fallbacks":probe.ArrayRecipeFallbacks,
 "shared_hits":probe.ArraySharedResolvedHits,"captured_seeds":probe.CapturedValidationSeeds,
 "captured_hits":probe.CapturedValidationHits,"captured_fallbacks":probe.CapturedValidationFallbacks,
 "boundary_checks":probe.BoundaryChecks,"full_scope_checks":probe.FullScopeChecks,"fast_scope_checks":probe.FastScopeChecks,
 "lease_closed":!nativeCLILeaseActive(runner.GetCompiler())}
 if err=os.MkdirAll(resultDir,0700);err!=nil{t.Fatal(err)}
 for name,payload:=range map[string][]byte{"stdout":stdout.Bytes(),"stderr":stderr.Bytes(),"status":[]byte(fmt.Sprint(status))}{
 if err=os.WriteFile(filepath.Join(resultDir,name),payload,0600);err!=nil{t.Fatal(err)}}
 payload,err:=json.MarshalIndent(counts,"","  ");if err!=nil{t.Fatal(err)}
 if err=os.WriteFile(filepath.Join(resultDir,"activation.json"),payload,0600);err!=nil{t.Fatal(err)}
 fmt.Println(string(payload))
}
''')
replacements={}
if a.base_overlay:replacements.update(json.loads(a.base_overlay.read_text()).get('Replace',{}))
replacements[str(mode)]=str(modeout)
replacements[str(root/'internal/jscomp/captured_validation_activation_overlay_test.go')]=str(test)
(out/'overlay.json').write_text(json.dumps({'Replace':replacements},indent=2)+'\n')
(out/'manifest.json').write_text(json.dumps({'root':str(root),'mode_source':str(mode),'timed':False,
'probe':'numeric constructor/scopes only; full guard and lease remain unmodified',
'run_regex':'^TestCapturedValidationRealCLIActivation$',
'args_env':'JSGO_CAPTURED_ACTIVATION_ARGS (JSON argument array)',
'output_env':'JSGO_CAPTURED_ACTIVATION_OUT (artifact directory)'},indent=2)+'\n')
print(out/'overlay.json')
