package jscomp

import (
	"github.com/paullepoulpe/jsgo/internal/rhino"
	"strings"
	"testing"
)

func TestConcreteScopeLookupMatchesGenericWalk(t *testing.T) {
	root := Scope_CreateGlobalScope(rhino.IR_Root())
	root.Declare("outer", rhino.IR_Name("outer"), nil)
	fn := rhino.IR_Function(rhino.IR_Name("f"), rhino.IR_ParamList(), rhino.IR_Block())
	function := Scope_CreateChildScope(root, fn)
	function.Declare("local", rhino.IR_Name("local"), nil)
	block := Scope_CreateChildScope(function, fn.GetLastChild())
	block.Declare("outer", rhino.IR_Name("outer"), nil)
	for _, scope := range []*Scope{root, function, block} {
		for _, name := range []string{"outer", "local", "arguments", "this", "exports", "super", "missing", ""} {
			got, want := scope.GetVar(name), scope.AbstractScopeBase.GetVar(name)
			if got != want {
				t.Fatalf("name %q scope depth %d: different variable", name, scope.GetDepth())
			}
		}
	}
}

func originalTypedLookup(s *TypedScope, name string) *TypedVar {
	if own := s.getOwnSlotV(name); own != nil {
		return own
	} else if s.parent == nil {
		return nil
	}
	rootName := name
	dot := strings.IndexByte(name, '.')
	if dot >= 0 {
		rootName = name[:dot]
	}
	root := s.AbstractScopeBase.GetVar(rootName)
	if dot < 0 {
		return root
	}
	if root == nil {
		return s.parent.GetGlobalScope().getOwnSlotV(name)
	}
	return root.getScopeS().getOwnSlotV(name)
}

func TestConcreteTypedLookupMatchesQualifiedShadowing(t *testing.T) {
	global := TypedScope_CreateGlobalScope(rhino.IR_Root())
	global.Declare("outer", rhino.IR_Name("outer"), nil, nil, true)
	global.Declare("outer.property", rhino.IR_Name("outer.property"), nil, nil, true)
	global.Declare("undeclared.property", rhino.IR_Name("undeclared.property"), nil, nil, true)
	fn := rhino.IR_Function(rhino.IR_Name("f"), rhino.IR_ParamList(), rhino.IR_Block())
	function := NewTypedScope(global, fn)
	function.Declare("outer", rhino.IR_Name("outer"), nil, nil, true)
	block := NewTypedScope(function, fn.GetLastChild())
	block.Declare("local", rhino.IR_Name("local"), nil, nil, true)
	for _, scope := range []*TypedScope{global, function, block} {
		for _, name := range []string{"outer", "outer.property", "undeclared.property", "local", "arguments", "this", "exports", "missing", ""} {
			got, want := scope.GetVar(name), originalTypedLookup(scope, name)
			if got != want {
				t.Fatalf("name %q depth %d: qualified/implicit lookup diverged", name, scope.depth)
			}
		}
	}
}
