package parser

import (
	"runtime"
	"testing"
	"unsafe"
)

func TestCompactParserLayoutAndIdentity(t *testing.T) {
	if unsafe.Sizeof(TokenBase{}) != 16 || unsafe.Sizeof(ParseTreeBase{}) != 16 {
		t.Fatal("parser bases no longer fit 16 bytes")
	}
	source := NewSourceFile("example.js", "(answer)")
	pos := NewSourcePosition(source, 1, 0, 1)
	loc := NewSourceRange(pos, pos)
	name := NewIdentifierToken(loc, "answer")
	tree := NewIdentifierExpressionTree(loc, name)
	parens := NewParenExpressionTree(loc, NewParenExpressionTree(loc, tree))
	// Reconstruction from the embedded base must keep the concrete allocation
	// alive across collections, including when the only reference is the base.
	base := tree.GetParseTreeBase()
	tokenBase := name.GetTokenBase()
	tree, name = nil, nil
	for i := 0; i < 4; i++ {
		runtime.GC()
	}
	if base.AsIdentifierExpression().IdentifierToken != tokenBase.AsIdentifier() || tokenBase.AsIdentifier().GetValue() != "answer" {
		t.Fatal("concrete identity or payload lost")
	}
	if !parens.IsValidAssignmentTarget() || !parens.IsValidNonVanillaAssignmentTarget() || parens.IsPattern() {
		t.Fatal("nested parentheses changed assignment predicates")
	}
	lit := NewStringLiteralToken("'x'", loc, false)
	if lit.AsLiteral() != LiteralToken(lit) || lit.GetTokenBase().AsLiteral() != LiteralToken(lit) {
		t.Fatal("literal casts changed concrete identity")
	}
	plain := NewToken(TokenType_IDENTIFIER, loc)
	defer func() {
		if recover() == nil {
			t.Fatal("plain token with identifier type must fail concrete cast")
		}
	}()
	plain.AsIdentifier()
}
