// Go-only: language-adapter — compact self references for the closed parser
// token/tree hierarchies. Each base is the first embedded field of its concrete
// allocation. A non-pointer kind in existing padding replaces a two-word self
// interface; reconstructing a pointer to that allocation preserves Go GC roots.
// No pointer is converted to uintptr or stored outside the Go heap.
package parser

import "unsafe"

func (t *ParseTreeBase) setSelf(self ParseTree) {
	switch self.(type) {
	case nil:
		t.selfKind = 0
	case *ArgumentListTree:
		t.selfKind = 1
	case *ArrayLiteralExpressionTree:
		t.selfKind = 2
	case *ArrayPatternTree:
		t.selfKind = 3
	case *AwaitExpressionTree:
		t.selfKind = 4
	case *BinaryOperatorTree:
		t.selfKind = 5
	case *BlockTree:
		t.selfKind = 6
	case *BreakStatementTree:
		t.selfKind = 7
	case *CallExpressionTree:
		t.selfKind = 8
	case *CaseClauseTree:
		t.selfKind = 9
	case *CatchTree:
		t.selfKind = 10
	case *ClassDeclarationTree:
		t.selfKind = 11
	case *CommaExpressionTree:
		t.selfKind = 12
	case *ComprehensionForTree:
		t.selfKind = 13
	case *ComprehensionIfTree:
		t.selfKind = 14
	case *ComprehensionTree:
		t.selfKind = 15
	case *ComputedPropertyDefinitionTree:
		t.selfKind = 16
	case *ComputedPropertyFieldTree:
		t.selfKind = 17
	case *ComputedPropertyGetterTree:
		t.selfKind = 18
	case *ComputedPropertyMethodTree:
		t.selfKind = 19
	case *ComputedPropertySetterTree:
		t.selfKind = 20
	case *ConditionalExpressionTree:
		t.selfKind = 21
	case *ContinueStatementTree:
		t.selfKind = 22
	case *DebuggerStatementTree:
		t.selfKind = 23
	case *DefaultClauseTree:
		t.selfKind = 24
	case *DefaultParameterTree:
		t.selfKind = 25
	case *DoWhileStatementTree:
		t.selfKind = 26
	case *DynamicImportTree:
		t.selfKind = 27
	case *EmptyStatementTree:
		t.selfKind = 28
	case *ExportDeclarationTree:
		t.selfKind = 29
	case *ExportSpecifierTree:
		t.selfKind = 30
	case *ExpressionStatementTree:
		t.selfKind = 31
	case *FieldDeclarationTree:
		t.selfKind = 32
	case *FinallyTree:
		t.selfKind = 33
	case *ForAwaitOfStatementTree:
		t.selfKind = 34
	case *ForInStatementTree:
		t.selfKind = 35
	case *ForOfStatementTree:
		t.selfKind = 36
	case *ForStatementTree:
		t.selfKind = 37
	case *FormalParameterListTree:
		t.selfKind = 38
	case *FunctionDeclarationTree:
		t.selfKind = 39
	case *GetAccessorTree:
		t.selfKind = 40
	case *IdentifierExpressionTree:
		t.selfKind = 41
	case *IfStatementTree:
		t.selfKind = 42
	case *ImportDeclarationTree:
		t.selfKind = 43
	case *ImportMetaExpressionTree:
		t.selfKind = 44
	case *ImportSpecifierTree:
		t.selfKind = 45
	case *IterRestTree:
		t.selfKind = 46
	case *IterSpreadTree:
		t.selfKind = 47
	case *LabelledStatementTree:
		t.selfKind = 48
	case *LiteralExpressionTree:
		t.selfKind = 49
	case *MemberExpressionTree:
		t.selfKind = 50
	case *MemberLookupExpressionTree:
		t.selfKind = 51
	case *MissingPrimaryExpressionTree:
		t.selfKind = 52
	case *NewExpressionTree:
		t.selfKind = 53
	case *NewTargetExpressionTree:
		t.selfKind = 54
	case *NullTree:
		t.selfKind = 55
	case *ObjectLiteralExpressionTree:
		t.selfKind = 56
	case *ObjectPatternTree:
		t.selfKind = 57
	case *ObjectRestTree:
		t.selfKind = 58
	case *ObjectSpreadTree:
		t.selfKind = 59
	case *OptChainCallExpressionTree:
		t.selfKind = 60
	case *OptionalMemberExpressionTree:
		t.selfKind = 61
	case *OptionalMemberLookupExpressionTree:
		t.selfKind = 62
	case *ParenExpressionTree:
		t.selfKind = 63
	case *ProgramTree:
		t.selfKind = 64
	case *PropertyNameAssignmentTree:
		t.selfKind = 65
	case *ReturnStatementTree:
		t.selfKind = 66
	case *SetAccessorTree:
		t.selfKind = 67
	case *SuperExpressionTree:
		t.selfKind = 68
	case *SwitchStatementTree:
		t.selfKind = 69
	case *TemplateLiteralExpressionTree:
		t.selfKind = 70
	case *TemplateLiteralPortionTree:
		t.selfKind = 71
	case *TemplateSubstitutionTree:
		t.selfKind = 72
	case *ThisExpressionTree:
		t.selfKind = 73
	case *ThrowStatementTree:
		t.selfKind = 74
	case *TryStatementTree:
		t.selfKind = 75
	case *UnaryExpressionTree:
		t.selfKind = 76
	case *UpdateExpressionTree:
		t.selfKind = 77
	case *VariableDeclarationListTree:
		t.selfKind = 78
	case *VariableDeclarationTree:
		t.selfKind = 79
	case *VariableStatementTree:
		t.selfKind = 80
	case *WhileStatementTree:
		t.selfKind = 81
	case *WithStatementTree:
		t.selfKind = 82
	case *YieldExpressionTree:
		t.selfKind = 83
	default:
		panic("unregistered parser subclass")
	}
}
func (t *ParseTreeBase) getSelf() ParseTree {
	switch t.selfKind {
	case 0:
		return nil
	case 1:
		return (*ArgumentListTree)(unsafe.Pointer(t))
	case 2:
		return (*ArrayLiteralExpressionTree)(unsafe.Pointer(t))
	case 3:
		return (*ArrayPatternTree)(unsafe.Pointer(t))
	case 4:
		return (*AwaitExpressionTree)(unsafe.Pointer(t))
	case 5:
		return (*BinaryOperatorTree)(unsafe.Pointer(t))
	case 6:
		return (*BlockTree)(unsafe.Pointer(t))
	case 7:
		return (*BreakStatementTree)(unsafe.Pointer(t))
	case 8:
		return (*CallExpressionTree)(unsafe.Pointer(t))
	case 9:
		return (*CaseClauseTree)(unsafe.Pointer(t))
	case 10:
		return (*CatchTree)(unsafe.Pointer(t))
	case 11:
		return (*ClassDeclarationTree)(unsafe.Pointer(t))
	case 12:
		return (*CommaExpressionTree)(unsafe.Pointer(t))
	case 13:
		return (*ComprehensionForTree)(unsafe.Pointer(t))
	case 14:
		return (*ComprehensionIfTree)(unsafe.Pointer(t))
	case 15:
		return (*ComprehensionTree)(unsafe.Pointer(t))
	case 16:
		return (*ComputedPropertyDefinitionTree)(unsafe.Pointer(t))
	case 17:
		return (*ComputedPropertyFieldTree)(unsafe.Pointer(t))
	case 18:
		return (*ComputedPropertyGetterTree)(unsafe.Pointer(t))
	case 19:
		return (*ComputedPropertyMethodTree)(unsafe.Pointer(t))
	case 20:
		return (*ComputedPropertySetterTree)(unsafe.Pointer(t))
	case 21:
		return (*ConditionalExpressionTree)(unsafe.Pointer(t))
	case 22:
		return (*ContinueStatementTree)(unsafe.Pointer(t))
	case 23:
		return (*DebuggerStatementTree)(unsafe.Pointer(t))
	case 24:
		return (*DefaultClauseTree)(unsafe.Pointer(t))
	case 25:
		return (*DefaultParameterTree)(unsafe.Pointer(t))
	case 26:
		return (*DoWhileStatementTree)(unsafe.Pointer(t))
	case 27:
		return (*DynamicImportTree)(unsafe.Pointer(t))
	case 28:
		return (*EmptyStatementTree)(unsafe.Pointer(t))
	case 29:
		return (*ExportDeclarationTree)(unsafe.Pointer(t))
	case 30:
		return (*ExportSpecifierTree)(unsafe.Pointer(t))
	case 31:
		return (*ExpressionStatementTree)(unsafe.Pointer(t))
	case 32:
		return (*FieldDeclarationTree)(unsafe.Pointer(t))
	case 33:
		return (*FinallyTree)(unsafe.Pointer(t))
	case 34:
		return (*ForAwaitOfStatementTree)(unsafe.Pointer(t))
	case 35:
		return (*ForInStatementTree)(unsafe.Pointer(t))
	case 36:
		return (*ForOfStatementTree)(unsafe.Pointer(t))
	case 37:
		return (*ForStatementTree)(unsafe.Pointer(t))
	case 38:
		return (*FormalParameterListTree)(unsafe.Pointer(t))
	case 39:
		return (*FunctionDeclarationTree)(unsafe.Pointer(t))
	case 40:
		return (*GetAccessorTree)(unsafe.Pointer(t))
	case 41:
		return (*IdentifierExpressionTree)(unsafe.Pointer(t))
	case 42:
		return (*IfStatementTree)(unsafe.Pointer(t))
	case 43:
		return (*ImportDeclarationTree)(unsafe.Pointer(t))
	case 44:
		return (*ImportMetaExpressionTree)(unsafe.Pointer(t))
	case 45:
		return (*ImportSpecifierTree)(unsafe.Pointer(t))
	case 46:
		return (*IterRestTree)(unsafe.Pointer(t))
	case 47:
		return (*IterSpreadTree)(unsafe.Pointer(t))
	case 48:
		return (*LabelledStatementTree)(unsafe.Pointer(t))
	case 49:
		return (*LiteralExpressionTree)(unsafe.Pointer(t))
	case 50:
		return (*MemberExpressionTree)(unsafe.Pointer(t))
	case 51:
		return (*MemberLookupExpressionTree)(unsafe.Pointer(t))
	case 52:
		return (*MissingPrimaryExpressionTree)(unsafe.Pointer(t))
	case 53:
		return (*NewExpressionTree)(unsafe.Pointer(t))
	case 54:
		return (*NewTargetExpressionTree)(unsafe.Pointer(t))
	case 55:
		return (*NullTree)(unsafe.Pointer(t))
	case 56:
		return (*ObjectLiteralExpressionTree)(unsafe.Pointer(t))
	case 57:
		return (*ObjectPatternTree)(unsafe.Pointer(t))
	case 58:
		return (*ObjectRestTree)(unsafe.Pointer(t))
	case 59:
		return (*ObjectSpreadTree)(unsafe.Pointer(t))
	case 60:
		return (*OptChainCallExpressionTree)(unsafe.Pointer(t))
	case 61:
		return (*OptionalMemberExpressionTree)(unsafe.Pointer(t))
	case 62:
		return (*OptionalMemberLookupExpressionTree)(unsafe.Pointer(t))
	case 63:
		return (*ParenExpressionTree)(unsafe.Pointer(t))
	case 64:
		return (*ProgramTree)(unsafe.Pointer(t))
	case 65:
		return (*PropertyNameAssignmentTree)(unsafe.Pointer(t))
	case 66:
		return (*ReturnStatementTree)(unsafe.Pointer(t))
	case 67:
		return (*SetAccessorTree)(unsafe.Pointer(t))
	case 68:
		return (*SuperExpressionTree)(unsafe.Pointer(t))
	case 69:
		return (*SwitchStatementTree)(unsafe.Pointer(t))
	case 70:
		return (*TemplateLiteralExpressionTree)(unsafe.Pointer(t))
	case 71:
		return (*TemplateLiteralPortionTree)(unsafe.Pointer(t))
	case 72:
		return (*TemplateSubstitutionTree)(unsafe.Pointer(t))
	case 73:
		return (*ThisExpressionTree)(unsafe.Pointer(t))
	case 74:
		return (*ThrowStatementTree)(unsafe.Pointer(t))
	case 75:
		return (*TryStatementTree)(unsafe.Pointer(t))
	case 76:
		return (*UnaryExpressionTree)(unsafe.Pointer(t))
	case 77:
		return (*UpdateExpressionTree)(unsafe.Pointer(t))
	case 78:
		return (*VariableDeclarationListTree)(unsafe.Pointer(t))
	case 79:
		return (*VariableDeclarationTree)(unsafe.Pointer(t))
	case 80:
		return (*VariableStatementTree)(unsafe.Pointer(t))
	case 81:
		return (*WhileStatementTree)(unsafe.Pointer(t))
	case 82:
		return (*WithStatementTree)(unsafe.Pointer(t))
	case 83:
		return (*YieldExpressionTree)(unsafe.Pointer(t))
	default:
		panic("invalid parser self kind")
	}
}
func (t *ArrayLiteralExpressionTree) AsArrayLiteralExpression() *ArrayLiteralExpressionTree { return t }
func (t *ArrayPatternTree) AsArrayPattern() *ArrayPatternTree                               { return t }
func (t *BinaryOperatorTree) AsBinaryOperator() *BinaryOperatorTree                         { return t }
func (t *BlockTree) AsBlock() *BlockTree                                                    { return t }
func (t *BreakStatementTree) AsBreakStatement() *BreakStatementTree                         { return t }
func (t *CallExpressionTree) AsCallExpression() *CallExpressionTree                         { return t }
func (t *OptChainCallExpressionTree) AsOptChainCallExpression() *OptChainCallExpressionTree { return t }
func (t *CaseClauseTree) AsCaseClause() *CaseClauseTree                                     { return t }
func (t *CatchTree) AsCatch() *CatchTree                                                    { return t }
func (t *ClassDeclarationTree) AsClassDeclaration() *ClassDeclarationTree                   { return t }
func (t *CommaExpressionTree) AsCommaExpression() *CommaExpressionTree                      { return t }
func (t *ComprehensionIfTree) AsComprehensionIf() *ComprehensionIfTree                      { return t }
func (t *ComprehensionForTree) AsComprehensionFor() *ComprehensionForTree                   { return t }
func (t *ComprehensionTree) AsComprehension() *ComprehensionTree                            { return t }
func (t *ComputedPropertyDefinitionTree) AsComputedPropertyDefinition() *ComputedPropertyDefinitionTree {
	return t
}
func (t *ComputedPropertyFieldTree) AsComputedPropertyField() *ComputedPropertyFieldTree    { return t }
func (t *ComputedPropertyGetterTree) AsComputedPropertyGetter() *ComputedPropertyGetterTree { return t }
func (t *ComputedPropertyMethodTree) AsComputedPropertyMethod() *ComputedPropertyMethodTree { return t }
func (t *ComputedPropertySetterTree) AsComputedPropertySetter() *ComputedPropertySetterTree { return t }
func (t *ConditionalExpressionTree) AsConditionalExpression() *ConditionalExpressionTree    { return t }
func (t *ContinueStatementTree) AsContinueStatement() *ContinueStatementTree                { return t }
func (t *DebuggerStatementTree) AsDebuggerStatement() *DebuggerStatementTree                { return t }
func (t *DefaultClauseTree) AsDefaultClause() *DefaultClauseTree                            { return t }
func (t *DefaultParameterTree) AsDefaultParameter() *DefaultParameterTree                   { return t }
func (t *DoWhileStatementTree) AsDoWhileStatement() *DoWhileStatementTree                   { return t }
func (t *EmptyStatementTree) AsEmptyStatement() *EmptyStatementTree                         { return t }
func (t *ExportDeclarationTree) AsExportDeclaration() *ExportDeclarationTree                { return t }
func (t *ExportSpecifierTree) AsExportSpecifier() *ExportSpecifierTree                      { return t }
func (t *ExpressionStatementTree) AsExpressionStatement() *ExpressionStatementTree          { return t }
func (t *FinallyTree) AsFinally() *FinallyTree                                              { return t }
func (t *ForOfStatementTree) AsForOfStatement() *ForOfStatementTree                         { return t }
func (t *ForInStatementTree) AsForInStatement() *ForInStatementTree                         { return t }
func (t *FormalParameterListTree) AsFormalParameterList() *FormalParameterListTree          { return t }
func (t *ForStatementTree) AsForStatement() *ForStatementTree                               { return t }
func (t *FunctionDeclarationTree) AsFunctionDeclaration() *FunctionDeclarationTree          { return t }
func (t *GetAccessorTree) AsGetAccessor() *GetAccessorTree                                  { return t }
func (t *IdentifierExpressionTree) AsIdentifierExpression() *IdentifierExpressionTree       { return t }
func (t *IfStatementTree) AsIfStatement() *IfStatementTree                                  { return t }
func (t *ImportDeclarationTree) AsImportDeclaration() *ImportDeclarationTree                { return t }
func (t *ImportSpecifierTree) AsImportSpecifier() *ImportSpecifierTree                      { return t }
func (t *DynamicImportTree) AsDynamicImportExpression() *DynamicImportTree                  { return t }
func (t *ImportMetaExpressionTree) AsImportMetaExpression() *ImportMetaExpressionTree       { return t }
func (t *LabelledStatementTree) AsLabelledStatement() *LabelledStatementTree                { return t }
func (t *LiteralExpressionTree) AsLiteralExpression() *LiteralExpressionTree                { return t }
func (t *MemberExpressionTree) AsMemberExpression() *MemberExpressionTree                   { return t }
func (t *OptionalMemberExpressionTree) AsOptionalMemberExpression() *OptionalMemberExpressionTree {
	return t
}
func (t *MemberLookupExpressionTree) AsMemberLookupExpression() *MemberLookupExpressionTree { return t }
func (t *OptionalMemberLookupExpressionTree) AsOptionalMemberLookupExpression() *OptionalMemberLookupExpressionTree {
	return t
}
func (t *MissingPrimaryExpressionTree) AsMissingPrimaryExpression() *MissingPrimaryExpressionTree {
	return t
}
func (t *NewExpressionTree) AsNewExpression() *NewExpressionTree { return t }
func (t *NullTree) AsNull() *NullTree                            { return t }
func (t *ObjectLiteralExpressionTree) AsObjectLiteralExpression() *ObjectLiteralExpressionTree {
	return t
}
func (t *ObjectPatternTree) AsObjectPattern() *ObjectPatternTree                            { return t }
func (t *ParenExpressionTree) AsParenExpression() *ParenExpressionTree                      { return t }
func (t *ProgramTree) AsProgram() *ProgramTree                                              { return t }
func (t *PropertyNameAssignmentTree) AsPropertyNameAssignment() *PropertyNameAssignmentTree { return t }
func (t *IterRestTree) AsIterRest() *IterRestTree                                           { return t }
func (t *ObjectRestTree) AsObjectRest() *ObjectRestTree                                     { return t }
func (t *ReturnStatementTree) AsReturnStatement() *ReturnStatementTree                      { return t }
func (t *SetAccessorTree) AsSetAccessor() *SetAccessorTree                                  { return t }
func (t *IterSpreadTree) AsIterSpread() *IterSpreadTree                                     { return t }
func (t *ObjectSpreadTree) AsObjectSpread() *ObjectSpreadTree                               { return t }
func (t *SuperExpressionTree) AsSuperExpression() *SuperExpressionTree                      { return t }
func (t *SwitchStatementTree) AsSwitchStatement() *SwitchStatementTree                      { return t }
func (t *TemplateLiteralExpressionTree) AsTemplateLiteralExpression() *TemplateLiteralExpressionTree {
	return t
}
func (t *TemplateLiteralPortionTree) AsTemplateLiteralPortion() *TemplateLiteralPortionTree { return t }
func (t *TemplateSubstitutionTree) AsTemplateSubstitution() *TemplateSubstitutionTree       { return t }
func (t *ThisExpressionTree) AsThisExpression() *ThisExpressionTree                         { return t }
func (t *ThrowStatementTree) AsThrowStatement() *ThrowStatementTree                         { return t }
func (t *TryStatementTree) AsTryStatement() *TryStatementTree                               { return t }
func (t *UnaryExpressionTree) AsUnaryExpression() *UnaryExpressionTree                      { return t }
func (t *VariableDeclarationListTree) AsVariableDeclarationList() *VariableDeclarationListTree {
	return t
}
func (t *VariableDeclarationTree) AsVariableDeclaration() *VariableDeclarationTree { return t }
func (t *VariableStatementTree) AsVariableStatement() *VariableStatementTree       { return t }
func (t *WhileStatementTree) AsWhileStatement() *WhileStatementTree                { return t }
func (t *WithStatementTree) AsWithStatement() *WithStatementTree                   { return t }
func (t *YieldExpressionTree) AsYieldStatement() *YieldExpressionTree              { return t }
func (t *AwaitExpressionTree) AsAwaitExpression() *AwaitExpressionTree             { return t }
func (t *NewTargetExpressionTree) AsNewTargetExpression() *NewTargetExpressionTree { return t }
func (t *UpdateExpressionTree) AsUpdateExpression() *UpdateExpressionTree          { return t }
func (t *ForAwaitOfStatementTree) AsForAwaitOfStatement() *ForAwaitOfStatementTree { return t }
func (t *FieldDeclarationTree) AsFieldDeclaration() *FieldDeclarationTree          { return t }
func (t *TokenBase) setSelf(self Token) {
	switch self.(type) {
	case nil:
		t.selfKind = 0
	case *IdentifierToken:
		t.selfKind = 1
	case *LiteralTokenBase:
		t.selfKind = 2
	case *StringLiteralToken:
		t.selfKind = 3
	case *TemplateLiteralToken:
		t.selfKind = 4
	case *TokenBase:
		t.selfKind = 5
	default:
		panic("unregistered parser subclass")
	}
}
func (t *TokenBase) getSelf() Token {
	switch t.selfKind {
	case 0:
		return nil
	case 1:
		return (*IdentifierToken)(unsafe.Pointer(t))
	case 2:
		return (*LiteralTokenBase)(unsafe.Pointer(t))
	case 3:
		return (*StringLiteralToken)(unsafe.Pointer(t))
	case 4:
		return (*TemplateLiteralToken)(unsafe.Pointer(t))
	case 5:
		return (*TokenBase)(unsafe.Pointer(t))
	default:
		panic("invalid parser self kind")
	}
}
func (t *IdentifierToken) AsIdentifier() *IdentifierToken                { return t }
func (t *LiteralTokenBase) AsLiteral() LiteralToken                      { return t }
func (t *StringLiteralToken) AsLiteral() LiteralToken                    { return t }
func (t *TemplateLiteralToken) AsLiteral() LiteralToken                  { return t }
func (t *TemplateLiteralToken) AsTemplateLiteral() *TemplateLiteralToken { return t }
