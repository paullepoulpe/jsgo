package parser

import (
	"fmt"
	"strings"
	"testing"
)

var benchmarkParserProgram *ProgramTree

// This exercises ordinary parser construction, including source ranges and
// tokens, rather than benchmarking the allocator in isolation.
func BenchmarkParserTreeStorage(b *testing.B) {
	for _, count := range []int{1, 256} {
		b.Run(fmt.Sprintf("functions_%d", count), func(b *testing.B) {
			var source strings.Builder
			for i := 0; i < count; i++ {
				fmt.Fprintf(&source, "function f%d(a) { var value = (a.member + 3) * call(a); value = value + a.other; return value; }\n", i)
			}
			file := NewSourceFile("bench.js", source.String())
			config := defaultParserConfig()
			b.ReportAllocs()
			b.SetBytes(int64(source.Len()))
			b.ResetTimer()
			for i := 0; i < b.N; i++ {
				reporter := newRecordingErrorReporter(file)
				p := NewParser(config, reporter, file)
				benchmarkParserProgram = p.ParseProgram()
				if len(reporter.lines) != 0 {
					b.Fatal(reporter.lines)
				}
			}
		})
	}
}
