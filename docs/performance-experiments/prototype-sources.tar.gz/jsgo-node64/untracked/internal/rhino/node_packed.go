package rhino

import "unsafe"

// Go-only: language-adapter — preserve Java's full token and int length ranges
// with a compact common representation. Rare overflows live in the payload;
// every link and payload remains a Go GC-tracked pointer.
const (
	nodeMetaTokenMask           uint32    = 255
	nodeMetaKindMask            uint32    = 7 << 8
	nodeMetaColor               uint32    = 1 << 11
	nodeMetaLengthMax           uint32    = (1 << 20) - 1
	nodeStringOriginalSame      node_kind = 5
	nodeStringOriginalDifferent node_kind = 6
	nodeStringExtended          node_kind = 7
)

type node_stringData struct{ str, originalName *string }
type node_stringMeta struct {
	node_stringData
	length int32
	token  Token
}

func (n *Node) storageKind() node_kind { return node_kind((n.meta >> 8) & 7) }
func (n *Node) nodeKind() node_kind {
	k := n.storageKind()
	if k >= nodeStringOriginalSame {
		return node_kindString
	}
	return k
}
func (n *Node) setStorageKind(k node_kind) { n.meta = (n.meta &^ nodeMetaKindMask) | (uint32(k) << 8) }
func (n *Node) setNodeKind(k node_kind) {
	if k == node_kindString && n.payload != nil && n.nodeKind() != node_kindString {
		ext := n.nodeExt()
		m := &node_stringMeta{node_stringData: node_stringData{originalName: ext.originalName}, length: ext.length, token: ext.token}
		n.payload = unsafe.Pointer(m)
		n.setStorageKind(nodeStringExtended)
		return
	}
	n.setStorageKind(k)
}
func (n *Node) nodeColorTag() bool { return n.meta&nodeMetaColor != 0 }
func (n *Node) setNodeColorTag(value bool) {
	if value {
		n.meta |= nodeMetaColor
	} else {
		n.meta &^= nodeMetaColor
	}
}
func (n *Node) nodeExt() *node_ext { return (*node_ext)(n.payload) }
func (n *Node) node_getExt() *node_ext {
	if n.payload == nil {
		n.payload = unsafe.Pointer(&node_ext{})
	}
	return n.nodeExt()
}
func (n *Node) stringMeta() *node_stringMeta {
	if n.storageKind() != nodeStringExtended {
		m := &node_stringMeta{node_stringData: node_stringData{str: n.nodeStringCell(), originalName: n.node_originalName()}}
		n.payload = unsafe.Pointer(m)
		n.setStorageKind(nodeStringExtended)
	}
	return (*node_stringMeta)(n.payload)
}
func (n *Node) packedToken() Token {
	t := Token(n.meta & nodeMetaTokenMask)
	if t != 255 {
		return t
	}
	if n.nodeKind() == node_kindString {
		return (*node_stringMeta)(n.payload).token
	}
	return n.nodeExt().token
}
func (n *Node) setPackedToken(t Token) {
	n.meta &^= nodeMetaTokenMask
	if t >= 0 && t < 255 {
		n.meta |= uint32(t)
		return
	}
	n.meta |= 255
	if n.nodeKind() == node_kindString {
		n.stringMeta().token = t
	} else {
		n.node_getExt().token = t
	}
}
func (n *Node) packedLength() int {
	v := n.meta >> 12
	if v != nodeMetaLengthMax {
		return int(v)
	}
	if n.nodeKind() == node_kindString {
		return int((*node_stringMeta)(n.payload).length)
	}
	return int(n.nodeExt().length)
}
func (n *Node) setPackedLength(value int) {
	length := int32(value)
	n.meta &= 0xfff
	if length >= 0 && uint32(length) < nodeMetaLengthMax {
		n.meta |= uint32(length) << 12
		return
	}
	n.meta |= nodeMetaLengthMax << 12
	if n.nodeKind() == node_kindString {
		n.stringMeta().length = length
	} else {
		n.node_getExt().length = length
	}
}
func (n *Node) nodeStringCell() *string {
	switch n.storageKind() {
	case node_kindString, nodeStringOriginalSame:
		return (*string)(n.payload)
	case nodeStringOriginalDifferent:
		return (*node_stringData)(n.payload).str
	case nodeStringExtended:
		return (*node_stringMeta)(n.payload).str
	case node_kindTemplateLiteralSubstring:
		if n.payload != nil {
			return n.nodeExt().str
		}
	}
	return nil
}
func nodeCellValue(p *string) string {
	if p == nil {
		return ""
	}
	return *p
}
func (n *Node) nodeStringValue() string { return nodeCellValue(n.nodeStringCell()) }
func (n *Node) setNodeStringCell(value *string) {
	switch n.storageKind() {
	case node_kindString:
		n.payload = unsafe.Pointer(value)
	case nodeStringOriginalSame:
		original := (*string)(n.payload)
		if nodeCellValue(original) == nodeCellValue(value) {
			n.payload = unsafe.Pointer(value)
		} else {
			n.payload = unsafe.Pointer(&node_stringData{value, original})
			n.setStorageKind(nodeStringOriginalDifferent)
		}
	case nodeStringOriginalDifferent:
		data := (*node_stringData)(n.payload)
		if nodeCellValue(value) == nodeCellValue(data.originalName) {
			n.payload = unsafe.Pointer(value)
			n.setStorageKind(nodeStringOriginalSame)
		} else {
			data.str = value
		}
	case nodeStringExtended:
		(*node_stringMeta)(n.payload).str = value
	case node_kindTemplateLiteralSubstring:
		n.node_getExt().str = value
	}
}
func (n *Node) node_originalName() *string {
	switch n.storageKind() {
	case node_kindString:
		return nil
	case nodeStringOriginalSame:
		return (*string)(n.payload)
	case nodeStringOriginalDifferent:
		return (*node_stringData)(n.payload).originalName
	case nodeStringExtended:
		return (*node_stringMeta)(n.payload).originalName
	default:
		if n.payload != nil {
			return n.nodeExt().originalName
		}
	}
	return nil
}
func (n *Node) node_setOriginalName(value *string) {
	if n.nodeKind() != node_kindString {
		if value != nil {
			n.node_getExt().originalName = value
		} else if n.payload != nil {
			n.nodeExt().originalName = nil
		}
		return
	}
	if n.storageKind() == nodeStringExtended {
		(*node_stringMeta)(n.payload).originalName = value
		return
	}
	cell := n.nodeStringCell()
	if value == nil {
		n.payload = unsafe.Pointer(cell)
		n.setStorageKind(node_kindString)
	} else if *value == nodeCellValue(cell) {
		if cell == nil {
			cell = rhinoStringPoolCell("")
		}
		n.payload = unsafe.Pointer(cell)
		n.setStorageKind(nodeStringOriginalSame)
	} else {
		n.payload = unsafe.Pointer(&node_stringData{cell, value})
		n.setStorageKind(nodeStringOriginalDifferent)
	}
}
func (n *Node) copyPackedPayloadTo(dest *Node) {
	if n.payload == nil {
		return
	}
	switch n.storageKind() {
	case node_kindString, nodeStringOriginalSame: // immutable shared string header
	case nodeStringOriginalDifferent:
		data := *(*node_stringData)(n.payload)
		dest.payload = unsafe.Pointer(&data)
	case nodeStringExtended:
		data := *(*node_stringMeta)(n.payload)
		dest.payload = unsafe.Pointer(&data)
	default:
		data := *n.nodeExt()
		dest.payload = unsafe.Pointer(&data)
	}
}
