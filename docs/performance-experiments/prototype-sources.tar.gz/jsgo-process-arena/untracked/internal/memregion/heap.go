//go:build !goexperiment.arenas

package memregion

// EnableProcessArena is a no-op in ordinary builds. The experiment is compiled
// only with GOEXPERIMENT=arenas and enabled only by the one-shot CLI entry point.
func EnableProcessArena()        {}
func Enabled() bool              { return false }
func New[T any]() *T             { return new(T) }
func MakeSlice[T any](n int) []T { return make([]T, n) }
