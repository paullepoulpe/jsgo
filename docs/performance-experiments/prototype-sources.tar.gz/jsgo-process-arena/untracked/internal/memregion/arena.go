//go:build goexperiment.arenas

package memregion

import (
	"arena"
	"sync"
	"sync/atomic"
)

// Go-only: performance experiment — the one-shot CLI can use a process-lifetime
// allocation region. It is deliberately never freed early: AST references may
// escape through diagnostics and caches. Process exit releases it. Library and
// worker entry points do not enable it. This trades more peak memory for bump
// allocation and fewer individually managed heap objects.
var processRegion struct {
	sync.Mutex
	arena  *arena.Arena
	active atomic.Bool
}

func EnableProcessArena() {
	processRegion.Lock()
	defer processRegion.Unlock()
	if processRegion.arena == nil {
		processRegion.arena = arena.NewArena()
	}
	processRegion.active.Store(true)
}
func Enabled() bool { return processRegion.active.Load() }
func New[T any]() *T {
	if !Enabled() {
		return new(T)
	}
	processRegion.Lock()
	p := arena.New[T](processRegion.arena)
	processRegion.Unlock()
	return p
}
func MakeSlice[T any](n int) []T {
	if !Enabled() {
		return make([]T, n)
	}
	processRegion.Lock()
	p := arena.MakeSlice[T](processRegion.arena, n, n)
	processRegion.Unlock()
	return p
}
