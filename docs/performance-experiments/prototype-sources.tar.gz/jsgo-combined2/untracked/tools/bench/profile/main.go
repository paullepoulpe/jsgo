// Command profile runs the real compiler with CPU/allocation profiling and
// an intercepted exit receiver. It does not modify the compiler or runtime
// settings. Build with -pgo=cmd/jsgo/default.pgo to profile the PGO build.
package main

import (
	"os"
	"runtime/pprof"

	"github.com/paullepoulpe/jsgo/internal/jscomp"
	"github.com/paullepoulpe/jsgo/internal/jutil"
)

func main() {
	if len(os.Args) < 4 {
		panic("usage: profile CPU_FILE ALLOCS_FILE|- CLOSURE_ARGS...")
	}
	cpu, err := os.Create(os.Args[1])
	if err != nil {
		panic(err)
	}
	if err = pprof.StartCPUProfile(cpu); err != nil {
		panic(err)
	}
	status := run(os.Args[3:])
	pprof.StopCPUProfile()
	if err = cpu.Close(); err != nil {
		panic(err)
	}
	if os.Args[2] != "-" {
		allocs, err := os.Create(os.Args[2])
		if err != nil {
			panic(err)
		}
		if err = pprof.Lookup("allocs").WriteTo(allocs, 0); err != nil {
			panic(err)
		}
		if err = allocs.Close(); err != nil {
			panic(err)
		}
	}
	os.Exit(status)
}

func run(args []string) (status int) {
	jutil.System_SetErr(jutil.NewPrintStreamWithCharset(os.Stderr, jutil.System_NativeCharset()))
	jscomp.PhaseOptimizer_logger.SetLevel(jutil.Level_OFF)
	defer func() {
		if r := recover(); r != nil {
			t, ok := r.(jutil.Throwable)
			if !ok {
				t = jutil.AsThrowable(r)
			}
			err := jutil.System_Err()
			err.Print("Exception in thread \"main\" ")
			jutil.Throwable_PrintStackTrace(t, err)
			err.Flush()
			status = 1
		}
	}()
	runner := jscomp.NewCommandLineRunner(args)
	if runner.ShouldRunCompiler() {
		runner.SetExitCodeReceiver(func(code int) { status = int(uint8(code)) })
		runner.Run()
	} else if runner.HasErrors() {
		status = 255
	}
	return
}
