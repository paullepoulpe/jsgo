#!/usr/bin/env python3
"""Generate an untimed, callback-preserving exact-key equality/hash audit overlay."""
import argparse, hashlib, json, subprocess
from pathlib import Path
p=argparse.ArgumentParser();p.add_argument('--repo',type=Path,required=True);p.add_argument('--out',type=Path,required=True);a=p.parse_args();repo=a.repo.resolve();out=a.out.resolve();out.mkdir(parents=True,exist_ok=True)
assert not subprocess.check_output(['git','status','--porcelain'],cwd=repo,text=True).strip(),'use a clean frozen worktree'
commit=subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip();replacements={};counts={}
def replace(s,old,new,key):
 assert s.count(old)==1,(key,s.count(old));counts[key]=1;return s.replace(old,new)
objects=repo/'internal/jutil/objects.go';s=objects.read_text();s=replace(s,'import (','import (\n "encoding/json"\n "os"\n "sync/atomic"','imports')
for name,args,site in [('ObjectsEquals','a, b any',1),('ObjectsEqualsOf[T any]','a, b T',0)]:
 old=f'func {name}({args}) bool {{';s=replace(s,old,old+f'\n diagnosticIdentityKeyOperation(any(a), any(b), {site})','observe_'+name)
for name,args,site in [('ObjectHashCode','v any',3),('ObjectHashCodeOf[T any]','v T',2)]:
 old=f'func {name}({args}) int32 {{';s=replace(s,old,old+f'\n diagnosticIdentityKeyOperation(any(v), nil, {site})','observe_'+name)
s+='''
// Diagnostic overlay only. No equality/hash callback is skipped or added.
// Counts at Of and dynamic sites overlap when Of delegates; never sum them.
type diagnosticIdentityKeyCounters struct {
 Calls, SameNonNull, DistinctNonNull, BothNil, OneNil, DifferentType atomic.Uint64
}
var diagnosticIdentityKeys [4][5]diagnosticIdentityKeyCounters
var diagnosticIdentityKeyNames = [5]string{"jscomp.Var", "jscomp.TypedVar", "jscomp.Scope", "jscomp.TypedScope", "rhino.Node"}
func diagnosticIdentityKeyOperation(a, b any, site int) {
 t := reflect.TypeOf(a)
 if t == nil || t.Kind() != reflect.Pointer { return }
 elem := t.Elem()
 id := -1
 switch elem.PkgPath() {
 case "github.com/paullepoulpe/jsgo/internal/jscomp":
  switch elem.Name() { case "Var": id=0; case "TypedVar": id=1; case "Scope": id=2; case "TypedScope": id=3 }
 case "github.com/paullepoulpe/jsgo/internal/rhino":
  if elem.Name()=="Node" { id=4 }
 }
 if id<0 { return }
 c:=&diagnosticIdentityKeys[site][id]
 c.Calls.Add(1)
 anil:=reflect.ValueOf(a).IsNil()
 if site>=2 { if anil {c.OneNil.Add(1)}; return }
 if reflect.TypeOf(b)!=t {c.DifferentType.Add(1);return}
 bnil:=reflect.ValueOf(b).IsNil()
 switch {
 case anil && bnil:c.BothNil.Add(1)
 case anil || bnil:c.OneNil.Add(1)
 case a==b:c.SameNonNull.Add(1)
 default:c.DistinctNonNull.Add(1)
 }
}
func WriteDiagnosticIdentityKeyAudit(path string) error {
 if path=="" {return nil}
 sites:=[4]string{"ObjectsEqualsOf","ObjectsEquals","ObjectHashCodeOf","ObjectHashCode"}
 rows:=map[string]map[string]map[string]uint64{}
 for site,name:=range sites {
  rows[name]=map[string]map[string]uint64{}
  for id,key:=range diagnosticIdentityKeyNames {
   c:=&diagnosticIdentityKeys[site][id]
   rows[name][key]=map[string]uint64{"calls":c.Calls.Load(),"same_nonnull_pointer":c.SameNonNull.Load(),"distinct_nonnull_pointers":c.DistinctNonNull.Load(),"both_nil":c.BothNil.Load(),"one_nil":c.OneNil.Load(),"different_dynamic_type":c.DifferentType.Load()}
  }
 }
 f,e:=os.Create(path);if e!=nil{return e};defer f.Close()
 return json.NewEncoder(f).Encode(map[string]any{"schema":1,"method":"untimed exact-concrete-key counts; original equality/hash callbacks unchanged","sites_overlap":"Of fallback calls also appear in dynamic site counts; do not sum","keys":"exact package+concrete pointer type; embedded/custom/aliased named types excluded","rows":rows})
}
'''
target=out/'objects.go';target.write_text(s);replacements[str(objects)]=str(target)
main=repo/'cmd/jsgo/main.go';s=main.read_text();s=replace(s,'jscomp.CommandLineRunner_Main(os.Args[1:])','''runner := jscomp.NewCommandLineRunner(os.Args[1:])
 code := 0
 runner.SetExitCodeReceiver(func(c int) { code = c })
 if runner.ShouldRunCompiler() { runner.Run() }
 if runner.HasErrors() { code = -1 }
 if err := jutil.WriteDiagnosticIdentityKeyAudit(os.Getenv("JSGO_IDENTITY_KEY_AUDIT_OUT")); err != nil { panic(err) }
 os.Exit(code)''','main_capture')
target=out/'main.go';target.write_text(s);replacements[str(main)]=str(target)
subprocess.check_call(['/workspace/toolchains/go1.27.2/bin/gofmt','-w',*replacements.values()]);overlay=out/'overlay.json';overlay.write_text(json.dumps({'Replace':replacements},indent=2)+'\n')
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
manifest={'source_repo':str(repo),'source_commit':commit,'overlay':str(overlay),'overlay_sha256':sha(overlay),'generator':str(Path(__file__).resolve()),'generator_sha256':sha(__file__),'callsite_counts':counts,'tracing_or_gc_settings_changed':False,'no_production_edits':True,'output_env':'JSGO_IDENTITY_KEY_AUDIT_OUT','measurement':'diagnostic counts only; never use this binary for timing/memory comparisons or PGO','files':[{'source':k,'source_sha256':sha(k),'replacement':v,'replacement_sha256':sha(v)} for k,v in replacements.items()],'limitations':['Counters add atomics/reflection/interface boxing; compile/runtime behavior and allocation differ; no performance result is supported.','Of fallback calls also appear in dynamic ObjectsEquals/ObjectHashCode counters; count sites separately.','Exact stock concrete names classify types, not constructor ownership or initialized invariants; this is evidence gathering only.','Bytegate stdout/stderr/exit/artifacts before interpreting counts.','No Equals/HashCode callbacks or invocation order are changed by observation.']}
(out/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n');print(json.dumps({'overlay':str(overlay),'source_commit':commit,'files':len(replacements)},indent=2))
