#!/usr/bin/env python3
"""Reduce test declarations only; keep real package/import path/production files."""
import argparse
import hashlib
import json
import re
import subprocess
from pathlib import Path

parser = argparse.ArgumentParser()
parser.add_argument('--root', type=Path, default=Path('/workspace/jsgo-post-colors-design-integration'))
args = parser.parse_args()
root = args.root.resolve()
out = Path(__file__).resolve().parent
package = root / 'internal/jscomp'
keep = {
    'inline_candidate_kernel_test.go',
    'native_live_phase_admission_test.go',
    'post_colors_native_admission_test.go',
    'remove_unused_stock_colors_test.go',
    'native_array_unknown_recipe_test.go',
    'parallel_commonjs_test.go',
    'fsiv_use_cardinality_test.go',
    'truth_test.go',
    'fresh_template_guard_test.go',
    'fresh_template_values_test.go',
    'scope_first_allocation_test.go',
    'native_output_buffer_test.go',
    'native_live_variables_test.go',
    'contextual_inverter_compact_test.go',
    'scope_recipes_test.go',
    'stock_scope_insertion_test.go',
    'native_leaf_traversal_test.go',
    'remove_unused_code_work_elision_test.go',
    'test_compiler_test.go',
    'testing_test_externs_builder_test.go',
    'remove_unused_intrusive_test.go',
    'parallel_peephole_test.go',
    'access_control_property_facts_test.go',
    'remove_unused_tasks_test.go',
    'native_typed_variables_test.go',
    'typed_inference_scope_schedule_test.go',
    'inline_direct_reference_worklist_test.go',
    'inline_discovery_chunks_test.go',
    'inline_callee_facts_test.go',
    'inline_argument_facts_test.go',
    'parallel_fsiv_test.go',
    'coding_convention_safety_test.go',
    'fsiv_scope_sharing_test.go',
    'deps_module_names_optimization_test.go',
    'contextual_inverter_noop_test.go',
    'empty_block_scoped_test.go',
    'empty_denormalize_test.go',
    'reference_batches_test.go',
    'reference_batches_lifetime_test.go',
    'reference_collector_native_storage_test.go',
    'parallel_coalesce_test.go',
    'inline_reference_discovery_tape_test.go',
    'source_file_cli_lock_test.go',
    'typed_initial_analysis_fusion_test.go',
    'native_dependency_scan_test.go',
}
for name in keep:
    if not (package / name).is_file():
        raise SystemExit('missing retained test: ' + name)

stub = out / 'excluded_test.go'
stub.write_text('package jscomp\n')

# Retain these three original helpers verbatim, without pulling in the large
# JUnit/assertion test-support dependency graph of the surrounding suite.
source = (package / 'function_argument_injector_test.go').read_text()
notice = source[:source.index('package jscomp')]
helpers = []
for name in ['FunctionArgumentInjectorTest_GetNameSupplier',
             'FunctionArgumentInjectorTest_FindCall',
             'FunctionArgumentInjectorTest_FindFunction']:
    match = re.search(r'^func ' + name + r'\([\s\S]*?^}\n', source, re.M)
    if match is None:
        raise SystemExit('missing helper ' + name)
    helpers.append(match.group())
helper_file = out / 'retained_helpers_test.go'
helper_file.write_text(notice + '''package jscomp

import (
 "fmt"
 "io"
 "strings"
 "github.com/paullepoulpe/jsgo/internal/jutil"
 "github.com/paullepoulpe/jsgo/internal/rhino"
)

''' + '\n'.join(helpers))

collector_source = (package / 'core_g3_oracle_test.go').read_text()
collector = collector_source.split('type coreG3Collector struct {', 1)[1].split('// coreG3DepInfo', 1)[0]
helper_file.write_text(helper_file.read_text() + '\n' + 'type coreG3Collector struct {' + collector)

typed_source = (package / 'typed_scope_creator_oracle_test.go').read_text()
for name in ['typedScopeDump_varLine', 'typedScopeDump_simpleClassName', 'typedScopeDump_typeString', 'typedScopeDump_pos']:
    match = re.search(r'^func ' + name + r'\([\s\S]*?^}\n', typed_source, re.M)
    if match is None:
        raise SystemExit('missing helper ' + name)
    helper_file.write_text(helper_file.read_text() + '\n' + match.group())

oracle_source = (package / 'remove_unused_oracle_test.go').read_text()
for name in ['removeUnusedOracleOptions', 'removeUnusedOracleNewCompiler', 'removeUnusedOraclePrepare']:
    match = re.search(r'^func ' + name + r'\([\s\S]*?^}\n', oracle_source, re.M)
    assert match, name
    helper_file.write_text(helper_file.read_text()+'\n'+match.group())
match = re.search(r'^var removeUnusedOracleExterns = [\s\S]*?^}, "\\n"\)\n', oracle_source, re.M)
assert match, 'removeUnusedOracleExterns'
helper_file.write_text(helper_file.read_text()+'\n'+match.group())
compiler_source = (package/'compiler_test_case_test.go').read_text()
match = re.search(r'^var CompilerTestCase_DEFAULT_EXTERNS = [\s\S]*?\n\tBuild\(\)\n', compiler_source, re.M)
assert match, 'default externs'
helper_file.write_text(helper_file.read_text()+'\n'+match.group()+'\nvar CompilerTypeTestCase_DEFAULT_EXTERNS = CompilerTestCase_DEFAULT_EXTERNS\n')

scope_helpers = (package/'scope_test_helpers_test.go').read_text()
match = re.search(r'^func scopeTestNewCompiler\([\s\S]*?^}\n', scope_helpers, re.M)
assert match
helper_file.write_text(helper_file.read_text()+'\n'+match.group())
# ReachingUseDefTester is a utility-only source, not a ported test suite.
# Copy exactly its declarations (and license) into an overlay-only helper file.
# Truth is retained as original helper support for its assertions, with no tests.
reaching_source = (package/'reaching_use_def_tester_test.go').read_text()
reaching_declarations = reaching_source.split('// ReachingUseDefTester is the utility', 1)[1]
reaching_declarations = '// ReachingUseDefTester is the utility' + reaching_declarations
helper_file.write_text(helper_file.read_text()+'\n'+reaching_source[:reaching_source.index('package jscomp')]+'\n'+reaching_declarations)
reaching_sha = hashlib.sha256(reaching_declarations.encode()).hexdigest()
# CommonJS tests depend on these four ModuleLoader helper declarations only.
module_source = (package/'deps_module_loader_test.go').read_text()
module_helpers = []
for name in ['jsaMlInputs', 'jsaMlInput', 'jsaMlPACKAGE_JSON_MAIN_ENTRIES', 'jsaMap']:
    match = re.search(r'^func ' + name + r'\([\s\S]*?^}\n', module_source, re.M)
    if match is None:
        raise SystemExit('missing CommonJS helper '+name)
    module_helpers.append(match.group())
helper_file.write_text(helper_file.read_text()+'\n'+module_source[:module_source.index('package jscomp')]+'\n'+'\n'.join(module_helpers))
replacements = {}
for path in sorted(package.glob('*_test.go')):
    if path.name not in keep:
        replacements[str(path)] = str(stub)
replacements[str(package / 'function_argument_injector_test.go')] = str(helper_file)
(out / 'overlay.json').write_text(json.dumps({'Replace': replacements}, indent=2) + '\n')
manifest = {
    'root': str(root),
    'source_commit': subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=root, text=True).strip(),
    'validated_test_replacements_only': all(name.endswith('_test.go') for name in replacements),
    'package_import_path': 'github.com/paullepoulpe/jsgo/internal/jscomp',
    'retained_original_tests': sorted(keep),
    'original_helpers_copied_verbatim': [h.split('(', 1)[0].removeprefix('func ') for h in helpers],
    'test_replacements': len(replacements),
    'production_replacements': 0,
    'reaching_helper_source_sha256': hashlib.sha256(reaching_source.encode()).hexdigest(),
    'reaching_helper_declarations_sha256': reaching_sha,
    'reaching_helper_declarations_verbatim': True,
    'commonjs_helper_source_sha256': hashlib.sha256(module_source.encode()).hexdigest(),
    'commonjs_helpers_verbatim_sha256': {h.split('(', 1)[0].removeprefix('func '): hashlib.sha256(h.encode()).hexdigest() for h in module_helpers},
    'overlay_helpers_sha256': hashlib.sha256(helper_file.read_bytes()).hexdigest(),
    'helper_extraction_source_sha256': {name: hashlib.sha256((package/name).read_bytes()).hexdigest() for name in ['function_argument_injector_test.go', 'core_g3_oracle_test.go', 'typed_scope_creator_oracle_test.go', 'remove_unused_oracle_test.go', 'compiler_test_case_test.go', 'scope_test_helpers_test.go', 'reaching_use_def_tester_test.go', 'deps_module_loader_test.go']},
    'retained_test_sha256': {name: hashlib.sha256((package/name).read_bytes()).hexdigest() for name in sorted(keep)},
}
(out / 'manifest.json').write_text(json.dumps(manifest, indent=2) + '\n')
print(json.dumps(manifest, indent=2))
