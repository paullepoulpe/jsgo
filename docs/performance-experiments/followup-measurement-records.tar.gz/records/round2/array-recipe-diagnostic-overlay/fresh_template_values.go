package jscomp

import (
	"os"

	"github.com/paullepoulpe/jsgo/internal/rhino"
)

func freshTemplateValuesEnabled() bool {
	return os.Getenv("JSGO_EXPERIMENT_FRESH_TEMPLATE_VALUES") == "1"
}

func nativeArrayUnknownRecipeEnabled() bool {
	return os.Getenv("JSGO_EXPERIMENT_ARRAY_UNKNOWN_RECIPE") == "1"
}

type freshTemplateValuesMode struct {
	owner              *Compiler
	root               *rhino.Node
	creator            *TypedScopeCreator
	registry           *rhino.JSTypeRegistry
	errorManager       ErrorManager
	errorCounter       *freshTemplateErrorCounter
	probe              *freshTemplateValuesProbe
	ready              bool
	slowChecks         bool
	freshVectors       bool
	arrayRecipeEnabled bool
	arrayRecipeTried   bool
	arrayRecipe        *rhino.NativeArrayUnknownRecipe
}

type freshTemplateValuesProbe struct {
	Activated, Calls, BoundaryChecks, FullScopeChecks, FastScopeChecks int
	ArrayRecipeSeeds, ArrayRecipeHits, ArrayRecipeFallbacks            int
	// Independent pre-V2 admission oracle for differential tests only.
	legacyScopeChecks bool
	Scopes            []freshTemplateValuesScopeAdmission
}

type freshTemplateValuesScopeAdmission struct {
	node     *rhino.Node
	errors   int
	accepted bool
}

func freshTemplateValuesSafe(p *TypeInferencePass, root *rhino.Node) bool {
	if !typedInferenceScopeScheduleSafe(p, root) {
		return false
	}
	c := p.compiler.(*Compiler)
	if c.typedAstFilesystem != nil || c.runtimeLibraryTypedAsts != nil {
		return false
	}
	for input := range c.inputsById.Values() {
		if input != nil && input.GetSourceFile() != nil {
			if _, owned := input.GetSourceFile().loader.(*cliOwnedSourceLoader); owned {
				return true
			}
		}
	}
	return false
}

func newFreshTemplateValuesMode(p *TypeInferencePass, root *rhino.Node) *freshTemplateValuesMode {
	owner := p.compiler.(*Compiler) // The full entry guard already checked this.
	mode := &freshTemplateValuesMode{owner: owner, root: root, creator: p.scopeCreator,
		registry: p.registry, errorManager: owner.errorManager, probe: p.freshTemplateProbe,
		freshVectors: freshTemplateValuesEnabled(), arrayRecipeEnabled: nativeArrayUnknownRecipeEnabled()}
	mode.errorCounter = newFreshTemplateErrorCounter(mode.errorManager)
	mode.slowChecks = mode.errorCounter == nil ||
		mode.probe != nil && mode.probe.legacyScopeChecks
	return mode
}

func (m *freshTemplateValuesMode) matches(p *TypeInferencePass) bool {
	owner, ok := p.compiler.(*Compiler)
	if !ok || owner != m.owner || p.scopeCreator != m.creator || p.registry != m.registry ||
		owner.GetRoot() != m.root || owner.typeRegistry != m.registry || owner.errorManager != m.errorManager {
		return false
	}
	creatorOwner, ok := m.creator.compiler.(*Compiler)
	return ok && creatorOwner == owner
}

// Scope construction can report errors or run the private adversarial test
// probe. Revalidate once after it finishes, before the second traversal/replay.
// The stock CLI has no callback that changes these admitted identities/hooks
// during inference. The private probe path below keeps the original full check.
func (p *TypeInferencePass) finishFreshTemplateScopeBuilding(root *rhino.Node) {
	if mode := p.freshTemplateValues; mode != nil {
		if mode.probe != nil {
			mode.probe.BoundaryChecks++
		}
		mode.ready = root == mode.root && mode.matches(p) && freshTemplateValuesSafe(p, root)
	}
}

func (p *TypeInferencePass) currentFreshTemplateValues(n *rhino.Node) *freshTemplateValuesMode {
	mode := p.freshTemplateValues
	if mode == nil {
		return nil
	}
	full := mode.slowChecks || p.scopeCreator != nil && p.scopeCreator.initialAnalysisProbe != nil &&
		p.scopeCreator.initialAnalysisProbe.afterFacts != nil
	accepted, errors := false, -1
	if full {
		// Preserve the original guard for callback-bearing internal fixtures and
		// the test oracle, including possible changes made by those callbacks.
		if owner, ok := p.compiler.(*Compiler); ok {
			accepted = freshTemplateValuesSafe(p, owner.GetRoot())
			if mode.probe != nil {
				errors = owner.GetErrorCount()
			}
		}
	} else if mode.matches(p) {
		// Report has returned before each private stock InferScope boundary.
		// Reading through the same mutex preserves concurrent Report exclusion
		// without the reentrant monitor's two runtime.Stack walks per scope.
		errors = mode.errorCounter.read()
		accepted = mode.ready && errors == 0
	}
	if probe := mode.probe; probe != nil {
		if full {
			probe.FullScopeChecks++
		} else {
			probe.FastScopeChecks++
		}
		// Diagnostic overlay counts scopes without retaining AST observations.
	}
	if accepted {
		return mode
	}
	return nil
}

// The plan captures only exact callback-free counter implementations. Every
// delegate is checked before any cold lock is acquired, including cycle/depth
// limits. Delegation is constructor-owned and never changes during stock CLI.
// An unknown/malformed chain retains the original per-scope admission path.
type freshTemplateErrorCounter struct {
	manager  ErrorManager
	wrappers []*ThreadSafeDelegatingErrorManager
	leaf     *SortingErrorManagerBase
}

func newFreshTemplateErrorCounter(manager ErrorManager) *freshTemplateErrorCounter {
	// The stock compiler always installs this synchronized outer wrapper.
	// Bare managers keep their original public path; a private leaf read must
	// always be protected by at least the same mutex as public Report.
	if _, wrapped := manager.(*ThreadSafeDelegatingErrorManager); !wrapped {
		return nil
	}
	plan := &freshTemplateErrorCounter{manager: manager}
	current := manager
	for depth := 0; depth <= 16; depth++ {
		switch m := current.(type) {
		case *ThreadSafeDelegatingErrorManager:
			if m == nil {
				return nil
			}
			for _, previous := range plan.wrappers {
				if previous == m {
					return nil
				}
			}
			plan.wrappers = append(plan.wrappers, m)
			current = m.delegated
		case *LoggerErrorManager:
			if m == nil {
				return nil
			}
			plan.leaf = &m.SortingErrorManagerBase
			return plan
		case *PrintStreamErrorManager:
			if m == nil {
				return nil
			}
			plan.leaf = &m.SortingErrorManagerBase
			return plan
		case *SortingErrorManagerBase:
			if m == nil {
				return nil
			}
			plan.leaf = m
			return plan
		default:
			return nil
		}
	}
	return nil
}

func (p *freshTemplateErrorCounter) read() int {
	locked := 0
	unlock := func() {
		for locked > 0 {
			locked--
			p.wrappers[locked].monitor.UnlockNonReentrant()
		}
	}
	defer unlock()
	for _, wrapper := range p.wrappers {
		if !wrapper.monitor.TryLockNonReentrant() {
			// Release every cold outer lock BEFORE calling the original getter.
			// This preserves reentry even when an inner public monitor was
			// already held by this goroutine, and excludes unknown callbacks
			// from running under a cold outer lock.
			unlock()
			return p.manager.GetErrorCount()
		}
		locked++
	}
	// This concrete base method sums two integers. It never dispatches through
	// self, prints, resolves source maps, or calls a report generator.
	return p.leaf.GetErrorCount()
}

func (ti *TypeInference) createTemplatizedType(base rhino.ObjectType, types ...rhino.JSType) *rhino.TemplatizedType {
	if mode := ti.freshTemplateValues; mode != nil {
		if probe := mode.probe; probe != nil {
			probe.Calls++
		}
		if mode.arrayRecipeEnabled && len(types) == 1 {
			array, arrayOK := base.(*rhino.InstanceObjectType)
			unknown, unknownOK := types[0].(*rhino.UnknownType)
			if arrayOK && array != nil && unknownOK && unknown != nil &&
				rhino.JSType(array) == ti.registry.GetNativeType(rhino.JSTypeNative_ARRAY_TYPE) &&
				rhino.JSType(unknown) == ti.registry.GetNativeType(rhino.JSTypeNative_UNKNOWN_TYPE) {
				if mode.arrayRecipe != nil {
					if result := mode.arrayRecipe.TryNew(); result != nil {
						if mode.probe != nil {
							mode.probe.ArrayRecipeHits++
						}
						return result
					}
					mode.arrayRecipe = nil
					mode.arrayRecipeTried = false
					if mode.probe != nil {
						mode.probe.ArrayRecipeFallbacks++
					}
				}
				// Seed from the first actual ORIGINAL construction, not an unobserved
				// extra exemplar. Unsupported shapes stay on this original factory.
				result := ti.registry.CreateTemplatizedType(base, types...)
				if !mode.arrayRecipeTried {
					mode.arrayRecipeTried = true
					mode.arrayRecipe = rhino.CaptureNativeArrayUnknownRecipe(ti.registry, result)
					if mode.probe != nil && mode.arrayRecipe != nil {
						mode.probe.ArrayRecipeSeeds++
					}
				}
				return result
			}
		}
		if mode.freshVectors {
			return ti.registry.CreateTemplatizedTypeWithFreshValues(base, types...)
		}
	}
	return ti.registry.CreateTemplatizedType(base, types...)
}
