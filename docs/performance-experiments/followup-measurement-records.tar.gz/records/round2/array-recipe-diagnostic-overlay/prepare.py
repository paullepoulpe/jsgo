#!/usr/bin/env python3
"""Prepare an UNTIMED focused-test overlay; never edits a checkout or builds.

The test invokes the exact pinned CLI jobs through stock CommandLineRunner.
Only a caller-owned numeric probe is attached; admission and experiment flags
are not overridden. Compose with --base-overlay to reuse a merged-factor suite.
"""
import argparse
import hashlib
import json
from pathlib import Path
import subprocess
import sys

ap=argparse.ArgumentParser(description=__doc__)
ap.add_argument('--root',type=Path,required=True)
ap.add_argument('--reference',type=Path,default=Path('/workspace/jsgo-results/round2/baseline'))
ap.add_argument('--cache',type=Path,default=Path('/workspace/jsgo/.cache'))
ap.add_argument('--base-overlay',type=Path)
ap.add_argument('--tasks',default='typed-app,bundle,downlevel-whitespace,downlevel-simple,checks-only')
ap.add_argument('--keep-test',action='append',default=[])
a=ap.parse_args()
root,ref,cache=a.root.resolve(),a.reference.resolve(),a.cache.resolve()
out=Path(__file__).resolve().parent
package=root/'internal/jscomp'
if not (package/'native_array_unknown_recipe_test.go').is_file():
 raise SystemExit('requested root does not contain the frozen Array recipe prototype')
if a.base_overlay:
 replacements=json.loads(a.base_overlay.read_text())['Replace'].copy()
 # Never silently import old-checkout replacement paths into the new package.
 old_roots={str(Path(p).parent) for p in replacements if p.endswith('_test.go')}
 if str(package) not in old_roots:
  raise SystemExit('base overlay must be regenerated against --root first')
else:
 base=out/'base'
 base.mkdir(exist_ok=True)
 source=Path('/workspace/jsgo-results/round2/focused-fresh-template-overlay/prepare.py').read_text()
 for name in ['native_array_unknown_recipe_test.go']+a.keep_test:
  if not (package/name).is_file(): raise SystemExit('missing requested focused test '+name)
  if repr(name) not in source:
   source=source.replace('keep = {','keep = {\n    '+repr(name)+',',1)
 (base/'prepare.py').write_text(source)
 subprocess.run([sys.executable,str(base/'prepare.py'),'--root',str(root)],check=True,stdout=subprocess.DEVNULL)
 replacements=json.loads((base/'overlay.json').read_text())['Replace']

factory_path=package/'typed_initial_analysis_fusion.go'
factory=factory_path.read_text()
if str(factory_path) in replacements:
 raise SystemExit('base overlay already replaces factory production source; compose explicitly')
marker='func (p *TypeInferencePass) inferAllScopesBuiltin(root *rhino.Node) *TypedScope {\n'
assert factory.count(marker)==1
factory=factory.replace(marker,marker+'\tif finish := arrayRecipeDiagnosticAttach(p); finish != nil { defer finish() }\n',1)
factory_copy=out/factory_path.name
factory_copy.write_text(factory)
replacements[str(factory_path)]=str(factory_copy)

probe_path=package/'fresh_template_values.go'
probe=probe_path.read_text()
if str(probe_path) in replacements:
 raise SystemExit('base overlay already replaces probe production source; compose explicitly')
marker='\t\tprobe.Scopes = append(probe.Scopes, freshTemplateValuesScopeAdmission{n, errors, accepted})'
assert probe.count(marker)==1
probe=probe.replace(marker,'\t\t// Diagnostic overlay counts scopes without retaining AST observations.',1)
probe_copy=out/probe_path.name
probe_copy.write_text(probe)
replacements[str(probe_path)]=str(probe_copy)

helper=out/'array_recipe_diagnostic_probe.go'
helper.write_text('''package jscomp

import "sync"

// Added only by the untimed overlay. No observer is installed in ordinary
// focused tests; the dedicated diagnostic test owns each collector.
var arrayRecipeDiagnosticMu sync.Mutex
var arrayRecipeDiagnosticObserver func(*freshTemplateValuesProbe)

func arrayRecipeDiagnosticSetObserver(observer func(*freshTemplateValuesProbe)) func() {
 arrayRecipeDiagnosticMu.Lock()
 previous := arrayRecipeDiagnosticObserver
 arrayRecipeDiagnosticObserver = observer
 arrayRecipeDiagnosticMu.Unlock()
 return func() {
  arrayRecipeDiagnosticMu.Lock()
  arrayRecipeDiagnosticObserver = previous
  arrayRecipeDiagnosticMu.Unlock()
 }
}

func arrayRecipeDiagnosticAttach(p *TypeInferencePass) func() {
 arrayRecipeDiagnosticMu.Lock()
 observer := arrayRecipeDiagnosticObserver
 arrayRecipeDiagnosticMu.Unlock()
 if observer == nil || p.freshTemplateProbe != nil { return nil }
 previous := p.freshTemplateProbe
 probe := &freshTemplateValuesProbe{}
 p.freshTemplateProbe = probe
 // Registered before the factory's original cleanup defer: its private
 // mode/creator window is restored before this observer runs, including panic.
 return func() { p.freshTemplateProbe = previous; observer(probe) }
}
''')
replacements[str(package/helper.name)]=str(helper)

# Reuse benchmark workspace creation only (symlinks); never fetch or build.
sys.path.insert(0,str(root/'tools/bench'))
sys.dont_write_bytecode=True
import bench
manifest={'root':str(root),'reference':str(ref),'tasks':[]}
for name in a.tasks.split(','):
 task=json.loads((root/'tools/bench/tasks'/f'{name}.json').read_text())
 jobs=json.loads((ref/name/'jobs.json').read_text())
 cold=json.loads((ref/name/'java-cold.json').read_text())['runs'][0]
 if cold['exits'] != [0] or len(jobs)!=len(cold['digests']):
  raise SystemExit('invalid successful pinned reference '+name)
 item={'name':name,'jobs':[]}
 for index,args in enumerate(jobs):
  directory=out/'runs'/name/f'job-{index}'
  bench.make_workspace(str(directory),str(cache))
  expected=cold['digests'][index]
  if any(value is None for value in expected.values()):
   raise SystemExit('incomplete reference artifacts '+name)
  item['jobs'].append({'directory':str(directory),'args':args,'expected':expected})
 manifest['tasks'].append(item)
(out/'jobs.json').write_text(json.dumps(manifest,indent=2)+'\n')

test=out/'array_recipe_diagnostic_test.go'
test.write_text('''package jscomp

import (
 "bytes"
 "crypto/sha256"
 "encoding/hex"
 "encoding/json"
 "fmt"
 "os"
 "path/filepath"
 "sync"
 "testing"

 "github.com/paullepoulpe/jsgo/internal/jutil"
)

type arrayRecipeDiagnosticCounts struct {
 Passes int `json:"passes"`
 Activated int `json:"activated"`
 Calls int `json:"constructor_calls"`
 Seeds int `json:"original_seeds"`
 Hits int `json:"fresh_recipe_hits"`
 Fallbacks int `json:"native_mutation_fallbacks"`
 FastScopeChecks int `json:"fast_scope_checks"`
 FullScopeChecks int `json:"full_scope_checks"`
 BoundaryChecks int `json:"boundary_checks"`
}

func TestArrayRecipeDiagnosticPinnedTasks(t *testing.T) {
 path:=os.Getenv("JSGO_ARRAY_RECIPE_DIAGNOSTIC_JOBS")
 if path=="" { t.Skip("untimed diagnostic only; manifest not provided") }
 data,err:=os.ReadFile(path); if err!=nil {t.Fatal(err)}
 var manifest struct {
  Root string `json:"root"`
  Reference string `json:"reference"`
  Tasks []struct {
   Name string `json:"name"`
   Jobs []struct {
    Directory string `json:"directory"`
    Args []string `json:"args"`
    Expected map[string]string `json:"expected"`
   } `json:"jobs"`
  } `json:"tasks"`
 }
 if err:=json.Unmarshal(data,&manifest);err!=nil {t.Fatal(err)}
 for _,task:=range manifest.Tasks {
  t.Run(task.Name,func(t *testing.T){
   var totals arrayRecipeDiagnosticCounts
   for index,job:=range task.Jobs {
    t.Run(fmt.Sprint(index),func(t *testing.T){
     t.Chdir(job.Directory)
     for artifact:=range job.Expected { if err:=os.Remove(artifact);err!=nil && !os.IsNotExist(err) {t.Fatal(err)} }
     var counts arrayRecipeDiagnosticCounts
     var mu sync.Mutex
     restore:=arrayRecipeDiagnosticSetObserver(func(p *freshTemplateValuesProbe){
      mu.Lock(); defer mu.Unlock()
      counts.Passes++; counts.Activated+=p.Activated; counts.Calls+=p.Calls
      counts.Seeds+=p.ArrayRecipeSeeds; counts.Hits+=p.ArrayRecipeHits; counts.Fallbacks+=p.ArrayRecipeFallbacks
      counts.FastScopeChecks+=p.FastScopeChecks; counts.FullScopeChecks+=p.FullScopeChecks; counts.BoundaryChecks+=p.BoundaryChecks
     })
     defer restore()
     var stdout,stderr bytes.Buffer
     runner:=NewCommandLineRunnerWithOutAndErr(job.Args,jutil.NewPrintStream(&stdout),jutil.NewPrintStream(&stderr))
     status:=runner.DoRun()
     // Only the real CLI chooses options, loaders and private admission. No
     // test-mode runner, synthetic owner or experimental flag is injected.
     for name,data:=range map[string][]byte{"stdout":stdout.Bytes(),"stderr":stderr.Bytes(),"exit":[]byte(fmt.Sprintln(status))} {
      if err:=os.WriteFile(name,data,0600);err!=nil {t.Fatal(err)}
     }
     for name,want:=range job.Expected {
      data,err:=os.ReadFile(filepath.Join(job.Directory,name));if err!=nil {t.Fatal(err)}
      hash:=sha256.Sum256(data);got:=hex.EncodeToString(hash[:]);if got!=want {t.Errorf("pinned Java artifact mismatch %s got%s want%s",name,got,want)}
     }
     mu.Lock()
     totals.Passes+=counts.Passes; totals.Activated+=counts.Activated; totals.Calls+=counts.Calls
     totals.Seeds+=counts.Seeds;totals.Hits+=counts.Hits;totals.Fallbacks+=counts.Fallbacks
     totals.FastScopeChecks+=counts.FastScopeChecks;totals.FullScopeChecks+=counts.FullScopeChecks;totals.BoundaryChecks+=counts.BoundaryChecks
     mu.Unlock()
    })
   }
   report:=struct {
    Kind string `json:"kind"`
    Task string `json:"task"`
    ArrayRecipeFlag string `json:"array_recipe_flag"`
    FreshVectorFlag string `json:"fresh_vector_flag"`
    CLIOwnershipFlag string `json:"cli_ownership_flag"`
    Counts arrayRecipeDiagnosticCounts `json:"counts"`
   }{"untimed-array-recipe-dispatch",task.Name,os.Getenv("JSGO_EXPERIMENT_ARRAY_UNKNOWN_RECIPE"),os.Getenv("JSGO_EXPERIMENT_FRESH_TEMPLATE_VALUES"),os.Getenv("JSGO_EXPERIMENT_CLI_SOURCE_LOCK"),totals}
   encoded,err:=json.Marshal(report);if err!=nil {t.Fatal(err)}
   t.Log("ARRAY_RECIPE_DIAGNOSTIC "+string(encoded))
  })
 }
}
''')
replacements[str(package/test.name)]=str(test)
subprocess.run(['/workspace/toolchains/go1.27.2/bin/gofmt','-w',str(factory_copy),str(probe_copy),str(helper),str(test)],check=True)
(out/'overlay.json').write_text(json.dumps({'Replace':replacements},indent=2)+'\n')
source=subprocess.check_output(['git','-C',str(root),'rev-parse','HEAD'],text=True).strip()
(out/'manifest.json').write_text(json.dumps({'root':str(root),'source':source,'reference':str(ref),'tasks':[x['name'] for x in manifest['tasks']],
 'base_overlay':str(a.base_overlay.resolve()) if a.base_overlay else str(out/'base/overlay.json'),
 'production_changes':{'targeted_hook':str(factory_path),'counter_only_observations':str(probe_path),'added_diagnostic_helper':str(package/helper.name)},
 'added_test':str(package/test.name),'production_stubs':0,'forces_admission':False,'forces_experiment_flags':False,
 'sha256':{p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in [factory_copy,probe_copy,helper,test,out/'jobs.json']}},indent=2)+'\n')
print(json.dumps({'root':str(root),'source':source,'overlay':str(out/'overlay.json'),'jobs':str(out/'jobs.json'),'tasks':[x['name'] for x in manifest['tasks']]},indent=2))
