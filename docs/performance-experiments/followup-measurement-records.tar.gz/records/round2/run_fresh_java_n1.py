#!/usr/bin/env python3
"""Fresh stock warm-Java reference; no Go runs or builds during timing."""
import argparse
import datetime
import json
import os
from pathlib import Path
import shutil
import statistics
import subprocess
import sys

sys.dont_write_bytecode = True


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--repo', required=True)
    p.add_argument('--reference', required=True)
    p.add_argument('--cache', required=True)
    p.add_argument('--out', required=True)
    p.add_argument('--tasks', default='typed-app,bundle,downlevel-whitespace,downlevel-simple,checks-only')
    p.add_argument('--warmup', type=int, default=12)
    p.add_argument('--warm-iters', type=int, default=10)
    p.add_argument('--nice', type=int, default=10)
    p.add_argument('--locale', default='C.UTF-8')
    a = p.parse_args()
    if a.warmup < 0 or a.warm_iters < 2:
        p.error('warmup must be nonnegative and warm-iters at least two')
    repo, ref, out = (Path(v).resolve() for v in (a.repo, a.reference, a.out))
    if out.exists():
        p.error('refusing to overwrite existing output')
    sys.path.insert(0, str(repo/'tools/bench'))
    import bench
    from cohort_compare import validate_reference, warm_metrics
    from thread_sweep import with_compiler_threads
    tasks = bench.load_tasks(a.tasks.split(','))
    references = {t['name']: validate_reference(ref, t) for t in tasks}
    a.out = str(out)
    runner = bench.Runner(a)
    jar_hash = bench.sha256_file(runner.jar)
    old_machine = bench.load(str(ref/'machine.json'))
    if jar_hash != bench.read_pin()['CLOSURE_JAR_SHA256'] or old_machine.get('jar_sha256') != jar_hash:
        raise ValueError('jar does not match both pin and reference')
    # Unique directory and check=True prevent stale helpers after failed javac.
    build = out/'java-driver'
    build.mkdir()
    src = repo/'tools/bench/java/CliBatch.java'
    javac = [shutil.which('javac'), '-nowarn', '-cp', runner.jar, '-d', str(build), str(src)]
    subprocess.run(javac, env=runner.java_env, check=True)
    runner.batch_cp = runner.jar+':'+str(build)
    metadata = bench.machine_info(runner, None)
    metadata.update({
        'mode': 'fresh ordinary stock warm Java, N1',
        'started_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
        'tasks': [t['name'] for t in tasks], 'warmup': a.warmup, 'measured': a.warm_iters,
        'compiler_threads': 1, 'cpu_affinity': sorted(os.sched_getaffinity(0)),
        'reference': str(ref), 'reference_machine': old_machine,
        'javac_command': javac, 'java_classpath': runner.batch_cp,
        'driver_source_sha256': bench.sha256_file(src),
        'driver_class_sha256': {str(f.relative_to(build)): bench.sha256_file(f) for f in build.rglob('*.class')},
        'runner_source_sha256': {str(f.relative_to(repo)): bench.sha256_file(f) for f in
                                  [repo/'tools/bench/bench.py', repo/'tools/bench/cohort_compare.py',
                                   repo/'tools/bench/thread_sweep.py']},
        'java': 'pinned unmodified jar; new runner/compiler and normal extern parsing each iteration; one fresh JVM per task',
        'rss_window': 'fresh JVM lifetime peak including class loading, JIT, warmup and measured iterations; not per-compilation live heap',
        'artifact_gate': 'last measured iteration: exact stdout/stderr/exit and every stored task artifact digest',
        'confidence': 'one cohort per task; correlated iterations, no independent-cohort confidence interval',
    })
    for name in ('cpu.max', 'cpuset.cpus.effective', 'memory.max'):
        path = Path('/sys/fs/cgroup')/name
        if path.exists():
            metadata[name] = path.read_text().strip()
    bench.save(str(out/'machine.json'), metadata)
    summary = {}
    for task in tasks:
        name = task['name']
        original, expected = references[name]
        jobs = [with_compiler_threads(job, 1) for job in original]
        td = out/name
        td.mkdir()
        (td/'java-cold').symlink_to(ref/name/'java-cold', target_is_directory=True)
        bench.save(str(td/'jobs.json'), jobs)
        print('== fresh stock warm Java N1: '+name, flush=True)
        warm = runner.measure_warm(task, jobs, str(td))
        bench.save(str(td/'java-warm.json'), warm)
        metrics = warm_metrics(warm, a.warm_iters)
        actual = []
        for index in range(len(jobs)):
            files = {k: str(td/'java-warm'/'batch'/f'{index}.{k}') for k in ('stdout','stderr','exit')}
            if len(jobs) == 1:
                files.update({k: str(td/'java-warm'/k) for k in task.get('compare', [])})
            actual.append(bench.digest_artifacts(files))
        if actual != expected:
            raise ValueError('final Java artifact digest mismatch: '+name)
        rows = [r for r in warm['iterations'] if r['kind'] == 'measure']
        warm_rows = [r for r in warm['iterations'] if r['kind'] == 'warmup']
        half = len(rows)//2
        metrics.update({'min_s': min(r['wall_ms'] for r in rows)/1000,
                        'max_s': max(r['wall_ms'] for r in rows)/1000,
                        'first_half_cpu_ms': statistics.median(r['cpu_ms'] for r in rows[:half]),
                        'second_half_cpu_ms': statistics.median(r['cpu_ms'] for r in rows[half:]),
                        'last_warmup_wall_s': [r['wall_ms']/1000 for r in warm_rows[-4:]],
                        'all_artifact_digests_match': True, 'digests': actual})
        summary[name] = metrics
        bench.save(str(out/'summary.json'), summary)
        print(json.dumps({name: metrics}), flush=True)


if __name__ == '__main__':
    main()
