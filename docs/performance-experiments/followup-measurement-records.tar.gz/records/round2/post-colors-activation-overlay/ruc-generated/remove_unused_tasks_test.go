package jscomp

import (
	"path/filepath"
	"os"
	"encoding/json"
	"bytes"
	"fmt"
	"reflect"
	"strings"
	"testing"
	"unsafe"

	"github.com/paullepoulpe/jsgo/internal/diagnostic"
	"github.com/paullepoulpe/jsgo/internal/jutil"
	"github.com/paullepoulpe/jsgo/internal/rhino"
)

func TestRemoveUnusedTaskSharedListAndQueueDifferential(t *testing.T) {
	// A builder can produce multiple removables sharing the same list. Apply
	// clears that shared list, while each removable's applied bit is separate.
	var orders [2]string
	for mode := 0; mode < 2; mode++ {
		r := &RemoveUnusedCode{worklist: jutil.NewArrayDeque[*RemoveUnusedCode_Continuation]()}
		if mode == 1 {
			r.nativeTasks = &removeUnusedTaskArena{}
		}
		builder := r.newRemovableBuilder()
		first, second := &RemoveUnusedCode_RemovableBase{}, &RemoveUnusedCode_RemovableBase{}
		first.InitRemoveUnusedCode_RemovableBase(nil, r, nil, builder)
		second.InitRemoveUnusedCode_RemovableBase(nil, r, nil, builder)
		for _, name := range []string{"first", "second"} {
			builder.addTraversal(rhino.IR_Name(name), nil)
		}
		first.ApplyContinuations()
		builder.addTraversal(rhino.IR_Name("third"), nil)
		second.ApplyContinuations()
		builder.addTraversal(rhino.IR_Name("unapplied"), nil)
		first.ApplyContinuations() // already applied, must not consume new work
		var names []string
		for i := 0; ; i++ {
			var node *rhino.Node
			if mode == 0 {
				if r.worklist.IsEmpty() {
					break
				}
				node = r.worklist.RemoveFirst().node
			} else {
				if r.nativeTasks.queue.empty() {
					break
				}
				node = r.nativeTasks.queue.remove().node
			}
			names = append(names, node.GetString())
			if i == 0 {
				// Reentrant traversal appends after every already-pending task.
				if mode == 0 {
					r.worklist.Add(NewRemoveUnusedCode_Continuation(r, rhino.IR_Name("appended"), nil))
				} else {
					r.nativeTasks.queue.add(removeUnusedTask{node: rhino.IR_Name("appended")})
				}
			}
		}
		orders[mode] = strings.Join(names, ",")
	}
	if orders[0] != "first,second,third,appended" || orders[1] != orders[0] {
		t.Fatalf("shared clear/applied/FIFO behavior differs: %v", orders)
	}
}

func TestRemoveUnusedTaskArenaRecyclesWithoutRetainingPointers(t *testing.T) {
	a := &removeUnusedTaskArena{}
	list := a.newList()
	root := rhino.IR_Root()
	scope := Scope_CreateGlobalScope(root)
	for i := 0; i < 10000; i++ {
		node := rhino.IR_Name(fmt.Sprint(i))
		a.add(list, removeUnusedTask{node: node, scope: scope})
		a.applyList(list)
		if row := a.task(1); row.node != nil || row.scope != nil {
			t.Fatal("transferred task retained AST/scope pointers")
		}
		if got := a.queue.remove(); got.node != node || got.scope != scope {
			t.Fatal("recycled row replaced a still-owned queued task")
		}
	}
	if a.taskCount != 1 || a.list(list).head != 0 || a.list(list).tail != 0 {
		t.Fatal("applied task storage grew with cumulative work or shared list retained tasks")
	}
	for _, row := range a.queue.rows {
		if row.node != nil || row.scope != nil {
			t.Fatal("consumed queue slot retained AST/scope pointers")
		}
	}
}

func TestRemoveUnusedTaskGrowthAndInterleavedFIFO(t *testing.T) {
	a := &removeUnusedTaskArena{}
	var lists []uint32
	for i := 0; i < 333; i++ {
		list := a.newList()
		lists = append(lists, list)
		a.add(list, removeUnusedTask{node: rhino.IR_Number(float64(i))})
	}
	for _, list := range lists {
		a.applyList(list)
	}
	for i := 0; i < 1000; i++ {
		task := a.queue.remove()
		if task.node.GetDouble() != float64(i) {
			t.Fatalf("FIFO order changed after growth/wrap: %v != %d", task.node, i)
		}
		if i < 667 {
			a.queue.add(removeUnusedTask{node: rhino.IR_Number(float64(i + 333))})
		}
	}
	if !a.queue.empty() {
		t.Fatal("FIFO retained unexpected tasks")
	}
}

func TestRemoveUnusedTaskPublicConstructorsAndLayout(t *testing.T) {
	r := &RemoveUnusedCode{nativeTasks: &removeUnusedTaskArena{}}
	builder := NewRemoveUnusedCode_RemovableBuilder(r)
	continuation := NewRemoveUnusedCode_Continuation(r, rhino.IR_Name("public"), nil)
	builder.AddContinuation(continuation)
	if builder.nativeListID != 0 || builder.continuations.Slice()[0] != continuation {
		t.Fatal("public builder stopped retaining exact continuation identity")
	}
	if unsafe.Sizeof(uintptr(0)) == 8 && (unsafe.Sizeof(*builder) != 32 || unsafe.Sizeof(RemoveUnusedCode_RemovableBase{}) != 56) {
		t.Fatal("private list ID increased existing builder/removable layout")
	}
}

func removeUnusedTasksSnapshot(t *testing.T, c *Compiler, pass *RemoveUnusedCode, ids map[*rhino.Node]int) string {
	t.Helper()
	var out strings.Builder
	fmt.Fprintln(&out, c.GetRoot().ToStringTree(), c.ToSource(), c.GetErrors(), c.GetWarnings(), c.changeTracker.GetChangeStamp())
	identities := map[RemoveUnusedCode_VarInfo]int{}
	for variable, info := range pass.varInfoMap.All() {
		if identities[info] == 0 {
			identities[info] = len(identities) + 1
		}
		if info != pass.GetVarInfo(variable) {
			t.Fatal("VarInfo identity changed for its canonical Var")
		}
		fmt.Fprintf(&out, "var:%s scope:%d info:%d type:%T removable:%t literal:%t\n", variable.GetName(), ids[variable.GetScope().GetRootNode()], identities[info], info, info.IsRemovable(), info.HasFunctionOrClassLiteralValue())
	}
	return out.String()
}

func newRemoveUnusedTasksCompiler(t *testing.T, program string) *Compiler {
	t.Helper()
	c := removeUnusedOracleNewCompiler("tasks.js", program)
	removeUnusedOraclePrepare(c)
	if c.GetErrorCount() != 0 {
		t.Fatal("fixture failed preparation", c.GetErrors())
	}
	// Deliberately install the package-private stock CLI ownership proof for
	// these isolated representation fixtures. Public callers cannot create it;
	// separate fallback coverage removes it and verifies original dispatch.
	for input := range c.inputsById.Values() {
		if file := input.GetSourceFile(); file != nil {
			loader := &cliOwnedSourceLoader{SourceFile_CodeLoader: file.loader}
			loader.cached.Store(file.code)
			file.loader = loader
		}
	}
	return c
}
func removeUnusedTasksBuilder(c AbstractCompiler) *RemoveUnusedCode_Builder {
	return NewRemoveUnusedCode_Builder(c).RemoveLocalVars(true).RemoveGlobals(true).
		RemoveUnusedPrototypeProperties(true).RemoveUnusedThisProperties(true).
		RemoveUnusedObjectDefinePropertiesDefinitions(true).RemoveUnusedPolyfills(false)
}

func TestRemoveUnusedTaskFullPassDifferential(t *testing.T) {
	var chain strings.Builder
	for i := 0; i < 333; i++ {
		fmt.Fprintf(&chain, "function f%d(a){return f%d(a+1);}function dead%d(){return %d;}\n", i, i+1, i, i)
	}
	chain.WriteString("function f333(a){alert(a);}f0(0);")
	fixtures := []string{
		`function dead(){return alert('dead');}function f(a){var unused=1;var live=function(){return a;};return live();}alert(f(1));`,
		`function C(a){this.dead=alert(a);this.live=a;}C.prototype.unused=function(){return alert(1);};C.prototype.used=function(){return this.live;};var x=new C(2);alert(x.used());`,
		`var x={unused:function(){return 1;},used:function(){return 2;}};x.unused=3;alert(x.used());Object.defineProperties(x,{dead:{value:1},live:{get:function(){return alert(2);}}});alert(x.live);`,
		`function f(a){var x;for(var i=0;i<a;i++){x=i;}try{throw x;}catch(e){alert(e);}return function(){return x;};}alert(f(2));`,
		`class Unused{method(){alert(0);}}class C{field=alert(1);static method(){return 2;}method(a=()=>3){return a();}}alert(new C().method());`,
		chain.String(),
	}
	for index, program := range fixtures {
		t.Run(fmt.Sprint(index), func(t *testing.T) {
			var snapshots [2]string
			for mode := 0; mode < 2; mode++ {
				t.Setenv("JSGO_EXPERIMENT_REMOVE_UNUSED_TASKS", fmt.Sprint(mode))
				c := newRemoveUnusedTasksCompiler(t, program)
				ids := typedInitialNodeIDs(c.GetRoot())
				pass := removeUnusedTasksBuilder(c).buildBuiltinPass()
				probe := &removeUnusedTaskProbe{}
				pass.nativeTaskProbe = probe
				pass.Process(c.GetExternsRoot(), c.GetJsRoot())
				if pass.nativeTasks != nil {
					t.Fatal("phase-owned task arena leaked after return")
				}
				if mode == 1 && (probe.Activated != 1 || probe.Tasks == 0 || probe.Enqueued == 0 || probe.Applied < 2) {
					t.Fatalf("native construction/dispatch not exercised: %+v", probe)
				}
				if mode == 0 && !reflect.DeepEqual(probe, &removeUnusedTaskProbe{}) {
					t.Fatal("baseline unexpectedly used native task storage")
				}
				snapshots[mode] = removeUnusedTasksSnapshot(t, c, pass, ids)
			}
			if snapshots[0] != snapshots[1] {
				t.Fatalf("task representation changed AST/output/diagnostics/changes/VarInfo identities\nlegacy:\n%s\nnative:\n%s", snapshots[0], snapshots[1])
			}
		})
	}
}

func TestRemoveUnusedTaskPublicAndCustomFallback(t *testing.T) {
	t.Setenv("JSGO_EXPERIMENT_REMOVE_UNUSED_TASKS", "1")
	for _, kind := range []string{"public", "ownership", "compiler", "convention", "observer", "scope-handler", "warnings"} {
		t.Run(kind, func(t *testing.T) {
			c := newRemoveUnusedTasksCompiler(t, `function f(a){return a+1;}alert(f(2));`)
			builder := removeUnusedTasksBuilder(c)
			pass := builder.buildBuiltinPass()
			switch kind {
			case "public":
				pass = builder.Build()
			case "ownership":
				for input := range c.inputsById.Values() {
					if file := input.GetSourceFile(); file != nil {
						file.loader = file.loader.(*cliOwnedSourceLoader).SourceFile_CodeLoader
					}
				}
			case "warnings":
				c.warningsGuard = &typedScheduleUnknownWarnings{}
			case "compiler":
				pass.compiler = &typedInitialUnknownCompiler{AbstractCompiler: c}
			case "convention":
				pass.codingConvention = &unusedWorkCustomConvention{c.GetCodingConvention()}
			case "observer":
				c.changeTracker.AddChangeHandler(&functionFSIVCustomObserver{})
			case "scope-handler":
				pass.scopeCreator.redeclarationHandler = &typedInitialObservedRedeclaration{registry: c.GetTypeRegistry()}
			}
			probe := &removeUnusedTaskProbe{}
			pass.nativeTaskProbe = probe
			pass.Process(c.GetExternsRoot(), c.GetJsRoot())
			if probe.Activated != 0 || pass.nativeTasks != nil {
				t.Fatal("public/custom path acquired a native arena")
			}
		})
	}
}

func TestRemoveUnusedTaskPhaseCleanupOnPanic(t *testing.T) {
	t.Setenv("JSGO_EXPERIMENT_REMOVE_UNUSED_TASKS", "1")
	c := newRemoveUnusedTasksCompiler(t, `function f(a){return a;}alert(f(1));`)
	function := c.GetJsRoot().GetFirstChild().GetFirstChild()
	if !function.IsFunction() {
		t.Fatal("fixture did not produce a function")
	}
	function.GetFirstChild().Detach() // fail the original syntactic/function invariants
	pass := removeUnusedTasksBuilder(c).buildBuiltinPass()
	probe := &removeUnusedTaskProbe{}
	pass.nativeTaskProbe = probe
	var caught any
	func() {
		defer func() { caught = recover() }()
		pass.Process(c.GetExternsRoot(), c.GetJsRoot())
	}()
	if caught == nil || probe.Activated != 1 || pass.nativeTasks != nil {
		t.Fatalf("exception did not release an active phase: panic=%v probe=%+v arena=%v", caught, probe, pass.nativeTasks)
	}
}

func TestRemoveUnusedTaskCustomLogsKeepLegacyPath(t *testing.T) {
	c := newRemoveUnusedTasksCompiler(t, `alert(1);`)
	pass := removeUnusedTasksBuilder(c).buildBuiltinPass()
	pass.removalLog, pass.unremovableLog = diagnostic.NewNoOpLogFile(), diagnostic.NewNoOpLogFile()
	if !pass.nativeTasksSafe(c.GetJsRoot()) {
		t.Fatal("stock fixture ineligible")
	}
	var events []string
	pass.removalLog = &unusedWorkLog{NoOpLogFile: diagnostic.NewNoOpLogFile(), events: &events}
	if pass.nativeTasksSafe(c.GetJsRoot()) {
		t.Fatal("custom logger admitted")
	}
}


func runRemoveUnusedActivationCLI(args []string) (int,string,string,[]removeUnusedActivationRecord) {
    removeUnusedActivationMutex.Lock()
    removeUnusedActivationRecords=nil
    removeUnusedActivationMutex.Unlock()
    var output,diagnostics bytes.Buffer
    runner:=NewCommandLineRunnerWithOutAndErr(args,jutil.NewPrintStream(&output),jutil.NewPrintStream(&diagnostics))
    status:=runner.DoRun()
    removeUnusedActivationMutex.Lock()
    records:=removeUnusedActivationRecords
    removeUnusedActivationRecords=nil
    removeUnusedActivationMutex.Unlock()
    return status,output.String(),diagnostics.String(),records
}

func TestRemoveUnusedTaskActualCLIPostColorsActivation(t *testing.T) {
    t.Setenv("JSGO_EXPERIMENT_CLI_SOURCE_LOCK","1")
    directory:=t.TempDir()
    input:=filepath.Join(directory,"input.js")
    output:=filepath.Join(directory,"out.js")
    mapping:=filepath.Join(directory,"out.js.map")
    source:=`function outer(seed){var unused=1;function live(value){return seed+value;}function dead(){return 99;}return live;} window['keep']=outer;window['result']=outer(window['seed'])(3);`
    if err:=os.WriteFile(input,[]byte(source),0600);err!=nil {t.Fatal(err)}
    for _,level:=range []string{"SIMPLE","ADVANCED"} {
        t.Run(level,func(t *testing.T){
            var snapshots [4]string
            for mode:=range 4 {
                taskFlag,fifoFlag:="",""
                if mode==1 || mode==2 {taskFlag="1"}
                if mode==2 || mode==3 {fifoFlag="1"}
                t.Setenv("JSGO_EXPERIMENT_REMOVE_UNUSED_TASKS",taskFlag)
                t.Setenv("JSGO_EXPERIMENT_REMOVE_UNUSED_INTRUSIVE_FIFO",fifoFlag)
                args:=[]string{"--compilation_level="+level,"--num_parallel_threads=2","--js="+input,"--js_output_file="+output,"--create_source_map="+mapping}
                status,stdout,stderr,records:=runRemoveUnusedActivationCLI(args)
                if status!=0 {t.Fatalf("fresh CLI failed: mode=%d exit=%d %s",mode,status,stderr)}
                activated,tasks,applied,intrusive:=0,0,0,0
                for _,record:=range records {
                    if !record.PostColors {t.Fatal("actual stock RUC did not observe post-colors runtime table")}
                    activated+=record.Probe.Activated
                    tasks+=record.Probe.Tasks
                    applied+=record.Probe.Applied
                    intrusive+=record.Probe.IntrusiveActivated
                }
                if len(records)==0 {t.Fatal("fixture did not reach an actual default RUC factory")}
                if mode==1 || mode==2 {
                    if activated==0 || tasks==0 || applied<2 {t.Fatalf("fresh post-colors CLI native work inactive: mode=%d activated=%d tasks=%d applied=%d",mode,activated,tasks,applied)}
                } else if activated!=0 {t.Fatal("task-disabled flag combination activated native work")}
                if (mode==2)!=(intrusive>0) {t.Fatal("intrusive FIFO dispatch lost flag independence")}
                code,err:=os.ReadFile(output);if err!=nil {t.Fatal(err)}
                maps,err:=os.ReadFile(mapping);if err!=nil {t.Fatal(err)}
                snapshots[mode]=fmt.Sprintf("%d\n%s\n%s\n%s\n%s",status,stdout,stderr,code,maps)
                t.Logf("mode=%d phases=%d activated=%d tasks=%d applied=%d intrusive=%d",mode,len(records),activated,tasks,applied,intrusive)
            }
            for mode:=1;mode<len(snapshots);mode++ {if snapshots[mode]!=snapshots[0] {t.Fatalf("fresh CLI output/maps/errors/status differ in mode%d",mode)}}
        })
    }
}

// Case JSONs can reuse commonjs_activation.py's exact pinned task arguments.
// Run once per fresh process, with the desired task/FIFO flags in its environment.
func TestRemoveUnusedTaskBenchmarkActivation(t *testing.T) {
    casePath:=os.Getenv("JSGO_RUC_ACTIVATION_CASE")
    if casePath=="" {t.Skip("set JSGO_RUC_ACTIVATION_CASE to an existing benchmark case JSON")}
    var invocation struct {Task string `json:"task"`; Cwd string `json:"cwd"`; Args []string `json:"args"`; Report string `json:"report"`}
    data,err:=os.ReadFile(casePath);if err!=nil {t.Fatal(err)}
    if err=json.Unmarshal(data,&invocation);err!=nil {t.Fatal(err)}
    previous,err:=os.Getwd();if err!=nil {t.Fatal(err)}
    if err=os.Chdir(invocation.Cwd);err!=nil {t.Fatal(err)}
    defer func(){if err:=os.Chdir(previous);err!=nil {t.Error(err)}}()
    t.Setenv("JSGO_EXPERIMENT_CLI_SOURCE_LOCK","1")
    status,_,diagnostics,records:=runRemoveUnusedActivationCLI(invocation.Args)
    report:=struct {Task string `json:"task"`; Exit int `json:"exit"`; Records []removeUnusedActivationRecord `json:"records"`; Diagnostics string `json:"diagnostics"`}{invocation.Task,status,records,diagnostics}
    encoded,err:=json.MarshalIndent(report,"","  ");if err!=nil {t.Fatal(err)}
    destination:=invocation.Report+".ruc.json"
    if err=os.WriteFile(destination,append(encoded,'\n'),0600);err!=nil {t.Fatal(err)}
    t.Logf("task=%s RUCphases=%d exit=%d report=%s",invocation.Task,len(records),status,destination)
    if status!=0 {t.Fatalf("actual CLI failed: %s",diagnostics)}
}
