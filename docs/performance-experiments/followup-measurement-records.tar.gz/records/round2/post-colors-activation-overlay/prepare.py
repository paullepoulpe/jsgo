#!/usr/bin/env python3
"""Prepare NON-RACE, UNTIMED numeric post-colors activation diagnostics; no builds."""
import argparse,hashlib,json,subprocess
from pathlib import Path
ap=argparse.ArgumentParser(description=__doc__)
ap.add_argument('--root',type=Path,required=True)
ap.add_argument('--base-overlay',type=Path)
ap.add_argument('--out',type=Path)
ap.add_argument('--jobs',type=Path,default=Path('/workspace/jsgo-results/round2/array-recipe-diagnostic-overlay/jobs.json'))
a=ap.parse_args();root=a.root.resolve();pkg=root/'internal/jscomp';out=(a.out or Path(__file__).resolve().parent/'generated').resolve();out.mkdir(parents=True,exist_ok=True)
replace=json.loads(a.base_overlay.read_text())['Replace'].copy() if a.base_overlay else {}
if replace and not any(str(Path(k).parent)==str(pkg) for k in replace):raise SystemExit('base overlay must target --root')
original_hashes={};copies=[]
def edit(name,before,after):
 target=pkg/name;effective=Path(replace.get(str(target),str(target)));source=effective.read_text()
 if source.count(before)!=1:raise SystemExit('nonunique diagnostic hook '+name+': '+repr(before))
 original_hashes.setdefault(name,hashlib.sha256(source.encode()).hexdigest())
 dest=out/name;dest.write_text(source.replace(before,after,1));replace[str(target)]=str(dest);copies.append(dest)
edit('native_live_variables.go','func (l *LiveVariablesAnalysis) tryNativeLiveVariables(probe *nativeLiveVariablesProbe) bool {\n',
 '''func (l *LiveVariablesAnalysis) tryNativeLiveVariables(probe *nativeLiveVariablesProbe) bool {
 if probe == nil {
  var finish func()
  probe, finish = postColorsDiagnosticLiveBegin()
  if finish != nil { defer finish() }
 }
''')
edit('scope_first_allocation.go','\ts.vars = variables\n\treturn variable\n','\ts.vars = variables\n\tpostColorsDiagnosticCoallocation()\n\treturn variable\n')
edit('contextual_inverter_noop.go','func (p *contextualInverterNoopPass) Process(externs, js *rhino.Node) {\n',
 '''func (p *contextualInverterNoopPass) Process(externs, js *rhino.Node) {
 if finish := postColorsDiagnosticInverterBegin(p); finish != nil { defer finish() }
''')
edit('contextual_inverter_compact.go','type compactInverterProbe struct {\n','type compactInverterProbe struct {\n diagnosticNumericOnly bool // Overlay-only; original test probes retain observations.\n')
# Work from the newly overlaid effective file; remove ONLY diagnostic NameOrder retention.
edit('contextual_inverter_compact.go','\t\t\ta.probe.NameOrder = append(a.probe.NameOrder, id)', '\t\t\tif !a.probe.diagnosticNumericOnly { a.probe.NameOrder = append(a.probe.NameOrder, id) }')
revision=subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip()
ruc_present=any('recordRemoveUnusedActivation' in Path(v).read_text() for k,v in replace.items() if k.endswith('/remove_unused_code.go'))
fsiv_present=any(k.endswith('/fsiv_use_cardinality_diagnostic.go') for k in replace)
helper=out/'post_colors_activation_diagnostic.go'
helper.write_text('''// Generated only for untimed, NON-RACE activation diagnostics.
package jscomp
import "sync"

type postColorsLiveCounts struct {
 Attempts int `json:"attempts"`
 Runs int `json:"runs"`
 Nodes int `json:"nodes"`
 Steps int `json:"steps"`
 Transfers int `json:"transfers"`
 CacheHits int `json:"cache_hits"`
 EscapeTransitions int `json:"escape_transitions"`
}
type postColorsInverterCounts struct {
 Calls int `json:"calls"`
 Activated int `json:"activated"`
 Closed int `json:"closed"`
 Records int `json:"records"`
 Variables int `json:"variables"`
 ShadowLinks int `json:"shadow_links"`
 DuplicateLinks int `json:"duplicate_links"`
 NameObservations int `json:"name_observations"`
 GenericMemberships int `json:"generic_memberships"`
 Retirements int `json:"retirements"`
 Cohorts int `json:"cohorts"`
 PeakRecords int `json:"max_records"`
 PeakVariables int `json:"max_variables"`
 PeakLinks int `json:"max_links"`
}
type postColorsDiagnosticCounts struct {
 Live postColorsLiveCounts `json:"liveness"`
 FirstCoallocations int `json:"first_scope_coallocations"`
 Inverter postColorsInverterCounts `json:"compact_inverter"`
}
var postColorsDiagnosticState struct {
 sync.Mutex
 current *postColorsDiagnosticCounts
}
func postColorsDiagnosticSet(target *postColorsDiagnosticCounts) func() {
 postColorsDiagnosticState.Lock();previous:=postColorsDiagnosticState.current;postColorsDiagnosticState.current=target;postColorsDiagnosticState.Unlock()
 return func(){postColorsDiagnosticState.Lock();postColorsDiagnosticState.current=previous;postColorsDiagnosticState.Unlock()}
}
func postColorsDiagnosticLiveBegin() (*nativeLiveVariablesProbe,func()) {
 postColorsDiagnosticState.Lock();target:=postColorsDiagnosticState.current;postColorsDiagnosticState.Unlock()
 if target==nil {return nil,nil}
 probe:=&nativeLiveVariablesProbe{}
 return probe,func(){
  postColorsDiagnosticState.Lock();defer postColorsDiagnosticState.Unlock()
  p:=&target.Live
  p.Attempts++;p.Runs+=probe.Runs;p.Nodes+=probe.Nodes;p.Steps+=probe.Steps;p.Transfers+=probe.Transfers;p.CacheHits+=probe.CacheHits;p.EscapeTransitions+=probe.EscapeTransitions
 }
}
func postColorsDiagnosticCoallocation() {
 postColorsDiagnosticState.Lock();defer postColorsDiagnosticState.Unlock()
 if target:=postColorsDiagnosticState.current;target!=nil {target.FirstCoallocations++}
}
func postColorsDiagnosticInverterBegin(pass *contextualInverterNoopPass) func() {
 postColorsDiagnosticState.Lock();target:=postColorsDiagnosticState.current;postColorsDiagnosticState.Unlock()
 if target==nil || pass.compactProbe!=nil {return nil}
 probe:=&compactInverterProbe{diagnosticNumericOnly:true}
 pass.compactProbe=probe
 return func(){
  pass.compactProbe=nil
  postColorsDiagnosticState.Lock();defer postColorsDiagnosticState.Unlock()
  p:=&target.Inverter
  p.Calls++;p.Activated+=probe.Activated;p.Closed+=probe.Closed;p.Records+=probe.Records;p.Variables+=probe.Variables;p.ShadowLinks+=probe.ShadowLinks;p.DuplicateLinks+=probe.DuplicateLinks
  p.NameObservations+=probe.NameObservations;p.GenericMemberships+=probe.GenericMemberships;p.Retirements+=probe.Retirements;p.Cohorts+=probe.Cohorts
  p.PeakRecords=max(p.PeakRecords,probe.PeakRecords);p.PeakVariables=max(p.PeakVariables,probe.PeakVariables);p.PeakLinks=max(p.PeakLinks,probe.PeakLinks)
 }
}
''')
if ruc_present:
 helper.write_text(helper.read_text()+'''
func postColorsDiagnosticRUCReset(){removeUnusedActivationMutex.Lock();removeUnusedActivationRecords=nil;removeUnusedActivationMutex.Unlock()}
func postColorsDiagnosticRUCTake() any {removeUnusedActivationMutex.Lock();defer removeUnusedActivationMutex.Unlock();records:=removeUnusedActivationRecords;removeUnusedActivationRecords=nil;return records}
''')
else:
 helper.write_text(helper.read_text()+'''
func postColorsDiagnosticRUCReset(){}
func postColorsDiagnosticRUCTake() any {return nil}
''')
replace[str(pkg/helper.name)]=str(helper);copies.append(helper)
test=out/'post_colors_activation_diagnostic_test.go'
test.write_text('''package jscomp
import (
 "bytes"
 "crypto/sha256"
 "encoding/hex"
 "encoding/json"
 "fmt"
 "os"
 "path/filepath"
 "runtime"
 "testing"
 "github.com/paullepoulpe/jsgo/internal/jutil"
)
func TestPostColorsDesignDiagnosticPinnedTasks(t *testing.T) {
 path:=os.Getenv("JSGO_POST_COLORS_DIAGNOSTIC_JOBS")
 if path=="" {t.Skip("untimed diagnostic only; exact pinned job manifest not supplied")}
 data,err:=os.ReadFile(path);if err!=nil {t.Fatal(err)}
 var manifest struct {Tasks []struct{Name string;Jobs []struct{Directory string;Args []string;Expected map[string]string}}}
 if err:=json.Unmarshal(data,&manifest);err!=nil {t.Fatal(err)}
 for _,task:=range manifest.Tasks {t.Run(task.Name,func(t *testing.T){
  for index,job:=range task.Jobs {t.Run(fmt.Sprint(index),func(t *testing.T){
   t.Chdir(job.Directory)
   for artifact:=range job.Expected{if err:=os.Remove(artifact);err!=nil&&!os.IsNotExist(err){t.Fatal(err)}}
   quotientPath:=filepath.Join(job.Directory,"post-colors-quotient.json")
   _=os.Remove(quotientPath)
   t.Setenv("JSGO_FSIV_USE_CARDINALITY_DIAGNOSTIC_JSON",quotientPath)
   var output,diagnostics bytes.Buffer
   runner:=NewCommandLineRunnerWithOutAndErr(job.Args,jutil.NewPrintStream(&output),jutil.NewPrintStream(&diagnostics))
   counts:=&postColorsDiagnosticCounts{}
   restore:=postColorsDiagnosticSet(counts)
   defer restore()
   probe:=&nativeOutputBufferProbe{}
   runner.nativeOutputBufferProbe=probe
   postColorsDiagnosticRUCReset()
   status:=runner.DoRun()
   // DoRun has joined compiler jobs and completed original code generation.
   postColorsDiagnosticState.Lock();snapshot:=*counts;postColorsDiagnosticState.Unlock()
   for name,data:=range map[string][]byte{"stdout":output.Bytes(),"stderr":diagnostics.Bytes(),"exit":[]byte(fmt.Sprintln(status))}{if err:=os.WriteFile(name,data,0600);err!=nil {t.Fatal(err)}}
   for name,want:=range job.Expected{
    data,err:=os.ReadFile(name);if err!=nil {t.Fatal(err)}
    hash:=sha256.Sum256(data);if got:=hex.EncodeToString(hash[:]);got!=want{t.Errorf("pinned Java artifact mismatch %s got%s want%s",name,got,want)}
   }
   var quotient json.RawMessage
   if FSIV_PRESENT {
    quotient,err=os.ReadFile(quotientPath);if err!=nil {t.Fatal(err)}
   }
   flags:=map[string]string{}
   for _,name:=range []string{"NATIVE_LIVE_VARIABLES","SCOPE_FIRST_ALLOCATION","COMPACT_INVERTER","ASCII_OUTPUT_BUFFER","FSIV_USE_CARDINALITY","REMOVE_UNUSED_TASKS","REMOVE_UNUSED_INTRUSIVE_FIFO","CLI_SOURCE_LOCK","INVERTER_NOOP","PARALLEL_COALESCE","PARALLEL_FSIV"}{flags[name]=os.Getenv("JSGO_EXPERIMENT_"+name)}
   report:=struct{
    Kind string `json:"kind"`
    Source string `json:"source"`
    Task string `json:"task"`
    Job int `json:"job"`
    Args []string `json:"args"`
    GOMAXPROCS int `json:"gomaxprocs"`
    Exit int `json:"exit"`
    Flags map[string]string `json:"flags"`
    Counts postColorsDiagnosticCounts `json:"counts"`
    Output map[string]int `json:"output"`
    Quotient json.RawMessage `json:"quotient,omitempty"`
    RUC any `json:"ruc,omitempty"`
   }{"untimed-post-colors-design-dispatch",SOURCE_REVISION,task.Name,index,job.Args,runtime.GOMAXPROCS(0),status,flags,snapshot,
    map[string]int{"printers":probe.printers,"ascii_printers":probe.asciiPrinters,"promoted_printers":probe.promotedPrinters,"utf16_units":probe.units,"join_builders":probe.joinBuilders,"post_colors_printers":probe.runtimeLibraryPrinters},quotient,postColorsDiagnosticRUCTake()}
   encoded,err:=json.MarshalIndent(report,"","  ");if err!=nil {t.Fatal(err)}
   destination:=filepath.Join(job.Directory,"post-colors-activation.json")
   if err:=os.WriteFile(destination,append(encoded,'\\n'),0600);err!=nil{t.Fatal(err)}
   t.Logf("POST_COLORS_DIAGNOSTIC task=%s job=%d actual LVA=%d/%d nodes%d coalloc%d inverter=%d/%d records%d output ASCII=%d promoted=%d report=%s",task.Name,index,snapshot.Live.Runs,snapshot.Live.Attempts,snapshot.Live.Nodes,snapshot.FirstCoallocations,snapshot.Inverter.Activated,snapshot.Inverter.Calls,snapshot.Inverter.Records,probe.asciiPrinters,probe.promotedPrinters,destination)
  })}
 })}
}
'''.replace('SOURCE_REVISION',json.dumps(revision)).replace('FSIV_PRESENT','true' if fsiv_present else 'false'))
replace[str(pkg/test.name)]=str(test);copies.append(test)
# Deduplicate destinations when two hooks compose in one effective source file.
copies=list(dict.fromkeys(copies))
subprocess.run(['/workspace/toolchains/go1.27.2/bin/gofmt','-w',*[str(x) for x in copies]],check=True)
(out/'overlay.json').write_text(json.dumps({'Replace':replace},indent=2)+'\n')
jobs=a.jobs.resolve()
if not jobs.is_file():raise SystemExit('missing pinned jobs manifest '+str(jobs))
manifest={'root':str(root),'source':revision,'base_overlay':str(a.base_overlay.resolve()) if a.base_overlay else None,'untimed_only':True,'non_race_only':True,'forces_flags':False,'forces_admission':False,'retains_ast_or_name_order':False,'jobs':str(jobs),'jobs_sha256':hashlib.sha256(jobs.read_bytes()).hexdigest(),'composed_ruc':ruc_present,'composed_quotient':fsiv_present,'original_effective_source_sha256':original_hashes,'output_sha256':{x.name:hashlib.sha256(x.read_bytes()).hexdigest() for x in copies}}
(out/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
print(json.dumps({'root':str(root),'source':revision,'overlay':str(out/'overlay.json'),'jobs':str(jobs),'RUC':ruc_present,'quotient':fsiv_present},indent=2))
