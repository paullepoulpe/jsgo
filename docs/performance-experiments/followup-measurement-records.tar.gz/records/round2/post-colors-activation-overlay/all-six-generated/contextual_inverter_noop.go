package jscomp

import (
	"os"
	"strings"

	"github.com/paullepoulpe/jsgo/internal/rhino"
)

// Only the stock pass factory selects this experiment. Public constructors
// preserve the original scoped traversal and all custom callback schedules.
func newBuiltinContextualRenameInverter(compiler AbstractCompiler) CompilerPass {
	if os.Getenv("JSGO_EXPERIMENT_INVERTER_NOOP") != "1" && !compactInverterEnabled() {
		return MakeDeclaredNamesUnique_GetContextualRenameInverter(compiler)
	}
	return &contextualInverterNoopPass{compiler: compiler}
}

type contextualInverterNoopPass struct {
	compiler     AbstractCompiler
	probe        *contextualInverterNoopProbe // Optional correctness/coverage only.
	compactProbe *compactInverterProbe        // Optional correctness/coverage only.
}

type contextualInverterNoopProbe struct {
	ScannedNodes, ScannedNames int
	Skipped, Traversed         int
}

func (p *contextualInverterNoopPass) eligible(externs, js *rhino.Node) bool {
	c, ok := p.compiler.(*Compiler)
	return os.Getenv("JSGO_EXPERIMENT_INVERTER_NOOP") == "1" && ok && c != nil &&
		c.GetOptions() != nil && c.changeTracker != nil &&
		externs == c.GetExternsRoot() && js == c.GetJsRoot() && js != nil && js.IsRoot() &&
		c.GetOptions().customPasses == nil && !c.IsDebugLoggingEnabled() && parallelFSIVObserversSafe(c)
}

func (p *contextualInverterNoopPass) Process(externs, js *rhino.Node) {
	if finish := postColorsDiagnosticInverterBegin(p); finish != nil {
		defer finish()
	}
	if p.eligible(externs, js) && !contextualInverterHasPossibleRename(js, p.probe) {
		if p.probe != nil {
			p.probe.Skipped++
		}
		return
	}
	if p.probe != nil {
		p.probe.Traversed++
	}
	inverter := NewMakeDeclaredNamesUnique_ContextualRenameInverter(p.compiler)
	if p.compactEligible(externs, js) {
		arena := &compactInverterArena{probe: p.compactProbe}
		inverter.compact = arena
		if p.compactProbe != nil {
			p.compactProbe.Activated++
		}
		defer func() {
			arena.clearCohort()
			inverter.compact = nil
			if p.compactProbe != nil {
				p.compactProbe.Closed++
			}
		}()
	}
	inverter.Process(externs, js)
}

// CreateDeclaredVariableInfo permits any last "$jscomp$" separator at an
// index greater than zero, including an empty/non-numeric suffix. Every
// explicitly declared untyped Var comes from NAME or IMPORT_STAR; implicit
// names (arguments/this/super/exports) contain no separator. Inspecting all such
// AST names, including globals/references, is conservative: extra matches only
// retain the original traversal. No scope or cross-pass state is retained.
//
// For an ASCII separator, byte-index positivity equals UTF-16-index positivity
// even for Unicode/WTF-8 identifiers. The byte index is never used for slicing.
func contextualInverterHasPossibleRename(node *rhino.Node, probe *contextualInverterNoopProbe) bool {
	if probe != nil {
		probe.ScannedNodes++
	}
	if node.IsName() || node.IsImportStar() {
		if probe != nil {
			probe.ScannedNames++
		}
		if strings.LastIndex(node.GetString(), MakeDeclaredNamesUnique_ContextualRenamer_UNIQUE_ID_SEPARATOR) > 0 {
			return true
		}
	}
	for child := node.GetFirstChild(); child != nil; child = child.GetNext() {
		if contextualInverterHasPossibleRename(child, probe) {
			return true
		}
	}
	return false
}
