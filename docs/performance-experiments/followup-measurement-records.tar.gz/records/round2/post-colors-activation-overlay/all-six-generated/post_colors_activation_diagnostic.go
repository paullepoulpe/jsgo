// Generated only for untimed, NON-RACE activation diagnostics.
package jscomp

import "sync"

type postColorsLiveCounts struct {
	Attempts          int `json:"attempts"`
	Runs              int `json:"runs"`
	Nodes             int `json:"nodes"`
	Steps             int `json:"steps"`
	Transfers         int `json:"transfers"`
	CacheHits         int `json:"cache_hits"`
	EscapeTransitions int `json:"escape_transitions"`
}
type postColorsInverterCounts struct {
	Calls              int `json:"calls"`
	Activated          int `json:"activated"`
	Closed             int `json:"closed"`
	Records            int `json:"records"`
	Variables          int `json:"variables"`
	ShadowLinks        int `json:"shadow_links"`
	DuplicateLinks     int `json:"duplicate_links"`
	NameObservations   int `json:"name_observations"`
	GenericMemberships int `json:"generic_memberships"`
	Retirements        int `json:"retirements"`
	Cohorts            int `json:"cohorts"`
	PeakRecords        int `json:"max_records"`
	PeakVariables      int `json:"max_variables"`
	PeakLinks          int `json:"max_links"`
}
type postColorsDiagnosticCounts struct {
	Live               postColorsLiveCounts     `json:"liveness"`
	FirstCoallocations int                      `json:"first_scope_coallocations"`
	Inverter           postColorsInverterCounts `json:"compact_inverter"`
}

var postColorsDiagnosticState struct {
	sync.Mutex
	current *postColorsDiagnosticCounts
}

func postColorsDiagnosticSet(target *postColorsDiagnosticCounts) func() {
	postColorsDiagnosticState.Lock()
	previous := postColorsDiagnosticState.current
	postColorsDiagnosticState.current = target
	postColorsDiagnosticState.Unlock()
	return func() {
		postColorsDiagnosticState.Lock()
		postColorsDiagnosticState.current = previous
		postColorsDiagnosticState.Unlock()
	}
}
func postColorsDiagnosticLiveBegin() (*nativeLiveVariablesProbe, func()) {
	postColorsDiagnosticState.Lock()
	target := postColorsDiagnosticState.current
	postColorsDiagnosticState.Unlock()
	if target == nil {
		return nil, nil
	}
	probe := &nativeLiveVariablesProbe{}
	return probe, func() {
		postColorsDiagnosticState.Lock()
		defer postColorsDiagnosticState.Unlock()
		p := &target.Live
		p.Attempts++
		p.Runs += probe.Runs
		p.Nodes += probe.Nodes
		p.Steps += probe.Steps
		p.Transfers += probe.Transfers
		p.CacheHits += probe.CacheHits
		p.EscapeTransitions += probe.EscapeTransitions
	}
}
func postColorsDiagnosticCoallocation() {
	postColorsDiagnosticState.Lock()
	defer postColorsDiagnosticState.Unlock()
	if target := postColorsDiagnosticState.current; target != nil {
		target.FirstCoallocations++
	}
}
func postColorsDiagnosticInverterBegin(pass *contextualInverterNoopPass) func() {
	postColorsDiagnosticState.Lock()
	target := postColorsDiagnosticState.current
	postColorsDiagnosticState.Unlock()
	if target == nil || pass.compactProbe != nil {
		return nil
	}
	probe := &compactInverterProbe{diagnosticNumericOnly: true}
	pass.compactProbe = probe
	return func() {
		pass.compactProbe = nil
		postColorsDiagnosticState.Lock()
		defer postColorsDiagnosticState.Unlock()
		p := &target.Inverter
		p.Calls++
		p.Activated += probe.Activated
		p.Closed += probe.Closed
		p.Records += probe.Records
		p.Variables += probe.Variables
		p.ShadowLinks += probe.ShadowLinks
		p.DuplicateLinks += probe.DuplicateLinks
		p.NameObservations += probe.NameObservations
		p.GenericMemberships += probe.GenericMemberships
		p.Retirements += probe.Retirements
		p.Cohorts += probe.Cohorts
		p.PeakRecords = max(p.PeakRecords, probe.PeakRecords)
		p.PeakVariables = max(p.PeakVariables, probe.PeakVariables)
		p.PeakLinks = max(p.PeakLinks, probe.PeakLinks)
	}
}

func postColorsDiagnosticRUCReset() {
	removeUnusedActivationMutex.Lock()
	removeUnusedActivationRecords = nil
	removeUnusedActivationMutex.Unlock()
}
func postColorsDiagnosticRUCTake() any {
	removeUnusedActivationMutex.Lock()
	defer removeUnusedActivationMutex.Unlock()
	records := removeUnusedActivationRecords
	removeUnusedActivationRecords = nil
	return records
}
