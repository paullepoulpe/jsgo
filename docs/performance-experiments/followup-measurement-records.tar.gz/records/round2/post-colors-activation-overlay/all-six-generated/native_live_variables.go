package jscomp

import (
	"math/bits"
	"os"

	"github.com/paullepoulpe/jsgo/internal/jutil"
	"github.com/paullepoulpe/jsgo/internal/rhino"
)

func nativeLiveVariablesEnabled() bool {
	return os.Getenv("JSGO_EXPERIMENT_NATIVE_LIVE_VARIABLES") == "1"
}

// Only fresh builtin Process invocations can select this backend. In particular,
// public Analyze and public consumer constructors retain every original graph,
// annotation and callback operation. The CLI ownership witness also excludes
// custom source loaders that could observe/reenter the delayed publication.
// runtimeLibraryTypedAsts is intentionally not an exclusion here: the stock
// ConvertTypesToColors pass always initializes that table before optimization.
// Neither these consumers nor liveness analysis reads/invokes its suppliers.
// The original source-owner/stock-callback proof remains required; this does
// not admit typed-AST inputs or change any shared inference/pass guard.
func nativeLiveVariablesCompilerSafe(compiler AbstractCompiler, root *rhino.Node) bool {
	c, ok := compiler.(*Compiler)
	if !ok || c == nil || c.GetOptions() == nil || c.changeTracker == nil ||
		root == nil || root != c.GetJsRoot() || root.GetParent() != c.GetRoot() ||
		c.GetOptions().customPasses != nil || c.IsDebugLoggingEnabled() ||
		c.typedAstFilesystem != nil ||
		!parallelFSIVObserversSafe(c) || !parallelCoalesceConventionSafe(c.GetCodingConvention()) ||
		!typedInferenceWarningsGuardSafe(c.warningsGuard, c, 0) ||
		!typedInferenceWarningsGuardSafe(c.GetOptions().GetWarningsGuard(), c, 0) {
		return false
	}
	if handler, ok := SyntacticScopeCreator_DEFAULT_REDECLARATION_HANDLER.(*SyntacticScopeCreator_DefaultRedeclarationHandler); !ok || handler == nil {
		return false
	}
	reporter, ok := c.oldErrorReporter.(*rhinoErrorReporter_OldRhinoErrorReporter)
	if !ok || reporter == nil || reporter.internalReporter != c.asErrorHandler || c.asErrorHandler == nil || c.asErrorHandler.c != c {
		return false
	}
	for input := range c.inputsById.Values() {
		if input != nil && input.GetSourceFile() != nil {
			if _, owned := input.GetSourceFile().loader.(*cliOwnedSourceLoader); owned {
				return true
			}
		}
	}
	return false
}

// All supported consumers already reject functions with about 100 locals. Two
// words keep iterative transfer/join state contiguous and allocation-free.
// These are variable-bit positions, never encoded AST pointers.
type nativeLiveBits [2]uint64

func nativeLiveBitsFromSet(set *jutil.BitSet) (result nativeLiveBits) {
	for bit := set.NextSetBit(0); bit >= 0; bit = set.NextSetBit(bit + 1) {
		result[bit>>6] |= uint64(1) << uint(bit&63)
	}
	return result
}

func (b nativeLiveBits) write(set *jutil.BitSet) {
	for word, value := range b {
		for value != 0 {
			set.Set(word*64 + bits.TrailingZeros64(value))
			value &= value - 1
		}
	}
}

type nativeLiveVariableState struct {
	in, out       nativeLiveBits
	gen, kill     nativeLiveBits
	steps         int
	escapedSize   int
	queued, valid bool
}

type nativeLiveVariablesProbe struct {
	Runs, Nodes, Steps, Transfers, CacheHits, EscapeTransitions int
}

type nativeLiveVariablesSolver struct {
	analysis *LiveVariablesAnalysis
	nodes    []*LinkedDirectedGraph_LinkedDiGraphNode[*rhino.Node, ControlFlowGraph_Branch]
	ids      map[*LinkedDirectedGraph_LinkedDiGraphNode[*rhino.Node, ControlFlowGraph_Branch]]int
	states   []nativeLiveVariableState
	implicit int
	queue    []int
	probe    *nativeLiveVariablesProbe
}

func (l *LiveVariablesAnalysis) analyzeOwnedLiveVariables(owned bool, probe *nativeLiveVariablesProbe) {
	if !owned || !l.tryNativeLiveVariables(probe) {
		l.Analyze()
	}
}

func (l *LiveVariablesAnalysis) tryNativeLiveVariables(probe *nativeLiveVariablesProbe) bool {
	if probe == nil {
		var finish func()
		probe, finish = postColorsDiagnosticLiveBegin()
		if finish != nil {
			defer finish()
		}
	}
	g, ok := l.cfg.(*ControlFlowAnalysis_AstControlFlowGraph)
	if !ok || g == nil || g.self != g || g.diSelf != g || !g.useNodeAnnotations ||
		l.self != l || len(l.orderedVars) > 128 {
		return false
	}
	f := nativeLiveVariablesSolver{analysis: l, nodes: g.GetLinkedDiGraphNodes(), implicit: -1, probe: probe}
	f.ids = make(map[*LinkedDirectedGraph_LinkedDiGraphNode[*rhino.Node, ControlFlowGraph_Branch]]int, len(f.nodes))
	for id, node := range f.nodes {
		// The original comparator calls GetPriority, which rejects unset
		// priorities. CFA normally fills every one; malformed/unprepared
		// graphs must retain the original failure timing and annotations.
		if node == nil || !node.annotated || !node.HasPriority() {
			return false
		}
		f.ids[node] = id
		if node == g.GetImplicitReturn() {
			f.implicit = id
		}
	}
	if f.implicit < 0 {
		return false
	}
	// Reject custom edge objects or edges outside this exact graph before any
	// annotations/effects change. Builtin CFA emits only these concrete edges.
	for _, node := range f.nodes {
		for _, edges := range [][]DiGraph_DiGraphEdge[*rhino.Node, ControlFlowGraph_Branch]{node.GetInEdges(), node.GetOutEdges()} {
			for _, edge := range edges {
				e, ok := edge.(*LinkedDirectedGraph_LinkedDiGraphEdge[*rhino.Node, ControlFlowGraph_Branch])
				if !ok || e == nil {
					return false
				}
				if _, ok := f.ids[e.sourceNode]; !ok {
					return false
				}
				if _, ok := f.ids[e.destNode]; !ok {
					return false
				}
			}
		}
	}
	f.states = make([]nativeLiveVariableState, len(f.nodes))
	f.queue = make([]int, 0, len(f.nodes))
	if probe != nil {
		probe.Runs++
		probe.Nodes += len(f.nodes)
	}
	// The private owned interval has no graph observers. Publish standard
	// lattices on both success and throw, including partial step/join results,
	// before the caller's original exception wrapper sees the failure.
	defer f.publish()
	f.compute()
	return true
}

func (f *nativeLiveVariablesSolver) compute() {
	for id := range f.nodes {
		if id != f.implicit {
			f.enqueue(id)
		}
	}
	gen, kill := jutil.NewBitSetWithSize(128), jutil.NewBitSetWithSize(128)
	for len(f.queue) != 0 {
		id := f.remove()
		state := &f.states[id]
		state.queued = false
		before := state.steps
		state.steps++
		if f.probe != nil {
			f.probe.Steps++
		}
		if before > DataFlowAnalysis_MAX_STEPS_PER_NODE {
			panic(jutil.NewIllegalStateExceptionMsg("Dataflow analysis appears to diverge around: " + jutil.ToJavaString(f.nodes[id])))
		}
		// For zero outgoing edges the original JoinInputs leaves the previous
		// out untouched. Otherwise OR inputs in original edge order. Implicit
		// return's entry lattice is always the empty set in this analysis.
		edges := f.nodes[id].GetOutEdges()
		if len(edges) != 0 {
			state.out = nativeLiveBits{}
			for _, edge := range edges {
				e := edge.(*LinkedDirectedGraph_LinkedDiGraphEdge[*rhino.Node, ControlFlowGraph_Branch])
				next := f.states[f.ids[e.destNode]].in
				state.out[0] |= next[0]
				state.out[1] |= next[1]
			}
		}
		escaped := f.analysis.escaped.Size()
		if !state.valid || state.escapedSize != escaped {
			gen.ClearAll()
			kill.ClearAll()
			conditional := false
			for _, edge := range edges {
				if edge.GetValue() == ControlFlowGraph_Branch_ON_EX {
					conditional = true
				}
			}
			// Do not precompute: encountering arguments adds escaped parameters
			// at this exact transfer/AST visit. Earlier names in this transfer
			// must still see the old escaped set, just as in the original.
			f.analysis.ComputeGenKill(f.nodes[id].value, gen, kill, conditional)
			state.gen, state.kill = nativeLiveBitsFromSet(gen), nativeLiveBitsFromSet(kill)
			state.escapedSize = escaped
			state.valid = escaped == f.analysis.escaped.Size()
			if f.probe != nil {
				f.probe.Transfers++
				if !state.valid {
					f.probe.EscapeTransitions++
				}
			}
		} else if f.probe != nil {
			f.probe.CacheHits++
		}
		next := nativeLiveBits{
			(state.out[0] &^ state.kill[0]) | state.gen[0],
			(state.out[1] &^ state.kill[1]) | state.gen[1],
		}
		if next != state.in {
			state.in = next
			for _, edge := range f.nodes[id].GetInEdges() {
				e := edge.(*LinkedDirectedGraph_LinkedDiGraphEdge[*rhino.Node, ControlFlowGraph_Branch])
				if previous := f.ids[e.sourceNode]; previous != f.implicit {
					f.enqueue(previous)
				}
			}
		}
	}
}

// Match PriorityQueue's original heap tie rules and initial insertion order.
// The stock backward comparator is exactly descending integer node priority.
func (f *nativeLiveVariablesSolver) enqueue(id int) {
	if f.states[id].queued {
		return
	}
	f.states[id].queued = true
	at := len(f.queue)
	f.queue = append(f.queue, id)
	for at > 0 {
		parent := (at - 1) / 2
		if f.nodes[id].priority <= f.nodes[f.queue[parent]].priority {
			break
		}
		f.queue[at] = f.queue[parent]
		at = parent
	}
	f.queue[at] = id
}

func (f *nativeLiveVariablesSolver) remove() int {
	id := f.queue[0]
	last := f.queue[len(f.queue)-1]
	f.queue = f.queue[:len(f.queue)-1]
	if len(f.queue) == 0 {
		return id
	}
	at := 0
	for {
		child := at*2 + 1
		if child >= len(f.queue) {
			break
		}
		if right := child + 1; right < len(f.queue) && f.nodes[f.queue[right]].priority > f.nodes[f.queue[child]].priority {
			child = right
		}
		if f.nodes[last].priority >= f.nodes[f.queue[child]].priority {
			break
		}
		f.queue[at] = f.queue[child]
		at = child
	}
	f.queue[at] = last
	return id
}

func (f *nativeLiveVariablesSolver) publish() {
	states := make([]DataFlowAnalysis_LinearFlowState[*LiveVariablesAnalysis_LiveVariableLattice], len(f.nodes))
	lattices := make([]LiveVariablesAnalysis_LiveVariableLattice, len(f.nodes)*2)
	sets := make([]jutil.BitSet, len(f.nodes)*2)
	for id, node := range f.nodes {
		for side, value := range [2]nativeLiveBits{f.states[id].in, f.states[id].out} {
			at := id*2 + side
			sets[at] = *jutil.NewBitSetWithSize(len(f.analysis.orderedVars))
			value.write(&sets[at])
			lattices[at].liveSet = &sets[at]
		}
		states[id] = DataFlowAnalysis_LinearFlowState[*LiveVariablesAnalysis_LiveVariableLattice]{
			stepCount: f.states[id].steps, in: &lattices[id*2], out: &lattices[id*2+1],
		}
		node.SetAnnotation(&states[id])
	}
}
