package jscomp

import (
	"github.com/paullepoulpe/jsgo/internal/jutil"
	"github.com/paullepoulpe/jsgo/internal/rhino"
)

// Coallocation ties the first Var/entry lifetime to its map. Admit only fresh
// stock CLI IV/RUC creators: their declaration maps remain read-only after
// population (RUC's one extra global declaration only appends). Public/custom
// creators retain independent allocation and unrestricted mutation lifetimes.
// Stock typesToColors loads runtimeLibraryTypedAsts before IV/RUC. This table
// contains deferred library suppliers; neither the syntactic declaration scan
// nor first Var/map/entry construction reads or invokes it. It does not change
// their ownership or read-only declaration-map lifetime proof. Injected typed
// AST files and arbitrary callbacks remain excluded independently.
func scopeFirstAllocationEligible(owner *Compiler) bool {
	if owner.typedAstFilesystem != nil ||
		!typedInferenceWarningsGuardSafe(owner.warningsGuard, owner, 0) ||
		!typedInferenceWarningsGuardSafe(owner.GetOptions().GetWarningsGuard(), owner, 0) {
		return false
	}
	reporter, ok := owner.oldErrorReporter.(*rhinoErrorReporter_OldRhinoErrorReporter)
	if !ok || reporter == nil || reporter.internalReporter != owner.asErrorHandler || owner.asErrorHandler == nil || owner.asErrorHandler.c != owner {
		return false
	}
	for input := range owner.inputsById.Values() {
		if input != nil && input.GetSourceFile() != nil {
			if _, owned := input.GetSourceFile().loader.(*cliOwnedSourceLoader); owned {
				return true
			}
		}
	}
	return false
}

// This is reached only for the first ordinary declaration of a private fresh
// scope. Preserve Scope.Declare's constructor/check/publication order, or the
// independently enabled stock-insertion experiment's exact prechecked order.
func (s *Scope) declareFirstCoallocated(name string, nameNode *rhino.Node, input *CompilerInput, prechecked bool) *Var {
	jutil.CheckArgument(name != "")
	if !prechecked {
		jutil.CheckState(s.getOwnSlotV(name) == nil)
	}
	variable, variables := jutil.NewLinkedHashMapWithOwnedFirstValue[string, Var](name)
	// Same pure initialization and validation as NewVar, without changing that
	// public hot constructor's call graph or allocating a temporary Var to copy.
	variable.InitAbstractVarBase(variable, name, nameNode, s, s.GetVarCount(), input, nil)
	if nameNode != nil {
		switch nameNode.GetToken() {
		case rhino.Token_MODULE_BODY, rhino.Token_NAME, rhino.Token_IMPORT_STAR:
		default:
			panic(jutil.NewIllegalArgumentExceptionMsg("Invalid name node " + jutil.ToJavaString(nameNode)))
		}
	}
	if prechecked {
		jutil.CheckStateMsg1(s.CanDeclare(name), "Illegal shadow: %s", variable.GetNode())
	} else {
		jutil.CheckStateMsg1(s.HasOwnSlot(name) || s.CanDeclare(name), "Illegal shadow: %s", variable.GetNode())
	}
	// Constructor and legality checks see the original nil map throughout.
	// The returned map already contains the exact first Var under an owned key.
	s.vars = variables
	postColorsDiagnosticCoallocation()
	return variable
}
