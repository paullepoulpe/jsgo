package jscomp

import (
	"os"
	"strconv"
	"unicode/utf8"

	"github.com/paullepoulpe/jsgo/internal/jutil"
	"github.com/paullepoulpe/jsgo/internal/rhino"
)

func compactInverterEnabled() bool {
	return os.Getenv("JSGO_EXPERIMENT_COMPACT_INVERTER") == "1"
}

// Ordinary optimized CLI runs have a loaded runtimeLibraryTypedAsts table.
// Shadow identity recording, name membership and the unchanged inverter never
// read/invoke its suppliers. It supplies no callbacks to this private pass;
// injected typed AST files and all other public/custom fences still apply.
func (p *contextualInverterNoopPass) compactEligible(externs, js *rhino.Node) bool {
	c, ok := p.compiler.(*Compiler)
	if !compactInverterEnabled() || !ok || c == nil || c.GetOptions() == nil || c.changeTracker == nil ||
		externs != c.GetExternsRoot() || js == nil || js != c.GetJsRoot() || js.GetParent() != c.GetRoot() ||
		c.GetOptions().customPasses != nil || c.IsDebugLoggingEnabled() ||
		c.typedAstFilesystem != nil ||
		!parallelFSIVObserversSafe(c) || !fsivScopeSharingConventionSafe(c.GetCodingConvention()) ||
		!typedInferenceWarningsGuardSafe(c.warningsGuard, c, 0) ||
		!typedInferenceWarningsGuardSafe(c.GetOptions().GetWarningsGuard(), c, 0) {
		return false
	}
	reporter, ok := c.oldErrorReporter.(*rhinoErrorReporter_OldRhinoErrorReporter)
	if !ok || reporter == nil || reporter.internalReporter != c.asErrorHandler || c.asErrorHandler == nil || c.asErrorHandler.c != c {
		return false
	}
	// The stock fresh CLI installs this package-private proof only after
	// excluding public AST/type injection and custom static source callbacks.
	for input := range c.inputsById.Values() {
		if input != nil && input.GetSourceFile() != nil {
			if _, owned := input.GetSourceFile().loader.(*cliOwnedSourceLoader); owned {
				return true
			}
		}
	}
	return false
}

// Records are indexed by IDs so slice growth cannot invalidate a live owner.
// Only the identity table contains VariableInfo pointers. Shadow sequences
// and their optional membership indexes contain pointer-free uint32 IDs.
type compactInverterRecord struct {
	owner *MakeDeclaredNamesUnique_ContextualRenameInverter_RenamingInfo
	ids   []uint32
	seen  map[uint32]struct{}
}

const compactInverterMaxVariables = 1 << 16
const compactInverterMaxRecords = 1 << 16
const compactInverterMaxLinks = 1 << 20

type compactInverterArena struct {
	variables []MakeDeclaredNamesUnique_ContextualRenameInverter_VariableInfo
	index     map[MakeDeclaredNamesUnique_ContextualRenameInverter_VariableInfo]uint32
	records   []compactInverterRecord
	links     int
	retired   bool
	probe     *compactInverterProbe
}

// Nil during ordinary CLI timing. No callbacks, globals, or shared counters.
type compactInverterProbe struct {
	diagnosticNumericOnly                                              bool // Overlay-only; original test probes retain observations.
	Activated, Closed, Records, Variables, ShadowLinks, DuplicateLinks int
	NameObservations, GenericMemberships, Retirements, Cohorts         int
	PeakRecords, PeakVariables, PeakLinks                              int
	NameOrder                                                          []uint32
}

func (a *compactInverterArena) newRecord(owner *MakeDeclaredNamesUnique_ContextualRenameInverter_RenamingInfo) uint32 {
	if a.retired {
		return 0
	}
	if len(a.records) == compactInverterMaxRecords {
		a.retire()
		return 0
	}
	a.records = append(a.records, compactInverterRecord{owner: owner})
	if a.probe != nil {
		a.probe.Records++
		if len(a.records) > a.probe.PeakRecords {
			a.probe.PeakRecords = len(a.records)
		}
	}
	return uint32(len(a.records))
}

func (a *compactInverterArena) add(recordID uint32, info MakeDeclaredNamesUnique_ContextualRenameInverter_VariableInfo) bool {
	// Unknown implementations may have public callback/identity behavior. The
	// private stock path creates exactly these final two implementations.
	switch info.(type) {
	case *MakeDeclaredNamesUnique_ContextualRenameInverter_DeclaredVariableInfo,
		*MakeDeclaredNamesUnique_ContextualRenameInverter_UndeclaredVariableInfo:
	default:
		a.retire()
		return false
	}
	id, found := a.index[info]
	if !found {
		if len(a.variables) == compactInverterMaxVariables {
			a.retire()
			return false
		}
		if a.index == nil {
			a.index = make(map[MakeDeclaredNamesUnique_ContextualRenameInverter_VariableInfo]uint32)
		}
		a.variables = append(a.variables, info)
		id = uint32(len(a.variables))
		a.index[info] = id
		if a.probe != nil {
			a.probe.Variables++
			if len(a.variables) > a.probe.PeakVariables {
				a.probe.PeakVariables = len(a.variables)
			}
		}
	}
	r := &a.records[recordID-1]
	if r.seen != nil {
		if _, duplicate := r.seen[id]; duplicate {
			if a.probe != nil {
				a.probe.DuplicateLinks++
			}
			return true
		}
	} else {
		for _, previous := range r.ids {
			if previous == id {
				if a.probe != nil {
					a.probe.DuplicateLinks++
				}
				return true
			}
		}
	}
	if a.links == compactInverterMaxLinks {
		a.retire()
		return false
	}
	r.ids = append(r.ids, id)
	if r.seen != nil {
		r.seen[id] = struct{}{}
	} else if len(r.ids) > 8 {
		r.seen = make(map[uint32]struct{}, len(r.ids))
		for _, existing := range r.ids {
			r.seen[existing] = struct{}{}
		}
	}
	a.links++
	if a.probe != nil {
		a.probe.ShadowLinks++
		if a.links > a.probe.PeakLinks {
			a.probe.PeakLinks = a.links
		}
	}
	return true
}

// Cap or unsupported-implementation fallback preserves every existing record
// and its encounter order without observing any names. No old ID can escape
// into a later cohort. The original public storage owns subsequent changes.
func (a *compactInverterArena) retire() {
	for _, record := range a.records {
		r := record.owner
		r.potentialShadowVariables = jutil.NewLinkedHashSet[MakeDeclaredNamesUnique_ContextualRenameInverter_VariableInfo]()
		for _, id := range record.ids {
			r.potentialShadowVariables.Add(a.variables[id-1])
		}
		r.compactShadowID = 0
	}
	a.variables, a.index, a.records = nil, nil, nil
	a.links = 0
	a.retired = true
	if a.probe != nil {
		a.probe.Retirements++
	}
}

func (a *compactInverterArena) clearCohort() {
	if len(a.records) != 0 || a.retired {
		if a.probe != nil {
			a.probe.Cohorts++
		}
	}
	a.variables, a.index, a.records = nil, nil, nil
	a.links, a.retired = 0, false
}

// String membership has no exposed iteration. Valid UTF-8 strings have a
// unique Java UTF-16 encoding. For malformed/WTF-8 public-style names, retain
// the original port's collection behavior instead of introducing a new byte
// hash/equality policy. GetName is still observed exactly once and in order.
type compactInverterNames struct {
	native  map[string]struct{}
	generic *jutil.LinkedHashSet[string]
}

func (s *compactInverterNames) add(name string) {
	if s.generic != nil {
		s.generic.Add(name)
		return
	}
	if !utf8.ValidString(name) {
		s.useOriginalCollection()
		s.generic.Add(name)
		return
	}
	if s.native == nil {
		s.native = make(map[string]struct{})
	}
	s.native[name] = struct{}{}
}

func (s *compactInverterNames) useOriginalCollection() {
	if s.generic != nil {
		return
	}
	s.generic = jutil.NewLinkedHashSet[string]()
	// This temporary set is only queried for membership; its iteration order
	// never escapes. All current names were already observed exactly once.
	for existing := range s.native {
		s.generic.Add(existing)
	}
	s.native = nil
}

func (s *compactInverterNames) contains(name string) bool {
	if s.generic == nil && !utf8.ValidString(name) {
		s.useOriginalCollection()
	}
	if s.generic != nil {
		return s.generic.Contains(name)
	}
	_, present := s.native[name]
	return present
}

func (r *MakeDeclaredNamesUnique_ContextualRenameInverter_RenamingInfo) attemptCompactRename() string {
	a := r.this_.compact
	var disallowed compactInverterNames
	disallowed.add(MakeDeclaredNamesUnique_ARGUMENTS)
	for _, id := range a.records[r.compactShadowID-1].ids {
		disallowed.add(a.variables[id-1].GetName())
		if a.probe != nil {
			a.probe.NameObservations++
			if !a.probe.diagnosticNumericOnly {
				a.probe.NameOrder = append(a.probe.NameOrder, id)
			}
		}
	}
	newName := r.preferredName
	if disallowed.contains(newName) {
		baseName := newName + MakeDeclaredNamesUnique_ContextualRenamer_UNIQUE_ID_SEPARATOR
		for i := 0; ; i++ {
			newName = baseName + strconv.Itoa(i)
			if !disallowed.contains(newName) {
				break
			}
		}
	}
	if a.probe != nil && disallowed.generic != nil {
		a.probe.GenericMemberships++
	}
	if newName == r.currentName {
		return r.currentName
	}
	for _, referenceNode := range r.referenceNodes {
		referenceNode.SetString(newName)
		r.this_.compiler.ReportChangeToEnclosingScope(referenceNode)
		parent := referenceNode.GetParent()
		if parent.IsFunction() && NodeUtil_IsFunctionDeclaration(parent) {
			r.this_.compiler.ReportChangeToEnclosingScope(parent)
		}
	}
	return newName
}
