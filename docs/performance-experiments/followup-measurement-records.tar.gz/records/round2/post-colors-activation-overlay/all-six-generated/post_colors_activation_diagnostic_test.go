package jscomp

import (
	"bytes"
	"crypto/sha256"
	"encoding/hex"
	"encoding/json"
	"fmt"
	"github.com/paullepoulpe/jsgo/internal/jutil"
	"os"
	"path/filepath"
	"runtime"
	"testing"
)

func TestPostColorsDesignDiagnosticPinnedTasks(t *testing.T) {
	path := os.Getenv("JSGO_POST_COLORS_DIAGNOSTIC_JOBS")
	if path == "" {
		t.Skip("untimed diagnostic only; exact pinned job manifest not supplied")
	}
	data, err := os.ReadFile(path)
	if err != nil {
		t.Fatal(err)
	}
	var manifest struct {
		Tasks []struct {
			Name string
			Jobs []struct {
				Directory string
				Args      []string
				Expected  map[string]string
			}
		}
	}
	if err := json.Unmarshal(data, &manifest); err != nil {
		t.Fatal(err)
	}
	for _, task := range manifest.Tasks {
		t.Run(task.Name, func(t *testing.T) {
			for index, job := range task.Jobs {
				t.Run(fmt.Sprint(index), func(t *testing.T) {
					t.Chdir(job.Directory)
					for artifact := range job.Expected {
						if err := os.Remove(artifact); err != nil && !os.IsNotExist(err) {
							t.Fatal(err)
						}
					}
					quotientPath := filepath.Join(job.Directory, "post-colors-quotient.json")
					_ = os.Remove(quotientPath)
					t.Setenv("JSGO_FSIV_USE_CARDINALITY_DIAGNOSTIC_JSON", quotientPath)
					var output, diagnostics bytes.Buffer
					runner := NewCommandLineRunnerWithOutAndErr(job.Args, jutil.NewPrintStream(&output), jutil.NewPrintStream(&diagnostics))
					counts := &postColorsDiagnosticCounts{}
					restore := postColorsDiagnosticSet(counts)
					defer restore()
					probe := &nativeOutputBufferProbe{}
					runner.nativeOutputBufferProbe = probe
					postColorsDiagnosticRUCReset()
					status := runner.DoRun()
					// DoRun has joined compiler jobs and completed original code generation.
					postColorsDiagnosticState.Lock()
					snapshot := *counts
					postColorsDiagnosticState.Unlock()
					for name, data := range map[string][]byte{"stdout": output.Bytes(), "stderr": diagnostics.Bytes(), "exit": []byte(fmt.Sprintln(status))} {
						if err := os.WriteFile(name, data, 0600); err != nil {
							t.Fatal(err)
						}
					}
					for name, want := range job.Expected {
						data, err := os.ReadFile(name)
						if err != nil {
							t.Fatal(err)
						}
						hash := sha256.Sum256(data)
						if got := hex.EncodeToString(hash[:]); got != want {
							t.Errorf("pinned Java artifact mismatch %s got%s want%s", name, got, want)
						}
					}
					var quotient json.RawMessage
					if true {
						quotient, err = os.ReadFile(quotientPath)
						if err != nil {
							t.Fatal(err)
						}
					}
					flags := map[string]string{}
					for _, name := range []string{"NATIVE_LIVE_VARIABLES", "SCOPE_FIRST_ALLOCATION", "COMPACT_INVERTER", "ASCII_OUTPUT_BUFFER", "FSIV_USE_CARDINALITY", "REMOVE_UNUSED_TASKS", "REMOVE_UNUSED_INTRUSIVE_FIFO", "CLI_SOURCE_LOCK", "INVERTER_NOOP", "PARALLEL_COALESCE", "PARALLEL_FSIV"} {
						flags[name] = os.Getenv("JSGO_EXPERIMENT_" + name)
					}
					report := struct {
						Kind       string                     `json:"kind"`
						Source     string                     `json:"source"`
						Task       string                     `json:"task"`
						Job        int                        `json:"job"`
						Args       []string                   `json:"args"`
						GOMAXPROCS int                        `json:"gomaxprocs"`
						Exit       int                        `json:"exit"`
						Flags      map[string]string          `json:"flags"`
						Counts     postColorsDiagnosticCounts `json:"counts"`
						Output     map[string]int             `json:"output"`
						Quotient   json.RawMessage            `json:"quotient,omitempty"`
						RUC        any                        `json:"ruc,omitempty"`
					}{"untimed-post-colors-design-dispatch", "9d190a2b20d05bc33b203b4370176129ac80dc80", task.Name, index, job.Args, runtime.GOMAXPROCS(0), status, flags, snapshot,
						map[string]int{"printers": probe.printers, "ascii_printers": probe.asciiPrinters, "promoted_printers": probe.promotedPrinters, "utf16_units": probe.units, "join_builders": probe.joinBuilders, "post_colors_printers": probe.runtimeLibraryPrinters}, quotient, postColorsDiagnosticRUCTake()}
					encoded, err := json.MarshalIndent(report, "", "  ")
					if err != nil {
						t.Fatal(err)
					}
					destination := filepath.Join(job.Directory, "post-colors-activation.json")
					if err := os.WriteFile(destination, append(encoded, '\n'), 0600); err != nil {
						t.Fatal(err)
					}
					t.Logf("POST_COLORS_DIAGNOSTIC task=%s job=%d actual LVA=%d/%d nodes%d coalloc%d inverter=%d/%d records%d output ASCII=%d promoted=%d report=%s", task.Name, index, snapshot.Live.Runs, snapshot.Live.Attempts, snapshot.Live.Nodes, snapshot.FirstCoallocations, snapshot.Inverter.Activated, snapshot.Inverter.Calls, snapshot.Inverter.Records, probe.asciiPrinters, probe.promotedPrinters, destination)
				})
			}
		})
	}
}
