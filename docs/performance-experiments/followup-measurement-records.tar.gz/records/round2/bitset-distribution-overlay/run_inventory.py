#!/usr/bin/env python3
"""Untimed original BitSet event inventory with unchanged Java artifact gates."""
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys

REPO = Path('/workspace/jsgo-structural-native-analysis')
RESULTS = Path('/workspace/jsgo-results/round2')
FROZEN = RESULTS/'bitset-distribution-overlay/native-analysis-f2c17056'
BINARY = RESULTS/'bin/jsgo-bitset-distribution'
OUT = RESULTS/'bitset-distribution-original'
REFERENCE = RESULTS/'baseline'
TASKS = ['downlevel-whitespace', 'downlevel-simple', 'typed-app', 'checks-only', 'bundle']


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def verify_frozen():
    manifest = json.loads((FROZEN/'manifest.json').read_text())
    current = subprocess.check_output(['git', '-C', str(REPO), 'rev-parse', 'HEAD'], text=True).strip()
    if current != manifest['commit']:
        raise RuntimeError('original source checkout HEAD changed')
    if sha(FROZEN/'generate.py') != manifest['generator_sha256']:
        raise RuntimeError('frozen generator changed')
    for item in manifest['sources']:
        if sha(item['original']) != item['original_sha256'] or sha(item['replacement']) != item['replacement_sha256']:
            raise RuntimeError('frozen original/replacement source hash changed: '+item['original'])
    return manifest


manifest = verify_frozen()
if OUT.exists():
    raise RuntimeError('refusing to overwrite inventory '+str(OUT))
OUT.mkdir()
sys.path.insert(0, str(REPO/'tools/bench'))
sys.dont_write_bytecode = True
import bench

control = json.loads((RESULTS/'native-live-words-screen/machine.json').read_text())['variant_environment']['base']
assert len(control) == 10 and control['JSGO_EXPERIMENT_CLI_SOURCE_LOCK'] == '1'
assert 'JSGO_EXPERIMENT_NATIVE_LIVE_VARIABLES' not in control
env = {k: v for k, v in os.environ.items() if not k.startswith('JSGO_') and k not in bench.GO_ENV_DROP}
env.update(control)
env['LC_ALL'] = 'C.UTF-8'
cache = bench.default_cache()
metadata = {
    'purpose': 'UNTIMED method/event inventory; constructor calls are NOT mallocs/retained objects/bytes/RSS.',
    'source_commit': manifest['commit'], 'binary': str(BINARY), 'binary_sha256': sha(BINARY),
    'overlay_manifest_sha256': sha(FROZEN/'manifest.json'), 'flags': control,
    'runtime': 'Default GC, GOMAXPROCS, GOMEMLIMIT and GODEBUG; inherited JSGO_* cleared.',
    'reference': str(REFERENCE), 'cache': cache, 'affinity': sorted(os.sched_getaffinity(0)),
    'tasks': TASKS,
}
(OUT/'provenance.json').write_text(json.dumps(metadata, indent=2)+'\n')
summary = {}
tasks = {task['name']: task for task in bench.load_tasks(TASKS)}
for name in TASKS:
    verify_frozen()
    task = tasks[name]
    reference = REFERENCE/name
    tdir = OUT/name
    tdir.mkdir()
    (tdir/'java-cold').symlink_to(reference/'java-cold', target_is_directory=True)
    jobs = json.loads((reference/'jobs.json').read_text())
    (tdir/'jobs.json').write_text(json.dumps(jobs, indent=2)+'\n')
    rundir = tdir/'jsgo/run-1'
    bench.make_workspace(str(rundir), cache)
    reports = []
    for index, arguments in enumerate(jobs):
        artifacts = bench.artifacts(task, str(rundir), index, len(jobs) == 1)
        counts = tdir/f'counts-{index}.json'
        child_env = env | {'JSGO_BITSET_DIAGNOSTIC_PATH': str(counts)}
        with open(artifacts['stdout'], 'wb') as stdout, open(artifacts['stderr'], 'wb') as stderr:
            result = subprocess.run([str(BINARY)]+arguments, cwd=rundir, env=child_env,
                                    stdin=subprocess.DEVNULL, stdout=stdout, stderr=stderr)
        Path(artifacts['exit']).write_text(str(result.returncode)+'\n')
        if result.returncode:
            raise RuntimeError(f'nonzero diagnostic exit: {name}/{index}')
        data = json.loads(counts.read_text())
        if sum(data['Constructors'][3]):
            raise RuntimeError('V2 owned-word publication contaminated original inventory')
        for kind in range(4):
            assert sum(row['Calls'] for row in data['ExactConstructors'] if row['Kind'] == kind) == sum(data['Constructors'][kind])
        assert sum(row['Calls'] for row in (data['ExactClones'] or [])) == sum(data['Constructors'][2])
        assert sum(row['Calls'] for row in (data['ExactGrowth'] or [])) == sum(map(sum, data['CapacityGrowthFromByTo']))
        assert sum((row['ToCapacityWords']-row['FromCapacityWords'])*row['Calls'] for row in (data['ExactGrowth'] or [])) == data['CapacityGrowthWords']
        assert sum(row['ToCapacityWords']*row['Calls'] for row in (data['ExactGrowth'] or [])) == data['CapacityGrowthAllocatedBackingWords']
        reports.append(data)
    gate = bench.gate(task, jobs, str(tdir))
    if gate != 'MATCH':
        raise RuntimeError('Java artifact mismatch: '+name)
    combined = [sum(report['Constructors'][kind][bucket] for report in reports for kind in range(3)) for bucket in range(4)]
    clones = [sum(report['Constructors'][2][bucket] for report in reports) for bucket in range(4)]
    growth = [[sum(report['CapacityGrowthFromByTo'][a][b] for report in reports) for b in range(4)] for a in range(4)]
    summary[name] = {'gate': gate, 'constructor_result_capacity_0_1_2_large': combined,
                     'clone_result_capacity_0_1_2_large': clones, 'growth_from_by_to_capacity_0_1_2_large': growth,
                     'owned_word_helper_calls': 0, 'raw_reports': [str(tdir/f'counts-{i}.json') for i in range(len(jobs))]}
    (OUT/'summary.json').write_text(json.dumps(summary, indent=2)+'\n')
    print(name, 'MATCH constructors0/1/2/>2=',combined,'clone0/1/2/>2=',clones,flush=True)
print('All five Java artifact gates MATCH. Events are NOT heap allocations or performance measurements.', flush=True)
