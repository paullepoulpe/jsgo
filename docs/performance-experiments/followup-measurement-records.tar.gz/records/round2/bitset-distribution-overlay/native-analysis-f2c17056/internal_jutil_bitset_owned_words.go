package jutil

// NewBitSetFromOwnedWords adopts a caller-owned word window without copying it.
//
// Go-only: performance — ownership transfers to the returned BitSet. The caller
// must not subsequently mutate the supplied words except through that BitSet.
// Other disjoint windows of the same allocation may belong to other BitSets.
// Capacity is limited to the supplied length before trimming zero words, so
// later growth cannot overwrite any adjacent window. Empty reserved words still
// contribute to Size, just as with NewBitSetWithSize.
func NewBitSetFromOwnedWords(words []uint64) *BitSet {
	bitSetDiagnostic.constructors[3][bitSetDiagnosticBucket(len(words))].Add(1)
	bitSetDiagnosticConstructor(3, len(words)*64, len(words))
	b := &BitSet{words: words[:len(words):len(words)]}
	b.trim()
	return b
}
