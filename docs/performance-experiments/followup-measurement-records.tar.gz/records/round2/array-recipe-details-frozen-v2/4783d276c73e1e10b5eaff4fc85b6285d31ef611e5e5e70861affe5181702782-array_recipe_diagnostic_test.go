package jscomp

import (
	"bytes"
	"crypto/sha256"
	"encoding/hex"
	"encoding/json"
	"fmt"
	"os"
	"path/filepath"
	"sync"
	"testing"

	"github.com/paullepoulpe/jsgo/internal/jutil"
	"github.com/paullepoulpe/jsgo/internal/rhino"
)

type arrayRecipeDiagnosticCounts struct {
	ExactCalls      int `json:"exact_array_unknown_calls"`
	CaptureAttempts int `json:"capture_attempts"`
	CaptureRejected int `json:"capture_rejected"`
	Passes          int `json:"passes"`
	Activated       int `json:"activated"`
	Calls           int `json:"constructor_calls"`
	Seeds           int `json:"original_seeds"`
	Hits            int `json:"fresh_recipe_hits"`
	Fallbacks       int `json:"native_mutation_fallbacks"`
	FastScopeChecks int `json:"fast_scope_checks"`
	FullScopeChecks int `json:"full_scope_checks"`
	BoundaryChecks  int `json:"boundary_checks"`
}

func TestArrayRecipeDiagnosticPinnedTasks(t *testing.T) {
	path := os.Getenv("JSGO_ARRAY_RECIPE_DIAGNOSTIC_JOBS")
	if path == "" {
		t.Skip("untimed diagnostic only; manifest not provided")
	}
	data, err := os.ReadFile(path)
	if err != nil {
		t.Fatal(err)
	}
	var manifest struct {
		Root      string `json:"root"`
		Reference string `json:"reference"`
		Tasks     []struct {
			Name string `json:"name"`
			Jobs []struct {
				Directory string            `json:"directory"`
				Args      []string          `json:"args"`
				Expected  map[string]string `json:"expected"`
			} `json:"jobs"`
		} `json:"tasks"`
	}
	if err := json.Unmarshal(data, &manifest); err != nil {
		t.Fatal(err)
	}
	for _, task := range manifest.Tasks {
		t.Run(task.Name, func(t *testing.T) {
			rhino.ResetNativeArrayRecipeDiagnostic()
			var totals arrayRecipeDiagnosticCounts
			for index, job := range task.Jobs {
				t.Run(fmt.Sprint(index), func(t *testing.T) {
					t.Chdir(job.Directory)
					for artifact := range job.Expected {
						if err := os.Remove(artifact); err != nil && !os.IsNotExist(err) {
							t.Fatal(err)
						}
					}
					var counts arrayRecipeDiagnosticCounts
					var mu sync.Mutex
					restore := arrayRecipeDiagnosticSetObserver(func(p *freshTemplateValuesProbe) {
						mu.Lock()
						defer mu.Unlock()
						counts.ExactCalls += p.DiagnosticExactCalls
						counts.CaptureAttempts += p.DiagnosticCaptureAttempts
						counts.CaptureRejected += p.DiagnosticCaptureRejected
						counts.Passes++
						counts.Activated += p.Activated
						counts.Calls += p.Calls
						counts.Seeds += p.ArrayRecipeSeeds
						counts.Hits += p.ArrayRecipeHits
						counts.Fallbacks += p.ArrayRecipeFallbacks
						counts.FastScopeChecks += p.FastScopeChecks
						counts.FullScopeChecks += p.FullScopeChecks
						counts.BoundaryChecks += p.BoundaryChecks
					})
					defer restore()
					var stdout, stderr bytes.Buffer
					runner := NewCommandLineRunnerWithOutAndErr(job.Args, jutil.NewPrintStream(&stdout), jutil.NewPrintStream(&stderr))
					status := runner.DoRun()
					// Only the real CLI chooses options, loaders and private admission. No
					// test-mode runner, synthetic owner or experimental flag is injected.
					for name, data := range map[string][]byte{"stdout": stdout.Bytes(), "stderr": stderr.Bytes(), "exit": []byte(fmt.Sprintln(status))} {
						if err := os.WriteFile(name, data, 0600); err != nil {
							t.Fatal(err)
						}
					}
					for name, want := range job.Expected {
						data, err := os.ReadFile(filepath.Join(job.Directory, name))
						if err != nil {
							t.Fatal(err)
						}
						hash := sha256.Sum256(data)
						got := hex.EncodeToString(hash[:])
						if got != want {
							t.Errorf("pinned Java artifact mismatch %s got%s want%s", name, got, want)
						}
					}
					mu.Lock()
					totals.ExactCalls += counts.ExactCalls
					totals.CaptureAttempts += counts.CaptureAttempts
					totals.CaptureRejected += counts.CaptureRejected
					totals.Passes += counts.Passes
					totals.Activated += counts.Activated
					totals.Calls += counts.Calls
					totals.Seeds += counts.Seeds
					totals.Hits += counts.Hits
					totals.Fallbacks += counts.Fallbacks
					totals.FastScopeChecks += counts.FastScopeChecks
					totals.FullScopeChecks += counts.FullScopeChecks
					totals.BoundaryChecks += counts.BoundaryChecks
					mu.Unlock()
				})
			}
			report := struct {
				Kind             string                      `json:"kind"`
				Task             string                      `json:"task"`
				ArrayRecipeFlag  string                      `json:"array_recipe_flag"`
				FreshVectorFlag  string                      `json:"fresh_vector_flag"`
				CLIOwnershipFlag string                      `json:"cli_ownership_flag"`
				Counts           arrayRecipeDiagnosticCounts `json:"counts"`
			}{"untimed-array-recipe-dispatch", task.Name, os.Getenv("JSGO_EXPERIMENT_ARRAY_UNKNOWN_RECIPE"), os.Getenv("JSGO_EXPERIMENT_FRESH_TEMPLATE_VALUES"), os.Getenv("JSGO_EXPERIMENT_CLI_SOURCE_LOCK"), totals}
			detail, err := json.Marshal(rhino.SnapshotNativeArrayRecipeDiagnostic())
			if err != nil {
				t.Fatal(err)
			}
			t.Log("ARRAY_RECIPE_CAPTURE_DETAIL " + task.Name + " " + string(detail))
			encoded, err := json.Marshal(report)
			if err != nil {
				t.Fatal(err)
			}
			t.Log("ARRAY_RECIPE_DIAGNOSTIC " + string(encoded))
		})
	}
}
