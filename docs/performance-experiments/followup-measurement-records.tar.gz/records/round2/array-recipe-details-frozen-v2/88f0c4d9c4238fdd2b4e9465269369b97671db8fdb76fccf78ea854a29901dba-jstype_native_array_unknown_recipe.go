// Derived from com/google/javascript/rhino/jstype/{TemplateTypeMap,TemplatizedType}.java
// @ closure-compiler v20261015
/*
 * ***** BEGIN LICENSE BLOCK *****
 * Version: MPL 1.1
 *
 * The contents of this file are subject to the Mozilla Public License Version
 * 1.1 (the "License"); you may not use this file except in compliance with
 * the License. You may obtain a copy of the License at
 * http://www.mozilla.org/MPL/
 *
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License
 * for the specific language governing rights and limitations under the
 * License.
 *
 * The Original Code is Rhino code, released May 6, 1999.
 * The Initial Developer of the Original Code is Netscape Communications
 * Corporation. Portions created by Netscape are Copyright (C) 1997-1999
 * Netscape Communications Corporation. All Rights Reserved.
 *
 * Contributors: Bob Jervis; Nick Santos.
 *
 * This Go translation is distributed under the MPL 1.1 only, as the
 * original's dual licence allows; the other licence it offers is not used.
 * ***** END LICENSE BLOCK *****
 */

package rhino

// NativeArrayUnknownRecipe records the immutable binding result for one exact
// closed-registry native Array<?> shape. It never stores an exemplar wrapper,
// replacer, AST node, flow scope or a previous result. Every instantiation owns
// its mutable type/map/replacer and all publicly exposed per-result value slices.
// This Go-only compiler experiment does not change any ordinary type factory.
type NativeArrayUnknownRecipe struct {
	registry     *JSTypeRegistry
	raw          *InstanceObjectType
	unknown      *UnknownType
	number       *NumberType
	source       *TemplateTypeMap
	keys         [8]*TemplateType
	sourceValues [7]JSType
	values       [8]JSType
	resolved     [8]JSType
	subMapBits   uint8
}

// CaptureNativeArrayUnknownRecipe inspects the first actual ordinary factory
// result. Failed admission observes no virtual/custom methods and changes no
// type or resolver state. The common native shape is exactly 8 keys/7 existing
// values/one unfilled T, as recorded by the pinned Java type-algebra oracle.
func CaptureNativeArrayUnknownRecipe(r *JSTypeRegistry, first *TemplatizedType) *NativeArrayUnknownRecipe {
	if r == nil || first == nil || r.resolver == nil || r.resolver.state != JSTypeResolver_State_CLOSED ||
		len(r.resolver.captureStack) != 0 || len(r.resolver.resolutionQueue) != 0 ||
		len(r.nativeTypes) <= JSTypeNative_ARRAY_TYPE.Ordinal() || len(r.nativeTypes) <= JSTypeNative_UNKNOWN_TYPE.Ordinal() ||
		len(r.nativeTypes) <= JSTypeNative_NUMBER_TYPE.Ordinal() {
		return nativeArrayRecipeDiagnosticReject("resolver_or_native_table", r, first)
	}
	raw, rawOK := r.GetNativeType(JSTypeNative_ARRAY_TYPE).(*InstanceObjectType)
	unknown, unknownOK := r.GetNativeType(JSTypeNative_UNKNOWN_TYPE).(*UnknownType)
	number, numberOK := r.GetNativeType(JSTypeNative_NUMBER_TYPE).(*NumberType)
	if !rawOK || raw == nil || !unknownOK || unknown == nil || !numberOK || number == nil ||
		raw.registry != r || raw.PrototypeObjectTypeBase.self != raw || raw.ObjectTypeBase.self != raw || raw.JSTypeBase.self != raw ||
		raw.resolveResult != raw || !raw.nativeType || raw.templateParamCount != 1 ||
		unknown.registry != r || unknown.ObjectTypeBase.self != unknown || unknown.JSTypeBase.self != unknown ||
		unknown.resolveResult != unknown || unknown.isChecked ||
		number.registry != r || number.self != number || number.resolveResult != number ||
		first.registry != r || first.referencedType != raw || first.referencedObjType != raw ||
		first.resolveResult != first || !first.isSpecializedOnlyWithUnknown || len(first.templateTypes) != 1 || first.templateTypes[0] != unknown {
		return nativeArrayRecipeDiagnosticReject("native_or_first_identity", r, first)
	}
	source, filled := raw.templateTypeMap, first.templateTypeMap
	if source == nil || filled == nil || source.registry != r || filled.registry != r ||
		len(source.templateKeys) != 8 || len(source.templateValues) != 7 ||
		len(filled.templateKeys) != 8 || len(filled.templateValues) != 8 || len(filled.resolvedTemplateValues) != 8 ||
		source.templateKeys[7] != r.arrayElementTemplateKey || source.subMapStarts == nil ||
		filled.subMapStarts != source.subMapStarts || source.subMapStarts.Size() < 8 {
		return nativeArrayRecipeDiagnosticReject("map_shape", r, first)
	}
	recipe := &NativeArrayUnknownRecipe{registry: r, raw: raw, unknown: unknown, number: number, source: source}
	for i, key := range source.templateKeys {
		if key == nil || key.registry != r || key.ProxyObjectTypeBase.self != key || key.ObjectTypeBase.self != key || key.JSTypeBase.self != key ||
			key.bound != unknown || key.typeTransformation != nil || filled.templateKeys[i] != key {
			return nativeArrayRecipeDiagnosticReject("template_key_metadata", r, first)
		}
		recipe.keys[i] = key
		if source.subMapStarts.Get(i) {
			recipe.subMapBits |= 1 << uint(i)
		}
		value := filled.templateValues[i]
		if i < 7 {
			if value != source.templateValues[i] {
				return nativeArrayRecipeDiagnosticReject("source_value_identity", r, first)
			}
			recipe.sourceValues[i] = value
		} else if value != unknown {
			return nativeArrayRecipeDiagnosticReject("last_value_identity", r, first)
		}
		if value != unknown && value != number {
			template, ok := value.(*TemplateType)
			found := false
			if ok {
				for _, candidate := range source.templateKeys {
					if template == candidate {
						found = true
						break
					}
				}
			}
			if !found {
				return nativeArrayRecipeDiagnosticReject("non_native_source_value", r, first)
			}
		}
		resolved := filled.resolvedTemplateValues[i]
		if resolved != unknown && resolved != number {
			return nativeArrayRecipeDiagnosticReject("non_native_resolved_value", r, first)
		}
		recipe.values[i], recipe.resolved[i] = value, resolved
	}
	return recipe
}

// unchanged checks only concrete native fields and bounded vectors. It does
// not invoke GetBound().IsUnknownType, visitors, equality, hashing or reporters.
// Native properties deliberately are not frozen: all fresh proxies delegate
// those live properties to the same raw Array, just like the ordinary factory.
func (r *NativeArrayUnknownRecipe) unchanged() bool {
	if r == nil || r.registry == nil || r.registry.resolver == nil || r.raw == nil || r.source == nil || r.unknown == nil || r.number == nil ||
		r.registry.resolver.state != JSTypeResolver_State_CLOSED ||
		len(r.registry.resolver.captureStack) != 0 || len(r.registry.resolver.resolutionQueue) != 0 ||
		r.registry.GetNativeType(JSTypeNative_ARRAY_TYPE) != r.raw ||
		r.registry.GetNativeType(JSTypeNative_UNKNOWN_TYPE) != r.unknown ||
		r.registry.GetNativeType(JSTypeNative_NUMBER_TYPE) != r.number ||
		r.raw.registry != r.registry || r.raw.PrototypeObjectTypeBase.self != r.raw || r.raw.ObjectTypeBase.self != r.raw || r.raw.JSTypeBase.self != r.raw ||
		r.raw.resolveResult != r.raw || r.raw.templateParamCount != 1 || !r.raw.nativeType ||
		r.unknown.registry != r.registry || r.unknown.ObjectTypeBase.self != r.unknown || r.unknown.JSTypeBase.self != r.unknown ||
		r.unknown.resolveResult != r.unknown || r.unknown.isChecked ||
		r.number.registry != r.registry || r.number.self != r.number || r.number.resolveResult != r.number ||
		r.raw.templateTypeMap != r.source || r.source.registry != r.registry || len(r.source.templateKeys) != 8 || len(r.source.templateValues) != 7 ||
		r.source.subMapStarts == nil || r.source.subMapStarts.Size() < 8 {
		return false
	}
	for i, key := range r.source.templateKeys {
		if key != r.keys[i] || key.registry != r.registry || key.ProxyObjectTypeBase.self != key || key.ObjectTypeBase.self != key || key.JSTypeBase.self != key ||
			key.bound != r.unknown || key.typeTransformation != nil ||
			r.source.subMapStarts.Get(i) != (r.subMapBits&(1<<uint(i)) != 0) {
			return false
		}
		if i < 7 && r.source.templateValues[i] != r.sourceValues[i] {
			return false
		}
	}
	return true
}

// A result remains an ordinary set of GC-traced objects with stable interior
// pointers. Keeping only a map/replacer also keeps this ONE wrapper and its
// native-only vectors; no slab, earlier wrapper, scope or AST is linked here.
// Static amd64 layout: 608 payload bytes, allocation class640. The corresponding
// separately allocated retained components round to624 bytes; coallocation is
// not itself a retained-byte saving. Avoided binding derivation is the target.
type nativeArrayUnknownAllocation struct {
	type_         TemplatizedType
	map_          TemplateTypeMap
	replacer      TemplateTypeReplacer
	values        [8]JSType
	resolved      [8]JSType
	templateTypes [1]JSType
}

// TryNew returns a fully fresh ordinary specialization or nil when the native
// recipe changed. The caller must run the original factory on nil. Constructor
// capture/Proxy initialization/final resolver registration and resolution keep
// their original order. Only the previously validated pure native binding
// derivation is replaced by fresh copies of its immutable result.
func (r *NativeArrayUnknownRecipe) TryNew() *TemplatizedType {
	if !r.unchanged() {
		return nil
	}
	a := &nativeArrayUnknownAllocation{}
	a.values, a.resolved = r.values, r.resolved
	a.templateTypes[0] = r.unknown
	a.map_ = TemplateTypeMap{registry: r.registry, templateKeys: r.source.templateKeys,
		templateValues: a.values[:], resolvedTemplateValues: a.resolved[:], subMapStarts: r.source.subMapStarts}
	t := &a.type_
	t.InitProxyObjectTypeBaseWithTemplateTypeMap(t, r.registry, r.raw, &a.map_)
	t.templateTypes = a.templateTypes[:]
	t.isSpecializedOnlyWithUnknown = true
	a.replacer = TemplateTypeReplacer{registry: r.registry, bindings: &a.map_, ownSubMapBoundary: -1}
	t.replacer = &a.replacer
	r.registry.GetResolver().ResolveIfClosed(t, TemplatizedType_TYPE_CLASS)
	return t
}
