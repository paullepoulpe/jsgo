package rhino

import (
	"fmt"
	"sync"
)

// This file only exists in the untimed diagnostic overlay. Snapshots contain
// scalar values and concrete type names, never an AST/type/registry pointer.
var nativeArrayRecipeDiagnostic struct {
	sync.Mutex
	Reasons map[string]int
	First   map[string]any
}

func ResetNativeArrayRecipeDiagnostic() {
	nativeArrayRecipeDiagnostic.Lock()
	defer nativeArrayRecipeDiagnostic.Unlock()
	nativeArrayRecipeDiagnostic.Reasons = make(map[string]int)
	nativeArrayRecipeDiagnostic.First = nil
}

func SnapshotNativeArrayRecipeDiagnostic() map[string]any {
	nativeArrayRecipeDiagnostic.Lock()
	defer nativeArrayRecipeDiagnostic.Unlock()
	reasons := make(map[string]int, len(nativeArrayRecipeDiagnostic.Reasons))
	for k, v := range nativeArrayRecipeDiagnostic.Reasons {
		reasons[k] = v
	}
	return map[string]any{"rejections": reasons, "first_rejection": nativeArrayRecipeDiagnostic.First}
}

func nativeArrayRecipeDiagnosticReject(reason string, r *JSTypeRegistry, first *TemplatizedType) *NativeArrayUnknownRecipe {
	nativeArrayRecipeDiagnostic.Lock()
	defer nativeArrayRecipeDiagnostic.Unlock()
	if nativeArrayRecipeDiagnostic.Reasons == nil {
		nativeArrayRecipeDiagnostic.Reasons = make(map[string]int)
	}
	nativeArrayRecipeDiagnostic.Reasons[reason]++
	if nativeArrayRecipeDiagnostic.First != nil {
		return nil
	}
	d := map[string]any{"reason": reason, "nil_registry": r == nil, "nil_first": first == nil}
	nativeArrayRecipeDiagnostic.First = d
	if r == nil {
		return nil
	}
	if r.resolver != nil {
		d["resolver_closed"] = r.resolver.state == JSTypeResolver_State_CLOSED
		d["capture_stack"] = len(r.resolver.captureStack)
		d["resolution_queue"] = len(r.resolver.resolutionQueue)
	}
	var raw *InstanceObjectType
	var unknown *UnknownType
	var number *NumberType
	if len(r.nativeTypes) > JSTypeNative_ARRAY_TYPE.Ordinal() {
		raw, _ = r.GetNativeType(JSTypeNative_ARRAY_TYPE).(*InstanceObjectType)
	}
	if len(r.nativeTypes) > JSTypeNative_UNKNOWN_TYPE.Ordinal() {
		unknown, _ = r.GetNativeType(JSTypeNative_UNKNOWN_TYPE).(*UnknownType)
	}
	if len(r.nativeTypes) > JSTypeNative_NUMBER_TYPE.Ordinal() {
		number, _ = r.GetNativeType(JSTypeNative_NUMBER_TYPE).(*NumberType)
	}
	d["nil_array"] = raw == nil
	d["nil_unknown"] = unknown == nil
	d["nil_number"] = number == nil
	describe := func(value JSType) map[string]any {
		return map[string]any{"type": fmt.Sprintf("%T", value), "is_unknown": value == unknown, "is_number": value == number}
	}
	if raw != nil {
		d["raw_native"] = raw.nativeType
		d["raw_template_count"] = raw.templateParamCount
		d["raw_registry"] = raw.registry == r
		d["raw_prototype_self"] = raw.PrototypeObjectTypeBase.self == raw
		d["raw_object_self"] = raw.ObjectTypeBase.self == raw
		d["raw_type_self"] = raw.JSTypeBase.self == raw
		d["raw_resolved_self"] = raw.resolveResult == raw
	}
	if unknown != nil {
		d["unknown_checked"] = unknown.isChecked
		d["unknown_registry"] = unknown.registry == r
		d["unknown_resolved_self"] = unknown.resolveResult == unknown
		d["unknown_object_self"] = unknown.ObjectTypeBase.self == unknown
		d["unknown_type_self"] = unknown.JSTypeBase.self == unknown
	}
	if number != nil {
		d["number_registry"] = number.registry == r
		d["number_self"] = number.self == number
		d["number_resolved_self"] = number.resolveResult == number
	}
	if first != nil {
		d["first_registry"] = first.registry == r
		d["first_referenced_type"] = first.referencedType == raw
		d["first_referenced_object"] = first.referencedObjType == raw
		d["first_resolved_self"] = first.resolveResult == first
		d["first_unknown_specialization"] = first.isSpecializedOnlyWithUnknown
		args := make([]map[string]any, min(16, len(first.templateTypes)))
		for i, v := range first.templateTypes[:len(args)] {
			args[i] = describe(v)
		}
		d["first_arguments"] = args
	}
	if raw == nil || raw.templateTypeMap == nil {
		return nil
	}
	source := raw.templateTypeMap
	d["source_registry"] = source.registry == r
	d["source_keys"] = len(source.templateKeys)
	d["source_values"] = len(source.templateValues)
	if source.subMapStarts != nil {
		d["source_submap_size"] = source.subMapStarts.Size()
	}
	keys := make([]map[string]any, min(16, len(source.templateKeys)))
	for i, key := range source.templateKeys[:len(keys)] {
		e := map[string]any{"nil": key == nil, "is_array_element_key": key == r.arrayElementTemplateKey}
		if key != nil {
			e["name"] = key.name
			e["registry"] = key.registry == r
			e["proxy_self"] = key.ProxyObjectTypeBase.self == key
			e["object_self"] = key.ObjectTypeBase.self == key
			e["type_self"] = key.JSTypeBase.self == key
			e["bound"] = describe(key.bound)
			e["transformed"] = key.typeTransformation != nil
		}
		keys[i] = e
	}
	d["keys"] = keys
	values := make([]map[string]any, min(16, len(source.templateValues)))
	for i, v := range source.templateValues[:len(values)] {
		values[i] = describe(v)
	}
	d["source_value_types"] = values
	if first != nil && first.templateTypeMap != nil {
		filled := first.templateTypeMap
		d["filled_registry"] = filled.registry == r
		d["filled_keys"] = len(filled.templateKeys)
		d["filled_values"] = len(filled.templateValues)
		d["filled_resolved_values"] = len(filled.resolvedTemplateValues)
		d["same_submap"] = filled.subMapStarts == source.subMapStarts
		values := make([]map[string]any, min(16, len(filled.resolvedTemplateValues)))
		for i, v := range filled.resolvedTemplateValues[:len(values)] {
			values[i] = describe(v)
		}
		d["resolved_value_types"] = values
	}
	return nil
}
