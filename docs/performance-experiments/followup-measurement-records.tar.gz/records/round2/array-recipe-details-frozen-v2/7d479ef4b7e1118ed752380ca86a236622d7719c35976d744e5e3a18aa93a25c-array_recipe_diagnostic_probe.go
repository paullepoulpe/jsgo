package jscomp

import "sync"

// Added only by the untimed overlay. No observer is installed in ordinary
// focused tests; the dedicated diagnostic test owns each collector.
var arrayRecipeDiagnosticMu sync.Mutex
var arrayRecipeDiagnosticObserver func(*freshTemplateValuesProbe)

func arrayRecipeDiagnosticSetObserver(observer func(*freshTemplateValuesProbe)) func() {
	arrayRecipeDiagnosticMu.Lock()
	previous := arrayRecipeDiagnosticObserver
	arrayRecipeDiagnosticObserver = observer
	arrayRecipeDiagnosticMu.Unlock()
	return func() {
		arrayRecipeDiagnosticMu.Lock()
		arrayRecipeDiagnosticObserver = previous
		arrayRecipeDiagnosticMu.Unlock()
	}
}

func arrayRecipeDiagnosticAttach(p *TypeInferencePass) func() {
	arrayRecipeDiagnosticMu.Lock()
	observer := arrayRecipeDiagnosticObserver
	arrayRecipeDiagnosticMu.Unlock()
	if observer == nil || p.freshTemplateProbe != nil {
		return nil
	}
	previous := p.freshTemplateProbe
	probe := &freshTemplateValuesProbe{}
	p.freshTemplateProbe = probe
	// Registered before the factory's original cleanup defer: its private
	// mode/creator window is restored before this observer runs, including panic.
	return func() { p.freshTemplateProbe = previous; observer(probe) }
}
