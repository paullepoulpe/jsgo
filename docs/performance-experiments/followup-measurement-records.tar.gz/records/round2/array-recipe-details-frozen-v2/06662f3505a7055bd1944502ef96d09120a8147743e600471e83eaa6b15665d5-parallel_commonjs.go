package jscomp

import (
	"os"
	"slices"
	"sync"

	"github.com/paullepoulpe/jsgo/internal/jutil"
	"github.com/paullepoulpe/jsgo/internal/rhino"
)

func parallelCommonJSEnabled() bool { return os.Getenv("JSGO_EXPERIMENT_PARALLEL_COMMONJS") == "1" }

type parallelCommonJSEvent struct {
	node       *rhino.Node
	diagnostic *JSError
	level      *CheckLevel
	deleted    bool
}

// The embedded AbstractCompiler remains nil. An unaudited compiler dependency
// must fail explicitly rather than silently reaching shared compiler mutation.
type parallelCommonJSCompiler struct {
	parallelFSIVCompiler
	input  *CompilerInput
	path   *ModuleLoader_ModulePath
	loader ModuleLoader
	script *rhino.Node
	owned  map[*rhino.Node]bool
	events []parallelCommonJSEvent
}

func (c *parallelCommonJSCompiler) GetModuleLoader() *ModuleLoader { return &c.loader }
func (c *parallelCommonJSCompiler) GetModuleTypeByName(name string) *CompilerInput_ModuleType {
	return c.owner.GetModuleTypeByName(name) // Populated before this pass; read-only.
}
func (c *parallelCommonJSCompiler) Report(error *JSError) {
	// Guards may inspect ancestors that this pass subsequently replaces. Freeze
	// their answer at the original report point, including OFF; replay must not
	// evaluate them on the later tree. All admitted concrete guards read only
	// diagnostic metadata and this job's own script (or immutable input maps).
	level := error.DefaultLevel().Ptr()
	if c.owner.warningsGuard != nil {
		if override := c.owner.warningsGuard.Level(error); override != nil {
			level = override
		}
	}
	c.events = append(c.events, parallelCommonJSEvent{diagnostic: error, level: level})
}
func (c *parallelCommonJSCompiler) ReportChangeToEnclosingScope(n *rhino.Node) {
	c.ReportChangeToChangeScope(c.owner.changeTracker.getChangeScopeForNode(n))
}
func (c *parallelCommonJSCompiler) ReportChangeToChangeScope(n *rhino.Node) {
	jutil.CheckState(n == c.script || c.owned[n])
	c.events = append(c.events, parallelCommonJSEvent{node: n})
}
func (c *parallelCommonJSCompiler) ReportFunctionDeleted(n *rhino.Node) {
	jutil.CheckState(c.owned[n])
	c.events = append(c.events, parallelCommonJSEvent{node: n, deleted: true})
}

type parallelCommonJSErrorHandler struct{ compiler *parallelCommonJSCompiler }

func (h *parallelCommonJSErrorHandler) Report(level *CheckLevel, error *JSError) {
	// The owner's AsErrorHandler deliberately ignores the supplied level.
	h.compiler.Report(error)
}

type parallelCommonJSJob struct {
	compiler parallelCommonJSCompiler
	weight   int
	eligible bool
	failure  jutil.Throwable
}

// Per-invocation untimed observation only. No global hooks or timed counters.
type parallelCommonJSProbe struct {
	beforeJobs func([]*parallelCommonJSJob)
	aroundJob  func(*parallelCommonJSJob, func())
	afterJobs  func([]*parallelCommonJSJob)
}

// Resolver maps/slices are immutable during this pass; the handler and receiver
// headers are private. Unknown/custom resolver implementations retain serial
// execution without calling any custom getter during eligibility.
func cloneParallelCommonJSLoader(original *ModuleLoader, c *parallelCommonJSCompiler) bool {
	if original == nil {
		return false
	}
	var handler ErrorHandler
	switch h := original.errorHandler.(type) {
	case *compiler_errorHandler:
		if h == nil || h != c.owner.asErrorHandler || h.c != c.owner {
			return false
		}
		handler = &parallelCommonJSErrorHandler{compiler: c}
	case moduleLoader_noopErrorHandler:
		handler = h
	default:
		return false
	}
	c.loader = *original
	switch resolver := original.moduleResolver.(type) {
	case *NodeModuleResolver:
		if resolver == nil || resolver.errorHandler != original.errorHandler {
			return false
		}
		copy := *resolver
		copy.errorHandler = handler
		c.loader.moduleResolver = &copy
	case *BrowserModuleResolver:
		if resolver == nil || resolver.errorHandler != original.errorHandler {
			return false
		}
		copy := *resolver
		copy.errorHandler = handler
		c.loader.moduleResolver = &copy
	default:
		return false // Includes Webpack's additional module-shim mutation.
	}
	c.loader.errorHandler = handler
	return true
}

// Outside UMD, this pass neither allocates global IDs nor clones function
// subtrees. Its only CloneTree duplicates a qualified export target. UMD/IIFE
// mutators do both, so conservatively retain the original route for any script
// with a condition that can be recognized as a UMD test by the original finder.
func prepareParallelCommonJSNodes(n *rhino.Node, inCondition bool, owned map[*rhino.Node]bool) (int, bool, string) {
	if n.GetJSType() != nil { return 0, false, "raw-types" }; if n.GetClosureUnawareShadow() != nil { return 0, false, "closure-unaware-shadow" }
	if n.IsFunction() {
		owned[n] = true
	}
	if inCondition {
		if (n.IsName() && (n.GetString() == "module" || n.GetString() == "define")) ||
			(n.IsGetProp() && n.GetString() == "define" && n.GetFirstChild().MatchesName("window")) ||
			(n.IsStringLit() && n.GetString() == "amd" && n.GetParent().IsIn()) || n.IsTrue() {
			return 0, false, "umd-condition"
		}
	}
	weight := 1
	for child := n.GetFirstChild(); child != nil; child = child.GetNext() {
		condition := inCondition || ((n.IsIf() || n.IsHook()) && child == n.GetFirstChild())
		childWeight, safe, reason := prepareParallelCommonJSNodes(child, condition, owned)
		if !safe {
			return 0, false, reason
		}
		weight += childWeight
	}
	return weight, true, "eligible-singleton-window"
}

func (p *ProcessCommonJSModules) processScriptCohorts(externs, root *rhino.Node, probe *parallelCommonJSProbe) bool {
	diagnostic := beginCommonJSActivation(p, root)
	defer diagnostic.finish()
	owner, stock := p.compiler.(*Compiler)
	if !p.builtin || !stock || owner == nil || owner.options == nil || owner.changeTracker == nil || owner.inputsById == nil ||
		owner.options.GetNumParallelThreads() < 2 || owner.GetLifeCycleStage() != AbstractCompiler_LifeCycleStage_RAW ||
		(owner.options.GetModuleResolutionMode() != ModuleLoader_ResolutionMode_NODE && owner.options.GetModuleResolutionMode() != ModuleLoader_ResolutionMode_BROWSER) ||
		owner.options.customPasses != nil || owner.typedAstFilesystem != nil || owner.runtimeLibraryTypedAsts != nil ||
		!parallelFSIVObserversSafe(owner) || !parallelCoalesceConventionSafe(owner.GetCodingConvention()) ||
		!typedInferenceWarningsGuardSafe(owner.warningsGuard, owner, 0) ||
		!typedInferenceWarningsGuardSafe(owner.options.GetWarningsGuard(), owner, 0) ||
		root == nil || externs == nil || !root.IsRoot() || root.GetParent() == nil ||
		root != owner.GetJsRoot() || externs != owner.GetExternsRoot() || root.GetParent() != externs.GetParent() {
		return false
	}
	witness, count := false, 0
	for script := root.GetFirstChild(); script != nil; script = script.GetNext() {
		if !script.IsScript() || script.GetInputId() == nil {
		diagnostic.Fallback = "script-shape-or-input-id"
			return false
		}
		input := owner.GetInput(script.GetInputId())
		if input == nil || input.IsExtern() || input.GetSourceFile() == nil {
		diagnostic.Fallback = "missing-input-or-source-or-extern"
			return false
		}
		switch input.GetSourceFile().loader.(type) {
		case *cliOwnedSourceLoader:
			witness = true
		case *SourceFile_CodeLoader_Preloaded:
			// Compiler-generated scripts can be added within the CLI lifetime.
			// Their concrete loader has no user callback or shared lazy source.
		default:
			diagnostic.Fallback = "source-loader"
			return false
		}
		count++
	}
	if !witness || count < 2 {
		diagnostic.Fallback = "fewer-than-two-scripts"
		if !witness { diagnostic.Fallback = "no-cli-ownership" }
		return false
	}
	// Validate all shared loader dependencies before any AST mutation.
	check := parallelCommonJSCompiler{parallelFSIVCompiler: parallelFSIVCompiler{owner: owner}}
	if !cloneParallelCommonJSLoader(owner.moduleLoader, &check) {
		diagnostic.Fallback = "resolver-or-handler"
		return false
	}
	workers := owner.options.GetNumParallelThreads()
	var sourceLines sync.Mutex
	for script := root.GetFirstChild(); script != nil; {
		// Private loader/path/analysis headers and buffered events live for
		// at most N adjacent scripts, then are published and released.
		jobs := make([]*parallelCommonJSJob, 0, min(workers, count))
		for len(jobs) < workers && script != nil {
			job := &parallelCommonJSJob{}
			input := owner.GetInput(script.GetInputId())
			path := input.GetPath() // Warm the canonical lazy input path serially.
			job.compiler = parallelCommonJSCompiler{
				parallelFSIVCompiler: parallelFSIVCompiler{owner: owner, options: owner.options, convention: owner.GetCodingConvention(), sourceLines: &sourceLines},
				input:                input, script: script, owned: make(map[*rhino.Node]bool),
			}
			var reason string
			job.weight, job.eligible, reason = prepareParallelCommonJSNodes(script, false, job.compiler.owned)
			jutil.CheckState(cloneParallelCommonJSLoader(owner.moduleLoader, &job.compiler))
			if path != nil && path.outer == owner.moduleLoader {
				job.compiler.path = job.compiler.loader.newModulePath(path.path)
			} else {
				// A cached path from a replaced loader must retain that original
				// loader's resolution semantics on the serial route.
				job.eligible = false
				reason = "nil-or-stale-module-path"
			}
			diagnostic.admit(job, reason)
			jobs = append(jobs, job)
			script = script.GetNext()
		}
		for start := 0; start < len(jobs); {
			end := start
			for end < len(jobs) && jobs[end].eligible {
				end++
			}
			if end-start > 1 {
				diagnostic.dispatch(jobs[start:end])
				runParallelCommonJSJobs(owner, jobs[start:end], workers, probe)
				start = end
			} else {
				// Includes one eligible file between unsupported scripts: keep
				// its original compiler/scopes and avoid worker setup overhead.
				NodeTraversal_Traverse(owner, jobs[start].compiler.script, p)
				start++
			}
		}
	}
	// Original pass order is JS scripts first, extern scripts second.
	NodeTraversal_Traverse(owner, externs, p)
	diagnostic.Fallback = ""
	diagnostic.Completed = true
	return true
}

func runParallelCommonJSJobs(owner *Compiler, jobs []*parallelCommonJSJob, workers int, probe *parallelCommonJSProbe) {
	order := make([]int, len(jobs))
	for i := range order {
		order[i] = i
	}
	slices.SortStableFunc(order, func(a, b int) int { return jobs[b].weight - jobs[a].weight })
	if probe != nil && probe.beforeJobs != nil {
		probe.beforeJobs(jobs)
	}
	failures := parallelPrebuild(len(jobs), workers, func(index int) {
		job := jobs[order[index]]
		run := func() {
			NodeTraversal_Traverse(&job.compiler, job.compiler.script, NewProcessCommonJSModules(&job.compiler))
		}
		if probe != nil && probe.aroundJob != nil {
			probe.aroundJob(job, run)
		} else {
			run()
		}
	})
	for index, failure := range failures {
		jobs[order[index]].failure = failure
	}
	for _, job := range jobs {
		for _, event := range job.compiler.events {
			switch {
			case event.diagnostic != nil:
				// Admission excludes custom error handlers, and stock managers
				// consume only this frozen level plus diagnostic value metadata.
				if event.level.IsOn() {
					owner.errorManager.Report(event.level, event.diagnostic)
				}
			case event.deleted:
				owner.ReportFunctionDeleted(event.node)
			default:
				owner.ReportChangeToChangeScope(event.node)
			}
		}
		if job.failure != nil {
			panic(job.failure)
		}
	}
	if probe != nil && probe.afterJobs != nil {
		probe.afterJobs(jobs)
	}
}


// Diagnostic overlay only: never include in a timed build.
type commonJSActivationScript struct {
    Name string `json:"name"`
    Eligible bool `json:"eligible"`
    Dispatched bool `json:"dispatched"`
    Reason string `json:"reason"`
    Weight int `json:"weight_nodes"`
}
type commonJSActivationRecord struct {
    Workers int `json:"workers"`
    Completed bool `json:"completed"`
    Fallback string `json:"pass_fallback,omitempty"`
    Eligible int `json:"eligible_scripts"`
    Dispatched int `json:"dispatched_scripts"`
    Cohorts int `json:"cohorts"`
    DispatchedWeight int `json:"dispatched_weight_nodes"`
    Scripts []commonJSActivationScript `json:"scripts"`
    nodes map[*rhino.Node]int
}
var commonJSActivationRecords []*commonJSActivationRecord
var commonJSActivationMutex sync.Mutex

func beginCommonJSActivation(p *ProcessCommonJSModules, root *rhino.Node) *commonJSActivationRecord {
    d := &commonJSActivationRecord{Fallback:"compiler-configuration-or-observers",nodes:make(map[*rhino.Node]int)}
    if c,ok:=p.compiler.(*Compiler);ok && c!=nil && c.options!=nil {
        d.Workers=c.options.GetNumParallelThreads()
        if d.Workers<2 { d.Fallback="fewer-than-two-workers" }
    }
    if root!=nil {
        for script:=root.GetFirstChild();script!=nil;script=script.GetNext() {
            name:="<no-input-id>"
            if id:=script.GetInputId();id!=nil { name=id.GetIdName() }
            d.nodes[script]=len(d.Scripts)
            d.Scripts=append(d.Scripts,commonJSActivationScript{Name:name})
        }
    }
    return d
}
func (d *commonJSActivationRecord) finish() {
    for i:=range d.Scripts {
        if d.Scripts[i].Reason=="" { d.Scripts[i].Reason=d.Fallback }
    }
    d.nodes=nil
    commonJSActivationMutex.Lock()
    commonJSActivationRecords=append(commonJSActivationRecords,d)
    commonJSActivationMutex.Unlock()
}
func (d *commonJSActivationRecord) admit(job *parallelCommonJSJob, reason string) {
    i:=d.nodes[job.compiler.script]
    d.Scripts[i].Eligible=job.eligible
    d.Scripts[i].Reason=reason
    d.Scripts[i].Weight=job.weight
    if job.eligible { d.Eligible++ }
}
func (d *commonJSActivationRecord) dispatch(jobs []*parallelCommonJSJob) {
    d.Cohorts++
    for _,job:=range jobs {
        i:=d.nodes[job.compiler.script]
        d.Scripts[i].Dispatched=true
        d.Scripts[i].Reason="parallel-cohort"
        d.Dispatched++
        d.DispatchedWeight+=job.weight
    }
}
