// Port of com/google/javascript/jscomp/FunctionArgumentInjectorTest.java @ closure-compiler v20261015
// (test/com/google/javascript/jscomp/FunctionArgumentInjectorTest.java)

/*
 * Copyright 2009 The Closure Compiler Authors.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package jscomp

import (
 "fmt"
 "io"
 "strings"
 "github.com/paullepoulpe/jsgo/internal/jutil"
 "github.com/paullepoulpe/jsgo/internal/rhino"
)

func FunctionArgumentInjectorTest_GetNameSupplier() func() string {
	i := 0
	return func() string {
		v := jutil.ToJavaString(i) // String.valueOf(i++)
		i++
		return v
	}
}

func FunctionArgumentInjectorTest_FindCall(n *rhino.Node, name string) *rhino.Node {
	if NodeUtil_IsNormalOrOptChainCall(n) {
		var callee *rhino.Node
		if NodeUtil_IsNormalOrOptChainGetProp(n.GetFirstChild()) {
			callee = n.GetFirstFirstChild()
			// Only "call" is supported at this point.
			jutil.CheckArgument(callee.GetParent().GetString() == "call")
		} else {
			callee = n.GetFirstChild()
		}

		if callee.IsName() && callee.GetString() == name {
			return n
		}
	}

	for c := n.GetFirstChild(); c != nil; c = c.GetNext() {
		result := FunctionArgumentInjectorTest_FindCall(c, name)
		if result != nil {
			return result
		}
	}

	return nil
}

func FunctionArgumentInjectorTest_FindFunction(n *rhino.Node, name string) *rhino.Node {
	if n.IsFunction() {
		if n.GetFirstChild().GetString() == name {
			return n
		}
	}

	for c := n.GetFirstChild(); c != nil; c = c.GetNext() {
		result := FunctionArgumentInjectorTest_FindFunction(c, name)
		if result != nil {
			return result
		}
	}

	return nil
}

type coreG3Collector struct {
	BasicErrorManagerBase
	reports []string
}

func newCoreG3Collector() *coreG3Collector {
	c := &coreG3Collector{}
	c.InitBasicErrorManagerBase(c)
	return c
}

func (c *coreG3Collector) Report(level *CheckLevel, error *JSError) {
	c.reports = append(c.reports, level.String()+" "+error.String())
	c.BasicErrorManagerBase.Report(level, error)
}

func (c *coreG3Collector) Println(level *CheckLevel, error *JSError) {}

func (c *coreG3Collector) PrintSummary() {}


func typedScopeDump_varLine(v *TypedVar) string {
	type_ := v.GetType()
	ann := "-"
	if type_ != nil && !v.IsTypeInferred() {
		jutil.Try(func() {
			ann = type_.ToAnnotationString(rhino.JSType_Nullability_EXPLICIT)
		}, func(e jutil.IRuntimeException) {
			ann = "!" + typedScopeDump_simpleClassName(e)
		})
	}
	node := "null"
	if v.GetNameNode() != nil {
		node = typedScopeDump_pos(v.GetNameNode())
	}
	return fmt.Sprintf("V %s | %s | %s | inferred=%t esc=%t once=%t input=%s node=%s",
		v.GetName(), typedScopeDump_typeString(type_), ann, v.IsTypeInferred(),
		v.IsMarkedEscaped(), v.IsMarkedAssignedExactlyOnce(), v.GetInputName(), node)
}

func typedScopeDump_simpleClassName(e jutil.Throwable) string {
	s := e.Error()
	if i := strings.Index(s, ": "); i >= 0 {
		s = s[:i]
	}
	return s[strings.LastIndexByte(s, '.')+1:]
}

func typedScopeDump_typeString(type_ rhino.JSType) (s string) {
	if type_ == nil {
		return "null"
	}
	jutil.Try(func() {
		s = type_.String()
	}, func(e jutil.IRuntimeException) {
		s = "!" + typedScopeDump_simpleClassName(e)
	})
	return s
}

func typedScopeDump_pos(n *rhino.Node) string {
	return fmt.Sprintf("%s@%d:%d", n.GetToken(), n.GetLineno(), n.GetCharno())
}

func removeUnusedOracleOptions() *CompilerOptions {
	options := NewCompilerOptions()
	options.SetLanguageIn(CompilerOptions_LanguageMode_ECMASCRIPT_NEXT)
	options.SetLanguageOut(CompilerOptions_LanguageMode_NO_TRANSPILE)
	// VarCheck declares the undeclared names (as the checks phase does before these passes run);
	// its "undefined variable" errors would only repeat in every run.
	options.SetWarningLevel(DiagnosticGroups_UNDEFINED_VARIABLES, CheckLevel_OFF)
	return options
}

func removeUnusedOracleNewCompiler(rel string, src string) *Compiler {
	compiler := NewCompilerWithOutStream(jutil.NewPrintStream(io.Discard))
	compiler.Init(
		[]*SourceFile{SourceFile_FromCode("externs.js", removeUnusedOracleExterns)},
		[]*SourceFile{SourceFile_FromCode(rel, src)},
		removeUnusedOracleOptions())
	compiler.Parse()
	return compiler
}

func removeUnusedOraclePrepare(c *Compiler) {
	externs := c.GetExternsRoot()
	js := c.GetJsRoot()
	NewVarCheck(c).Process(externs, js)
	Normalize_CreateNormalizeForOptimizations(c).Process(externs, js)
	NewGatherGetterAndSetterProperties(c).Process(externs, js)
	NewGatherExternProperties(c, GatherExternProperties_Mode_OPTIMIZE).Process(externs, js)
}

var removeUnusedOracleExterns = strings.Join([]string{
	"var window;",
	"var document;",
	"var console;",
	"var Arguments;",
	"/** @constructor @param {*=} opt_value @return {!Object} */",
	"function Object(opt_value) {}",
	"/** @type {Function} */ Object.defineProperties = function() {};",
	"/** @type {Function} */ Object.defineProperty = function() {};",
	"/** @constructor @param {...*} var_args @return {!Array} */",
	"function Array(var_args) {}",
	"/** @constructor @param {*=} message */ function Error(message) {}",
	"/** @nosideeffects */ function externPure() {}",
	"function alert(a) {}",
	"",
}, "\n")

var CompilerTestCase_DEFAULT_EXTERNS = NewTestExternsBuilder().
	AddArray().
	AddIterable().
	AddObject().
	AddUndefined().
	AddFunction().
	AddString().
	AddPromise().
	AddClosureExterns().
	AddITemplateArray().
	Build()

var CompilerTypeTestCase_DEFAULT_EXTERNS = CompilerTestCase_DEFAULT_EXTERNS

func scopeTestNewCompiler(options *CompilerOptions) *Compiler {
	return newTestCompiler(options)
}

// Port of com/google/javascript/jscomp/ReachingUseDefTester.java @ closure-compiler v20261015
// (test/com/google/javascript/jscomp/ReachingUseDefTester.java)

/*
 * Copyright 2020 The Closure Compiler Authors.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */


// ReachingUseDefTester is the utility for testing MaybeReachingVariableUse
// and MustBeReachingVariableDef.
type ReachingUseDefTester struct {
	compiler     *Compiler
	scopeCreator *SyntacticScopeCreator
	labelFinder  *ReachingUseDefTester_LabelFinder
	root         *rhino.Node
	reachingUse  *MaybeReachingVariableUse
	reachingDef  *MustBeReachingVariableDef
}

// Java: ReachingUseDefTester(Compiler, SyntacticScopeCreator, LabelFinder)
func newReachingUseDefTester(
	compiler *Compiler, scopeCreator *SyntacticScopeCreator, labelFinder *ReachingUseDefTester_LabelFinder) *ReachingUseDefTester {
	return &ReachingUseDefTester{
		compiler:     compiler,
		scopeCreator: scopeCreator,
		labelFinder:  labelFinder,
	}
}

// Java: ReachingUseDefTester.create()
func ReachingUseDefTester_Create() *ReachingUseDefTester {
	compiler := reachingUseDefTester_createCompiler()
	return newReachingUseDefTester(
		compiler, NewSyntacticScopeCreator(compiler), NewReachingUseDefTester_LabelFinder())
}

// Java: ReachingUseDefTester.createCompiler()
func reachingUseDefTester_createCompiler() *Compiler {
	compiler := NewCompiler()
	compiler.SetLifeCycleStage(AbstractCompiler_LifeCycleStage_NORMALIZED)
	options := NewCompilerOptions()
	options.SetCodingConvention(NewGoogleCodingConvention())
	options.SetLanguage(CompilerOptions_LanguageMode_UNSUPPORTED)
	compiler.InitOptions(options)
	return compiler
}

// ComputeReachingUses runs `MaybeReachingVariableUse` pass to compute and
// store the may-be-reaching uses for all definitions of each variable in the
// test source.
//
// Java: ReachingUseDefTester.computeReachingUses(String, boolean)
func (r *ReachingUseDefTester) ComputeReachingUses(src string, async bool) {
	script := r.parseScript(src, async)
	r.root = script.GetFirstChild()
	funcBlockScope := r.computeFunctionBlockScope(script, r.root)
	cfg := r.computeCfg(r.root)
	escaped := jutil.NewObjectLinkedHashSet[*Var]()

	allVarsDeclaredInFunction :=
		NodeUtil_GetAllVarsDeclaredInFunction(r.compiler, r.scopeCreator, funcBlockScope.GetParent())
	allVarsInFn := allVarsDeclaredInFunction.GetAllVariables()
	DataFlowAnalysis_ComputeEscaped(
		funcBlockScope.GetParent(), escaped, r.compiler, r.scopeCreator, allVarsInFn)
	r.reachingUse = NewMaybeReachingVariableUse(cfg, escaped, allVarsInFn)
	r.reachingUse.Analyze()
}

// ComputeReachingDef runs `MustBeReachingVariableDef` pass to compute and
// store the must-be-reaching definition for all uses of each variable in the
// test source.
//
// Java: ReachingUseDefTester.computeReachingDef(String)
func (r *ReachingUseDefTester) ComputeReachingDef(src string) {
	script := r.parseScript(src /* async= */, false)
	r.root = script.GetFirstChild()
	funcBlockScope := r.computeFunctionBlockScope(script, r.root)
	cfg := r.computeCfg(r.root)
	escaped := jutil.NewObjectLinkedHashSet[*Var]()

	allVarsDeclaredInFunction :=
		NodeUtil_GetAllVarsDeclaredInFunction(r.compiler, r.scopeCreator, funcBlockScope.GetParent())
	allVarsInFn := allVarsDeclaredInFunction.GetAllVariables()
	DataFlowAnalysis_ComputeEscaped(
		funcBlockScope.GetParent(), escaped, r.compiler, r.scopeCreator, allVarsInFn)
	r.reachingDef = NewMustBeReachingVariableDef(cfg, r.compiler, escaped, allVarsInFn)
	r.reachingDef.Analyze()
}

// Java: ReachingUseDefTester.parseScript(String, boolean)
func (r *ReachingUseDefTester) parseScript(src string, async bool) *rhino.Node {
	prefix := ""
	if async {
		prefix = "async "
	}
	src = prefix + "function _FUNCTION(param1, param2){" + src + "}"
	script := r.compiler.ParseTestCode(src)
	AssertThat(r.compiler.GetErrors()).IsEmpty()
	return script
}

// Java: ReachingUseDefTester.computeFunctionBlockScope(Node, Node)
func (r *ReachingUseDefTester) computeFunctionBlockScope(script *rhino.Node, fn *rhino.Node) *Scope {
	functionBlock := fn.GetLastChild()
	globalScope := r.scopeCreator.CreateScopeOfScope(script, nil)
	functionScope := r.scopeCreator.CreateScopeOfScope(r.root, globalScope)
	return r.scopeCreator.CreateScopeOfScope(functionBlock, functionScope)
}

// Java: ReachingUseDefTester.computeCfg(Node)
func (r *ReachingUseDefTester) computeCfg(fn *rhino.Node) ControlFlowGraph[*rhino.Node] {
	return ControlFlowAnalysis_Builder_().
		SetCompiler(r.compiler).
		SetCfgRoot(fn).
		SetIncludeEdgeAnnotations(true).
		ComputeCfg()
}

// GetComputedUses returns may-be-reaching uses of definition of variable `x`
// on the node extracted at label `D:`.
//
// Java: ReachingUseDefTester.getComputedUses()
func (r *ReachingUseDefTester) GetComputedUses() *jutil.LinkedHashSet[*rhino.Node] {
	uses := jutil.NewLinkedHashSet[*rhino.Node]()
	for n := range r.reachingUse.GetUses("x", r.labelFinder.extractedDef) {
		uses.Add(n)
	}
	return uses
}

// GetComputedDef returns must-be-reaching definition of variable `x` on the
// use node extracted at label `U:`.
//
// Java: ReachingUseDefTester.getComputedDef()
func (r *ReachingUseDefTester) GetComputedDef() *rhino.Node {
	return r.reachingDef.GetDefNode("x", r.labelFinder.extractedUses[0])
}

// ExtractDefAndUsesFromInputLabels runs `LabelFinder` to find the `D:` and
// `U:` labels and save the def and uses of `x`.
//
// Java: ReachingUseDefTester.extractDefAndUsesFromInputLabels()
func (r *ReachingUseDefTester) ExtractDefAndUsesFromInputLabels() {
	NodeTraversal_Builder_().
		SetCompiler(r.compiler).
		SetCallback(r.labelFinder).
		SetScopeCreator(r.scopeCreator).
		Traverse(r.root)
	AssertWithMessage("Code should have an instruction labeled D").
		That(r.labelFinder.extractedDef).
		IsNotNull()
	AssertWithMessage("Code should have an instruction label starting withing U").
		That(len(r.labelFinder.extractedUses) == 0).
		IsFalse()
}

// ReachingUseDefTester_LabelFinder finds the D: and U: label and store which
// node they point to.
type ReachingUseDefTester_LabelFinder struct {
	NodeTraversal_AbstractPostOrderCallbackBase
	// Def and uses extracted from `D:` and `U:` labels respectively
	extractedDef  *rhino.Node
	extractedUses []*rhino.Node
}

// Java: ReachingUseDefTester.LabelFinder()
func NewReachingUseDefTester_LabelFinder() *ReachingUseDefTester_LabelFinder {
	return &ReachingUseDefTester_LabelFinder{extractedUses: []*rhino.Node{}}
}

// Java: ReachingUseDefTester.LabelFinder.visit(NodeTraversal, Node, Node)
func (f *ReachingUseDefTester_LabelFinder) Visit(t *NodeTraversal, n *rhino.Node, parent *rhino.Node) {
	if n.IsLabel() {
		if n.GetFirstChild().GetString() == "D" {
			AssertWithMessage("Multiple D: labels in test src").That(f.extractedDef).IsNull()
			f.extractedDef = n.GetLastChild()
		} else if jutil.StringStartsWith(n.GetFirstChild().GetString(), "U") {
			f.extractedUses = append(f.extractedUses, n.GetLastChild())
		}
	}
}

// Java: ReachingUseDefTester.getExtractedUses()
func (r *ReachingUseDefTester) GetExtractedUses() []*rhino.Node {
	return r.labelFinder.extractedUses
}

// Java: ReachingUseDefTester.getExtractedDef()
func (r *ReachingUseDefTester) GetExtractedDef() *rhino.Node {
	return r.labelFinder.extractedDef
}
