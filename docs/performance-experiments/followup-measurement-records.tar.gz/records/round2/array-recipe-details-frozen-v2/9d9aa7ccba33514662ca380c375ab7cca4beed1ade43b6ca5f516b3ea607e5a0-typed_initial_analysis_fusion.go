package jscomp

import (
	"os"

	"github.com/paullepoulpe/jsgo/internal/rhino"
)

func typedInitialAnalysisFusionEnabled() bool {
	return os.Getenv("JSGO_EXPERIMENT_TYPED_INITIAL_FUSION") == "1"
}

// Only DefaultPassConfig's private inference factory opens this window. It
// closes before returning or propagating a panic, so a retained public creator
// never acquires a permanent change in its traversal schedule.
func (p *TypeInferencePass) inferAllScopesBuiltin(root *rhino.Node) *TypedScope {
	if finish := arrayRecipeDiagnosticAttach(p); finish != nil {
		defer finish()
	}
	c := p.scopeCreator
	previous := c.initialAnalysisFusion
	previousSchedule := p.scopeScheduleAllowed
	previousTemplateValues := p.freshTemplateValues
	owner, stockCompiler := p.compiler.(*Compiler)
	creatorOwner, stockCreator := c.compiler.(*Compiler)
	c.initialAnalysisFusion = stockCompiler && stockCreator && owner == creatorOwner &&
		typedInitialAnalysisFusionEnabled() && typedInitialAnalysisFusionSafe(c, root)
	p.scopeScheduleAllowed = typedInferenceScopeScheduleEnabled() && typedInferenceScopeScheduleSafe(p, root)
	p.freshTemplateValues = nil
	if (freshTemplateValuesEnabled() || nativeArrayUnknownRecipeEnabled()) && freshTemplateValuesSafe(p, root) {
		p.freshTemplateValues = newFreshTemplateValuesMode(p, root)
		if p.freshTemplateProbe != nil {
			p.freshTemplateProbe.Activated++
		}
	}
	defer func() {
		c.initialAnalysisFusion = previous
		p.scopeScheduleAllowed = previousSchedule
		p.freshTemplateValues = previousTemplateValues
	}()
	return p.InferAllScopes(root)
}

func typedInitialAnalysisFusionSafe(c *TypedScopeCreator, root *rhino.Node) bool {
	owner, ok := c.compiler.(*Compiler)
	if !ok || owner == nil || owner.GetOptions() == nil || owner.changeTracker == nil ||
		root == nil || root != owner.GetRoot() || !root.IsRoot() || !root.HasTwoChildren() ||
		root.GetFirstChild() != owner.GetExternsRoot() || root.GetLastChild() != owner.GetJsRoot() ||
		owner.GetOptions().customPasses != nil || owner.IsDebugLoggingEnabled() ||
		!fsivScopeSharingConventionSafe(c.codingConvention) ||
		!fsivScopeSharingConventionSafe(owner.GetCodingConvention()) ||
		c.codingConvention != owner.GetCodingConvention() || !parallelFSIVObserversSafe(owner) {
		return false
	}
	// No unknown reporter/error handler may observe registry mutations being
	// interleaved with first-order analysis instead of following its whole walk.
	reporter, ok := c.typeParsingErrorReporter.(*rhinoErrorReporter_OldRhinoErrorReporter)
	if !ok || reporter == nil || reporter.internalReporter != owner.asErrorHandler || c.typeRegistry == nil ||
		c.typeRegistry != owner.typeRegistry || c.typeRegistry.GetErrorReporter() != reporter ||
		owner.oldErrorReporter != reporter {
		return false
	}
	return owner.GetErrorCount() == 0
}

// Each original callback's own sequence is retained. The only changed order is
// the interleaving of independent first-order fact writes and nonnullable-name
// registry writes. The first analysis does not consult the registry; the second
// does not consult first-order facts. The shared stock syntactic creator reads
// only AST declarations/input bindings and its default redeclaration handler is
// empty. All scopes are materialized by first.EnterScope before either Visit.
func (c *TypedScopeCreator) gatherInitialAnalysisFacts(root *rhino.Node, scopes *MemoizedScopeCreator) {
	probe := c.initialAnalysisProbe
	if c.initialAnalysisFusion && typedInitialAnalysisFusionSafe(c, root) {
		callback := &typedInitialFusedCallback{
			first:  TypedScopeCreator_FirstOrderFunctionAnalyzer{outer: c},
			second: TypedScopeCreator_IdentifyEnumsAndTypedefsAsNonNullable{registry: c.typeRegistry},
			root:   root, probe: probe,
		}
		if probe != nil {
			probe.Fused = true
			probe.Traversals++
		}
		// Traverse(root) includes the second callback's final ROOT visit. The
		// first originally used TraverseRoots and therefore omits that visit.
		NodeTraversal_Builder_().SetCompiler(c.compiler).SetCallback(callback).SetScopeCreator(scopes).Traverse(root)
	} else {
		first := NewTypedScopeCreator_FirstOrderFunctionAnalyzer(c)
		var firstCallback NodeTraversal_Callback = first
		if probe != nil {
			probe.Traversals += 2
			firstCallback = &typedInitialFirstProbe{first: first, probe: probe}
		}
		NodeTraversal_Builder_().SetCompiler(c.compiler).SetCallback(firstCallback).SetScopeCreator(scopes).TraverseRoots(root.GetFirstChild(), root.GetLastChild())
		second := NewTypedScopeCreator_IdentifyEnumsAndTypedefsAsNonNullable(c.typeRegistry)
		var secondCallback NodeTraversal_Callback = second
		if probe != nil {
			secondCallback = &typedInitialSecondProbe{second: second, probe: probe}
		}
		NodeTraversal_Builder_().SetCompiler(c.compiler).SetCallback(secondCallback).SetScopeCreator(scopes).Traverse(root)
	}
	if probe != nil && probe.afterFacts != nil {
		probe.afterFacts(c)
	}
}

type typedInitialFusedCallback struct {
	first  TypedScopeCreator_FirstOrderFunctionAnalyzer
	second TypedScopeCreator_IdentifyEnumsAndTypedefsAsNonNullable
	root   *rhino.Node
	probe  *typedInitialAnalysisProbe
}

func (f *typedInitialFusedCallback) ShouldTraverse(t *NodeTraversal, n, parent *rhino.Node) bool {
	if n != f.root {
		f.probe.first("pre", t, n)
		if !f.first.ShouldTraverse(t, n, parent) {
			return false
		}
	}
	f.probe.second("pre", t, n)
	return f.second.ShouldTraverse(t, n, parent)
}
func (f *typedInitialFusedCallback) Visit(t *NodeTraversal, n, parent *rhino.Node) {
	if n != f.root {
		f.probe.first("post", t, n)
		f.first.Visit(t, n, parent)
	}
	f.probe.second("post", t, n)
	f.second.Visit(t, n, parent)
}
func (f *typedInitialFusedCallback) EnterScope(t *NodeTraversal) {
	f.probe.first("enter", t, t.GetScopeRoot())
	f.first.EnterScope(t)
}
func (f *typedInitialFusedCallback) ExitScope(t *NodeTraversal) {
	f.probe.first("exit", t, t.GetScopeRoot())
	f.first.ExitScope(t)
}

// Test-only observations allocate nothing when the optional probe is nil.
// Scope roots, not transient CurrentNode values, identify Enter/Exit events.
type typedInitialAnalysisEvent struct {
	kind            string
	node, scopeRoot *rhino.Node
}
type typedInitialAnalysisProbe struct {
	Fused         bool
	Traversals    int
	First, Second []typedInitialAnalysisEvent
	afterFacts    func(*TypedScopeCreator)
}

func (p *typedInitialAnalysisProbe) first(kind string, t *NodeTraversal, n *rhino.Node) {
	if p != nil {
		p.First = append(p.First, typedInitialAnalysisEvent{kind: kind, node: n, scopeRoot: t.GetScopeRoot()})
	}
}
func (p *typedInitialAnalysisProbe) second(kind string, t *NodeTraversal, n *rhino.Node) {
	if p != nil {
		p.Second = append(p.Second, typedInitialAnalysisEvent{kind: kind, node: n, scopeRoot: t.GetScopeRoot()})
	}
}

type typedInitialFirstProbe struct {
	first *TypedScopeCreator_FirstOrderFunctionAnalyzer
	probe *typedInitialAnalysisProbe
}

func (f *typedInitialFirstProbe) ShouldTraverse(t *NodeTraversal, n, parent *rhino.Node) bool {
	f.probe.first("pre", t, n)
	return f.first.ShouldTraverse(t, n, parent)
}
func (f *typedInitialFirstProbe) Visit(t *NodeTraversal, n, parent *rhino.Node) {
	f.probe.first("post", t, n)
	f.first.Visit(t, n, parent)
}
func (f *typedInitialFirstProbe) EnterScope(t *NodeTraversal) {
	f.probe.first("enter", t, t.GetScopeRoot())
	f.first.EnterScope(t)
}
func (f *typedInitialFirstProbe) ExitScope(t *NodeTraversal) {
	f.probe.first("exit", t, t.GetScopeRoot())
	f.first.ExitScope(t)
}

type typedInitialSecondProbe struct {
	second *TypedScopeCreator_IdentifyEnumsAndTypedefsAsNonNullable
	probe  *typedInitialAnalysisProbe
}

func (f *typedInitialSecondProbe) ShouldTraverse(t *NodeTraversal, n, parent *rhino.Node) bool {
	f.probe.second("pre", t, n)
	return f.second.ShouldTraverse(t, n, parent)
}
func (f *typedInitialSecondProbe) Visit(t *NodeTraversal, n, parent *rhino.Node) {
	f.probe.second("post", t, n)
	f.second.Visit(t, n, parent)
}
