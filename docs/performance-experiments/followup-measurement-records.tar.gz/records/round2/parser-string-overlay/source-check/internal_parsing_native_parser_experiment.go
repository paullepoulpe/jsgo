package parsing

import (
	"os"
	"strings"

	"github.com/paullepoulpe/jsgo/internal/jutil"
	"github.com/paullepoulpe/jsgo/internal/parser"
	"github.com/paullepoulpe/jsgo/internal/rhino"
)

// This opt-in experiment builds final Rhino nodes directly from Scanner tokens.
// The original parser remains the default and the fallback for every construct
// outside the explicit subset below. Read once before concurrent compilations.
var nativeParserExperimentEnabled = os.Getenv("JSGO_EXPERIMENT_NATIVE_PARSER") == "1"

// Current main allocates nodes independently. Keep batching a separate opt-in
// axis so direct parsing does not silently reintroduce chunk retention.
var nativeParserOwnedAllocatorEnabled = os.Getenv("JSGO_EXPERIMENT_NATIVE_PARSER_ALLOCATOR") == "1"

// nativeParserDiagnostics never publishes speculative diagnostics. A lexical or
// IR warning/error rejects the entire native attempt, so the original pipeline
// produces the complete diagnostic sequence, with its original ordering.
// A caller may request a non-timed coverage observation. No global counters or
// instrumentation are enabled in the normal compiler path. Offsets are UTF-16
// source offsets, while SourceBytes is the original UTF-8 file size.
type nativeParserObservation struct {
	Accepted           bool
	Reason             string
	OffsetUTF16        int
	SourceBytes        int
	FallbackBytes      int
	FallbackSpans      []nativeFallbackSpan
	AnnotationWarnings int
}

type nativeFallbackSpan struct {
	Reason               string
	StartUTF16, EndUTF16 int
	Bytes                int
}

type nativeParserDiagnostics struct {
	parser.ErrorReporterBase
	failed             bool
	sourceMapURL       *string
	comments           []*parser.Comment
	factory            *IRFactory
	observation        *nativeParserObservation
	lastCommentEnd     int
	annotationWarnings []nativeAnnotationWarning
}

func (r *nativeParserDiagnostics) reject(reason string, position *parser.SourcePosition) {
	r.failed = true
	if r.observation != nil && r.observation.Reason == "" {
		r.observation.Reason = reason
		if position != nil {
			r.observation.OffsetUTF16 = position.Offset
		}
	}
}
func (r *nativeParserDiagnostics) ReportError(pos *parser.SourcePosition, _ string) {
	r.reject("lexical-error", pos)
}
func (r *nativeParserDiagnostics) ReportWarning(pos *parser.SourcePosition, _ string) {
	r.reject("lexical-warning", pos)
}
func (r *nativeParserDiagnostics) Warning(string, string, int, int) { r.reject("IR-warning", nil) }
func (r *nativeParserDiagnostics) Error(string, string, int, int)   { r.reject("IR-error", nil) }
func (r *nativeParserDiagnostics) RecordComment(kind parser.Comment_Type, location *parser.SourceRange, value string) {
	if location.End.Offset <= r.lastCommentEnd {
		return
	}
	r.lastCommentEnd = location.End.Offset
	value = jutil.StringTrim(value)
	if strings.HasPrefix(value, "<!--") || strings.HasPrefix(value, "-->") || strings.HasPrefix(value, "#!") {
		r.reject("legacy-comment", location.Start)
		return
	}
	comment := parser.NewComment(value, location, kind)
	r.comments = append(r.comments, comment)
	r.factory.jsdocTracker.appendSource(r.comments, comment)
	r.factory.nonJsdocTracker.appendSource(r.comments, comment)
	if strings.HasPrefix(value, parser.Parser_SOURCE_MAPPING_URL_PREFIX) {
		url := value[len(parser.Parser_SOURCE_MAPPING_URL_PREFIX):]
		r.sourceMapURL = &url
	}
}

type nativeAnnotationWarning struct {
	message, file string
	line, column  int
}
type nativeAnnotationReporter struct{ owner *nativeParserDiagnostics }

func (r *nativeAnnotationReporter) Warning(message, file string, line, column int) {
	r.owner.annotationWarnings = append(r.owner.annotationWarnings, nativeAnnotationWarning{message, file, line, column})
}
func (r *nativeAnnotationReporter) Error(string, string, int, int) {
	r.owner.reject("JSDoc-error", nil)
}

// Reporter exceptions receive the same original ParserRunner wrapping. Nothing
// reaches the caller before the speculative parse and validation both succeed.
func publishNativeAnnotationWarnings(warnings []nativeAnnotationWarning, reporter rhino.ErrorReporter) {
	if len(warnings) == 0 {
		return
	}
	jutil.Try(func() {
		for _, warning := range warnings {
			reporter.Warning(warning.message, warning.file, warning.line, warning.column)
		}
	}, func(cause jutil.Throwable) {
		panic(jutil.NewRuntimeExceptionWithMessageAndCause("Exception parsing \""+warnings[0].file+"\"", cause))
	})
}

type nativeExpression struct {
	node       *rhino.Node
	start, end *parser.SourcePosition
}

// nativeParser builds ordinary expressions/statements directly into final Rhino
// nodes. Annotation attachment and validation use the original IRFactory; complex
// constructs delegate to the original grammar one subtree at a time. Unsupported
// contexts discard the entire private attempt. See docs/round-native-parser.md
// for coverage, ownership and differential-oracle limits.
type nativeParser struct {
	scanner        *parser.Scanner
	current        parser.Token
	last           parser.Token
	factory        *IRFactory
	fragmentConfig *parser.Parser_Config
	diagnostics    *nativeParserDiagnostics
	depth          int
	statementDepth int
	functionDepth  int
	suppressCalls  int
	features       *parser.FeatureSet
}

func parserRunnerParseWithNativeFallback(sourceFile rhino.StaticSourceFile, source string,
	config *Config, reporter rhino.ErrorReporter) *ParserRunner_ParseResult {
	if result, ok, warnings := tryNativeParserWithDiagnostics(sourceFile, source, config, nil); ok {
		publishNativeAnnotationWarnings(warnings, reporter)
		return result
	}
	return parserRunnerParseUncached(sourceFile, source, config, reporter)
}

func tryNativeParser(sourceFile rhino.StaticSourceFile, source string, config *Config) (*ParserRunner_ParseResult, bool) {
	return tryNativeParserObserved(sourceFile, source, config, nil)
}

func tryNativeParserObserved(sourceFile rhino.StaticSourceFile, source string, config *Config,
	observation *nativeParserObservation) (*ParserRunner_ParseResult, bool) {
	result, accepted, _ := tryNativeParserWithDiagnostics(sourceFile, source, config, observation)
	return result, accepted
}
func tryNativeParserWithDiagnostics(sourceFile rhino.StaticSourceFile, source string, config *Config,
	observation *nativeParserObservation) (result *ParserRunner_ParseResult, accepted bool, warnings []nativeAnnotationWarning) {
	if observation == nil {
		observation = &nativeParserObservation{}
	}
	stringDiagnostic := rhino.NewStringPoolParseDiagnostic(len(source))
	defer func() { stringDiagnostic.Finish(accepted, observation.Reason, observation.OffsetUTF16) }()

	if observation != nil {
		*observation = nativeParserObservation{SourceBytes: len(source), OffsetUTF16: -1}
	}
	jutil.Try(func() {
		result, accepted, warnings = nativeParserAttempt(sourceFile, source, config, observation, stringDiagnostic)
	}, func(jutil.Throwable) {
		// The original entry point owns exception wrapping as well as normal
		// diagnostics. No speculative exception may bypass that boundary.
		result, accepted, warnings = nil, false, nil
		if observation != nil && observation.Reason == "" {
			observation.Reason = "speculative-exception"
		}
	})
	if observation != nil {
		observation.Accepted = accepted
		observation.AnnotationWarnings = len(warnings)
	}
	return result, accepted, warnings
}

func nativeParserAttempt(sourceFile rhino.StaticSourceFile, source string, config *Config, observation *nativeParserObservation, stringDiagnostic *rhino.StringPoolParseDiagnostic) (*ParserRunner_ParseResult, bool, []nativeAnnotationWarning) {
	if sourceFile.IsTypeScriptSource() || config.JsDocParsingMode().ShouldParseDescriptions() {
		if observation != nil {
			observation.Reason = "configuration"
			observation.OffsetUTF16 = 0
		}
		return nil, false, nil
	}
	file := parser.NewSourceFile(sourceFile.GetName(), source)
	stringDiagnostic.SetSourceName(file.Name)
	diagnostics := &nativeParserDiagnostics{observation: observation}
	diagnostics.InitErrorReporterBase(diagnostics)
	p := &nativeParser{diagnostics: diagnostics, features: parser.FeatureSet_BARE_MINIMUM}
	p.scanner = parser.NewScanner(diagnostics, diagnostics, file, 0)
	var allocator *rhino.NodeAllocator
	if nativeParserOwnedAllocatorEnabled {
		allocator = &rhino.NodeAllocator{StringPoolDiagnostic: stringDiagnostic}
		stringDiagnostic.ActivateAllocator()
	}
	p.factory = newIRFactoryWithNodeAllocator(sourceFile, config, diagnostics, nil, file,
		JsDocInfoParser_JsDocSourceKind_NORMAL, allocator)
	diagnostics.factory = p.factory
	p.factory.jsdocErrorReporter = &nativeAnnotationReporter{owner: diagnostics}
	start := p.scanner.GetPosition()
	p.advance()
	root := p.factory.NewNode(rhino.Token_SCRIPT)
	for !p.failed() && p.kind() != parser.TokenType_END_OF_FILE {
		statement := p.statement()
		if p.failed() {
			return nil, false, nil
		}
		root.AddChildToBack(statement.node)
	}
	if p.failed() {
		return nil, false, nil
	}
	p.factory.SetSourceInfoFromPositions(root, start, p.current.GetTokenBase().Location.End)
	p.factory.transformDispatcher.ParseDirectives(root)
	p.factory.transformDispatcher.wrapModuleRoot(root, start, p.current.GetTokenBase().Location.End)
	p.factory.finishRoot(root, diagnostics.comments, p.current.GetTokenBase().Location.End)
	if p.failed() {
		return nil, false, nil
	}
	features := p.features.Union(p.factory.GetFeatures())
	root.PutProp(rhino.Node_FEATURE_SET, features)
	return NewParserRunner_ParseResultWithTopLevelStatementRanges(root, []*parser.Comment{}, []*parser.SourceRange{}, features, diagnostics.sourceMapURL), true, diagnostics.annotationWarnings
}

func (p *nativeParser) failed() bool { return p.diagnostics.failed }
func (p *nativeParser) reject() {
	p.diagnostics.reject("unsupported:"+p.kind().String(), p.current.GetStart())
}
func (p *nativeParser) kind() parser.TokenType { return p.current.GetTokenBase().Type }
func (p *nativeParser) advance() {
	p.last = p.current
	p.current = p.scanner.NextToken()

}
func (p *nativeParser) take(kind parser.TokenType) bool {
	if p.failed() || p.kind() != kind {
		p.reject()
		return false
	}
	p.advance()
	return !p.failed()
}
func (p *nativeParser) located(node *rhino.Node, start, end *parser.SourcePosition) nativeExpression {
	p.factory.SetSourceInfoFromPositions(node, start, end)
	return nativeExpression{node, start, end}
}
func (p *nativeParser) statement() nativeExpression {
	switch p.kind() {
	case parser.TokenType_CLASS, parser.TokenType_FOR, parser.TokenType_DO,
		parser.TokenType_SWITCH, parser.TokenType_TRY, parser.TokenType_WITH,
		parser.TokenType_BREAK, parser.TokenType_CONTINUE, parser.TokenType_DEBUGGER:
		return p.originalFragment(nativeOriginalStatement)
	case parser.TokenType_FUNCTION:
		// es3.js also declares the global eval stub. Keep the complete original
		// function parser for its exact plain-code/empty-body signature. This
		// does not enable special native parameters or named expressions.
		if p.factory.sourceFile.IsExtern() && p.statementDepth == 0 && p.functionDepth == 0 &&
			nativePlainIdentifier(p.scanner.PeekToken(), "eval") &&
			p.scanner.PeekTokenAt(1).GetTokenBase().Type == parser.TokenType_OPEN_PAREN &&
			nativePlainIdentifier(p.scanner.PeekTokenAt(2), "code") &&
			p.scanner.PeekTokenAt(3).GetTokenBase().Type == parser.TokenType_CLOSE_PAREN &&
			p.scanner.PeekTokenAt(4).GetTokenBase().Type == parser.TokenType_OPEN_CURLY &&
			p.scanner.PeekTokenAt(5).GetTokenBase().Type == parser.TokenType_CLOSE_CURLY {
			return p.originalFragment(nativeOriginalStatement)
		}
	case parser.TokenType_VAR, parser.TokenType_LET, parser.TokenType_CONST:
		nextToken := p.scanner.PeekToken()
		next := nextToken.GetTokenBase().Type
		// The standard es3 extern declares this global explicitly. Preserve the
		// original binding parser for this one complete statement, rather than
		// relaxing special-name bindings in native functions or source scripts.
		// Decide before consuming VAR or its leading JSDoc state.
		if p.kind() == parser.TokenType_VAR && p.factory.sourceFile.IsExtern() &&
			p.statementDepth == 0 && p.functionDepth == 0 && next == parser.TokenType_IDENTIFIER {
			if nativePlainIdentifier(nextToken, "arguments") &&
				p.scanner.PeekTokenAt(1).GetTokenBase().Type == parser.TokenType_SEMI_COLON {
				return p.originalFragment(nativeOriginalStatement)
			}
		}
		if next == parser.TokenType_OPEN_CURLY || next == parser.TokenType_OPEN_SQUARE {
			return p.originalFragment(nativeOriginalStatement)
		}
	case parser.TokenType_IDENTIFIER:
		if p.scanner.PeekToken().GetTokenBase().Type == parser.TokenType_COLON ||
			p.current.AsIdentifier().ValueEquals("async") && p.scanner.PeekToken().GetTokenBase().Type == parser.TokenType_FUNCTION {
			return p.originalFragment(nativeOriginalStatement)
		}
	}
	var info *rhino.JSDocInfo
	switch p.kind() {
	case parser.TokenType_OPEN_CURLY, parser.TokenType_FUNCTION, parser.TokenType_RETURN,
		parser.TokenType_THROW, parser.TokenType_IF, parser.TokenType_WHILE,
		parser.TokenType_SEMI_COLON, parser.TokenType_VAR, parser.TokenType_LET, parser.TokenType_CONST:
		info = p.beginAnnotation(p.current.GetStart())
	}
	result := p.statementBody()
	if !p.failed() {
		result = p.finishAnnotation(result, info, false)
	}
	return result
}

func (p *nativeParser) beginAnnotation(start *parser.SourcePosition) *rhino.JSDocInfo {
	info := p.factory.ParseJSDocInfoFrom(p.factory.GetJSDocCommentAt(start))
	if info != nil && info.IsClosureUnawareCode() ||
		p.factory.firstFileoverview != nil && p.factory.firstFileoverview.IsClosureUnawareCode() {
		p.reject()
	}
	return info
}

func (p *nativeParser) finishAnnotation(result nativeExpression, info *rhino.JSDocInfo, parenthesized bool) nativeExpression {
	if info != nil {
		if parenthesized && info.HasType() {
			result.node = p.factory.NewNodeWithChild(rhino.Token_CAST, result.node)
			p.factory.SetSourceInfoFromPositions(result.node, result.start, result.end)
		}
		result.node.SetJSDocInfo(info)
	}
	return result
}

func (p *nativeParser) statementBody() nativeExpression {
	p.statementDepth++
	defer func() { p.statementDepth-- }()
	if p.statementDepth > 128 || p.failed() {
		p.reject()
		return nativeExpression{}
	}
	start := p.current.GetStart()
	switch p.kind() {
	case parser.TokenType_OPEN_CURLY:
		return p.block()
	case parser.TokenType_FUNCTION:
		return p.function(true)
	case parser.TokenType_RETURN, parser.TokenType_THROW:
		return p.returnOrThrow()
	case parser.TokenType_IF, parser.TokenType_WHILE:
		return p.controlStatement()
	}
	if p.kind() == parser.TokenType_SEMI_COLON {
		p.advance()
		return p.located(p.factory.NewNode(rhino.Token_EMPTY), start, p.last.GetTokenBase().Location.End)
	}
	if p.kind() == parser.TokenType_VAR || p.kind() == parser.TokenType_LET || p.kind() == parser.TokenType_CONST {
		declarationToken := p.current
		declarationKind := rhino.Token_VAR
		if p.kind() == parser.TokenType_LET {
			declarationKind = rhino.Token_LET
			p.factory.MaybeWarnForFeatureToken(declarationToken, parser.FeatureSet_Feature_LET_DECLARATIONS)
		} else if p.kind() == parser.TokenType_CONST {
			declarationKind = rhino.Token_CONST
			p.factory.MaybeWarnForFeatureToken(declarationToken, parser.FeatureSet_Feature_CONST_DECLARATIONS)
		}
		p.advance()
		declaration := p.factory.NewNode(declarationKind)
		end := declarationToken.GetTokenBase().Location.End
		for !p.failed() {
			if p.kind() != parser.TokenType_IDENTIFIER {
				p.reject()
				break
			}
			token := p.current.AsIdentifier()
			bindingEnd := token.GetTokenBase().Location.End
			if !nativeBindingName(token) {
				p.reject()
				break
			}
			name := p.factory.transformDispatcher.ProcessNameWithInlineCommentsOfToken(token, IRFactory_TransformDispatcher_IdentifierType_STANDARD)
			p.advance()
			if p.kind() == parser.TokenType_EQUAL {
				p.advance()
				initializer := p.expression(1)
				if p.failed() {
					break
				}
				name.AddChildToBack(initializer.node)
				p.factory.SetLength(name, token.GetStart(), initializer.end)
				bindingEnd = initializer.end
			} else if declarationKind == rhino.Token_CONST {
				p.reject()
				return nativeExpression{}
			}
			end = bindingEnd
			declaration.AddChildToBack(name)
			if p.kind() != parser.TokenType_COMMA {
				break
			}
			p.advance()
		}
		end = p.semicolon(end)
		if p.failed() {
			return nativeExpression{}
		}
		return p.located(declaration, start, end)
	}
	expr := p.expression(0)
	if p.failed() {
		return nativeExpression{}
	}
	end := p.semicolon(expr.end)
	if p.failed() {
		return nativeExpression{}
	}
	return p.located(p.factory.NewNodeWithChild(rhino.Token_EXPR_RESULT, expr.node), start, end)
}

func nativeBinaryPrecedence(kind parser.TokenType) int {
	switch kind {
	case parser.TokenType_COMMA:
		return 0
	case parser.TokenType_EQUAL, parser.TokenType_PLUS_EQUAL, parser.TokenType_MINUS_EQUAL,
		parser.TokenType_STAR_EQUAL, parser.TokenType_SLASH_EQUAL, parser.TokenType_PERCENT_EQUAL,
		parser.TokenType_LEFT_SHIFT_EQUAL, parser.TokenType_RIGHT_SHIFT_EQUAL, parser.TokenType_UNSIGNED_RIGHT_SHIFT_EQUAL,
		parser.TokenType_AMPERSAND_EQUAL, parser.TokenType_BAR_EQUAL, parser.TokenType_CARET_EQUAL,
		parser.TokenType_STAR_STAR_EQUAL, parser.TokenType_OR_EQUAL, parser.TokenType_AND_EQUAL, parser.TokenType_QUESTION_QUESTION_EQUAL:
		return 1
	case parser.TokenType_OR, parser.TokenType_QUESTION_QUESTION:
		return 3
	case parser.TokenType_AND:
		return 4
	case parser.TokenType_BAR:
		return 5
	case parser.TokenType_CARET:
		return 6
	case parser.TokenType_AMPERSAND:
		return 7
	case parser.TokenType_EQUAL_EQUAL, parser.TokenType_NOT_EQUAL, parser.TokenType_EQUAL_EQUAL_EQUAL, parser.TokenType_NOT_EQUAL_EQUAL:
		return 8
	case parser.TokenType_OPEN_ANGLE, parser.TokenType_CLOSE_ANGLE, parser.TokenType_LESS_EQUAL, parser.TokenType_GREATER_EQUAL, parser.TokenType_IN, parser.TokenType_INSTANCEOF:
		return 9
	case parser.TokenType_LEFT_SHIFT, parser.TokenType_RIGHT_SHIFT, parser.TokenType_UNSIGNED_RIGHT_SHIFT:
		return 10
	case parser.TokenType_PLUS, parser.TokenType_MINUS:
		return 11
	case parser.TokenType_STAR, parser.TokenType_SLASH, parser.TokenType_PERCENT:
		return 12
	case parser.TokenType_STAR_STAR:
		return 13
	default:
		return -1
	}
}
func (p *nativeParser) expression(minimum int) nativeExpression {
	if minimum > 1 && p.arrowStart() {
		p.reject()
		return nativeExpression{}
	}
	var info *rhino.JSDocInfo
	if p.kind() != parser.TokenType_OPEN_PAREN {
		info = p.beginAnnotation(p.current.GetStart())
	}
	result := p.expressionBody(minimum)
	if !p.failed() {
		result = p.finishAnnotation(result, info, false)
	}
	return result
}

func (p *nativeParser) expressionBody(minimum int) nativeExpression {
	p.depth++
	defer func() { p.depth-- }()
	if p.depth > 128 || p.failed() {
		p.reject()
		return nativeExpression{}
	}
	left := p.prefix(minimum)
	for !p.failed() {
		kind := p.kind()
		if kind == parser.TokenType_QUESTION && minimum <= 2 {
			p.advance()
			middle := p.expression(1)
			if !p.take(parser.TokenType_COLON) {
				return nativeExpression{}
			}
			right := p.expression(1)
			if p.failed() {
				return nativeExpression{}
			}
			left = p.located(p.factory.NewNodeWith3Children(rhino.Token_HOOK, left.node, middle.node, right.node), left.start, right.end)
			continue
		}
		precedence := nativeBinaryPrecedence(kind)
		if precedence < 0 || precedence < minimum {
			break
		}
		if precedence == 1 && !left.node.IsValidAssignmentTarget() {
			p.reject()
			return nativeExpression{}
		}
		operator := p.current
		p.advance()
		next := precedence + 1
		if precedence == 1 || kind == parser.TokenType_STAR_STAR {
			next = precedence
		}
		right := p.expression(next)
		if p.failed() {
			return nativeExpression{}
		}
		if kind == parser.TokenType_QUESTION_QUESTION {
			if nativeBareLogical(left.node) || nativeBareLogical(right.node) {
				p.reject()
				return nativeExpression{}
			}
			p.factory.MaybeWarnForFeatureToken(operator, parser.FeatureSet_Feature_NULL_COALESCE_OP)
		} else if kind == parser.TokenType_OR || kind == parser.TokenType_AND {
			if nativeBareCoalesce(left.node) || nativeBareCoalesce(right.node) {
				p.reject()
				return nativeExpression{}
			}
		}
		if kind == parser.TokenType_STAR_STAR || kind == parser.TokenType_STAR_STAR_EQUAL {
			p.factory.MaybeWarnForFeatureToken(operator, parser.FeatureSet_Feature_EXPONENT_OP)
		}
		if kind == parser.TokenType_QUESTION_QUESTION_EQUAL {
			p.factory.MaybeWarnForFeatureToken(operator, parser.FeatureSet_Feature_NULL_COALESCE_OP)
		}
		if kind == parser.TokenType_OR_EQUAL || kind == parser.TokenType_AND_EQUAL || kind == parser.TokenType_QUESTION_QUESTION_EQUAL {
			p.factory.MaybeWarnForFeatureToken(operator, parser.FeatureSet_Feature_LOGICAL_ASSIGNMENT)
		}
		left = p.located(p.factory.NewNodeWith2Children(IRFactory_TransformBinaryTokenType(kind), left.node, right.node), left.start, right.end)
	}
	return left
}
func (p *nativeParser) prefix(minimum int) nativeExpression {
	if p.failed() {
		return nativeExpression{}
	}
	token := p.current
	start := token.GetStart()
	kind := p.kind()
	switch kind {
	case parser.TokenType_PLUS, parser.TokenType_MINUS, parser.TokenType_BANG, parser.TokenType_TILDE, parser.TokenType_VOID, parser.TokenType_TYPEOF, parser.TokenType_DELETE:
		p.advance()
		operand := p.expression(13)
		if p.failed() {
			return nativeExpression{}
		}
		if operand.node.IsExponent() && !operand.node.GetIsParenthesized() {
			p.reject()
			return nativeExpression{}
		}
		if kind == parser.TokenType_DELETE && !operand.node.IsGetProp() && !operand.node.IsGetElem() && !operand.node.IsName() ||
			kind == parser.TokenType_PLUS && operand.node.IsBigInt() {
			p.reject()
			return nativeExpression{}
		}
		return p.located(p.factory.NewNodeWithChild(IRFactory_TransformUnaryTokenType(kind), operand.node), start, operand.end)
	}
	var result nativeExpression
	switch kind {
	case parser.TokenType_CLASS, parser.TokenType_BIGINT, parser.TokenType_NO_SUBSTITUTION_TEMPLATE,
		parser.TokenType_TEMPLATE_HEAD, parser.TokenType_SLASH, parser.TokenType_SLASH_EQUAL:
		result = p.originalFragment(nativeOriginalPrimary)
	case parser.TokenType_FUNCTION:
		result = p.function(false)
	case parser.TokenType_NEW:
		result = p.newExpression()
	case parser.TokenType_PLUS_PLUS, parser.TokenType_MINUS_MINUS:
		p.advance()
		operand := p.expression(14)
		if p.failed() {
			return nativeExpression{}
		}
		node := p.factory.transformDispatcher.CreateUpdateNode(IRFactory_TransformUpdateTokenType(kind), false, operand.node)
		return p.located(node, start, operand.end)
	case parser.TokenType_IDENTIFIER:
		if token.AsIdentifier().ValueEquals("async") {
			if p.scanner.PeekToken().GetTokenBase().Type == parser.TokenType_FUNCTION &&
				p.scanner.PeekToken().GetStart().Line == token.GetTokenBase().Location.End.Line {
				result = p.originalFragment(nativeOriginalAsyncFunction)
				break
			}
			if p.asyncArrowStart() {
				result = p.originalFragment(nativeOriginalAssignment)
				break
			}
		}
		if p.scanner.PeekToken().GetTokenBase().Type == parser.TokenType_ARROW {
			result = p.arrowFunction()
			break
		}
		if !nativeReferenceName(token.AsIdentifier()) {
			p.reject()
			return nativeExpression{}
		}
		node := p.factory.transformDispatcher.ProcessNameOfToken(token.AsIdentifier(), rhino.Token_NAME, IRFactory_TransformDispatcher_IdentifierType_STANDARD)
		p.advance()
		result = nativeExpression{node, start, token.GetTokenBase().Location.End}
	case parser.TokenType_NUMBER:
		if strings.Contains(token.AsLiteral().GetLiteralTokenBase().Value, "_") {
			p.features = p.features.With(parser.FeatureSet_Feature_NUMERIC_SEPARATOR)
		}
		node := p.factory.NewNumberNode(p.factory.NormalizeNumber(token.AsLiteral()))
		p.advance()
		result = p.located(node, start, token.GetTokenBase().Location.End)
	case parser.TokenType_STRING:
		if token.(*parser.StringLiteralToken).HasUnescapedUnicodeLineOrParagraphSeparator() {
			p.features = p.features.With(parser.FeatureSet_Feature_UNESCAPED_UNICODE_LINE_OR_PARAGRAPH_SEP)
		}
		node := p.factory.transformDispatcher.ProcessString(token.AsLiteral())
		p.advance()
		result = nativeExpression{node, start, token.GetTokenBase().Location.End}
	case parser.TokenType_TRUE, parser.TokenType_FALSE, parser.TokenType_NULL, parser.TokenType_THIS:
		var nodeKind rhino.Token
		switch kind {
		case parser.TokenType_TRUE:
			nodeKind = rhino.Token_TRUE
		case parser.TokenType_FALSE:
			nodeKind = rhino.Token_FALSE
		case parser.TokenType_NULL:
			nodeKind = rhino.Token_NULL
		case parser.TokenType_THIS:
			nodeKind = rhino.Token_THIS
		}
		p.advance()
		result = p.located(p.factory.NewNode(nodeKind), start, token.GetTokenBase().Location.End)
	case parser.TokenType_OPEN_PAREN:
		info := p.beginAnnotation(start)
		if p.simpleArrowHead() {
			result = p.finishAnnotation(p.arrowFunction(), info, false)
			break
		}
		if p.complexParenthesizedHead() {
			result = p.originalFragment(nativeOriginalParenthesized)
			if p.failed() {
				return nativeExpression{}
			}
			if minimum > 1 && result.node.IsArrowFunction() && !result.node.GetIsParenthesized() {
				p.reject()
				return nativeExpression{}
			}
			result = p.finishAnnotation(result, info, result.node.GetIsParenthesized())
			break
		}
		p.advance()
		result = p.nestedExpression(0)
		if !p.take(parser.TokenType_CLOSE_PAREN) {
			return nativeExpression{}
		}
		result.node.SetIsParenthesized(true)
		result.start, result.end = start, p.last.GetTokenBase().Location.End
		result = p.finishAnnotation(result, info, true)
	case parser.TokenType_OPEN_SQUARE, parser.TokenType_OPEN_CURLY:
		if p.destructuringAssignmentHead() {
			if minimum > 1 {
				p.reject()
				return nativeExpression{}
			}
			result = p.originalFragment(nativeOriginalAssignment)
		} else {
			result = p.literalContainer()
		}
	default:
		p.reject()
		return nativeExpression{}
	}
	for !p.failed() {
		switch p.kind() {
		case parser.TokenType_NO_SUBSTITUTION_TEMPLATE, parser.TokenType_TEMPLATE_HEAD:
			template := p.originalFragmentAt(nativeOriginalTaggedTemplate, result.start)
			if p.failed() {
				return nativeExpression{}
			}
			tagged := p.factory.NewNodeWith2Children(rhino.Token_TAGGED_TEMPLATELIT, result.node, template.node)
			p.factory.transformDispatcher.AnnotateCalls(tagged)
			result = p.located(tagged, result.start, template.end)
		case parser.TokenType_PERIOD:
			p.advance()
			propertyIdentifier := p.propertyIdentifier()
			if p.failed() || propertyIdentifier == nil {
				p.reject()
				return nativeExpression{}
			}
			property := p.current
			node := p.factory.transformDispatcher.NewStringNodeFromIdentifier(rhino.Token_GETPROP, IRFactory_TransformDispatcher_IdentifierType_STANDARD, propertyIdentifier)
			node.AddChildToBack(result.node)
			p.factory.SetSourceInfoFromToken(node, property)
			p.factory.transformDispatcher.MaybeWarnKeywordProperty(node)
			p.advance()
			result = nativeExpression{node, result.start, property.GetTokenBase().Location.End}
		case parser.TokenType_OPEN_SQUARE:
			p.advance()
			index := p.nestedExpression(0)
			if !p.take(parser.TokenType_CLOSE_SQUARE) {
				return nativeExpression{}
			}
			result = p.located(p.factory.NewNodeWith2Children(rhino.Token_GETELEM, result.node, index.node), result.start, p.last.GetTokenBase().Location.End)
		case parser.TokenType_PLUS_PLUS, parser.TokenType_MINUS_MINUS:
			if p.suppressCalls != 0 {
				return result
			}
			if p.current.GetStart().Line != result.end.Line {
				return result // ASI ends this expression before a prefix update.
			}
			kind := p.kind()
			end := p.current.GetTokenBase().Location.End
			p.advance()
			node := p.factory.transformDispatcher.CreateUpdateNode(IRFactory_TransformUpdateTokenType(kind), true, result.node)
			return p.located(node, result.start, end)
		case parser.TokenType_OPEN_PAREN:
			if p.suppressCalls != 0 {
				return result
			}
			p.advance()
			call := p.factory.NewNodeWithChild(rhino.Token_CALL, result.node)
			for !p.failed() && p.kind() != parser.TokenType_CLOSE_PAREN {
				var arg nativeExpression
				if p.kind() == parser.TokenType_ELLIPSIS {
					arg = p.originalFragment(nativeOriginalSpread)
				} else {
					arg = p.expression(1)
				}
				if p.failed() {
					return nativeExpression{}
				}
				call.AddChildToBack(arg.node)
				if p.kind() != parser.TokenType_COMMA {
					break
				}
				p.advance()
				if p.kind() == parser.TokenType_CLOSE_PAREN {
					if p.factory.config.LanguageMode() < Config_LanguageMode_ECMASCRIPT_2017 {
						p.reject()
						return nativeExpression{}
					}
					call.SetTrailingComma(true)
				}
			}
			if !p.take(parser.TokenType_CLOSE_PAREN) {
				return nativeExpression{}
			}
			p.factory.transformDispatcher.AnnotateCalls(call)
			result = p.located(call, result.start, p.last.GetTokenBase().Location.End)
		default:
			return result
		}
	}
	return nativeExpression{}
}
func (p *nativeParser) trailingComma(container *rhino.Node) {
	container.SetTrailingComma(true)
	p.features = p.features.With(parser.FeatureSet_Feature_TRAILING_COMMA)
	if p.factory.config.LanguageMode() == Config_LanguageMode_ECMASCRIPT3 {
		p.reject()
	}
}

func (p *nativeParser) literalContainer() nativeExpression {
	start := p.current.GetStart()
	object := p.kind() == parser.TokenType_OPEN_CURLY
	endKind, nodeKind := parser.TokenType_CLOSE_SQUARE, rhino.Token_ARRAYLIT
	if object {
		endKind, nodeKind = parser.TokenType_CLOSE_CURLY, rhino.Token_OBJECTLIT
	}
	p.advance()
	container := p.factory.NewNode(nodeKind)
	for !p.failed() && p.kind() != endKind {
		if !object && p.kind() == parser.TokenType_COMMA {
			position := p.current.GetStart()
			info := p.beginAnnotation(position)
			hole := p.located(p.factory.NewNode(rhino.Token_EMPTY), position, position)
			container.AddChildToBack(p.finishAnnotation(hole, info, false).node)
			p.advance()
			if p.kind() == endKind {
				p.trailingComma(container)
			}
			continue
		}
		var key *rhino.Node
		if object {
			identifier := p.propertyIdentifier()
			plainKey := identifier != nil || p.kind() == parser.TokenType_STRING || p.kind() == parser.TokenType_NUMBER
			if !plainKey || p.scanner.PeekToken().GetTokenBase().Type != parser.TokenType_COLON {
				property := p.originalFragment(nativeOriginalProperty)
				if p.failed() {
					return nativeExpression{}
				}
				container.AddChildToBack(property.node)
			} else {
				info := p.beginAnnotation(p.current.GetStart())
				propertyToken := p.current
				if identifier != nil {
					propertyToken = identifier
				}
				key = p.factory.transformDispatcher.ProcessObjectLitKey(propertyToken, rhino.Token_STRING_KEY, IRFactory_TransformDispatcher_IdentifierType_STANDARD)
				p.advance()
				if !p.take(parser.TokenType_COLON) {
					return nativeExpression{}
				}
				value := p.expression(1)
				if p.failed() {
					return nativeExpression{}
				}
				key.AddChildToBack(value.node)
				if info != nil {
					key.SetJSDocInfo(info)
				}
				if !key.IsQuotedStringKey() && !p.factory.currentFileIsExterns {
					p.factory.transformDispatcher.MaybeWarnKeywordProperty(key)
				}
				container.AddChildToBack(key)
			}
		} else {
			var value nativeExpression
			if p.kind() == parser.TokenType_ELLIPSIS {
				value = p.originalFragment(nativeOriginalSpread)
			} else {
				value = p.expression(1)
			}
			if p.failed() {
				return nativeExpression{}
			}
			container.AddChildToBack(value.node)
		}
		if p.kind() != parser.TokenType_COMMA {
			break
		}
		p.advance()
		if p.kind() == endKind {
			p.trailingComma(container)
		}
	}
	if !p.take(endKind) {
		return nativeExpression{}
	}
	return p.located(container, start, p.last.GetTokenBase().Location.End)
}

// Raw token width excludes escaped spellings; the value and token kind keep
// boundaries exact (argumentsX/evalX/private identifiers cannot match).
func nativePlainIdentifier(token parser.Token, name string) bool {
	if token.GetTokenBase().Type != parser.TokenType_IDENTIFIER {
		return false
	}
	identifier := token.AsIdentifier()
	location := token.GetTokenBase().Location
	return !identifier.IsPrivateIdentifier() && identifier.ValueEquals(name) &&
		location.End.Offset-location.Start.Offset == len(name)
}

func nativeReferenceName(token *parser.IdentifierToken) bool {
	return !token.IsPrivateIdentifier() && !token.IsKeyword() && !token.ValueEquals("await")
}
func nativeBindingName(token *parser.IdentifierToken) bool {
	return nativeReferenceName(token) && !token.ValueEquals("eval") && !token.ValueEquals("arguments")
}
func (p *nativeParser) propertyIdentifier() *parser.IdentifierToken {
	if p.kind() == parser.TokenType_IDENTIFIER && !p.current.AsIdentifier().IsPrivateIdentifier() {
		return p.current.AsIdentifier()
	}
	if parser.Keywords_IsKeywordTokenType(p.kind()) {
		return parser.NewIdentifierToken(p.current.GetTokenBase().Location, parser.Keywords_GetByTokenType(p.kind()).String())
	}
	return nil
}

func (p *nativeParser) block() nativeExpression {
	start := p.current.GetStart()
	info := p.beginAnnotation(start)
	if !p.take(parser.TokenType_OPEN_CURLY) {
		return nativeExpression{}
	}
	block := p.factory.NewNode(rhino.Token_BLOCK)
	for !p.failed() && p.kind() != parser.TokenType_CLOSE_CURLY {
		if p.kind() == parser.TokenType_END_OF_FILE {
			p.reject()
			return nativeExpression{}
		}
		statement := p.statement()
		if p.failed() {
			return nativeExpression{}
		}
		block.AddChildToBack(statement.node)
	}
	if !p.take(parser.TokenType_CLOSE_CURLY) {
		return nativeExpression{}
	}
	return p.finishAnnotation(p.located(block, start, p.last.GetTokenBase().Location.End), info, false)
}

func (p *nativeParser) function(declaration bool) nativeExpression {
	if !p.simpleFunctionHead() {
		if declaration {
			return p.originalFragment(nativeOriginalStatement)
		}
		return p.originalFragment(nativeOriginalFunction)
	}
	start := p.current.GetStart()
	if !p.take(parser.TokenType_FUNCTION) {
		return nativeExpression{}
	}
	var name *rhino.Node
	anonymous := false
	if p.kind() == parser.TokenType_IDENTIFIER {
		token := p.current.AsIdentifier()
		if !nativeBindingName(token) {
			p.reject()
			return nativeExpression{}
		}
		name = p.factory.transformDispatcher.ProcessNameWithInlineCommentsOfToken(token, IRFactory_TransformDispatcher_IdentifierType_STANDARD)
		p.advance()
	} else if declaration {
		p.reject()
		return nativeExpression{}
	} else {
		name = p.factory.NewStringNodeWithToken(rhino.Token_NAME, "")
		anonymous = true
	}
	paramStart := p.current.GetStart()
	if !p.take(parser.TokenType_OPEN_PAREN) {
		return nativeExpression{}
	}
	params := p.factory.NewNode(rhino.Token_PARAM_LIST)
	for !p.failed() && p.kind() != parser.TokenType_CLOSE_PAREN {
		if p.kind() != parser.TokenType_IDENTIFIER || !nativeBindingName(p.current.AsIdentifier()) {
			p.reject()
			return nativeExpression{}
		}
		param := p.factory.transformDispatcher.ProcessNameWithInlineCommentsOfToken(p.current.AsIdentifier(), IRFactory_TransformDispatcher_IdentifierType_STANDARD)
		params.AddChildToBack(param)
		p.advance()
		if p.kind() != parser.TokenType_COMMA {
			break
		}
		p.advance()
		if p.kind() == parser.TokenType_CLOSE_PAREN {
			p.reject()
			return nativeExpression{}
		}
	}
	if !p.take(parser.TokenType_CLOSE_PAREN) {
		return nativeExpression{}
	}
	p.located(params, paramStart, p.last.GetTokenBase().Location.End)
	if p.kind() != parser.TokenType_OPEN_CURLY {
		p.reject()
		return nativeExpression{}
	}
	p.functionDepth++
	previousSuppression := p.suppressCalls
	p.suppressCalls = 0
	body := p.block()
	p.suppressCalls = previousSuppression
	p.functionDepth--
	if p.failed() {
		return nativeExpression{}
	}
	p.factory.transformDispatcher.ParseDirectives(body.node)
	function := p.factory.NewNodeWith3Children(rhino.Token_FUNCTION, name, params, body.node)
	if anonymous {
		p.factory.SetSourceInfoFromPositions(name, start, body.end)
	}
	return p.located(function, start, body.end)
}

func (p *nativeParser) semicolon(end *parser.SourcePosition) *parser.SourcePosition {
	if p.kind() == parser.TokenType_SEMI_COLON {
		p.advance()
		return p.last.GetTokenBase().Location.End
	}
	if p.kind() == parser.TokenType_CLOSE_CURLY || p.kind() == parser.TokenType_END_OF_FILE || p.current.GetStart().Line > end.Line {
		return end
	}
	p.reject()
	return end
}

func (p *nativeParser) returnOrThrow() nativeExpression {
	token := p.current
	isReturn := p.kind() == parser.TokenType_RETURN
	if isReturn && p.functionDepth == 0 {
		p.reject()
		return nativeExpression{}
	}
	p.advance()
	kind := rhino.Token_THROW
	if isReturn {
		kind = rhino.Token_RETURN
	}
	node := p.factory.NewNode(kind)
	end := token.GetTokenBase().Location.End
	implicit := p.kind() == parser.TokenType_SEMI_COLON || p.kind() == parser.TokenType_CLOSE_CURLY || p.kind() == parser.TokenType_END_OF_FILE || p.current.GetStart().Line > end.Line
	if !isReturn || !implicit {
		if p.current.GetStart().Line != end.Line {
			p.reject()
			return nativeExpression{}
		}
		value := p.expression(0)
		if p.failed() {
			return nativeExpression{}
		}
		node.AddChildToBack(value.node)
		end = value.end
	}
	end = p.semicolon(end)
	if p.failed() {
		return nativeExpression{}
	}
	return p.located(node, token.GetStart(), end)
}

func (p *nativeParser) controlStatement() nativeExpression {
	token := p.current
	isIf := p.kind() == parser.TokenType_IF
	p.advance()
	if !p.take(parser.TokenType_OPEN_PAREN) {
		return nativeExpression{}
	}
	condition := p.expression(0)
	if !p.take(parser.TokenType_CLOSE_PAREN) {
		return nativeExpression{}
	}
	body := p.controlBody()
	if p.failed() {
		return nativeExpression{}
	}
	kind := rhino.Token_WHILE
	if isIf {
		kind = rhino.Token_IF
	}
	node := p.factory.NewNodeWith2Children(kind, condition.node, body.node)
	end := body.end
	if isIf && p.kind() == parser.TokenType_ELSE {
		p.advance()
		other := p.controlBody()
		if p.failed() {
			return nativeExpression{}
		}
		node.AddChildToBack(other.node)
		end = other.end
	}
	return p.located(node, token.GetStart(), end)
}

func (p *nativeParser) controlBody() nativeExpression {
	// Legacy unbraced function declarations have extra contextual rules.
	if p.kind() == parser.TokenType_FUNCTION || p.kind() == parser.TokenType_CLASS ||
		p.kind() == parser.TokenType_LET || p.kind() == parser.TokenType_CONST {
		p.reject()
		return nativeExpression{}
	}
	body := p.statement()
	if p.failed() || body.node.IsBlock() {
		return body
	}
	block := p.factory.NewNode(rhino.Token_BLOCK)
	if !body.node.IsEmpty() {
		block.AddChildToBack(body.node)
	}
	p.factory.SetSourceInfoFromNode(block, body.node)
	block.SetIsAddedBlock(true)
	body.node = block
	return body
}

func (p *nativeParser) newExpression() nativeExpression {
	start := p.current.GetStart()
	p.advance()
	switch p.kind() {
	case parser.TokenType_IDENTIFIER, parser.TokenType_THIS, parser.TokenType_FUNCTION, parser.TokenType_OPEN_PAREN, parser.TokenType_CLASS, parser.TokenType_NEW:
	default:
		p.reject()
		return nativeExpression{}
	}
	p.suppressCalls++
	constructor := p.expression(14)
	p.suppressCalls--
	if p.failed() {
		return nativeExpression{}
	}
	node := p.factory.NewNodeWithChild(rhino.Token_NEW, constructor.node)
	end := constructor.end
	if p.kind() == parser.TokenType_OPEN_PAREN {
		p.advance()
		for !p.failed() && p.kind() != parser.TokenType_CLOSE_PAREN {
			var arg nativeExpression
			if p.kind() == parser.TokenType_ELLIPSIS {
				arg = p.originalFragment(nativeOriginalSpread)
			} else {
				arg = p.nestedExpression(1)
			}
			if p.failed() {
				return nativeExpression{}
			}
			node.AddChildToBack(arg.node)
			if p.kind() != parser.TokenType_COMMA {
				break
			}
			p.advance()
			if p.kind() == parser.TokenType_CLOSE_PAREN {
				if p.factory.config.LanguageMode() < Config_LanguageMode_ECMASCRIPT_2017 {
					p.reject()
					return nativeExpression{}
				}
				node.SetTrailingComma(true)
			}
		}
		if !p.take(parser.TokenType_CLOSE_PAREN) {
			return nativeExpression{}
		}
		end = p.last.GetTokenBase().Location.End
	}
	return p.located(node, start, end)
}

type nativeFragmentKind int

const (
	nativeOriginalStatement nativeFragmentKind = iota
	nativeOriginalPrimary
	nativeOriginalProperty
	nativeOriginalSpread
	nativeOriginalFunction
	nativeOriginalAsyncFunction
	nativeOriginalAssignment
	nativeOriginalParenthesized
	nativeOriginalTaggedTemplate
)

func (p *nativeParser) originalFragment(kind nativeFragmentKind) nativeExpression {
	return p.originalFragmentAt(kind, nil)
}

func (p *nativeParser) originalFragmentAt(kind nativeFragmentKind, tagStart *parser.SourcePosition) nativeExpression {
	start := p.current.GetStart()
	scanStart := *start
	// Template token metadata begins just after the opening backtick. That
	// metadata is preserved, but rescanning the grammar must include it.
	if p.kind() == parser.TokenType_TEMPLATE_HEAD || p.kind() == parser.TokenType_NO_SUBSTITUTION_TEMPLATE {
		scanStart.Offset--
		scanStart.Column--
	}
	p.scanner.SetPosition(&scanStart)
	// Parser_Config contains four constructor-initialized booleans. Grammar
	// methods only read them; function/strict context lives on each Parser.
	// Reuse only within this file, and allocate lazily for fully direct files.
	if p.fragmentConfig == nil {
		p.fragmentConfig = ParserRunner_NewParserConfig(p.factory.config)
	}
	original := parser.NewParserForFragment(p.fragmentConfig, p.diagnostics, p.scanner)
	// Fragment grammar never reads GetComments/GetSourceMapURL or calls
	// ParseProgram. Route scanner events to the owning file directly instead
	// of allocating a second comment inventory and replaying it afterward.
	// IR conversion starts only after grammar parsing finishes, so trackers
	// observe the same ordered comments before any fragment annotation work.
	p.scanner.SetCommentRecorder(p.diagnostics)
	defer p.scanner.SetCommentRecorder(p.diagnostics)
	var tree parser.ParseTree
	switch kind {
	case nativeOriginalTaggedTemplate:
		template := original.ParseTaggedTemplateBody()
		template.Location.Start = tagStart
		tree = template
	case nativeOriginalPrimary:
		tree = original.ParsePrimaryExpression()
	case nativeOriginalProperty:
		tree = original.ParseObjectLiteralPropertyAssignment()
	case nativeOriginalSpread:
		tree = original.ParseAssignmentOrSpread()
	case nativeOriginalFunction:
		tree = original.ParseFunctionExpression()
	case nativeOriginalAsyncFunction:
		tree = original.ParseAsyncFunctionExpression()
	case nativeOriginalAssignment:
		tree = original.ParseAssignmentExpression()
	case nativeOriginalParenthesized:
		tree = original.ParseCoverParenthesizedExpressionAndArrowParameterList()
		if original.Peek(parser.TokenType_ARROW) {
			tree = original.CompleteAssignmentExpressionParseAtArrowWithExpression(tree, parser.Parser_Expression_NORMAL)
		}
	default:
		tree = original.ParseSourceElement()
	}
	if p.failed() || tree == nil {
		return nativeExpression{}
	}
	consumedEnd := original.GetTreeEndLocation()
	p.features = p.features.Union(original.GetFeatures())
	if kind == nativeOriginalProperty {
		switch tree.GetParseTreeBase().Type {
		case parser.ParseTreeType_DEFAULT_PARAMETER:
			p.reject()
			return nativeExpression{}
		case parser.ParseTreeType_GET_ACCESSOR:
			if p.factory.transformDispatcher.MaybeReportGetter(tree) {
				return nativeExpression{}
			}
		case parser.ParseTreeType_SET_ACCESSOR:
			if p.factory.transformDispatcher.MaybeReportSetter(tree) {
				return nativeExpression{}
			}
		}
	}
	node := p.factory.Transform(tree)
	if kind == nativeOriginalProperty {
		if !node.IsComputedProp() && !node.IsQuotedStringKey() && !node.IsSpread() && !p.factory.currentFileIsExterns {
			p.factory.transformDispatcher.MaybeWarnKeywordProperty(node)
		}
		if node.IsShorthandProperty() {
			p.factory.MaybeWarnForFeatureNode(node, parser.FeatureSet_Feature_SHORTHAND_OBJECT_PROPERTIES)
		}
	}
	// Some original tree metadata ranges (labels/properties) end before
	// their children. Resume at the actual last consumed token, never at
	// such a metadata boundary; retain original node source ranges above.
	end := consumedEnd
	if end.Offset <= start.Offset || p.failed() {
		p.reject()
		return nativeExpression{}
	}
	if observation := p.diagnostics.observation; observation != nil {
		bytes := len(jutil.StringFromUTF16(p.factory.fileWithContent.ContentsUTF16[scanStart.Offset:end.Offset]))
		observation.FallbackBytes += bytes
		observation.FallbackSpans = append(observation.FallbackSpans,
			nativeFallbackSpan{Reason: tree.GetParseTreeBase().Type.String(), StartUTF16: scanStart.Offset, EndUTF16: end.Offset, Bytes: bytes})
	}
	p.scanner.SetCommentRecorder(p.diagnostics)
	p.scanner.SetPosition(end)
	p.last = p.current
	p.current = p.scanner.NextToken()
	return nativeExpression{node: node, start: start, end: end}
}

// These bounded heads inspect only identifier/comma parameter lists. Complex
// ordinary functions use the original grammar before native state is consumed.
func (p *nativeParser) simpleParameterTail(index int) (int, bool) {
	if p.scanner.PeekTokenAt(index).GetTokenBase().Type == parser.TokenType_CLOSE_PAREN {
		return index, true
	}
	for index < 256 {
		if p.scanner.PeekTokenAt(index).GetTokenBase().Type != parser.TokenType_IDENTIFIER {
			return index, false
		}
		index++
		switch p.scanner.PeekTokenAt(index).GetTokenBase().Type {
		case parser.TokenType_CLOSE_PAREN:
			return index, true
		case parser.TokenType_COMMA:
			index++
		default:
			return index, false
		}
	}
	return index, false
}
func (p *nativeParser) simpleArrowHead() bool {
	end, simple := p.simpleParameterTail(0)
	return simple && p.scanner.PeekTokenAt(end+1).GetTokenBase().Type == parser.TokenType_ARROW
}
func (p *nativeParser) simpleFunctionHead() bool {
	index := 0
	if p.scanner.PeekTokenAt(index).GetTokenBase().Type == parser.TokenType_IDENTIFIER {
		index++
	}
	if p.scanner.PeekTokenAt(index).GetTokenBase().Type != parser.TokenType_OPEN_PAREN {
		return false
	}
	_, simple := p.simpleParameterTail(index + 1)
	return simple
}
func (p *nativeParser) arrowFunction() nativeExpression {
	start := p.current.GetStart()
	parenthesized := p.kind() == parser.TokenType_OPEN_PAREN
	params := p.factory.NewNode(rhino.Token_PARAM_LIST)
	if parenthesized {
		p.advance()
	}
	for !p.failed() && p.kind() != parser.TokenType_CLOSE_PAREN && p.kind() != parser.TokenType_ARROW {
		if p.kind() != parser.TokenType_IDENTIFIER || !nativeBindingName(p.current.AsIdentifier()) {
			p.reject()
			return nativeExpression{}
		}
		params.AddChildToBack(p.factory.transformDispatcher.ProcessNameWithInlineCommentsOfToken(
			p.current.AsIdentifier(), IRFactory_TransformDispatcher_IdentifierType_STANDARD))
		p.advance()
		if !parenthesized || p.kind() != parser.TokenType_COMMA {
			break
		}
		p.advance()
	}
	if parenthesized && !p.take(parser.TokenType_CLOSE_PAREN) {
		return nativeExpression{}
	}
	paramEnd := p.last.GetTokenBase().Location.End
	p.located(params, start, paramEnd)
	if p.current.GetStart().Line != paramEnd.Line {
		p.reject() // The original parser owns the restricted-newline diagnostic.
		return nativeExpression{}
	}
	if !p.take(parser.TokenType_ARROW) {
		return nativeExpression{}
	}
	p.factory.MaybeWarnForFeatureNode(params, parser.FeatureSet_Feature_ARROW_FUNCTIONS)
	p.functionDepth++
	var body nativeExpression
	if p.kind() == parser.TokenType_OPEN_CURLY {
		body = p.block()
	} else {
		body = p.expression(1)
	}
	p.functionDepth--
	if p.failed() {
		return nativeExpression{}
	}
	p.factory.transformDispatcher.ParseDirectives(body.node)
	name := p.factory.NewStringNodeWithToken(rhino.Token_NAME, "")
	p.located(name, start, body.end)
	function := p.factory.NewNodeWith3Children(rhino.Token_FUNCTION, name, params, body.node)
	function.SetIsArrowFunction(true)
	return p.located(function, start, body.end)
}

func (p *nativeParser) asyncArrowStart() bool {
	if p.kind() != parser.TokenType_IDENTIFIER || !p.current.AsIdentifier().ValueEquals("async") {
		return false
	}
	next := p.scanner.PeekToken()
	if next.GetStart().Line != p.current.GetTokenBase().Location.End.Line {
		return false
	}
	if next.GetTokenBase().Type == parser.TokenType_IDENTIFIER {
		return p.scanner.PeekTokenAt(1).GetTokenBase().Type == parser.TokenType_ARROW
	}
	if next.GetTokenBase().Type == parser.TokenType_OPEN_PAREN {
		end, simple := p.simpleParameterTail(1)
		return simple && p.scanner.PeekTokenAt(end+1).GetTokenBase().Type == parser.TokenType_ARROW
	}
	return false
}
func (p *nativeParser) arrowStart() bool {
	if p.kind() == parser.TokenType_OPEN_PAREN {
		return p.simpleArrowHead()
	}
	return p.kind() == parser.TokenType_IDENTIFIER &&
		(p.scanner.PeekToken().GetTokenBase().Type == parser.TokenType_ARROW || p.asyncArrowStart())
}
func nativeBareLogical(node *rhino.Node) bool {
	return !node.GetIsParenthesized() && (node.IsAnd() || node.IsOr())
}
func nativeBareCoalesce(node *rhino.Node) bool {
	return !node.GetIsParenthesized() && node.GetToken() == rhino.Token_COALESCE
}

func (p *nativeParser) nestedExpression(minimum int) nativeExpression {
	previous := p.suppressCalls
	p.suppressCalls = 0
	result := p.expression(minimum)
	p.suppressCalls = previous
	return result
}
func (p *nativeParser) complexParenthesizedHead() bool {
	first := p.scanner.PeekToken().GetTokenBase().Type
	if first == parser.TokenType_ELLIPSIS || first == parser.TokenType_OPEN_CURLY || first == parser.TokenType_OPEN_SQUARE {
		return true
	}
	if first != parser.TokenType_IDENTIFIER {
		return false
	}
	end, simple := p.simpleParameterTail(0)
	if simple {
		return false
	}
	kind := p.scanner.PeekTokenAt(end).GetTokenBase().Type
	return kind == parser.TokenType_EQUAL || kind == parser.TokenType_ELLIPSIS || kind == parser.TokenType_OPEN_CURLY || kind == parser.TokenType_OPEN_SQUARE
}

// Inspect a bounded balanced container before consuming native AST state. The
// original assignment grammar distinguishes destructuring targets from literals.
func (p *nativeParser) destructuringAssignmentHead() bool {
	depth := 1
	for index := 0; index < 256; index++ {
		kind := p.scanner.PeekTokenAt(index).GetTokenBase().Type
		switch kind {
		case parser.TokenType_OPEN_SQUARE, parser.TokenType_OPEN_CURLY, parser.TokenType_OPEN_PAREN:
			depth++
		case parser.TokenType_CLOSE_SQUARE, parser.TokenType_CLOSE_CURLY, parser.TokenType_CLOSE_PAREN:
			depth--
			if depth == 0 {
				return p.scanner.PeekTokenAt(index+1).GetTokenBase().Type == parser.TokenType_EQUAL
			}
		case parser.TokenType_IDENTIFIER, parser.TokenType_COMMA, parser.TokenType_COLON, parser.TokenType_ELLIPSIS:
			// Inspect binding-pattern tokens only. General token lookahead is
			// unsafe across regex/template boundaries that need parser context.
		default:
			return false
		}
	}
	return false
}
