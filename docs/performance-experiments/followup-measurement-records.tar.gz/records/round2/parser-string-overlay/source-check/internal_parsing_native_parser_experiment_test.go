package parsing

import (
	"encoding/json"
	"fmt"
	"math/rand"
	"os"
	"path/filepath"
	"reflect"
	"strings"
	"sync"
	"testing"

	"github.com/paullepoulpe/jsgo/internal/jutil"
	"github.com/paullepoulpe/jsgo/internal/parser"
	"github.com/paullepoulpe/jsgo/internal/rhino"
)

type nativeExperimentReporter struct{ diagnostics []string }

func (r *nativeExperimentReporter) Warning(message, file string, line, column int) {
	r.diagnostics = append(r.diagnostics, fmt.Sprintf("warning:%s:%d:%d:%s", file, line, column, message))
}
func (r *nativeExperimentReporter) Error(message, file string, line, column int) {
	r.diagnostics = append(r.diagnostics, fmt.Sprintf("error:%s:%d:%d:%s", file, line, column, message))
}

func nativeExperimentCompare(t *testing.T, source string, config *Config, requireNative bool) {
	t.Helper()
	file := rhino.NewSimpleSourceFile("native.js", rhino.StaticSourceFile_SourceKind_STRONG)
	baselineReporter, experimentReporter := &nativeExperimentReporter{}, &nativeExperimentReporter{}
	var baseline, experiment *ParserRunner_ParseResult
	var baselineException, experimentException jutil.Throwable
	jutil.Try(func() {
		baseline = parserRunnerParseUncached(file, source, config, baselineReporter)
	}, func(e jutil.Throwable) { baselineException = e })
	var observation nativeParserObservation
	experiment, accepted, warnings := tryNativeParserWithDiagnostics(file, source, config, &observation)
	if accepted != requireNative {
		t.Fatalf("native acceptance %v, want %v for %.160q (%d bytes); reject %s at UTF16 %d", accepted, requireNative, source, len(source), observation.Reason, observation.OffsetUTF16)
	}
	if accepted {
		publishNativeAnnotationWarnings(warnings, experimentReporter)
	}
	if !accepted {
		jutil.Try(func() {
			experiment = parserRunnerParseWithNativeFallback(file, source, config, experimentReporter)
		}, func(e jutil.Throwable) { experimentException = e })
	}
	if !reflect.DeepEqual(experimentReporter.diagnostics, baselineReporter.diagnostics) {
		t.Fatalf("diagnostics changed for %q: %v, want %v", source, experimentReporter.diagnostics, baselineReporter.diagnostics)
	}
	for original, replacement := baselineException, experimentException; original != nil || replacement != nil; {
		if original == nil || replacement == nil || original.Error() != replacement.Error() {
			t.Fatalf("exception changed for %q: %v, want %v", source, experimentException, baselineException)
		}
		original, replacement = original.GetCause(), replacement.GetCause()
	}
	if baselineException != nil {
		return
	}
	if baseline.Ast == nil || experiment.Ast == nil {
		if baseline.Ast != experiment.Ast {
			t.Fatalf("AST availability changed for %q", source)
		}
		return
	}
	// This includes node properties, literal values, UTF-16 line/column/length,
	// parenthesis/call flags and features, beyond equivalent printed JS alone.
	if got, want := nativeASTOracle(experiment.Ast), nativeASTOracle(baseline.Ast); got != want {
		offset := 0
		for offset < len(got) && offset < len(want) && got[offset] == want[offset] {
			offset++
		}
		start := offset - 160
		if start < 0 {
			start = 0
		}
		t.Fatalf("AST changed for %.160q (%d source bytes), dump offset %d\ngot: %.500q\nwant: %.500q", source, len(source), offset, got[start:], want[start:])
	}
	if experiment.Features.String() != baseline.Features.String() ||
		!reflect.DeepEqual(experiment.Comments, baseline.Comments) ||
		!reflect.DeepEqual(experiment.TopLevelStatementRanges, baseline.TopLevelStatementRanges) ||
		!reflect.DeepEqual(experiment.SourceMapURL, baseline.SourceMapURL) {
		t.Fatalf("parse metadata changed for %q", source)
	}
}

func TestNativeParserExpressionSubset(t *testing.T) {
	cases := []string{
		"", " \n\t ", ";;", "var x;", "var x=1,y=2; x=x+y*3;",
		"'use strict'; var x=(1+2)*3;",
		"var data={name:'😀', flag:true, nested:[1,2,{value:null}], 'quoted key':0.125};",
		"var x=-a + +b * ~c; var y=typeof x; void y;",
		"var x=a?b=c:d?e:f;",
		"var x=a.b[2](1, b.c); obj.member=call(x);",
		"(a).b(c)[d]; (a)=1; a?b=c:d=e; a=b=c;",
		"var data={1:true, 'é':null}; var \\u0061=1; \\u0061;",
		"var o={1e309:0,1e-9999:1,0.0:2,2.:3}; var zero=-0;",
		"(obj.method)(); (obj['method'])(); 'custom';'use strict';x;",
		"var o={__proto__:1,__proto__:2};",
		"var x=1; // late comment", "/* ordinary */ var x=1; /* late */",
		"var x=1;\n//# sourceMappingURL=test.map",
		"function f(){return 1;}",
		"/** @license MIT */ function f(){return 1;}",
		"/** @unknownTag one */ var a=1; /** @unknownTag two */ function f(){return 1;} /** @unknownTag three */",
		"/** @fileoverview Test */ var x=1; /** @license Late */",
		"/** @type {number} */ var x=1; /** @param {number} x */ function f(x){return x;}",
		"var x=/** @type {number} */ (foo); var y=/** @type {number} */ foo.bar;",
		"var x=/** @type {number} */ (foo).bar; var y=/** @type {number} */ (foo+1);",
		"var x=/** @type {number} */ foo+1; var f=function(/** number */ x){return x;};",
		"var object={/** @type {number} */ key:1};",
		"function outer(){function inner(a){return a;} return inner(1);}",
		"var f=(function(a){return a+1;}); f(2);",
		"var f=function(a /* ordinary */, b){/* body */ return a+b;};",
		"var x=1; //# sourceMappingURL=first.map\n/* ordinary */ var y=2; //# sourceMappingURL=last.map",
		"function f(a,b){var x=a+b; if(x) return x; else return 0;} f(1,2);",
		"var fn=function named(a){'use strict'; return a;}; fn(1);",
		"var fn=function(a){return arguments[0];}; eval('code');",
		"var x=new TypeError('message'); var y=new ns.Type(1, f(2));",
		"function f(x){while(x>0){x--; ++x; x=x-2;} return x;}",
		"function f(x){if(x) throw new TypeError('bad'); return;} var y=f(1);",
		"function f(x){if(x) {if(x>2) return 2;} else if(x<0) return 0; return 1;}",
		"var x=a||b&&c|d^e&f==g<h<<i+j*k;",
		"var x=1e3 + .5 + 2.; var π='é'; π;",
		"var s='😀';\r\nvar t = {\n key : s\n};\u2028t.key;\n",
	}
	for _, mode := range []Config_LanguageMode{Config_LanguageMode_ECMASCRIPT3, Config_LanguageMode_ECMASCRIPT5, Config_LanguageMode_ES_NEXT} {
		for _, strict := range []Config_StrictMode{Config_StrictMode_STRICT, Config_StrictMode_SLOPPY} {
			config := ParserRunner_CreateConfig(mode, nil, strict)
			for _, source := range cases {
				nativeExperimentCompare(t, source, config, true)
			}
		}
	}
}

func TestNativeParserFallsBackBeforePublishing(t *testing.T) {
	config := ParserRunner_CreateConfig(Config_LanguageMode_ES_NEXT, nil, Config_StrictMode_STRICT)
	for _, source := range []string{
		"var x=01;", "var eval=1;", "var arguments=1;", "var x=#private;", "var x=(a?b:c)=d;",
		"/** @closureUnaware */ var x=1;", "'use strict'; var x='\\1'; var y=;",
		"var x='unterminated", "var x=1; function (", "return 1;", "function f(){throw\n1;}",
		"function f(a,a){return a;}", "new Foo++;", "if (x) function f(){}", "a\n++;",
		"var \\u0063lass=1;", "var x=1; /* unterminated", "<!-- html comment\nvar x=1;", "#!/bin/node\nvar x=1;",
		"a??b||c;", "a&&b??c;", "-a**b;", "a+(x)=>x;", "const x;",
		"()\n=>1;", "x\n=>x;", "(x)\n=>x;", "(x,y) /* newline\n*/ => x+y;",
		strings.Repeat("(", 150) + "x" + strings.Repeat(")", 150) + ";",
	} {
		nativeExperimentCompare(t, source, config, false)
		keepGoing := config.ToBuilder().SetRunMode(Config_RunMode_KEEP_GOING).Build()
		nativeExperimentCompare(t, source, keepGoing, false)
	}
	withComments := config.ToBuilder().SetJsDocParsingMode(Config_JsDocParsing_INCLUDE_ALL_COMMENTS).Build()
	nativeExperimentCompare(t, "var x=1;", withComments, false)
}

func TestNativeParserGeneratedExpressions(t *testing.T) {
	rng := rand.New(rand.NewSource(651017))
	var expression func(int) string
	expression = func(depth int) string {
		if depth == 0 {
			return []string{"a", "3", "null", "true", "'😀'"}[rng.Intn(5)]
		}
		switch rng.Intn(8) {
		case 0:
			return "(" + expression(depth-1) + ")"
		case 1:
			return "f(" + expression(depth-1) + ", " + expression(depth-1) + ")"
		case 2:
			return "[" + expression(depth-1) + ", " + expression(depth-1) + "]"
		case 3:
			return "{a:" + expression(depth-1) + ", b:" + expression(depth-1) + "}"
		case 4:
			return "(" + expression(depth-1) + ").member"
		case 5:
			return "!(" + expression(depth-1) + ")"
		case 6:
			return "(" + expression(depth-1) + "?" + expression(depth-1) + ":" + expression(depth-1) + ")"
		default:
			return "(" + expression(depth-1) + []string{"+", "*", "||", "===", "<<"}[rng.Intn(5)] + expression(depth-1) + ")"
		}
	}
	config := ParserRunner_CreateConfig(Config_LanguageMode_ES_NEXT, nil, Config_StrictMode_STRICT)
	for range 200 {
		nativeExperimentCompare(t, "var result="+expression(3)+";", config, true)
	}
}

var nativeExperimentBenchmarkResult *ParserRunner_ParseResult

func BenchmarkNativeParserDataProgram(b *testing.B) {
	var source strings.Builder
	for i := 0; i < 128; i++ {
		fmt.Fprintf(&source, "var entry%d={id:%d, name:'item', enabled:true, values:[1,2,3], computed:base.member+%d*2};\n", i, i, i)
	}
	text := source.String()
	config := ParserRunner_CreateConfig(Config_LanguageMode_ES_NEXT, nil, Config_StrictMode_STRICT)
	file := rhino.NewSimpleSourceFile("bench.js", rhino.StaticSourceFile_SourceKind_STRONG)
	for _, native := range []bool{false, true} {
		b.Run(fmt.Sprintf("native=%v", native), func(b *testing.B) {
			b.ReportAllocs()
			b.SetBytes(int64(len(text)))
			for i := 0; i < b.N; i++ {
				if native {
					result, ok := tryNativeParser(file, text, config)
					if !ok {
						b.Fatal("benchmark left supported grammar")
					}
					nativeExperimentBenchmarkResult = result
				} else {
					nativeExperimentBenchmarkResult = parserRunnerParseUncached(file, text, config, rhino.ErrorReporter_ALWAYS_THROWS_INSTANCE)
				}
			}
		})
	}
}

// Optional real-input oracle gate. The corpus remains outside the source tree;
// accepted files must match every AST/source/feature/diagnostic field, while
// rejected files retain whole-file fallback. This reports coverage, not timing.
func TestNativeParserCoreJSWorkloadCoverage(t *testing.T) {
	root := os.Getenv("NATIVE_PARSER_CORPUS_ROOT")
	if root == "" {
		t.Skip("set NATIVE_PARSER_CORPUS_ROOT to a benchmark workspace")
	}
	config := ParserRunner_CreateConfig(Config_LanguageMode_ES_NEXT, nil, Config_StrictMode_STRICT)
	if _, err := os.Stat(filepath.Join(root, "internals")); err != nil {
		root = filepath.Join(root, "node_modules", "core-js")
	}
	var total, accepted, fullyDirect int
	var totalBytes, acceptedBytes, directBytes int64
	for _, directory := range []string{"internals", "modules"} {
		files, err := filepath.Glob(filepath.Join(root, directory, "*.js"))
		if err != nil {
			t.Fatal(err)
		}
		for _, path := range files {
			data, err := os.ReadFile(path)
			if err != nil {
				t.Fatal(err)
			}
			total++
			totalBytes += int64(len(data))
			file := rhino.NewSimpleSourceFile("native.js", rhino.StaticSourceFile_SourceKind_STRONG)
			var observation nativeParserObservation
			_, ok := tryNativeParserObserved(file, string(data), config, &observation)
			if !ok {
				continue
			}
			accepted++
			acceptedBytes += int64(len(data))
			directBytes += int64(len(data) - observation.FallbackBytes)
			if len(observation.FallbackSpans) == 0 {
				fullyDirect++
			}
			nativeExperimentCompare(t, string(data), config, true)
		}
	}
	if total == 0 {
		t.Fatal("no core-js workload files found")
	}
	t.Logf("native core-js coverage: accepted %d/%d files (%d fully direct); accepted %d/%d source bytes; direct outside fragment fallback %d bytes", accepted, total, fullyDirect, acceptedBytes, totalBytes, directBytes)
}

// ToStringTree covers node/source/feature properties; include complete JSDoc
// payloads and closure shadows too, rather than checking emitted JS alone.
func nativeASTOracle(root *rhino.Node) string {
	var out strings.Builder
	out.WriteString(root.ToStringTree())
	var visit func(*rhino.Node)
	visit = func(node *rhino.Node) {
		if info := node.GetJSDocInfo(); info != nil {
			fmt.Fprintf(&out, "\n@jsdoc %d:%d %s", node.GetLineno(), node.GetCharno(), info.ToStringVerbose())
		}
		if shadow := node.GetClosureUnawareShadow(); shadow != nil {
			out.WriteString("\n@shadow ")
			out.WriteString(nativeASTOracle(shadow))
		}
		for child := node.GetFirstChild(); child != nil; child = child.GetNext() {
			visit(child)
		}
	}
	visit(root)
	return out.String()
}

func TestNativeParserHybridGrammar(t *testing.T) {
	config := ParserRunner_CreateConfig(Config_LanguageMode_ES_NEXT, nil, Config_StrictMode_STRICT)
	for _, source := range []string{
		"var x=1", "{foo:1};", "let x=1; const {a}=b;",
		"goog.module('example'); var x=1; exports=x;",
		"/** @license MIT */ /** @fileoverview Example */ 'use strict'; goog.module('example'); goog.module.declareLegacyNamespace(); exports={x:1};",
		"'custom'; 'use strict'; goog.module('example'); function f(){return 1;} exports=f;",
		"foo(); goog.module('example');", "goog.module(1);", "goog.module('a','b');",
		"var x=[1,,2]; var y=[1,]; var z=[,,]; var o={a:1,}; f(1,);",
		"var o={a, method(x){return x;}, get value(){return 1;}};",
		"var x=0x10 + 1_000 + 1n; var s='a\\n'; var re=/a[b]\\/c/gi;",
		"var x=`template`; var y=(a,b); obj.default;",
		"[a,b]=values; ({a,b}=value); var arr=[{a:1},[b,c]];",
		"var x=tag`template`; var y=obj.tag`a${value}b`; var z=tag`\\unicode`;",
		"var re=/r/; function f(a=1){return a;} class C {m(){return 1;}} var t=`x`; for(var i=0;i<3;i++){f(i);}",
		"/** @unknownTag first */ var re=/* before */ /r/ /** @type {number} */ ; var y=1;",
		"var f=function(/** number */ a=1){/** @license inner */ return a;}; /** @type {number} */ var following=1;",
		"var o={/** @return {number} */ get x(){return 1;}, /** @type {number} */ value:2}; /** @type {number} */ var next=3;",
		"var re=/r/; /* between */ var f=function(a=1){return a;}; //# sourceMappingURL=first.map\nvar o={get x(){return 1;}}; //# sourceMappingURL=last.map",
		"var x=tag`raw ${/** @type {number} */ (value)}`; /** @type {number} */ var next=1;",
		"/** @type {number} */ tag /* between */ `a${1}`; var z=new tag`a`();",
		"function f(){return\n1;} function g(){return /* newline\n*/ 1;}",
		"function f(a=1){return a;} function g(...a){return a;}",
		"async function f(){return 1;} function* g(){yield 1;}",
		"function f(n){for(var i=0;i<n;i++){if(i) continue;} try{return n;}catch(e){throw e;}finally{n++;}}",
		"class C {constructor(x){this.x=x;} value(){return this.x;}} var x=new C(1);",
		"var final=1; var abstract=2; final+=abstract;",
		"var f=x=>x+1; var g=(a,b)=>{return a+b;}; var h=()=>({a:1});",
		"var f=(...args)=>!fn(...args); var g=(a=1)=>a; var h=({a})=>a;",
		"var x=new (test(x)?First:Second)(x,1); var y=new function(){foo();}(); var z=new Type[index()]();",
		"var x=new new Type()(); var y=a*({key:1})+b; var z=a*((...x)=>x);",
		"var f=async x=>{return await x;}; var g=async (x)=>x; var h=async function(){return 1;};",
		"var x=a??b; var y=(a&&b)??c; var z=a??(b||c); a??=b; a||=c;",
		"var x=2**3**4; var y=(-a)**b; var z=++a**b; var k=2**-a;",
		"/** @type {number} */ a.b(c); /** @type {number} */ (a+b).c;",
		"/** @type {number} */ ((a)); /** @type {number} */ {var x=1;} /** note */ ;",
	} {
		nativeExperimentCompare(t, source, config, true)
	}
}

// Non-timed coverage inventory on actual bundle files. Accepted does not imply
// wholly native: explicit disjoint original-grammar ranges quantify the work
// still delegated. Rejected files contribute zero optimized source bytes.
func TestNativeParserBundleCoverage(t *testing.T) {
	root := os.Getenv("NATIVE_PARSER_BUNDLE_ROOT")
	if root == "" {
		t.Skip("set NATIVE_PARSER_BUNDLE_ROOT to downloaded benchmark inputs")
	}
	config := ParserRunner_CreateConfig(Config_LanguageMode_ES_NEXT, nil, Config_StrictMode_STRICT)
	for _, name := range []string{"three@0.159.0/build/three.js", "lodash@4.17.21/lodash.js", "react-dom@18.3.1/umd/react-dom.development.js", "typescript@5.6.3/lib/typescript.js"} {
		t.Run(name, func(t *testing.T) {
			data, err := os.ReadFile(filepath.Join(root, name))
			if err != nil {
				t.Fatal(err)
			}
			file := rhino.NewSimpleSourceFile("native.js", rhino.StaticSourceFile_SourceKind_STRONG)
			var observation nativeParserObservation
			_, accepted := tryNativeParserObserved(file, string(data), config, &observation)
			directBytes := 0
			if accepted {
				directBytes = len(data) - observation.FallbackBytes
			}
			reasons := map[string]int{}
			lastEnd := 0
			for _, span := range observation.FallbackSpans {
				if span.StartUTF16 < lastEnd || span.EndUTF16 < span.StartUTF16 {
					t.Fatalf("overlapping fragment ranges: %+v", span)
				}
				lastEnd = span.EndUTF16
				reasons[span.Reason] += span.Bytes
			}
			t.Logf("accepted=%v source_bytes=%d direct_bytes=%d fragment_bytes=%d fragment_count=%d reject=%s UTF16=%d fragments_by_bytes=%v", accepted, len(data), directBytes, observation.FallbackBytes, len(observation.FallbackSpans), observation.Reason, observation.OffsetUTF16, reasons)
			if accepted {
				nativeExperimentCompare(t, string(data), config, true)
			}
		})
	}
}

func TestNativeParserAnnotationReporterException(t *testing.T) {
	config := ParserRunner_CreateConfig(Config_LanguageMode_ES_NEXT, nil, Config_StrictMode_STRICT)
	file := rhino.NewSimpleSourceFile("native.js", rhino.StaticSourceFile_SourceKind_STRONG)
	source := "/** @unknownTag warning */ var x=1;"
	var original, experiment jutil.Throwable
	jutil.Try(func() { parserRunnerParseUncached(file, source, config, rhino.ErrorReporter_ALWAYS_THROWS_INSTANCE) }, func(err jutil.Throwable) { original = err })
	jutil.Try(func() {
		parserRunnerParseWithNativeFallback(file, source, config, rhino.ErrorReporter_ALWAYS_THROWS_INSTANCE)
	}, func(err jutil.Throwable) { experiment = err })
	if original == nil || experiment == nil {
		t.Fatal("fixture did not exercise throwing warning reporter")
	}
	for original != nil || experiment != nil {
		if original == nil || experiment == nil || original.Error() != experiment.Error() {
			t.Fatalf("warning exception changed: got %v, want %v", experiment, original)
		}
		original, experiment = original.GetCause(), experiment.GetCause()
	}
}

// Acceptance is deliberately unconstrained here: every speculative acceptance
// must preserve original diagnostics/recovery, and every rejection must delegate
// privately. Context crosses native function/block and original-fragment edges.
func TestNativeParserContextAndInvalidSyntaxOracle(t *testing.T) {
	cases := []string{
		"return 1;", "while(x){return 1;}", "for(;;){return 1;}",
		"function f(){for(;;){return 1;}}", "function f(){try{return 1;}finally{cleanup();}}",
		"break;", "continue;", "while(x){break;continue;}", "function f(){while(x){continue;}}",
		"outer: while(x){break outer;}", "outer: {continue outer;}", "label: label: while(x){break label;}",
		"function f(){outer: while(x){function g(){break outer;}}}",
		"function f(a,a){return a;}", "function f(a,a){'use strict';return a;}",
		"function f(a=1,a=2){return a;}", "var f=(a,a)=>a;", "function f(...a,b){}",
		"'use strict'; var eval=1;", "function f(){'use strict'; var arguments=1;}",
		"function f(){'use strict'; with(x){y;}}", "function f(a=1){'use strict';return a;}",
		"function f(){'use strict'; delete x;}", "'use strict'; var x=010;", "var x='\\1';",
		"var final=1; final;", "var abstract=1; abstract;",
		"var x=/[/;", "var x=/a/gg;", "var x=/a/z;", "var x=/a\\/b/giu;",
		"var x=`unterminated;", "var x=`a${}`;", "var x=`\\unicode`;", "var x=tag`\\unicode`;",
		"var x=tag`a${function(){return 1;}}`;", "var x=tag`a${x}b${y}c`;",
		"var x=tag`a${/[/}b`;", "var x=tag`a${1;2}b`;",
		"a+(x)=>x;", "a+((...x)=>x);", "var f=(a=1,...b)=>b;", "var f=({a},[b])=>a+b;",
		"()\n=>1;", "x\n=>x;", "(x)\n=>x;", "(x,y) /* newline\n*/ => x+y;",
		"(x,\ny)=>x+y;", "async x\n=>x;", "async (x)\n=>x;",
		"var x=new (factory())();", "var x=new factory()();", "new Foo++;", "++foo();", "foo()++;",
		"var x={get a(x){return x;}};", "var x={set a(){}};", "var x={a=1};",
		"if(x) function f(){}", "if(x) class C{}", "let x; const y;", "var x=;",
		"/** @unknownTag one */ var x=; /** @unknownTag two */", "var x=1; /* unfinished",
		"/** @unknownTag first */ function f(a=1){ <!-- html\nreturn a;}",
		"/** @unknownTag first */ function f(a=1){return a;} /* unterminated",
		"function f(){throw\n1;}", "function f(){return\n/regexp/;}",
	}
	file := rhino.NewSimpleSourceFile("native.js", rhino.StaticSourceFile_SourceKind_STRONG)
	for _, language := range []Config_LanguageMode{Config_LanguageMode_ECMASCRIPT3, Config_LanguageMode_ECMASCRIPT5, Config_LanguageMode_ES_NEXT} {
		for _, strict := range []Config_StrictMode{Config_StrictMode_STRICT, Config_StrictMode_SLOPPY} {
			for _, run := range []Config_RunMode{Config_RunMode_STOP_AFTER_ERROR, Config_RunMode_KEEP_GOING} {
				config := ParserRunner_CreateConfig(language, nil, strict).ToBuilder().SetRunMode(run).Build()
				for i, source := range cases {
					t.Run(fmt.Sprintf("%s/%s/%s/%d", language, strict, run, i), func(t *testing.T) {
						_, accepted := tryNativeParser(file, source, config)
						nativeExperimentCompare(t, source, config, accepted)
					})
				}
			}
		}
	}
}

// Shared immutable input/configuration may be parsed concurrently. In particular
// a rejected speculative graph or buffered warning must not leak into another
// owner's accepted AST or diagnostics.
func TestNativeParserIndependentConcurrentAttempts(t *testing.T) {
	config := ParserRunner_CreateConfig(Config_LanguageMode_ES_NEXT, nil, Config_StrictMode_STRICT).
		ToBuilder().SetRunMode(Config_RunMode_KEEP_GOING).Build()
	file := rhino.NewSimpleSourceFile("native.js", rhino.StaticSourceFile_SourceKind_STRONG)
	sources := []string{
		"/** @license MIT */ function f(a){while(a){try{return /a/.test(a);}finally{a--;}}} f('a');",
		"/** @unknownTag one */ var x=tag`a${1}`; [a,b]=values;",
		strings.Repeat("var x={a:1,b:[2,3]};", 50) + " var invalid=;",
		"/** @unknownTag one */ function f(a,a){return a;} var invalid=;",
	}
	type snapshot struct {
		ast, features string
		diagnostics   []string
	}
	parse := func(source string, native bool) snapshot {
		reporter := &nativeExperimentReporter{}
		var result *ParserRunner_ParseResult
		if native {
			result = parserRunnerParseWithNativeFallback(file, source, config, reporter)
		} else {
			result = parserRunnerParseUncached(file, source, config, reporter)
		}
		out := snapshot{diagnostics: reporter.diagnostics}
		if result != nil {
			if result.Ast != nil {
				out.ast = nativeASTOracle(result.Ast)
			}
			out.features = result.Features.String()
		}
		return out
	}
	want := make([]snapshot, len(sources))
	for i, source := range sources {
		want[i] = parse(source, false)
	}
	var wait sync.WaitGroup
	errors := make(chan int, 4)
	for range 4 {
		wait.Add(1)
		go func() {
			defer wait.Done()
			for repeat := 0; repeat < 8; repeat++ {
				for i, source := range sources {
					if got := parse(source, true); !reflect.DeepEqual(got, want[i]) {
						errors <- i
						return
					}
				}
			}
		}()
	}
	wait.Wait()
	close(errors)
	for i := range errors {
		t.Errorf("concurrent native/fallback result changed for source %d", i)
	}
}

// This is the checks-only task's real Closure Library input selection. All
// accepted files receive full AST/JSDoc/diagnostic comparison; rejected files
// must preserve original fallback and contribute no optimized bytes.
func TestNativeParserClosureWorkloadCoverage(t *testing.T) {
	root := os.Getenv("NATIVE_PARSER_CLOSURE_ROOT")
	if root == "" {
		t.Skip("set NATIVE_PARSER_CLOSURE_ROOT to downloaded Closure Library")
	}
	config := ParserRunner_CreateConfig(Config_LanguageMode_ES_NEXT, nil, Config_StrictMode_STRICT)
	file := rhino.NewSimpleSourceFile("native.js", rhino.StaticSourceFile_SourceKind_STRONG)
	var total, accepted, modules int
	var totalBytes, acceptedBytes, directBytes int64
	rejections := make(map[string]int)
	for _, directory := range []string{"closure/goog", "third_party/closure/goog"} {
		err := filepath.WalkDir(filepath.Join(root, directory), func(path string, entry os.DirEntry, err error) error {
			if err != nil {
				return err
			}
			if entry.IsDir() || !strings.HasSuffix(path, ".js") || strings.HasSuffix(path, "_test.js") {
				return nil
			}
			data, err := os.ReadFile(path)
			if err != nil {
				return err
			}
			total++
			totalBytes += int64(len(data))
			var observation nativeParserObservation
			result, ok := tryNativeParserObserved(file, string(data), config, &observation)
			if ok {
				accepted++
				acceptedBytes += int64(len(data))
				directBytes += int64(len(data) - observation.FallbackBytes)
				if result.Ast.GetBooleanProp(rhino.Node_GOOG_MODULE) {
					modules++
				}
			} else {
				rejections[observation.Reason]++
			}
			t.Run(strings.TrimPrefix(path, root+string(os.PathSeparator)), func(t *testing.T) {
				nativeExperimentCompare(t, string(data), config, ok)
			})
			return nil
		})
		if err != nil {
			t.Fatal(err)
		}
	}
	if total == 0 {
		t.Fatal("no Closure workload files found")
	}
	t.Logf("native Closure coverage: accepted %d/%d files (%d modules); accepted %d/%d bytes; direct outside fragments %d bytes; rejection reasons %v", accepted, total, modules, acceptedBytes, totalBytes, directBytes, rejections)
}

// Native name validation uses the scanner keyword table once. This subset
// invariant prevents later reserved-word additions from silently weakening it.
func TestNativeReservedKeywordsAreScannerKeywords(t *testing.T) {
	for keyword := range IRFactory_ES5_STRICT_RESERVED_KEYWORDS.All() {
		if !parser.Keywords_IsKeyword(keyword) {
			t.Errorf("reserved native name %q is absent from scanner keywords", keyword)
		}
	}
}

// Appended only by the diagnostic overlay to native_parser_experiment_test.go.
func TestStringPoolDiagnosticParserRoutesAndExactOracle(t *testing.T) {
	previous := nativeParserOwnedAllocatorEnabled
	defer func() { nativeParserOwnedAllocatorEnabled = previous }()
	config := ParserRunner_CreateConfig(Config_LanguageMode_ES_NEXT, nil, Config_StrictMode_STRICT)
	for _, active := range []bool{false, true} {
		nativeParserOwnedAllocatorEnabled = active
		nativeExperimentCompare(t, `var parserDiagnosticValue=1;function add(a){return a+parserDiagnosticValue;}add(parserDiagnosticValue);`, config, true)
		nativeExperimentCompare(t, `var eval;`, config, false)
	}
	path := filepath.Join(t.TempDir(), "string-pool-counts.json")
	t.Setenv("JSGO_STRING_POOL_DIAGNOSTIC_PATH", path)
	rhino.DiagnosticStringPoolDump()
	data, err := os.ReadFile(path)
	if err != nil {
		t.Fatal(err)
	}
	var report struct {
		GlobalPoolCalls, ObservedNativeNewStringCalls uint64
		Files                                         []struct {
			Accepted, AllocatorActive bool
			NewStringCalls            uint64
			Policies                  []struct{ Calls, Hits, Misses, ExcludedLong uint64 }
		}
	}
	if err := json.Unmarshal(data, &report); err != nil {
		t.Fatal(err)
	}
	accepted, rejected, inactive := false, false, false
	for _, row := range report.Files {
		if row.AllocatorActive {
			accepted = accepted || row.Accepted && row.NewStringCalls > 0
			rejected = rejected || !row.Accepted
		} else {
			inactive = true
			if row.NewStringCalls != 0 {
				t.Fatal("inactive allocator reported native calls")
			}
		}
		for _, policy := range row.Policies {
			if policy.Calls != row.NewStringCalls || policy.Hits+policy.Misses+policy.ExcludedLong != row.NewStringCalls {
				t.Fatal("per-policy accounting missed a native call", row)
			}
		}
	}
	if !accepted || !rejected || !inactive || report.ObservedNativeNewStringCalls == 0 || report.GlobalPoolCalls < report.ObservedNativeNewStringCalls {
		t.Fatalf("diagnostic missed accepted/rejected/inactive routes or global calls: %+v", report)
	}
}
