package rhino

import (
	"math/big"
	"reflect"
	"runtime"
	"sync"
	"testing"
	"weak"

	"github.com/paullepoulpe/jsgo/internal/colors"
)

func TestNodeAllocatorCloneMatchesOriginal(t *testing.T) {
	cooked := "cooked"
	pool := NewRhinoStringPool_LazyInternedStringList([]string{"lazy"})
	for _, source := range []*Node{
		NewNode(Token_SCRIPT), Node_NewStringWithToken(Token_NAME, "name"),
		Node_NewStringFromStringPool(Token_NAME, pool, 0),
		Node_NewNumber(0.25), Node_NewBigInt(big.NewInt(12345)),
		Node_NewTemplateLitString(&cooked, "raw"), Node_NewTemplateLitString(nil, "bad\\x"),
	} {
		source.SetLinenoCharno(3, 7)
		source.SetLength(12)
		source.SetColor(colors.StandardColors_NUMBER)
		source.SetSourceFileForTesting("allocator.js")
		name := "original"
		source.SetOriginalName(&name)
		source.AddChildToBack(NewNode(Token_EMPTY))
		var allocator NodeAllocator
		got, want := allocator.CloneNode(source), source.CloneNode()
		if !reflect.DeepEqual(got, want) || got == source || got.HasChildren() || got.GetParent() != nil {
			t.Fatalf("owned clone differs for %v: %s, want %s", source.GetToken(), got, want)
		}
		if got.propListHead != want.propListHead {
			t.Fatal("clone stopped sharing immutable properties")
		}
	}
}

func discardedOwnedGraph() weak.Pointer[Node] {
	var allocator NodeAllocator
	root := allocator.NewNode(Token_SCRIPT)
	for range 1000 {
		child := allocator.NewString(Token_NAME, "discarded")
		root.AddChildToBack(child)
	}
	return weak.Make(root)
}

func TestNodeAllocatorDiscardDoesNotShareGlobalOrOtherOwner(t *testing.T) {
	before := NewNode(Token_EMPTY)
	discarded := discardedOwnedGraph()
	var survivorAllocator NodeAllocator
	survivor := survivorAllocator.NewNode(Token_SCRIPT)
	survivor.AddChildToBack(survivorAllocator.NewNumber(1))
	after := NewNode(Token_EMPTY)
	for attempt := 0; attempt < 10; attempt++ {
		runtime.GC()
		if discarded.Value() == nil {
			runtime.KeepAlive(before)
			runtime.KeepAlive(after)
			runtime.KeepAlive(survivor)
			return
		}
	}
	t.Fatal("a surviving independent allocation retained a discarded graph")
}

func TestNodeAllocatorIndependentConcurrentOwners(t *testing.T) {
	const workers, count = 4, 1000
	groups := make([][]*Node, workers)
	var wait sync.WaitGroup
	for worker := range groups {
		wait.Add(1)
		go func(worker int) {
			defer wait.Done()
			var allocator NodeAllocator
			for range count {
				groups[worker] = append(groups[worker], allocator.NewNumber(float64(worker)))
			}
		}(worker)
	}
	wait.Wait()
	seen := make(map[*Node]bool, workers*count)
	for worker, group := range groups {
		for _, node := range group {
			if seen[node] || !node.IsNumber() || node.GetDouble() != float64(worker) {
				t.Fatal("independent allocation streams shared or corrupted nodes")
			}
			seen[node] = true
		}
	}
}

// Appended only by the diagnostic overlay to node_allocator_test.go.
func TestStringPoolDiagnosticMRULocalityAndLongExclusion(t *testing.T) {
	d := NewStringPoolParseDiagnostic(100)
	a := NodeAllocator{StringPoolDiagnostic: d}
	for _, value := range []string{"a", "b", "a", "c", "a", "d", "b", string(make([]byte, 65))} {
		a.NewString(Token_NAME, value)
	}
	for i, hits := range [3]uint64{2, 3, 3} {
		stats := d.policies[i].stats
		if stats.Calls != 8 || stats.Hits != hits || stats.Misses != 7-hits || stats.ExcludedLong != 1 || stats.HighWaterEntries > stats.Capacity {
			t.Fatalf("incorrect MRU accounting: %+v", stats)
		}
	}
	d.Finish(false, "fixture", 10)
	for _, policy := range d.policies {
		for _, cell := range policy.cells {
			if cell != nil {
				t.Fatal("completed diagnostic retained canonical cells")
			}
		}
	}
}

func TestStringPoolDiagnosticCanonicalCellsAndReset(t *testing.T) {
	d := NewStringPoolParseDiagnostic(100)
	a := NodeAllocator{StringPoolDiagnostic: d}
	padding := string(make([]byte, 1024))
	backing := padding + "front-cache-canonical" + padding
	value := backing[len(padding) : len(padding)+len("front-cache-canonical")]
	first := a.NewString(Token_NAME, value)
	second := (&NodeAllocator{}).NewString(Token_NAME, string(append([]byte(nil), value...)))
	if first.str != second.str || d.policies[0].cells[0] != first.str {
		t.Fatal("diagnostic did not retain the exact original global cell")
	}
	old := first.str
	first.SetString("replacement")
	if *old != value || d.policies[0].cells[0] != old || second.GetString() != value {
		t.Fatal("SetString changed an existing shared canonical cell")
	}
	// A legal global-generation change must not invalidate a value hit. Keep
	// every real lookup: the second node still receives the new global cell.
	rhinoStringPool_mu.Lock()
	clear(rhinoStringPool_strings)
	rhinoStringPool_mu.Unlock()
	afterReset := a.NewString(Token_NAME, value)
	if afterReset.str == old || afterReset.GetString() != value || d.policies[0].cells[0] != old || d.policies[0].stats.Hits != 1 {
		t.Fatal("simulated hit across a global reset changed real interning")
	}
	for _, value := range []string{"", "π", "\xed\xa0\x80"} {
		if got := a.NewString(Token_NAME, value).GetString(); got != value {
			t.Fatal("empty/Unicode/WTF-8 spelling changed")
		}
	}
	d.Finish(true, "", -1)
}

func TestStringPoolDiagnosticExactEvictionBounds(t *testing.T) {
	for _, capacity := range []int{2, 4, 64} {
		cache := stringPoolCacheDiagnostic{stats: stringPoolCacheDiagnosticStats{Capacity: capacity}}
		for i := 0; i <= capacity; i++ {
			cache.observe(rhinoStringPoolCell(string(rune(0x100 + i))))
		}
		cache.observe(rhinoStringPoolCell(string(rune(0x100))))
		if cache.stats.Hits != 0 || cache.stats.Misses != uint64(capacity+2) || cache.used != capacity || cache.stats.HighWaterEntries != capacity {
			t.Fatalf("eviction/bound differs for %d: %+v", capacity, cache.stats)
		}
		for _, cell := range cache.cells[capacity:] {
			if cell != nil {
				t.Fatal("cache stored beyond fixed capacity")
			}
		}
	}
}

func TestStringPoolDiagnosticIndependentConcurrentOwners(t *testing.T) {
	results := make(chan bool, 16)
	for range 16 {
		go func() {
			d := NewStringPoolParseDiagnostic(100)
			a := NodeAllocator{StringPoolDiagnostic: d}
			valid := true
			for _, value := range []string{"same", "value", "same", "", "π", "\xed\xa0\x80"} {
				valid = a.NewString(Token_NAME, value).GetString() == value && valid
			}
			valid = d.row.NewStringCalls == 6 && d.policies[2].stats.Hits == 1 && valid
			d.Finish(true, "", -1)
			results <- valid
		}()
	}
	for range 16 {
		if !<-results {
			t.Fatal("concurrent owner values/counters changed")
		}
	}
}
