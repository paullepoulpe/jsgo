// Port of com/google/javascript/rhino/RhinoStringPool.java @ closure-compiler v20261015

/*
 *
 * ***** BEGIN LICENSE BLOCK *****
 * Version: MPL 1.1
 *
 * The contents of this file are subject to the Mozilla Public License Version
 * 1.1 (the "License"); you may not use this file except in compliance with
 * the License. You may obtain a copy of the License at
 * http://www.mozilla.org/MPL/
 *
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License
 * for the specific language governing rights and limitations under the
 * License.
 *
 * The Original Code is Rhino code, released
 * May 6, 1999.
 *
 * The Initial Developer of the Original Code is
 * Netscape Communications Corporation.
 * Portions created by the Initial Developer are Copyright (C) 1997-1999
 * the Initial Developer. All Rights Reserved.
 *
 * Contributor(s):
 *   Google Inc.
 *
 * This Go translation is distributed under the MPL 1.1 only, as the
 * original's dual licence allows; the other licence it offers is not
 * used.
 *
 * ***** END LICENSE BLOCK ***** */

package rhino

import (
	"encoding/json"
	"iter"
	"os"
	"sort"
	"strings"
	"sync"
	"sync/atomic"

	"github.com/paullepoulpe/jsgo/internal/base"
	"github.com/paullepoulpe/jsgo/internal/jutil"
)

// RhinoStringPool is an interning pool for strings used by the Rhino
// package.
//
// As of 2021-03-16 and again as of 2024-12-09, this custom pool is
// measurably more performant than `String::intern`.
type RhinoStringPool struct{}

// The threadsafe datastructure that backs this pool.
//
// We use weak-refs, rather than strong-refs, to prevent a memory leak in
// server-like applications.
//
// Go-only: performance — Guava's Interners.newWeakInterner() was Go's unique
// package (canonical, weakly held values), but unique.Make and the cleanup
// that walks its whole map after every GC cost ~14% of the front end's CPU.
// The pool is now a strong map behind a mutex (the parse oracles parse on
// several goroutines). Identity is never observable in the port: strings
// compare by value (RhinoStringPool_UncheckedEquals), so the pool only
// shares memory, as Java's does. The map holds the strings of the current
// compilation, which its AST keeps alive anyway; to stay bounded in a
// long-lived process (tests, benchmarks) it starts over once it holds
// rhinoStringPool_MAX_SIZE strings, which only ends the sharing with the
// strings interned before.
var (
	rhinoStringPool_mu      sync.Mutex
	rhinoStringPool_strings = make(map[string]*string)
)

const rhinoStringPool_MAX_SIZE = 1 << 20

// RhinoStringPool_UncheckedEquals checks if two strings are the same
// according to interning.
//
// The caller is responsible for ensuring that strings passed to this method
// are actually interned. This method mainly exists to highlight where
// equality checks depend on interning for correctness.
//
// Ideally we could use something like a branded-type, for interned strings,
// to verify correct usage. However, Java doesn't support type-brands, and
// using like wrapper objects would undermine performance. This also needs to
// be ergonomic enough that callers don't resort to using `==` directly.
//
// Go-only: language-adapter — Java compares the references; Go compares the
// string values, which is the same for interned strings.
//
// Java: RhinoStringPool.uncheckedEquals(String, String)
func RhinoStringPool_UncheckedEquals(a string, b string) bool {
	return base.JSCompObjects_Identical(a, b)
}

// RhinoStringPool_UncheckedEqualsNullable is uncheckedEquals for Java
// Strings that may be null (*string in the port): null is identical only to
// null.
//
// Go-only: language-adapter — nullable String overload of
// RhinoStringPool.uncheckedEquals(String, String).
func RhinoStringPool_UncheckedEqualsNullable(a *string, b *string) bool {
	if a == nil || b == nil {
		return a == nil && b == nil
	}
	return RhinoStringPool_UncheckedEquals(*a, *b)
}

// Java: RhinoStringPool.addOrGet(String)
func RhinoStringPool_AddOrGet(s string) string { return *rhinoStringPoolCell(s) }

// Go-only: performance — immutable header shared by StringNodes.
func rhinoStringPoolCell(s string) *string {
	stringPoolDiagnostic.poolCalls.Add(1)
	rhinoStringPool_mu.Lock()
	interned, ok := rhinoStringPool_strings[s]
	if !ok {
		stringPoolDiagnostic.poolMisses.Add(1)
		if len(rhinoStringPool_strings) >= rhinoStringPool_MAX_SIZE {
			stringPoolDiagnostic.poolResets.Add(1)
			clear(rhinoStringPool_strings)
		}
		// Like unique.Make, keep a copy rather than the larger string s may
		// be a slice of.
		value := strings.Clone(s)
		interned = &value
		rhinoStringPool_strings[value] = interned
	}
	rhinoStringPool_mu.Unlock()
	return interned
}

// Java: RhinoStringPool()
func NewRhinoStringPool() *RhinoStringPool { return &RhinoStringPool{} }

// RhinoStringPool_LazyInternedStringList is a list of strings that is lazily
// interned into a RhinoStringPool as they are accessed.
//
// The only reason to use this class is for performance optimizations - the
// LazyInternedStringList#newStringNode method skips re-interning the string.
// This is a performance win if creating a lot of string nodes with the same
// string.
type RhinoStringPool_LazyInternedStringList struct {
	pool *jutil.ArrayList[string]

	isInterned *RhinoStringPool_WriteOnlyBitset
}

// Java: RhinoStringPool.LazyInternedStringList(List<String>)
func NewRhinoStringPool_LazyInternedStringList(pool []string) *RhinoStringPool_LazyInternedStringList {
	return &RhinoStringPool_LazyInternedStringList{
		pool:       jutil.NewArrayListFrom(pool),
		isInterned: NewRhinoStringPool_WriteOnlyBitset(len(pool)),
	}
}

// Get returns the interned string at offset.
//
// if Java supported type-brands we would want to use one here to indicate
// that the returned string is always interned but that's not possible
// without an expensive wrapper type - see also the comment on
// uncheckedEquals().
//
// Java: RhinoStringPool.LazyInternedStringList.get(int)
func (l *RhinoStringPool_LazyInternedStringList) Get(offset int) string {
	if !l.isInterned.Get(offset) {
		uninterned := l.pool.Get(offset)
		interned := RhinoStringPool_AddOrGet(uninterned)
		l.pool.Set(offset, interned)
		l.isInterned.Set(offset) // must happen after this.pool.set() to avoid a race condition
		return interned
	}
	return l.pool.Get(offset)
}

// Java: RhinoStringPool.LazyInternedStringList.stream()
func (l *RhinoStringPool_LazyInternedStringList) Stream() iter.Seq[string] {
	return l.pool.All()
}

// RhinoStringPool_WriteOnlyBitset is a bitset implementation that only
// supports setting bits from false => true, not vice versa, and is not
// resizable once created.
//
// This class was originally copied from the JDK BitSet implementation, but
// has been heavily modified to be thread-safe and remove unnecessary
// functionality.
//
// Go-only: language-adapter — the AtomicIntegerArray is a plain []int32
// (the port is single-threaded; see PORTING.md §5); out-of-range accesses
// throw ArrayIndexOutOfBoundsException like the JDK's.
type RhinoStringPool_WriteOnlyBitset struct {
	bits []int32
}

// BitSets are packed into arrays of "words." Currently a word is an int,
// which consists of 32 bits, requiring 5 address bits. The choice of word
// size comes from the convenience of using AtomicIntegerArray.
const RhinoStringPool_WriteOnlyBitset_ADDRESS_BITS_PER_WORD = 5

// Java: RhinoStringPool.WriteOnlyBitset(int)
func NewRhinoStringPool_WriteOnlyBitset(size int) *RhinoStringPool_WriteOnlyBitset {
	n := RhinoStringPool_WriteOnlyBitset_WordIndex(size-1) + 1
	if n < 0 {
		panic(jutil.NewRuntimeException("java.lang.NegativeArraySizeException: " + jutil.ToJavaString(n)))
	}
	return &RhinoStringPool_WriteOnlyBitset{bits: make([]int32, n)}
}

func (b *RhinoStringPool_WriteOnlyBitset) checkIndex(wordIndex int) {
	if wordIndex < 0 || wordIndex >= len(b.bits) {
		panic(jutil.NewArrayIndexOutOfBoundsExceptionForLength(wordIndex, len(b.bits)))
	}
}

// Java: RhinoStringPool.WriteOnlyBitset.set(int)
func (b *RhinoStringPool_WriteOnlyBitset) Set(offset int) {
	wordIndex := RhinoStringPool_WriteOnlyBitset_WordIndex(offset)
	b.checkIndex(wordIndex)
	b.bits[wordIndex] = b.bits[wordIndex] | jutil.Shl32(1, int64(offset))
}

// Java: RhinoStringPool.WriteOnlyBitset.get(int)
func (b *RhinoStringPool_WriteOnlyBitset) Get(offset int) bool {
	wordIndex := RhinoStringPool_WriteOnlyBitset_WordIndex(offset)
	b.checkIndex(wordIndex)
	return (b.bits[wordIndex] & jutil.Shl32(1, int64(offset))) != 0
}

// RhinoStringPool_WriteOnlyBitset_WordIndex returns, given a bit index, the
// word index containing it.
//
// Java: RhinoStringPool.WriteOnlyBitset.wordIndex(int)
func RhinoStringPool_WriteOnlyBitset_WordIndex(bitIndex int) int {
	return int(int32(bitIndex) >> RhinoStringPool_WriteOnlyBitset_ADDRESS_BITS_PER_WORD)
}

// Diagnostic overlay only. This code is appended to rhino_string_pool.go;
// ordinary source, global-pool semantics and compiler admission are unchanged.
var stringPoolDiagnostic struct {
	poolCalls, poolMisses, poolResets atomic.Uint64
	mu                                sync.Mutex
	rows                              []stringPoolParseDiagnosticRow
	once                              sync.Once
}

type stringPoolCacheDiagnosticStats struct {
	Capacity                                  int
	Calls, Hits, Misses, ExcludedLong         uint64
	HighWaterEntries, HighWaterCanonicalBytes int
}

// A simulated cache contains exact cells already returned by the unchanged
// global pool. No scanner/source string header, node, token or scope is retained.
type stringPoolCacheDiagnostic struct {
	stats                stringPoolCacheDiagnosticStats
	cells                [64]*string
	used, canonicalBytes int
}

func (c *stringPoolCacheDiagnostic) observe(cell *string) {
	c.stats.Calls++
	if len(*cell) > 64 {
		c.stats.ExcludedLong++
		return
	}
	at := 0
	for at < c.used && *c.cells[at] != *cell {
		at++
	}
	if at < c.used {
		c.stats.Hits++
		// On a hit, keep the old generation's cell, as the proposed MRU
		// would. A global reset does not invalidate immutable equal values.
		old := c.cells[at]
		copy(c.cells[1:at+1], c.cells[:at])
		c.cells[0] = old
		return
	}
	c.stats.Misses++
	if c.used == c.stats.Capacity {
		c.canonicalBytes -= len(*c.cells[c.used-1])
	} else {
		c.used++
	}
	copy(c.cells[1:c.used], c.cells[:c.used-1])
	c.cells[0] = cell
	c.canonicalBytes += len(*cell)
	if c.used > c.stats.HighWaterEntries {
		c.stats.HighWaterEntries = c.used
	}
	if c.canonicalBytes > c.stats.HighWaterCanonicalBytes {
		c.stats.HighWaterCanonicalBytes = c.canonicalBytes
	}
}

type stringPoolParseDiagnosticRow struct {
	SourceName                 string
	SourceBytes                int
	Accepted, AllocatorActive  bool
	Reason                     string
	OffsetUTF16                int
	NewStringCalls, EmptyCalls uint64
	MaxSpellingBytes           int
	Policies                   [3]stringPoolCacheDiagnosticStats
}

// StringPoolParseDiagnostic exists only in generated diagnostic source.
// Its owner is one speculative parse. Nodes/returned rows never retain it.
type StringPoolParseDiagnostic struct {
	row      stringPoolParseDiagnosticRow
	policies [3]stringPoolCacheDiagnostic
}

func NewStringPoolParseDiagnostic(sourceBytes int) *StringPoolParseDiagnostic {
	d := &StringPoolParseDiagnostic{row: stringPoolParseDiagnosticRow{SourceBytes: sourceBytes, OffsetUTF16: -1}}
	for i, capacity := range [3]int{2, 4, 64} {
		d.policies[i].stats.Capacity = capacity
	}
	return d
}

func (d *StringPoolParseDiagnostic) SetSourceName(name string) {
	d.row.SourceName = strings.Clone(name)
}
func (d *StringPoolParseDiagnostic) ActivateAllocator() { d.row.AllocatorActive = true }

func (d *StringPoolParseDiagnostic) observe(cell *string) {
	d.row.NewStringCalls++
	if len(*cell) == 0 {
		d.row.EmptyCalls++
	}
	if len(*cell) > d.row.MaxSpellingBytes {
		d.row.MaxSpellingBytes = len(*cell)
	}
	for i := range d.policies {
		d.policies[i].observe(cell)
	}
}

func (d *StringPoolParseDiagnostic) Finish(accepted bool, reason string, offsetUTF16 int) {
	d.row.Accepted, d.row.Reason, d.row.OffsetUTF16 = accepted, reason, offsetUTF16
	for i := range d.policies {
		d.row.Policies[i] = d.policies[i].stats
		// Aggregate only numeric summaries. Do not extend cell lifetimes past
		// the attempt even if its factory/allocator is retained unexpectedly.
		clear(d.policies[i].cells[:])
	}
	stringPoolDiagnostic.mu.Lock()
	stringPoolDiagnostic.rows = append(stringPoolDiagnostic.rows, d.row)
	stringPoolDiagnostic.mu.Unlock()
}

type stringPoolGroupDiagnostic struct {
	Attempts, SourceBytes                  int
	NewStringCalls                         uint64
	PolicyHits, PolicyMisses, ExcludedLong [3]uint64
	MaxCacheEntries, MaxCanonicalBytes     [3]int
}

// DiagnosticStringPoolDump never runs in an ordinary production binary.
// Call counts and hypothetical lookup savings are not CPU time or mallocs.
func DiagnosticStringPoolDump() {
	path := os.Getenv("JSGO_STRING_POOL_DIAGNOSTIC_PATH")
	if path == "" {
		return
	}
	stringPoolDiagnostic.once.Do(func() {
		stringPoolDiagnostic.mu.Lock()
		rows := append([]stringPoolParseDiagnosticRow(nil), stringPoolDiagnostic.rows...)
		stringPoolDiagnostic.mu.Unlock()
		sort.SliceStable(rows, func(i, j int) bool {
			a, b := rows[i], rows[j]
			if a.SourceName != b.SourceName {
				return a.SourceName < b.SourceName
			}
			if a.SourceBytes != b.SourceBytes {
				return a.SourceBytes < b.SourceBytes
			}
			if a.Accepted != b.Accepted {
				return !a.Accepted
			}
			return a.Reason < b.Reason
		})
		groups := make(map[string]*stringPoolGroupDiagnostic)
		var nativeCalls uint64
		for _, row := range rows {
			key := "accepted-allocator"
			if !row.AllocatorActive {
				key = "no-allocator"
			} else if !row.Accepted {
				key = "rejected-allocator"
			}
			group := groups[key]
			if group == nil {
				group = &stringPoolGroupDiagnostic{}
				groups[key] = group
			}
			group.Attempts++
			group.SourceBytes += row.SourceBytes
			group.NewStringCalls += row.NewStringCalls
			nativeCalls += row.NewStringCalls
			for i, policy := range row.Policies {
				group.PolicyHits[i] += policy.Hits
				group.PolicyMisses[i] += policy.Misses
				group.ExcludedLong[i] += policy.ExcludedLong
				if policy.HighWaterEntries > group.MaxCacheEntries[i] {
					group.MaxCacheEntries[i] = policy.HighWaterEntries
				}
				if policy.HighWaterCanonicalBytes > group.MaxCanonicalBytes[i] {
					group.MaxCanonicalBytes[i] = policy.HighWaterCanonicalBytes
				}
			}
		}
		report := struct {
			Note                                                string
			NativeParserFlag, NativeAllocatorFlag               string
			PolicyCapacities                                    [3]int
			AdmissionMaxBytes                                   int
			GlobalPoolCalls, GlobalPoolMisses, GlobalPoolResets uint64
			ObservedNativeNewStringCalls                        uint64
			Groups                                              map[string]*stringPoolGroupDiagnostic
			Files                                               []stringPoolParseDiagnosticRow
		}{
			Note:                "Untimed diagnostic only. Every real global lookup/lock is unchanged. Global counts include initialization, other passes, fallback, templates and JSDoc; native observations cover only NodeAllocator.NewString in opted-in native attempts, including original fragments. Simulated MRU hits do not prove material CPU/lock contention or measure allocations/RSS. Rows with no allocator had no observed calls. Cache keys are existing canonical cells, cleared after each attempt; report rows retain only file names and numeric summaries. No mutex timing is captured.",
			NativeParserFlag:    os.Getenv("JSGO_EXPERIMENT_NATIVE_PARSER"),
			NativeAllocatorFlag: os.Getenv("JSGO_EXPERIMENT_NATIVE_PARSER_ALLOCATOR"),
			PolicyCapacities:    [3]int{2, 4, 64}, AdmissionMaxBytes: 64,
			GlobalPoolCalls:              stringPoolDiagnostic.poolCalls.Load(),
			GlobalPoolMisses:             stringPoolDiagnostic.poolMisses.Load(),
			GlobalPoolResets:             stringPoolDiagnostic.poolResets.Load(),
			ObservedNativeNewStringCalls: nativeCalls, Groups: groups, Files: rows,
		}
		data, err := json.MarshalIndent(report, "", "  ")
		if err != nil {
			panic(err)
		}
		if err := os.WriteFile(path, append(data, '\n'), 0600); err != nil {
			panic(err)
		}
	})
}
