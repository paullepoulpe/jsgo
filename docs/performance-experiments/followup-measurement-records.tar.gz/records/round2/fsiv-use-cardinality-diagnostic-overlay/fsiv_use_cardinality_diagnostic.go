// Untimed diagnostic overlay only. Never include in production/race timing builds.
package jscomp

import (
	"encoding/json"
	"os"
	"reflect"
	"sync"
)

type fsivUseDiagnosticReport struct {
	Kind              string                    `json:"kind"`
	Source            string                    `json:"source"`
	Root              string                    `json:"root"`
	Enabled           string                    `json:"enabled"`
	NativeFlow        string                    `json:"native_flow"`
	ParallelFSIV      string                    `json:"parallel_fsiv"`
	Functions         int                       `json:"function_windows"`
	FunctionNodes     int                       `json:"function_nodes"`
	FunctionVariables int                       `json:"function_variables"`
	Counts            nativeUseCardinalityStats `json:"counts"`
}

var fsivUseDiagnosticState struct {
	sync.Mutex
	report fsivUseDiagnosticReport
}

func fsivUseDiagnosticBegin() func() {
	path := os.Getenv("JSGO_FSIV_USE_CARDINALITY_DIAGNOSTIC_JSON")
	if path == "" {
		return nil
	}
	fsivUseDiagnosticState.Lock()
	fsivUseDiagnosticState.report = fsivUseDiagnosticReport{
		Kind: "untimed-fsiv-use-cardinality-dispatch", Source: "4bbbb8a9fd1392a1053bae44f3429beae3ad954b", Root: "/workspace/jsgo-fundamental-compiler-designs",
		Enabled:    os.Getenv("JSGO_EXPERIMENT_FSIV_USE_CARDINALITY"),
		NativeFlow: os.Getenv("JSGO_EXPERIMENT_NATIVE_LOCAL_FLOW"), ParallelFSIV: os.Getenv("JSGO_EXPERIMENT_PARALLEL_FSIV"),
	}
	fsivUseDiagnosticState.Unlock()
	return func() {
		fsivUseDiagnosticState.Lock()
		report := fsivUseDiagnosticState.report
		fsivUseDiagnosticState.Unlock()
		data, err := json.MarshalIndent(report, "", "  ")
		if err == nil {
			_ = os.WriteFile(path, append(data, '\n'), 0600)
		}
	}
}

func fsivUseDiagnosticAttach(f *FlowSensitiveInlineVariables, variables int) func() {
	if os.Getenv("JSGO_FSIV_USE_CARDINALITY_DIAGNOSTIC_JSON") == "" || f.useCardinalityProbe != nil {
		return nil
	}
	probe := &nativeUseCardinalityStats{}
	f.useCardinalityProbe = probe
	nodes := 0
	if f.nativeCFG != nil {
		nodes = len(f.nativeCFG.nodes)
	}
	return func() {
		f.useCardinalityProbe = nil
		fsivUseDiagnosticState.Lock()
		defer fsivUseDiagnosticState.Unlock()
		report := &fsivUseDiagnosticState.report
		report.Functions++
		report.FunctionNodes += nodes
		report.FunctionVariables += variables
		// Private numeric copies only. No AST, Var, Scope or topology is retained.
		target := reflect.ValueOf(&report.Counts).Elem()
		source := reflect.ValueOf(probe).Elem()
		for index := 0; index < target.NumField(); index++ {
			field := target.Field(index)
			value := source.Field(index).Int()
			if target.Type().Field(index).Name == "MaxDenseBytes" {
				field.SetInt(max(field.Int(), value))
			} else {
				field.SetInt(field.Int() + value)
			}
		}
	}
}
