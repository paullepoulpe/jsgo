package jscomp

import (
	"bytes"
	"crypto/sha256"
	"encoding/hex"
	"encoding/json"
	"fmt"
	"github.com/paullepoulpe/jsgo/internal/jutil"
	"os"
	"path/filepath"
	"testing"
)

func TestFSIVUseCardinalityDiagnosticPinnedTasks(t *testing.T) {
	path := os.Getenv("JSGO_FSIV_USE_CARDINALITY_DIAGNOSTIC_JOBS")
	if path == "" {
		t.Skip("untimed diagnostic only; manifest not supplied")
	}
	data, err := os.ReadFile(path)
	if err != nil {
		t.Fatal(err)
	}
	var manifest struct {
		Tasks []struct {
			Name string
			Jobs []struct {
				Directory string
				Args      []string
				Expected  map[string]string
			}
		}
	}
	if err := json.Unmarshal(data, &manifest); err != nil {
		t.Fatal(err)
	}
	for _, task := range manifest.Tasks {
		t.Run(task.Name, func(t *testing.T) {
			for index, job := range task.Jobs {
				t.Run(fmt.Sprint(index), func(t *testing.T) {
					t.Chdir(job.Directory)
					for artifact := range job.Expected {
						if err := os.Remove(artifact); err != nil && !os.IsNotExist(err) {
							t.Fatal(err)
						}
					}
					reportPath := filepath.Join(job.Directory, "fsiv-use-cardinality.json")
					_ = os.Remove(reportPath)
					t.Setenv("JSGO_FSIV_USE_CARDINALITY_DIAGNOSTIC_JSON", reportPath)
					var stdout, stderr bytes.Buffer
					runner := NewCommandLineRunnerWithOutAndErr(job.Args, jutil.NewPrintStream(&stdout), jutil.NewPrintStream(&stderr))
					status := runner.DoRun()
					for name, data := range map[string][]byte{"stdout": stdout.Bytes(), "stderr": stderr.Bytes(), "exit": []byte(fmt.Sprintln(status))} {
						if err := os.WriteFile(name, data, 0600); err != nil {
							t.Fatal(err)
						}
					}
					for name, want := range job.Expected {
						data, err := os.ReadFile(name)
						if err != nil {
							t.Fatal(err)
						}
						hash := sha256.Sum256(data)
						if got := hex.EncodeToString(hash[:]); got != want {
							t.Errorf("pinned Java artifact mismatch %s got%s want%s", name, got, want)
						}
					}
					report, err := os.ReadFile(reportPath)
					if err != nil {
						t.Fatal(err)
					}
					t.Log("FSIV_USE_CARDINALITY_DIAGNOSTIC " + string(report))
				})
			}
		})
	}
}
