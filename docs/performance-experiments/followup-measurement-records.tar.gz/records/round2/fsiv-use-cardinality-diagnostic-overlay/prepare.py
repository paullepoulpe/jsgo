#!/usr/bin/env python3
"""Prepare UNTIMED activation-only instrumentation; never build or edit checkout."""
import argparse, hashlib, json, subprocess
from pathlib import Path
p=argparse.ArgumentParser(description=__doc__)
p.add_argument('--root',type=Path,required=True)
p.add_argument('--base-overlay',type=Path)
a=p.parse_args();root=a.root.resolve();out=Path(__file__).resolve().parent;pkg=root/'internal/jscomp'
replacements=json.loads(a.base_overlay.read_text())['Replace'].copy() if a.base_overlay else {}
if replacements and not any(str(pkg)==str(Path(k).parent) for k in replacements):
 raise SystemExit('base overlay must target --root')
revision=subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip()
original_hashes={}
for name,marker,insert in [
 ('flow_sensitive_inline_variables.go','\tallVarsInFn := allVarsDeclaredInFunction.GetAllVariables()\n','\tif finish := fsivUseDiagnosticAttach(f, allVarsInFn.Size()); finish != nil { defer finish() }\n'),
 ('abstract_command_line_runner.go','func (r *AbstractCommandLineRunnerBase) DoRun() int {\n','\tif finish := fsivUseDiagnosticBegin(); finish != nil { defer finish() }\n')]:
 target=pkg/name
 # Compose existing production overlays by reading their effective contents.
 source=Path(replacements.get(str(target),str(target))).read_text()
 if source.count(marker)!=1:raise SystemExit('nonunique diagnostic hook '+name)
 original_hashes[name]=hashlib.sha256(source.encode()).hexdigest()
 source=source.replace(marker,marker+insert,1)
 copy=out/name;copy.write_text(source);replacements[str(target)]=str(copy)
helper=out/'fsiv_use_cardinality_diagnostic.go'
helper.write_text('''// Untimed diagnostic overlay only. Never include in production/race timing builds.
package jscomp

import (
 "encoding/json"
 "os"
 "reflect"
 "sync"
)

type fsivUseDiagnosticReport struct {
 Kind string `json:"kind"`
 Source string `json:"source"`
 Root string `json:"root"`
 Enabled string `json:"enabled"`
 NativeFlow string `json:"native_flow"`
 ParallelFSIV string `json:"parallel_fsiv"`
 Functions int `json:"function_windows"`
 FunctionNodes int `json:"function_nodes"`
 FunctionVariables int `json:"function_variables"`
 Counts nativeUseCardinalityStats `json:"counts"`
}
var fsivUseDiagnosticState struct {
 sync.Mutex
 report fsivUseDiagnosticReport
}

func fsivUseDiagnosticBegin() func() {
 path:=os.Getenv("JSGO_FSIV_USE_CARDINALITY_DIAGNOSTIC_JSON")
 if path=="" { return nil }
 fsivUseDiagnosticState.Lock()
 fsivUseDiagnosticState.report=fsivUseDiagnosticReport{
  Kind:"untimed-fsiv-use-cardinality-dispatch",Source:SOURCE_REVISION,Root:SOURCE_ROOT,
  Enabled:os.Getenv("JSGO_EXPERIMENT_FSIV_USE_CARDINALITY"),
  NativeFlow:os.Getenv("JSGO_EXPERIMENT_NATIVE_LOCAL_FLOW"),ParallelFSIV:os.Getenv("JSGO_EXPERIMENT_PARALLEL_FSIV"),
 }
 fsivUseDiagnosticState.Unlock()
 return func() {
  fsivUseDiagnosticState.Lock()
  report:=fsivUseDiagnosticState.report
  fsivUseDiagnosticState.Unlock()
  data,err:=json.MarshalIndent(report,"","  ")
  if err==nil { _=os.WriteFile(path,append(data,'\\n'),0600) }
 }
}

func fsivUseDiagnosticAttach(f *FlowSensitiveInlineVariables, variables int) func() {
 if os.Getenv("JSGO_FSIV_USE_CARDINALITY_DIAGNOSTIC_JSON")=="" || f.useCardinalityProbe!=nil { return nil }
 probe:=&nativeUseCardinalityStats{}
 f.useCardinalityProbe=probe
 nodes:=0
 if f.nativeCFG!=nil {nodes=len(f.nativeCFG.nodes)}
 return func() {
  f.useCardinalityProbe=nil
  fsivUseDiagnosticState.Lock()
  defer fsivUseDiagnosticState.Unlock()
  report:=&fsivUseDiagnosticState.report
  report.Functions++;report.FunctionNodes+=nodes;report.FunctionVariables+=variables
  // Private numeric copies only. No AST, Var, Scope or topology is retained.
  target:=reflect.ValueOf(&report.Counts).Elem()
  source:=reflect.ValueOf(probe).Elem()
  for index:=0;index<target.NumField();index++ {
   field:=target.Field(index)
   value:=source.Field(index).Int()
   if target.Type().Field(index).Name=="MaxDenseBytes" {field.SetInt(max(field.Int(),value))} else {field.SetInt(field.Int()+value)}
  }
 }
}
'''.replace('SOURCE_REVISION',json.dumps(revision)).replace('SOURCE_ROOT',json.dumps(str(root))))
replacements[str(pkg/helper.name)]=str(helper)
# Dedicated real-job test: manifest schema is identical to Array diagnostic jobs.
test=out/'fsiv_use_cardinality_diagnostic_test.go'
test.write_text('''package jscomp
import (
 "bytes"
 "crypto/sha256"
 "encoding/hex"
 "encoding/json"
 "fmt"
 "os"
 "path/filepath"
 "testing"
 "github.com/paullepoulpe/jsgo/internal/jutil"
)
func TestFSIVUseCardinalityDiagnosticPinnedTasks(t *testing.T) {
 path:=os.Getenv("JSGO_FSIV_USE_CARDINALITY_DIAGNOSTIC_JOBS")
 if path=="" {t.Skip("untimed diagnostic only; manifest not supplied")}
 data,err:=os.ReadFile(path);if err!=nil {t.Fatal(err)}
 var manifest struct {Tasks []struct {Name string;Jobs []struct {Directory string;Args []string;Expected map[string]string}}}
 if err:=json.Unmarshal(data,&manifest);err!=nil {t.Fatal(err)}
 for _,task:=range manifest.Tasks {t.Run(task.Name,func(t *testing.T){
  for index,job:=range task.Jobs {t.Run(fmt.Sprint(index),func(t *testing.T){
   t.Chdir(job.Directory)
   for artifact:=range job.Expected {if err:=os.Remove(artifact);err!=nil&&!os.IsNotExist(err){t.Fatal(err)}}
   reportPath:=filepath.Join(job.Directory,"fsiv-use-cardinality.json")
   _=os.Remove(reportPath)
   t.Setenv("JSGO_FSIV_USE_CARDINALITY_DIAGNOSTIC_JSON",reportPath)
   var stdout,stderr bytes.Buffer
   runner:=NewCommandLineRunnerWithOutAndErr(job.Args,jutil.NewPrintStream(&stdout),jutil.NewPrintStream(&stderr))
   status:=runner.DoRun()
   for name,data:=range map[string][]byte{"stdout":stdout.Bytes(),"stderr":stderr.Bytes(),"exit":[]byte(fmt.Sprintln(status))} {
    if err:=os.WriteFile(name,data,0600);err!=nil {t.Fatal(err)}
   }
   for name,want:=range job.Expected {
    data,err:=os.ReadFile(name);if err!=nil {t.Fatal(err)}
    hash:=sha256.Sum256(data);if got:=hex.EncodeToString(hash[:]);got!=want{t.Errorf("pinned Java artifact mismatch %s got%s want%s",name,got,want)}
   }
   report,err:=os.ReadFile(reportPath);if err!=nil {t.Fatal(err)}
   t.Log("FSIV_USE_CARDINALITY_DIAGNOSTIC "+string(report))
  })}
 })}
}
''')
replacements[str(pkg/test.name)]=str(test)
outputs=[out/'flow_sensitive_inline_variables.go',out/'abstract_command_line_runner.go',helper,test]
subprocess.run(['/workspace/toolchains/go1.27.2/bin/gofmt','-w',*[str(x) for x in outputs]],check=True)
(out/'overlay.json').write_text(json.dumps({'Replace':replacements},indent=2)+'\n')
(out/'manifest.json').write_text(json.dumps({'root':str(root),'source':revision,'base_overlay':str(a.base_overlay.resolve()) if a.base_overlay else None,
 'kind':'untimed-activation-only-NOT-race','original_effective_source_sha256':original_hashes,
 'sha256':{x.name:hashlib.sha256(x.read_bytes()).hexdigest() for x in outputs},
 'forces_admission':False,'forces_experiment_flags':False,'test_manifest_schema':'array-recipe-diagnostic-overlay/jobs.json',
 'production_stubs':0,'adds_diagnostic_mutex':True},indent=2)+'\n')
print(json.dumps({'root':str(root),'source':revision,'overlay':str(out/'overlay.json')},indent=2))
