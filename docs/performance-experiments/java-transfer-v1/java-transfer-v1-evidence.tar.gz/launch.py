#!/usr/bin/env python3
"""Root-owned serial launch; immutable runtime receipts and logs for each attempt."""
import argparse,hashlib,json,subprocess,time
from pathlib import Path
ROOT=Path(__file__).resolve().parent
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def main():
 p=argparse.ArgumentParser()
 p.add_argument('task',choices=['bigquery','bundle']);p.add_argument('baseline');p.add_argument('candidate');p.add_argument('name');p.add_argument('--cohorts',type=int,default=1)
 a=p.parse_args();b=ROOT/'bench';runner=b/'run-v3.py';manifest=b/'build-manifest.json'
 assert sha(runner)=='2eca9cede566627bc2511f660f32830bce039b47c4b101d194c2918348470d16'
 assert sha(manifest)=='e9625f3ea767f40fde71aff81dc7276ccbdd2f430d7f85a8ffeb4ca678a21ba3'
 if a.task=='bigquery':
  oracle=Path('/workspace/jsgo-results/round4/bigquery-stock-oracle-v1');spec=oracle/'spec.json'
 else:
  oracle=Path('/workspace/jsgo-results/round4/paired-main5de-bundle-advanced-t1-v1')
  spec=Path('/workspace/jsgo-results/round4/main-9c895b43-sync-v1/benchmark-preparation-v2/go-screen-v2/specs/bundle-n1.json')
 out=ROOT/'results'/a.name;launch=ROOT/'launches'/a.name;launch.mkdir(parents=True)
 assert not out.exists()
 grant={'runner_sha256':sha(runner),'manifest_sha256':sha(manifest),'spec_sha256':sha(spec),'out':str(out),'baseline':a.baseline,'candidate':a.candidate,'cohorts':a.cohorts,'pairs':5,'allowed_stages':['benchmark'],'root_review':'same9families identicalflags; classorigin and everyrequest sixdigest admission; focusedprobes tracked separately'}
 (launch/'grant.json').write_text(json.dumps(grant,indent=2)+'\n')
 argv=['python3','-u',str(runner),'--manifest',str(manifest),'--baseline',a.baseline,'--candidate',a.candidate,'--spec',str(spec),'--oracle',str(oracle/'stock-java-oracle-digests.json'),'--oracle-metadata',str(oracle/'metadata.json'),'--jar','/workspace/jsgo/.cache/closure-compiler-v20261015-maven.jar','--java-home','/usr/lib/jvm/java-21-openjdk-amd64','--image','python@sha256:70729b46c69b4f1e97c4822c1af3df53a1476cf5ddc6c087c0c10bc3a5678c2f','--out',str(out),'--runtime-grant',str(launch/'grant.json'),'--cohorts',str(a.cohorts),'--pairs','5']
 record={'argv':argv,'started_unix':time.time()};(launch/'command.json').write_text(json.dumps(record,indent=2)+'\n')
 with (launch/'stdout').open('wb') as stdout,(launch/'stderr').open('wb') as stderr:
  result=subprocess.run(argv,stdout=stdout,stderr=stderr)
 record.update(ended_unix=time.time(),exit=result.returncode);(launch/'result.json').write_text(json.dumps(record,indent=2)+'\n')
 print(json.dumps({'name':a.name,'exit':result.returncode,'seconds':record['ended_unix']-record['started_unix'],'out':str(out)}),flush=True)
 if result.returncode:print((launch/'stderr').read_text()[-5000:])
 raise SystemExit(result.returncode)
if __name__=='__main__':main()
