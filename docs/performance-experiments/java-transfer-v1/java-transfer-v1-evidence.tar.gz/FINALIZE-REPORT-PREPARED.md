Final report renderer: source prepared, not executed

finalize_report.py was AST-parsed only. It has not been imported or run; the current
report draft and all original evidence remain unchanged by its preparation.

Root may run, only after final analysis and all result/review stages are CLOSED:

    python3 /workspace/jsgo-java-experiments/transfer-v1/finalize_report.py --execute

Without --execute it only prints PREPARED ONLY. The renderer has no compiler,
benchmark, Docker, subprocess, hash, interval-computation or archive code.

Required inputs are the seven completed screen independent reviews/summaries/stopped
receipts; the closed three-job confirmation sequence; final color/ALL BigQuery reviews
(3 cohorts each) and ALL bundle review (1 cohort); the final confirmation analysis and
its two CSVs; independent diagnostic results review; and historical upstream-readiness
note. It fails before report mutation if required closure/byte/count/diagnostic schemas
are absent or inconsistent. It checks adjusted-upper<1 against the reported primary
support flags and requires no screen observations pooled into holdouts. It copies,
rather than recalculates, intervals from the original completed analysis.

On execution the current README/methodology/evidence/results/screen-data files are
preserved under report/history/before-final-confirmation-render-v1. Existing history
or generated final browse/status files are refused; partial writes need root review
and a new deliberate version rather than silent reruns. Original result/review/source
receipts and analysis files stay read-only.

The new README leads with the adjusted primary finding, not screen selection. It
contains all five factors plus ALL screens, median/mean sensitivity, CPU/RSS/allocation,
all three raw holdout ratios, direct and inverse 95%/adjusted intervals, exact absolute
holdout medians/SD/current RSS/lifetime HWM per JVM, a separate one-cohort bundle screen,
activation counts, failure/recovery history and unmeasured open ideas. The original
analysis/CSVs and upstream-readiness note are copied into report for browsing. Relative
links point to patches/, copied JSON/CSV, and java-transfer-v1-evidence.tar.gz; raw
ROOT-relative receipt paths are explicitly archive paths.

Status/evidence/template JSONs then record completed results with root_reviewed=false.
Root must inspect the final narrative, numerical tables and compatibility limitations
and grant publication separately. In particular, confirm no stale pending claims,
no screen RSS-significance inference, no fixed recompilation-penalty correction,
no new Go/Java claim, and no universal upstream-test claim. The publisher's final
README hash must be computed AFTER this render and root review. No actual result is
inferred by the mere presence of this prepared source.

Renderer revision2: post hoc telemetry review amendment

The prior unexecuted renderer/note are preserved under history/finalize-report-v1/.
The new source requires the original failed color review, failure-time progress
snapshot, amendment and Linux documentation receipts plus confirm_resume.py.
It discloses the 60 KiB STOCK cohort3 warmup dip, the later strictly higher maximum,
unchanged raw timings/bytes/cgroup peak and unchanged runner/flags/inputs. The
review amendment was post hoc, not prespecified performance-protocol tuning.
Measured VmHWM dips and cgroup peak dips remain fatal. RSS display labels now say
maximum observed approximate /proc VmHWM, including warmup/JIT/measurement; legacy
field names stay unchanged and no root cause or accuracy bound is claimed. The accepted amendment must explicitly be V2_FULL_REVIEW_PASS_NO_MEASUREMENT_CHANGED,
with color reviewer_version v2-warmup-VmHWM-amendment and one matching telemetry
anomaly record. Its accepted-review/reviewer hashes and original failed review
remain recorded; the initial pending state is not presented as the final outcome.
The generator/evidence update remains source-only until root runs it after final
analysis. No report was rendered or original receipt changed during this update.
