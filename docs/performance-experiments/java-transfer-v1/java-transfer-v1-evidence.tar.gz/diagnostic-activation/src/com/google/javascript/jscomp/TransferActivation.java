package com.google.javascript.jscomp;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardOpenOption;
import java.util.concurrent.atomic.AtomicLongArray;

/** Diagnostic activation counters only; never use this build for benchmark timings. */
public final class TransferActivation {
  public static final int FSIV_ELIGIBLE_FUNCTIONS = 0;
  public static final int FSIV_BACKWARD_ANALYSES = 1;
  public static final int FSIV_NO_CANDIDATES = 2;
  public static final int NAMESPACE_TRAVERSAL_COLLECT_CALLS = 3;
  public static final int NAMESPACE_SCOPE_RESOLUTIONS = 4;
  public static final int NAMESPACE_CHUNK_RESOLUTIONS = 5;
  public static final int COALESCE_OR_INTO_CALLS = 6;
  public static final int COLOR_LOOKUP_CALLS = 7;
  public static final int COLOR_CACHE_HITS = 8;
  public static final int COLOR_CACHE_MISSES = 9;
  public static final int POLYFILL_GET_DEFAULT_CALLS = 10;
  public static final int POLYFILL_RESOURCE_PARSE_CALLS = 11;
  private static final String[] NAMES = {
    "fsiv.eligibleFunctions",
    "fsiv.backwardAnalyses",
    "fsiv.noCandidates",
    "namespace.traversalCollectCalls",
    "namespace.scopeResolutions",
    "namespace.chunkResolutions",
    "coalesce.orIntoCalls",
    "color.lookupCalls",
    "color.cacheHits",
    "color.cacheMisses",
    "polyfill.getDefaultCalls",
    "polyfill.resourceParseCalls"
  };
  private static final AtomicLongArray COUNTS = new AtomicLongArray(NAMES.length);
  private static final String OUTPUT_PATH = System.getProperty("transfer.activation.path");
  private static final boolean ENABLED = OUTPUT_PATH != null && !OUTPUT_PATH.isBlank();

  static {
    if (ENABLED) {
      try {
        Runtime.getRuntime().addShutdownHook(
            new Thread(TransferActivation::writeSidecar, "transfer-activation-sidecar"));
      } catch (RuntimeException ignored) {
        // Missing sidecar is a failed diagnostic admission. Never contaminate compiler streams.
      }
    }
  }

  private TransferActivation() {}

  public static void increment(int counter) {
    if (ENABLED) {
      COUNTS.incrementAndGet(counter);
    }
  }

  private static void writeSidecar() {
    StringBuilder json = new StringBuilder();
    json.append("{\n  \"schema\": \"jsgo-java-transfer-activation-v1\",\n")
        .append("  \"diagnostic_only\": true,\n  \"counters\": {\n");
    for (int i = 0; i < NAMES.length; i++) {
      if (i != 0) {
        json.append(",\n");
      }
      json.append("    \"").append(NAMES[i]).append("\": ").append(COUNTS.get(i));
    }
    json.append("\n  }\n}\n");
    try {
      Files.writeString(Path.of(OUTPUT_PATH), json, StandardCharsets.UTF_8,
          StandardOpenOption.CREATE_NEW, StandardOpenOption.WRITE);
    } catch (IOException | RuntimeException ignored) {
      // Preserve an existing sidecar and compiler stdout/stderr. Root checks a fresh sidecar exists.
    }
  }
}
