#!/usr/bin/env python3
"""Root-only activation capture after quiet screens. NOT a performance experiment."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import signal
import subprocess
import sys
import time
import types
from urllib.parse import unquote, urlparse

sys.dont_write_bytecode = True
HERE = Path(__file__).resolve().parent
TRANSFER = HERE.parent
JAR = Path('/workspace/jsgo/.cache/closure-compiler-v20261015-maven.jar')
JAVA_HOME = '/usr/lib/jvm/java-21-openjdk-amd64'
IMAGE = 'python@sha256:70729b46c69b4f1e97c4822c1af3df53a1476cf5ddc6c087c0c10bc3a5678c2f'
HELP = Path('/workspace/jsgo-round4-bench/tools/bench')
HELPERS = {'paired_cli.py': '914a9c97eb5cb66fa786d01a2f43599b781327c89b51fe0e4fef3ab207fd0854',
           'cgroup_exec.py': '3b19b27b04a146b3793b917ab1eef30573ca92bcff06360acfb964ac7b6d025e'}
JAR_SHA = 'd6864ebf70bca5ba6e237898de6611a389aaf8b933c2549036ced4a684b664b6'
SOURCE_SHA = '495057925ec7824a75cb481656cecdc93e852437cc2d501b552b5c2d522131b5'
DRIVER_SHA = '1195afce140d50af49ba270147357564de8ec6a58a5c890162092397ae8d8458'
DRIVER_CLASS = 'bcfb35f2f65f747a9508ff2f642a6bd4b8040f80a72fb27f9a535fbe2a7c27db'
TASKS = {
    'bigquery': ('/workspace/jsgo-results/round4/bigquery-stock-oracle-v1/spec.json',
                 '/workspace/jsgo-results/round4/bigquery-stock-oracle-v1'),
    'bundle': ('/workspace/jsgo-results/round4/main-9c895b43-sync-v1/benchmark-preparation-v2/go-screen-v2/specs/bundle-n1.json',
               '/workspace/jsgo-results/round4/paired-main5de-bundle-advanced-t1-v1'),
}


def read(path):
    return json.loads(Path(path).read_text())


def save(path, value):
    Path(path).write_text(json.dumps(value, indent=2, allow_nan=False) + '\n')


def sha(path):
    digest = hashlib.sha256()
    with Path(path).open('rb') as stream:
        for block in iter(lambda: stream.read(1 << 20), b''):
            digest.update(block)
    return digest.hexdigest()


def require(condition, message):
    if not condition:
        raise RuntimeError(message)


def active():
    result = []
    for proc in Path('/proc').iterdir():
        if not proc.name.isdigit():
            continue
        try:
            comm = (proc / 'comm').read_text().strip()
            exe = Path((proc / 'cmdline').read_bytes().split(b'\0')[0].decode()).name
            state = (proc / 'stat').read_text().split()[2]
            if state != 'Z' and (comm in ('go', 'compile', 'link', 'java', 'javac')
                                 or comm.startswith('jsgo') or exe.endswith('.test')):
                result.append({'pid': int(proc.name), 'comm': comm, 'argv0': exe})
        except (OSError, IndexError, UnicodeDecodeError):
            pass
    return result


def events(text):
    return {k: int(v) for k, v in (line.split() for line in text.replace(';', '\n').splitlines())}


def outer():
    root = Path('/sys/fs/cgroup')
    return {name: (root / name).read_text().strip()
            for name in ('memory.events', 'memory.current', 'memory.max')}


def oom_delta(before, after):
    return {key: events(after['memory.events']).get(key, 0)
            - events(before['memory.events']).get(key, 0)
            for key in ('oom', 'oom_kill', 'oom_group_kill')}


def work_identity(spec):
    return {key: spec[key] for key in ('argv', 'links', 'inputs', 'artifacts')} | {
        'absent_artifacts': spec.get('absent_artifacts', []),
        'builtin_externs': spec['same_work']['builtin_externs']}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--task', required=True, choices=TASKS)
    parser.add_argument('--out', required=True, type=Path)
    args = parser.parse_args()
    require(args.out.is_absolute(), '--out must be absolute')
    root = args.out.resolve()
    require(not root.exists(), 'fresh output directory required')
    require(not active(), 'compiler process active; diagnostic execution forbidden')
    pins = read(HERE / 'runner-input-pins.json')
    for path, expected in pins['files'].items():
        require(sha(path) == expected, 'runner preparation changed: ' + path)
    source_path = HERE / 'source-manifest.json'
    require(sha(source_path) == SOURCE_SHA, 'instrumentation source manifest changed')
    source = read(source_path)
    require(sha(JAR) == JAR_SHA == source['published_jar_sha256'], 'jar identity')
    build_path = HERE / 'build/build.json'
    build = read(build_path)
    require(build['status'] == 'PASS' and build['exit'] == 0
            and build['diagnostic_only'] is True and build['performance_claim'] is False
            and build['source_manifest_sha256'] == SOURCE_SHA, 'diagnostic build not admitted')
    overlay = HERE / 'build/classes'
    require({str(p.relative_to(overlay)) for p in overlay.rglob('*.class')}
            == set(build['classes']), 'diagnostic exact class inventory')
    for relative, expected in build['classes'].items():
        require(sha(overlay / relative) == expected, 'diagnostic class changed: ' + relative)
    for relative, entry in source['sources'].items():
        require(sha(HERE / 'src' / relative) == entry['instrumented_sha256'], 'diagnostic source changed')
    require(sha(source['base_all_build_proof']) == source['base_all_build_proof_sha256'], 'ALL build identity')
    driver = TRANSFER / 'bench/driver'
    require(sha(TRANSFER / 'bench/CliFactors.java') == DRIVER_SHA, 'driver source')
    require({p.name for p in driver.rglob('*.class')} == {'CliFactors.class'}
            and sha(driver / 'CliFactors.class') == DRIVER_CLASS, 'driver exact classes')
    spec_path, oracle_dir = TASKS[args.task]
    spec, provenance = read(spec_path), read(Path(oracle_dir) / 'metadata.json')
    oracle = read(Path(oracle_dir) / 'stock-java-oracle-digests.json')
    require(all(isinstance(v, str) and not any(c in v for c in '\n\r\0')
                for v in spec['argv']), 'invalid argv')
    require(work_identity(spec) == work_identity(provenance['spec'])
            and provenance.get('jar_sha256', provenance.get('java_jar_sha256')) == JAR_SHA,
            'oracle work/jar mismatch')
    require(set(oracle) == {'stdout', 'stderr', 'exit', *spec['artifacts'],
                            *spec.get('absent_artifacts', [])} and len(oracle) == 6
            and oracle['exit'] == hashlib.sha256(b'0\n').hexdigest(), 'strict six oracle')
    root.mkdir(parents=True)
    snapshots = root / 'helper-snapshots'
    snapshots.mkdir()
    for relative, expected in HELPERS.items():
        require(sha(HELP / relative) == expected, 'helper pin')
        (snapshots / relative).write_bytes((HELP / relative).read_bytes())
    helper = types.ModuleType('frozen_diagnostic_support')
    helper.__file__ = str(snapshots / 'paired_cli.py')
    exec(compile((snapshots / 'paired_cli.py').read_bytes(), helper.__file__, 'exec'), helper.__dict__)
    identity = helper.input_identity(spec)
    require(identity == provenance['input_manifest'], 'input identity differs from stock oracle')
    dependencies = helper.java_runtime_dependencies(JAVA_HOME)
    work = root / 'work'
    helper.workspace(work, spec)
    sidecar = work / 'activation.json'
    require(not sidecar.exists(), 'stale sidecar')
    (work / 'argv.txt').write_text('\n'.join(spec['argv']) + '\n')
    origins = {relative.removesuffix('.class').replace('/', '.'): digest
               for relative, digest in build['classes'].items()
               if '$' not in relative}
    require(len(origins) == 10, 'expected nine instrumented source families plus helper')
    origins['CliFactors'] = DRIVER_CLASS
    (work / 'classes.txt').write_text('\n'.join(sorted(origins)) + '\n')
    cp = os.pathsep.join(map(str, (overlay, JAR, driver)))
    command = ['python3', str(snapshots / 'cgroup_exec.py'), JAVA_HOME + '/bin/java',
               '-Xmx3g', '-Dtransfer.activation.path=' + str(sidecar), '-cp', cp,
               'CliFactors', str(work / 'argv.txt'), str(work / 'classes.txt')]
    engine_args = types.SimpleNamespace(readonly_bind=sorted(set(spec['links'].values()) | {str(overlay)}),
        binary=str(JAR), java_home=JAVA_HOME, jar=str(JAR), driver=str(driver), image=IMAGE)
    engine = helper.Engine(engine_args)
    owner = 'jsgo-transfer-diag-' + hashlib.sha256(str(root).encode()).hexdigest()[:16]
    original_call = engine.call

    def bounded_call(*argv, **kwargs):
        kwargs.setdefault('timeout', 20)
        if argv[0] == 'create':
            argv = ('create', '--name=' + owner, '--label=jsgo.transfer.diagnostic=' + str(root), *argv[1:])
        return original_call(*argv, **kwargs)

    engine.call = bounded_call
    require(not engine.call('ps', '-q', capture_output=True, text=True).stdout.strip(), 'active container')
    require(not active(), 'compiler started during preflight')
    before = outer()
    require(int(before['memory.max']) - int(before['memory.current']) >= 1 << 30, 'outer headroom <1GiB')
    require(os.statvfs(root).f_bavail * os.statvfs(root).f_frsize >= 1 << 30, 'disk headroom <1GiB')
    save(root / 'metadata.json', {'diagnostic_only': True, 'performance_claim': False,
        'task': args.task, 'argv': command, 'compiler_argv': spec['argv'],
        'runner_sha256': sha(__file__), 'source_manifest_sha256': SOURCE_SHA,
        'build_receipt_sha256': sha(build_path), 'build_receipt': build,
        'spec_path': spec_path, 'spec_sha256': sha(spec_path), 'oracle': oracle,
        'oracle_metadata_sha256': sha(Path(oracle_dir) / 'metadata.json'),
        'oracle_sha256': sha(Path(oracle_dir) / 'stock-java-oracle-digests.json'),
        'input_manifest': identity, 'readonly_inputs': spec['links'], 'helper_pins': HELPERS,
        'jar_sha256': JAR_SHA, 'driver_source_sha256': DRIVER_SHA,
        'driver_class_sha256': DRIVER_CLASS, 'java_binary_sha256': sha(JAVA_HOME + '/bin/java'),
        'java_runtime_dependencies': dependencies, 'class_origins_expected': origins,
        'outer_before': before, 'protocol_input': '1\twarmup\nSTOP\n',
        'logger_policy': 'shared CliFactors disables PhaseOptimizer logger exactly as existing stock oracle',
        'metrics_policy': 'all clocks/CPU/RSS/allocation metrics diagnostic only; no performance comparison'})
    process = None
    cid = None
    failure = None
    cleanup_errors = []
    summary = None
    started = time.monotonic()
    try:
        cid = engine.create(work, command, java=True)
        save(root / 'owned.json', {'name': owner, 'cid': cid, 'work': str(work), 'label': str(root)})
        process = subprocess.Popen(helper.DOCKER + ['start', '-a', '-i', cid],
            stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.PIPE,
            env=engine.env, start_new_session=True)
        save(root / 'owned-driver.json', {'pid': process.pid, 'pgid': process.pid, 'cid': cid})
        try:
            stdout, stderr = process.communicate(b'1\twarmup\nSTOP\n', timeout=1200)
        except subprocess.TimeoutExpired:
            try:
                engine.call('kill', cid, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
            except Exception as error:
                cleanup_errors.append('timeout container kill: ' + repr(error))
            finally:
                try:
                    os.killpg(process.pid, signal.SIGKILL)
                except ProcessLookupError:
                    pass
                stdout, stderr = process.communicate(timeout=20)
                (root / 'driver.stdout').write_bytes(stdout)
                (root / 'driver.stderr').write_bytes(stderr)
            raise RuntimeError('diagnostic compiler timeout')
        (root / 'driver.stdout').write_bytes(stdout)
        (root / 'driver.stderr').write_bytes(stderr)
        require(process.returncode == 0 and stderr == b'', 'driver exit/stderr')
        require(len(stdout) <= 1 << 20, 'protocol output bound')
        lines = [line.split('\t') for line in stdout.decode('utf-8').splitlines()]
        require(len(lines) == len(origins) + 3 and lines[0][0] == 'VM', 'protocol line inventory')
        vm, ready, result = lines[0], lines[-2], lines[-1]
        require(len(vm) == 4 and vm[1].startswith('21.') and 0 < int(vm[3]) <= 3 << 30, 'VM identity/heap')
        loaded = {}
        for row in lines[1:-2]:
            require(len(row) == 4 and row[0] == 'CLASS' and row[1] not in loaded, 'CLASS protocol')
            expected_location = driver if row[1] == 'CliFactors' else overlay
            require(Path(unquote(urlparse(row[2]).path)).resolve() == expected_location.resolve()
                    and row[3] == origins.get(row[1]), 'loaded class identity/origin')
            loaded[row[1]] = {'location': row[2], 'sha256': row[3]}
        require(set(loaded) == set(origins), 'missing target class')
        require(len(ready) == 5 and ready[:3] == ['READY', '4294967296', '0']
                and ready[4] in ('0-1', '0,1'), 'READY memory/affinity')
        quota, period = map(int, ready[3].split())
        require(quota == 2 * period, 'READY CPU quota')
        require(len(result) == 17 and result[:3] == ['RESULT', '1', 'warmup'], 'RESULT protocol')
        require(int(result[11]) == 0 and 0 < int(result[12]) <= 1 << 32, 'compiler exit/memory peak')
        require(not any(events(result[13]).get(k, 0) for k in ('oom', 'oom_kill', 'oom_group_kill')),
                'inner OOM')
        digests = helper.digests(work, spec, work / 'protocol/1')
        require(digests == oracle, 'strict six digest DIFF')
        activation = read(sidecar)
        require(activation['schema'] == 'jsgo-java-transfer-activation-v1'
                and activation['diagnostic_only'] is True, 'sidecar schema')
        counts = activation['counters']
        require(set(counts) == set(source['counter_names']) and len(counts) == 12
                and all(type(v) is int and v >= 0 for v in counts.values()), 'counter inventory/type')
        checks = {
            'fsiv': counts['fsiv.eligibleFunctions'] >= counts['fsiv.backwardAnalyses'] > 0,
            'namespace': 0 < counts['namespace.chunkResolutions']
                <= counts['namespace.scopeResolutions'] < counts['namespace.traversalCollectCalls'],
            'coalesce': counts['coalesce.orIntoCalls'] > 0,
            'color': counts['color.lookupCalls'] > 0 and counts['color.cacheHits'] > 0
                and counts['color.cacheHits'] + counts['color.cacheMisses'] <= counts['color.lookupCalls'],
            'polyfill': counts['polyfill.getDefaultCalls'] > 1 and counts['polyfill.resourceParseCalls'] == 1,
        }
        require(all(checks.values()), 'not all five paths activated: ' + repr(checks))
        require(helper.input_identity(spec) == identity, 'inputs changed during diagnostic')
        require(helper.java_runtime_dependencies(JAVA_HOME) == dependencies, 'JDK dependencies changed')
        summary = {'status': 'PASS_DIAGNOSTIC_ACTIVATION_ONLY', 'task': args.task,
            'diagnostic_only': True, 'performance_claim': False, 'all_five_paths': checks,
            'activation': activation, 'six_digests': digests, 'loaded_classes': loaded,
            'READY': ready, 'VM': vm, 'RESULT_diagnostic_only': result,
            'container_exit': process.returncode, 'sidecar_sha256': sha(sidecar),
            'controller_seconds_diagnostic_only': time.monotonic() - started}
    except BaseException as error:
        failure = repr(error)
        save(root / 'failure.json', {'status': 'FAILED', 'error': failure, 'diagnostic_only': True})
    finally:
        if process is not None and process.poll() is None:
            try:
                os.killpg(process.pid, signal.SIGKILL)
                process.wait(timeout=20)
            except Exception as error:
                cleanup_errors.append('host client reap: ' + repr(error))
        # Exact owned name covers create-timeout after daemon creation but before cid capture.
        try:
            inspected = engine.call('inspect', owner, capture_output=True, text=True)
            row = json.loads(inspected.stdout)[0]
            require(row['Config']['Labels'].get('jsgo.transfer.diagnostic') == str(root)
                    and row['Config']['WorkingDir'] == str(work), 'cleanup ownership mismatch')
            require(cid is None or row['Id'] == cid, 'cleanup cid mismatch')
            engine.call('rm', '-f', row['Id'], stdout=subprocess.DEVNULL)
            engine.containers.discard(row['Id'])
        except subprocess.CalledProcessError as error:
            if cid is not None:
                cleanup_errors.append('owned container inspect/remove: ' + repr(error))
        except Exception as error:
            cleanup_errors.append('owned cleanup: ' + repr(error))
        try:
            remaining = engine.call('ps', '-a', '-q', '--filter',
                'label=jsgo.transfer.diagnostic=' + str(root), capture_output=True, text=True).stdout.strip()
        except Exception as error:
            remaining = 'UNVERIFIED'
            cleanup_errors.append('stopped inspect: ' + repr(error))
        after = outer()
        proof = {'owned_name': owner, 'owned_cid': cid, 'cleanup_errors': cleanup_errors,
            'remaining_owned_containers': remaining, 'engine_owned': sorted(engine.containers),
            'remaining_owned_client': process.pid if process is not None and process.poll() is None else None,
            'active_compilers': active(), 'outer_after': after, 'outer_OOM_delta': oom_delta(before, after)}
        save(root / 'stopped-proof.json', proof)
    require(not cleanup_errors and not proof['remaining_owned_containers']
            and not proof['engine_owned'] and proof['remaining_owned_client'] is None
            and not proof['active_compilers'] and not any(proof['outer_OOM_delta'].values()),
            'cleanup/OOM/stopped admission failed')
    require(failure is None and summary is not None, failure or 'missing summary')
    save(root / 'summary.json', summary)
    print(json.dumps({'status': summary['status'], 'task': args.task, 'out': str(root),
                      'performance_claim': False}))


if __name__ == '__main__':
    main()
