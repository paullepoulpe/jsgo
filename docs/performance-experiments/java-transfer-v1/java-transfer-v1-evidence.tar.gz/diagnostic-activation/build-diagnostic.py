#!/usr/bin/env python3
"""Root-owned diagnostic build. Never launch during the quiet timing sequence."""
import argparse, hashlib, json, os, re, subprocess, time
from pathlib import Path
ROOT = Path(__file__).resolve().parent
JAR = Path('/workspace/jsgo/.cache/closure-compiler-v20261015-maven.jar')
JAVA = '/usr/lib/jvm/java-21-openjdk-amd64/bin/java'
def sha(p): return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def save(p, value): p.write_text(json.dumps(value, indent=2) + '\n')
def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--root-grant', required=True, type=Path)
    args = parser.parse_args()
    manifest_path = ROOT / 'source-manifest.json'
    manifest = json.loads(manifest_path.read_text())
    grant = json.loads(args.root_grant.read_text())
    assert grant['source_manifest_sha256'] == sha(manifest_path)
    assert grant['quiet_benchmarks_finished'] is True
    assert 'diagnostic-build' in grant['allowed_stages']
    assert manifest['performance_claim'] is False and len(manifest['sources']) == 10
    assert sha(JAR) == manifest['published_jar_sha256']
    assert sha(manifest['base_all_build_proof']) == manifest['base_all_build_proof_sha256']
    sources = {}
    for rel, item in manifest['sources'].items():
        p = ROOT / 'src' / rel
        assert sha(p) == item['instrumented_sha256'], rel
        sources[rel] = p.read_text()
    dest = ROOT / 'build'
    assert not dest.exists(), 'Preserve prior diagnostic build; existing destination forbidden.'
    dest.mkdir(); (dest / 'src').mkdir(); (dest / 'classes').mkdir()
    paths = []; relocated = {}
    for rel, text in sources.items():
        text = re.sub(r'(?<![\w.])com\.google\.(common|auto|errorprone|gson|protobuf|j2objc|thirdparty)(?=\.)',
                      r'com.google.javascript.jscomp.jarjar.com.google.\1', text)
        out = dest / 'src' / rel; out.parent.mkdir(parents=True, exist_ok=True)
        out.write_text(text); relocated[rel] = sha(out); paths.append(str(out))
    flags = ['-source', '21', '-target', '21', '-g', '-proc:none', '-implicit:none', '-encoding', 'UTF-8']
    argv = [JAVA, '-Xmx1g', '-m', 'jdk.compiler/com.sun.tools.javac.Main', *flags,
            '-classpath', str(JAR), '-sourcepath', str(dest / 'src'), '-d', str(dest / 'classes'), *paths]
    meta = {'status': 'STARTED', 'diagnostic_only': True, 'performance_claim': False,
            'argv': argv, 'source_manifest_sha256': sha(manifest_path),
            'relocated_sources': relocated, 'started_unix': time.time()}
    save(dest / 'build.json', meta)
    env = dict(os.environ)
    for key in ('JAVA_TOOL_OPTIONS', '_JAVA_OPTIONS', 'JDK_JAVA_OPTIONS'): env.pop(key, None)
    with (dest / 'stdout').open('wb') as out, (dest / 'stderr').open('wb') as err:
        result = subprocess.run(argv, stdout=out, stderr=err, env=env, timeout=180)
    meta.update(status='PASS' if result.returncode == 0 else 'FAILED', exit=result.returncode,
                ended_unix=time.time(), classes={str(p.relative_to(dest / 'classes')): sha(p)
                    for p in sorted((dest / 'classes').rglob('*.class'))})
    save(dest / 'build.json', meta)
    print(json.dumps({'status': meta['status'], 'class_count': len(meta['classes']),
                      'diagnostic_only': True, 'root': str(dest)}))
    raise SystemExit(result.returncode)
if __name__ == '__main__': main()
