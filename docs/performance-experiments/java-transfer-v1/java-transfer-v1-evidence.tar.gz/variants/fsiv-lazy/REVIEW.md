# FSIV lazy backward-use analysis

Status: source prepared only. No javac, Java process, benchmark or runtime gate was run by this worker. There is no measured speed or memory claim.

The sole production source is the exact pinned v20261015 `FlowSensitiveInlineVariables.java` with the attached patch. The original extracted source remains untouched. `source-manifest.json` pins the original, candidate and patch SHA256 values.

The existing forward definition analysis, candidate gathering and `canInline` rejection order remain unchanged. After gathering, `reachingUses` resets to null for this function. An empty candidate set returns. The first candidate that reaches the original backward-use query initializes and analyzes the full original variable map; every later candidate reuses that analysis. No candidate-only projection, predicate reordering, CFG reuse across functions or pooling is included. Escaped variables and the full map are passed explicitly through the private `canInline` method, avoiding new retained pass fields or supplier allocations.

A successful inline cannot occur before the first use query: the only `inlineVariable()` call remains after `canInline` returns true. Thus lazy construction precedes the first AST mutation, and the analysis sees the same CFG and AST as the eager version. Later mutations continue using the same analysis as stock, preserving its existing conservative dependency handling. Candidate iteration/removal order is unchanged. The analysis still overwrites the same private CFG annotations when needed.

The empty candidate guard and omitted unused analysis can bypass failures that only the unused analysis would throw (for example the data-flow iteration bound on pathological CFGs). Strict stdout/stderr/exit parity tests must include failure cases; this source review does not establish universal error-path equivalence. Existing scope callbacks and candidate checks have not been reordered.

## Prepared focused probe

`probe-src/com/google/javascript/jscomp/FsivLazyProbe.java` is a standalone package-local probe using the public parser plus Normalize and the FSIV pass. It is uncompiled and unrun. Compile separately from production classes against the pinned jar, then run it with classpath ordering that selects stock or patched production classes and the matching argument `stock` or `lazy`.

It covers seven fixtures: no candidates, side-effect rejection, loop rejection, successful single inlining, dependent candidates, rejection followed by success, and state reset between functions. The first two tab-separated output columns (fixture name and Base64 compiler output) must match byte-for-byte between stock and variant. The third column confirms whether the backward analysis was actually instantiated. The probe checks its expected presence internally, but those fixture expectations remain unverified until root executes it.

Root should additionally run the original FlowSensitiveInlineVariables tests and representative ADVANCED output/diagnostic gates, including nested functions, captured variables, block shadowing, destructuring, optional-chain control flow, loops and side-effect ordering. The focused probe is an activation and narrow correctness aid, not a full parity suite or an end-to-end performance measurement.
