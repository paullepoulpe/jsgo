package com.google.javascript.jscomp.disambiguate;

import com.google.common.collect.ImmutableSet;
import com.google.javascript.jscomp.colors.Color;
import com.google.javascript.jscomp.colors.ColorId;
import com.google.javascript.jscomp.colors.ColorRegistry;
import com.google.javascript.jscomp.colors.StandardColors;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;

/** Standalone semantic probe; run unchanged against stock and candidate classpaths. */
public final class ColorGraphNodeFactoryCacheProbe {
  private static void check(boolean condition, String description) {
    if (!condition) {
      throw new AssertionError(description);
    }
  }

  private static Color color(String id) {
    return Color.singleBuilder().setId(ColorId.fromAscii(id)).build();
  }

  public static void main(String[] args) {
    ColorRegistry registry = ColorRegistry.builder().setDefaultNativeColorsForTesting().build();
    ColorGraphNodeFactory factory = ColorGraphNodeFactory.createFactory(registry);
    ColorGraphNode unknown = factory.createNode(null);
    check(unknown.getIndex() == 0, "unknown retains initial ID");
    check(factory.createNode(StandardColors.UNKNOWN) == unknown, "null/unknown canonicalization");
    check(factory.createNode(StandardColors.NULL_OR_VOID) == unknown, "null-or-void canonicalization");

    ColorGraphNode number = factory.createNode(StandardColors.NUMBER);
    check(number.getIndex() == 1, "primitive first miss preserves insertion ID");
    check(number.getColor() == registry.get(StandardColors.NUMBER_OBJECT_ID), "primitive boxing");
    check(factory.createNode(registry.get(StandardColors.NUMBER_OBJECT_ID)) == number,
        "primitive and boxed color converge");
    Color nullableNumber = Color.createUnion(ImmutableSet.of(StandardColors.NUMBER,
        StandardColors.NULL_OR_VOID));
    check(factory.createNode(nullableNumber) == number, "nullable primitive collapses to box");
    check(factory.createNode(nullableNumber) == number, "repeated nullable primitive");

    Color a = color("cacheA");
    Color b = color("cacheB");
    ColorGraphNode nodeA = factory.createNode(a);
    ColorGraphNode nodeB = factory.createNode(b);
    check(nodeA.getIndex() == 2 && nodeB.getIndex() == 3, "singleton insertion IDs");
    Color abNullable = Color.createUnion(ImmutableSet.of(a, b, StandardColors.NULL_OR_VOID));
    Color ab = Color.createUnion(ImmutableSet.of(b, a));
    ColorGraphNode union = factory.createNode(abNullable);
    check(union.getIndex() == 4, "union first miss insertion ID");
    check(factory.createNode(abNullable) == union, "same original union identity repeats");
    check(factory.createNode(ab) == union, "distinct equivalent union converges");
    check(factory.createNode(Color.createUnion(ImmutableSet.of(a, b))) == union,
        "new equal union converges through canonical cache");
    check(factory.createNode(color("cacheA")) == nodeA,
        "distinct equal singleton converges through canonical cache");
    List<ColorGraphNode> ordered = new ArrayList<>(factory.getAllKnownTypes());
    check(ordered.equals(List.of(unknown, number, nodeA, nodeB, union)),
        "cache hits neither add nodes nor reorder IDs");

    Color differentNumber = Color.singleBuilder().setId(StandardColors.NUMBER_OBJECT_ID)
        .setInvalidating(true).build();
    ColorRegistry otherRegistry = ColorRegistry.builder().setDefaultNativeColorsForTesting()
        .setNativeColor(differentNumber).build();
    ColorGraphNodeFactory otherFactory = ColorGraphNodeFactory.createFactory(otherRegistry);
    ColorGraphNode otherNumber = otherFactory.createNode(StandardColors.NUMBER);
    check(otherNumber != number && otherNumber.getColor() == differentNumber,
        "no cross-factory/registry cache leak");
    check(otherNumber.getIndex() == 1, "fresh factory IDs restart");

    LinkedHashMap<Color, ColorGraphNode> externalMap = new LinkedHashMap<>();
    externalMap.put(StandardColors.UNKNOWN, ColorGraphNode.create(StandardColors.UNKNOWN, 0));
    ColorGraphNodeFactory externalFactory = new ColorGraphNodeFactory(externalMap, registry);
    ColorGraphNode oldA = externalFactory.createNode(a);
    ColorGraphNode replacementA = ColorGraphNode.create(a, 42);
    externalMap.put(a, replacementA);
    check(externalFactory.createNode(a) == replacementA && oldA != replacementA,
        "protected constructor preserves caller-owned map mutation");

    ColorGraphNodeFactory missingRegistry = ColorGraphNodeFactory.createFactory(null);
    for (int i = 0; i < 2; i++) {
      boolean failed = false;
      try {
        missingRegistry.createNode(StandardColors.NUMBER);
      } catch (NullPointerException expected) {
        failed = true;
      }
      check(failed, "failed normalization is not cached as a success");
      check(missingRegistry.getAllKnownTypes().size() == 1,
          "failed normalization does not publish a graph node");
    }
    System.out.println("PASS color cache semantic probe");
  }
}
