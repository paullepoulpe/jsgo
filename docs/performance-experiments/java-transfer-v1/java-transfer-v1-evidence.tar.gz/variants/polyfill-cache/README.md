Source-only Java experiment: shared immutable default polyfill table

Status: PREPARED, UNBUILT, UNRUN. No performance or memory result exists.
Only this variant directory was written; pinned cache/oracle/source files are untouched.

Four exact v20261015 source files were copied from /workspace/jsgo/.cache/closure-src.
`original/` preserves their bytes; `src/` contains the candidate and `production.patch`
is a unified patch rooted at the source package paths. `source-manifest.json` records
per-file original/candidate hashes and the source-jar expected pin (not a new archive hash).

Change

`PolyfillUsageFinder.Polyfills.getDefault()` lazily memoizes the result of loading and
parsing js/polyfills.txt. RemoveUnusedCode, RewritePolyfills and IsolatePolyfills use
that factory for their default table. Their per-pass maps, ASTs and compiler state remain
separate. Explicit `fromTable` and the injected-table constructors are unchanged.

Guava Suppliers.memoize was chosen over initialization-on-demand holder parsing:
success is safely published once; failed resource loads/parses are not cached and are
retried. RuntimeException/IllegalArgumentException from the resource/parser therefore
remain direct failures, rather than becoming ExceptionInInitializerError followed by
NoClassDefFoundError for a poisoned holder. Error stack frames necessarily differ.
The Supplier instance is initialized with the Polyfills class; resource IO/parse happens
only on getDefault(), so explicit custom fromTable calls do not read the default resource.

The cache belongs to the defining Polyfills class/classloader. It does not cross loader
boundaries or retain compiler/extern/AST state. All original lookup anchors and the new
anchor have package com.google.javascript.jscomp; for the normal pinned distribution they
resolve the same package-relative resource. Custom split-package or instrumented loaders
that distinguish class anchors, resource mutation after a successful read, or agents that
change the resource dynamically are outside the claimed resource-equivalence boundary.

Immutability proof from the pinned source

- Polyfills is final; all four instance fields are private final Guava ImmutableMap,
  ImmutableMultimap or ImmutableSet. Builders are local and are discarded at construction.
- Every entry value is a final Polyfill whose instance fields are final Strings and Kind
  enum values; keys/suffixes/version strings are immutable Strings.
- No field can retain Node, AbstractCompiler, SourceFile, pass, traversal or mutable builder.
- getPolyfillsNewerThan creates a fresh result builder/list; it never writes into the table.
- Finder traversal only reads statics/methods/suffixes. Rewrite/Isolate consume immutable
  Polyfill fields and create their own usage, injection, visited-node and library state.
- Iteration order follows the same existing builders and exact resource bytes; no sorting,
  deduplication, filtering or parsing change is made.

Potential tradeoff: one table remains live for the classloader lifetime; it replaces
repeated load/parse allocations in one JVM. Cold startup, retained heap, speed and RSS
are unknown until measured. This intentionally changes the amount of immutable metadata
setup performed by Java, so report it as an optimized Java variant, separately from stock.
It does not add a worker or a parsed-extern cache.

Prepared controls (not executed)

`test/com/google/javascript/jscomp/PolyfillsDefaultCacheTest.java` is a standalone main
with four candidate-only controls (the added factory does not exist in stock): concurrent first default requests; ordered query values versus a
fresh table loaded using an original resource anchor; all three default constructors
sharing only the table across two compiler instances; and explicit injected-table,
malformed custom parse and default-isolation behavior. It uses the real Compiler.initOptions
setup before constructors and contains no JUnit dependency. Successful initialization
is the only resource path covered by this source control; missing/IO-failure retry and
separate-classloader isolation still need future controlled-loader tests if required.

Future validation, under root's serial runtime grant: compile the four candidate files
and the test in an isolated output directory using the established pinned dependency/
shading setup; overlay all generated nested classes too (especially Polyfills and its
supplier lambda call site), not only the four top-level .class files; run the test in a fresh JVM; run upstream polyfill/RUC pass tests if their
fixtures are available; then strict byte gates and interleaved stock/candidate same-session
warm-JVM timing/RSS. First parse must still occur within that JVM's warmup window; do not
preinitialize only one variant. Do not merge this Java experiment into the stock oracle.
