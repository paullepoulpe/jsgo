#!/usr/bin/env python3
"""Render reviewed CLOSED Java evidence; source prepared, never run by its author.

Default is prepare-only. --execute reads JSON/text and changes report files only.
It does not import runners or compute intervals, hashes, builds, timing or archives.
Root must independently review the rendered report before granting publication.
"""
import argparse
import json
from pathlib import Path
import shutil
import sys

sys.dont_write_bytecode = True
ROOT = Path('/workspace/jsgo-java-experiments/transfer-v1')
REPORT = ROOT/'report'
ANALYSIS = 'results/confirmation-analysis-v1/analysis.json'
DIAGNOSTIC = 'diagnostic-activation/results-review-v1.json'
HWM_AMENDMENT = 'results/review-telemetry-amendment-v1/amendment.json'
FAILED_COLOR_REVIEW = 'reviews/confirm-bigquery-stock-color-cache-v1-review-v1-failed/review.json'
HWM_DOCUMENTATION = 'bench/proc-status-documentation-v2.json'
JOBS = {'confirm-bigquery-stock-color-cache-v1': ('color-cache', 3),
        'confirm-bigquery-stock-all-v1': ('ALL', 3),
        'confirm-bundle-stock-all-v1': ('ALL', 1)}
SCREENS = ['screen-bigquery-stock-control-v4', 'screen-bigquery-control-all-v1',
           'screen-bigquery-control-fsiv-lazy-v1', 'screen-bigquery-control-namespace-lazy-v1',
           'screen-bigquery-control-color-cache-v1', 'screen-bigquery-control-coalesce-bitset-v1',
           'screen-bigquery-control-polyfill-cache-v1']
METRICS = [('median_wall', 'Median wall time (primary)'), ('mean_wall', 'Mean wall time'),
           ('median_CPU', 'Median process CPU'), ('mean_CPU', 'Mean process CPU'),
           ('lifetime_HWM', 'Max observed approximate VmHWM RSS'),
           ('median_allocated_bytes', 'Median allocated bytes')]

def require(ok, message):
    if not ok:
        raise ValueError(message)

def read(path):
    return json.loads(Path(path).read_text())

def write(path, value):
    Path(path).write_text(json.dumps(value, indent=2, allow_nan=False) + '\n')

def value(number):
    return 'unavailable' if number is None else str(number)

def interval(obj):
    return 'unavailable' if obj is None else '[' + value(obj['lower']) + ', ' + value(obj['upper']) + ']'

def raw(numbers):
    return ', '.join(value(x) for x in numbers)

def table(headers, rows):
    return ('| ' + ' | '.join(headers) + ' |\n| ' + ' | '.join('---' for _ in headers) + ' |\n'
            + ''.join('| ' + ' | '.join(str(x) for x in row) + ' |\n' for row in rows) + '\n')

def stopped(result):
    receipt = read(result/'stopped-proof.json')
    for key in ('cleanup_errors', 'remaining_owned_containers', 'active_compilers',
                'remaining_owned_driver_processes'):
        require(receipt[key] == [], 'not stopped: ' + str(result) + ':' + key)
    require(all(receipt['outer_OOM_delta'].get(k) == 0
                for k in ('oom', 'oom_kill', 'oom_group_kill')), 'new OOM: ' + str(result))

def review(name, baseline, candidate, cohorts):
    result = ROOT/'results'/name
    item = read(ROOT/'reviews'/name/'review.json')
    require(item['status'] == 'PASS independent Java-factor review', 'review not PASS: ' + name)
    require(item['baseline'] == baseline and item['candidate'] == candidate, 'review variants: ' + name)
    require(item['cohorts'] == cohorts and item['pairs_per_cohort'] == 5
            and item['measured_requests'] == cohorts * 10
            and item['strict_digests_every_request'] == 6, 'review counts: ' + name)
    require(item['Java_vs_Go_claim'] is False, 'unexpected Go claim')
    summary = read(result/'summary.json')
    require(summary['status'] == 'PASS settled byteidentical Java-vs-Java'
            and summary['complete'] is True, 'underlying summary incomplete: ' + name)
    stopped(result)
    return item

def load():
    sequence = read(ROOT/'confirmation-sequence-v1.json')
    require('finished_unix' in sequence and not any(x in sequence for x in
            ('active', 'failed', 'review_failed')), 'confirmation sequence not closed')
    require(len(sequence['completed']) == 3 and {x['name'] for x in sequence['completed']} == set(JOBS),
            'three planned confirmation jobs required')
    analysis = read(ROOT/ANALYSIS)
    require(analysis['status'] == 'COMPLETE preselected freshholdout analysis', 'final analysis missing')
    require(set(analysis['comparisons']) == {'color-cache', 'ALL'}, 'preselected comparison set')
    require(analysis['Java_vs_Go_claim'] is False, 'analysis Go claim')
    final_reviews = {name: review(name, 'STOCK', candidate, n) for name, (candidate, n) in JOBS.items()}
    for candidate, item in analysis['comparisons'].items():
        require(item['screen_observations_pooled'] == 0 and len(item['cohort_rows']) == 3,
                'holdout pooled screens/incomplete: ' + candidate)
        metric = item['metrics']['median_wall']
        adjusted = metric['bonferroni_family95_log_t_candidate_over_STOCK']
        require(metric['familywise_supported_reduction'] is (adjusted['upper'] < 1),
                'primary flag/adjusted interval mismatch')
    bundle = analysis['bundle_external_validity']
    require(bundle['status'] == 'ONE_COHORT_EXTERNAL_VALIDITY_SCREEN_NOT_CONFIRMATION'
            and bundle['pooled_into_BigQuery'] is False and bundle['confidence_interval'] is None,
            'bundle must remain a separate one-cohort screen')
    screens = []
    for name in SCREENS:
        item = read(ROOT/'reviews'/name/'review.json')
        screens.append((name, review(name, item['baseline'], item['candidate'], 1)))
    diag = read(ROOT/DIAGNOSTIC)
    require(diag['status'] == 'PASS_INDEPENDENT_RECEIPT_REVIEW_ONLY'
            and diag['diagnostic_only'] is True and diag['performance_claim'] is False,
            'diagnostic review failed/mislabelled')
    for item in diag['results'].values():
        require(all(item['all_five_paths_recomputed'].values()), 'activation not established')
        for key in ('strict_stock_six_digest_receipts_match',
                    'source_jar_driver_overlay_origin_receipts_match',
                    'input_manifest_matches_stock_oracle', 'caps_exit_zeroOOM_stopped_receipts_match'):
            require(item[key] is True, 'diagnostic receipt failed: ' + key)
    amendment = read(ROOT/HWM_AMENDMENT)
    require(amendment['status'] == 'V2_FULL_REVIEW_PASS_NO_MEASUREMENT_CHANGED',
            'post hoc amendment has not completed full v2 review')
    accepted_color_review = final_reviews['confirm-bigquery-stock-color-cache-v1']
    require(accepted_color_review['reviewer_version'] == 'v2-warmup-VmHWM-amendment'
            and len(accepted_color_review['telemetry_anomalies']) == 1,
            'accepted color review lacks the recorded v2 anomaly policy')
    require(amendment['telemetry_anomalies'] == accepted_color_review['telemetry_anomalies'],
            'accepted review/amendment anomaly records differ')
    old_review = read(ROOT/FAILED_COLOR_REVIEW)
    require(old_review['status'] == 'FAIL independent Java-factor review', 'original failed review missing')
    require(amendment['benchmark_runner_flags_inputs_and_raw_values_changed'] is False,
            'telemetry review amendment must not change the benchmark')
    observed = amendment['observed']
    require(observed['kind'] == 'warmup' and observed['cohort'] == 3
            and observed['variant'] == 'STOCK' and observed['drop_KiB'] == 60
            and observed['later_final_HWM_KiB'] > observed['previous_HWM_KiB'],
            'amendment must describe the recorded superseded warmup-only anomaly')
    for path in [HWM_DOCUMENTATION, 'results/review-telemetry-amendment-v1/sequence-at-failure.json',
                 'results/review-telemetry-amendment-v1/original-review-failure.json', 'confirm_resume.py']:
        require((ROOT/path).is_file(), 'missing post hoc review history: ' + path)
    # Fail before changing report if any intended browse copy is unavailable.
    for path in ['results/confirmation-analysis-v1/comparisons.csv',
                 'results/confirmation-analysis-v1/cohort-ratios.csv',
                 'variants/java-upstream-readiness-v1.md']:
        require((ROOT/path).is_file(), 'missing final source: ' + path)
    return analysis, final_reviews, screens, diag, amendment

def render(analysis, final_reviews, screens, diag, amendment):
    supported = [name for name, item in analysis['comparisons'].items()
                 if item['metrics']['median_wall']['bonferroni_family95_log_t_candidate_over_STOCK']['upper'] < 1]
    require(set(supported) == set(analysis['primary_family']['supported_candidates']), 'analysis family finding')
    if supported:
        finding = ('On generated BigQuery, ' + ', '.join(supported)
                   + ' cleared the prespecified familywise-adjusted median-wall criterion against stock Java. '
                   'This is a workload-specific result under the stated three-cohort log-effect assumptions.')
    else:
        finding = ('Neither selected candidate cleared the prespecified familywise-adjusted median-wall '
                   'criterion against stock Java. The promising single-cohort screens therefore do not '
                   'establish a reliably faster warm Java compiler on this workload.')
    text = finding + '\n\n'
    text += ('These are Java-versus-Java experiments on Closure Compiler v20261015, with fresh compiler '
             'construction and normal extern parsing on every request. They do not update any Go result '
             'or establish a new Java/Go ratio. Root review is required before publication.\n\n'
             'Download the [complete evidence archive](java-transfer-v1-evidence.tar.gz), '
             '[screen data](completed-screens.json), [final analysis](confirmation-analysis.json), '
             '[comparison CSV](confirmation-comparisons.csv) and [raw cohort ratios](confirmation-cohort-ratios.csv). '
             'Receipt paths shown in code below are paths inside the evidence archive, not web links.\n\n')
    text += ('BigQuery uses ADVANCED with dependency pruning: 1,270 supplied input files total '
             '22,180,254 bytes, including 1,209 JavaScript sources totaling 21,607,844 bytes and '
             '227 generated protobuf-model JavaScript files. The retained manifest has 251 inputs; '
             'the emitted JavaScript is 161,467 bytes. Supplied bytes therefore overstate the '
             'retained application size. The separate ADVANCED bundle contains 11 pinned library '
             'inputs totaling 5,677,811 bytes (including Three.js, Lodash, React DOM, RxJS, D3, '
             'Moment, Vue, jQuery, Handlebars, Immutable and Underscore). Both use compiler N=1 '
             'inside the same two-CPU, 4 GiB limits. These workloads do not cover every large '
             'chunked enterprise build.\n\n')
    factors = [
      ['[Lazy FSIV analysis](patches/fsiv-lazy.patch)', 'Initialize backward use analysis only at the original use query; full variable map and candidate order unchanged.', 'Initialization precedes first successful inline. Skipping unused analysis may omit its pathological error; broader failure-path parity is unproved.'],
      ['[Lazy namespace context](patches/namespace-lazy.patch)', 'Request Scope/JSChunk only after existing irrelevant-token/name exits; preserve explicit incremental context.', 'Custom compiler callbacks or input errors may observe changed getter timing; full extension equivalence is unproved.'],
      ['[BitSet interference](patches/coalesce-bitset.patch)', 'Bulk-OR live sets instead of repeatedly setting variable pairs.', 'Upper triangle/diagonal/order preserved; extra lower bits unobserved. Rows do not alias lattice storage; ordinary analysis caps at 100 variables.'],
      ['[Color identity cache](patches/color-cache.patch)', 'Per-factory cache before repeated normalization; protected external-map constructor remains uncached.', 'Preserve canonical insertion/IDs and errors; extra retained original-color entries may increase memory.'],
      ['[Default polyfill table](patches/polyfill-cache.patch)', 'Lazily share immutable resource metadata; custom table injection unchanged.', 'No compiler/AST/extern cache. One table remains per classloader; successful resource immutability and normal loader anchors assumed.']]
    text += table(['Factor', 'Change', 'Boundary'], factors)
    text += ('[ALL](patches/all.patch) combines all five over nine disjoint production source files. '
             'STOCK is the unchanged published jar; CONTROL recompiles those same nine source families '
             'with matched flags/relocation, and every factor uses the same compiler setup. '
             'CONTROL/STOCK is an experimental-artifact control, not a fixed rebuilding penalty to subtract '
             'from another cohort. Final holdouts compare candidates directly with STOCK.\n\n')
    text += 'Exploratory BigQuery screens: one pair of JVMs and five measured pairs each; no confidence intervals.\n\n'
    screen_rows = []
    for name, r in screens:
        c = r['per_cohort'][0];base = c['variants'][r['baseline']];new = c['variants'][r['candidate']]
        q = c['candidate_over_baseline']
        screen_rows.append([r['candidate'] + ' / ' + r['baseline'], q['elapsed'],
                            new['wall_seconds']['mean']/base['wall_seconds']['mean'], q['CPU'],
                            q['RSS_lifetimeHWM'], value(q.get('allocated_bytes'))])
    text += table(['Candidate / baseline', 'Median wall ratio', 'Mean wall ratio (sensitivity)',
                   'Median CPU ratio', 'Max observed approximate VmHWM ratio', 'Median allocated-byte ratio'], screen_rows)
    text += ('All ratios use candidate/baseline; below1 means lower cost. Means, medians of paired ratios '
             'and ratios of medians are different estimators. Namespace and ALL screen reductions weaken '
             'under mean-wall sensitivity; bitset changes direction. All five factors, neutral/negative '
             'screens and ALL are retained. Sampled RSS reductions from one JVM pair have no significance '
             'claim, and factor percentages cannot be added or multiplied.\n\n')
    text += 'Prespecified BigQuery holdouts: two selected candidates, three fresh independent paired-JVM cohorts each, five measured pairs per cohort; no screen rows pooled.\n\n'
    primary_rows = []
    for name in ['color-cache', 'ALL']:
        m = analysis['comparisons'][name]['metrics']['median_wall']
        primary_rows.append([name, raw(m['candidate_over_STOCK']['raw']),
                            m['candidate_over_STOCK']['geomean'],
                            interval(m['bonferroni_family95_log_t_candidate_over_STOCK']),
                            m['STOCK_over_candidate']['geomean'],
                            interval(m['bonferroni_family95_log_t_STOCK_over_candidate']),
                            'cleared adjusted criterion' if m['familywise_supported_reduction'] else 'did not clear adjusted criterion'])
    text += table(['Candidate', 'All 3 raw candidate/STOCK median-wall ratios', 'Geometric mean',
                   'Familywise 95% adjusted interval', 'Inverse STOCK/candidate', 'Inverse adjusted interval', 'Finding'], primary_rows)
    text += ('The overall finding uses adjusted upper bound < 1, not the most favorable screen or unadjusted interval. '
             'Bonferroni covers two prespecified median-wall comparisons: individual 97.5% log-t intervals '
             'with 2 degrees of freedom. Three cohort effects are the inference units; persistent-JVM requests are correlated. '
             'Log-t assumes independent approximately normal log effects, which three cohorts cannot test. '
             'Whole-cohort bootstrap intervals are discrete and confined to the three observed cohorts.\n\n')
    for name in ['color-cache', 'ALL']:
        text += name + ': all metrics and interval sensitivity\n\n'
        rows = []
        for key, label in METRICS:
            m = analysis['comparisons'][name]['metrics'].get(key)
            if m is None:
                rows.append([label] + ['unavailable']*7);continue
            rows.append([label, raw(m['candidate_over_STOCK']['raw']), m['candidate_over_STOCK']['geomean'],
                         interval(m['bootstrap95_candidate_over_STOCK']), interval(m['log_t95_candidate_over_STOCK']),
                         m['STOCK_over_candidate']['geomean'], interval(m['bootstrap95_STOCK_over_candidate']),
                         interval(m['log_t95_STOCK_over_candidate'])])
        text += table(['Metric', 'All 3 raw candidate/STOCK ratios', 'Geometric mean', 'Bootstrap 95%',
                       'Log-t 95%', 'Inverse STOCK/candidate', 'Inverse bootstrap 95%', 'Inverse log-t 95%'], rows)
    text += ('Mean wall/CPU, RSS and allocation are descriptive sensitivities, not additional adjusted '
             'confirmatory endpoints. No memory significance claim is inferred from a screen or selected '
             'secondary interval. All exact analysis values are copied without recomputing intervals.\n\n')
    text += 'Exact absolute measured statistics for each holdout JVM\n\n'
    abs_rows = []
    for job in JOBS:
        r = final_reviews[job]
        for cohort in r['per_cohort']:
            for variant, v in cohort['variants'].items():
                abs_rows.append([job, cohort['cohort'], variant, v['wall_seconds']['median'],
                                 v['wall_seconds']['sample_SD'], v['CPU_seconds']['median'],
                                 v['CPU_seconds']['sample_SD'], v['final_lifetime_HWM_MiB'],
                                 v['current_RSS_MiB']['median'], v['current_RSS_MiB']['sample_SD'],
                                 value(v['allocated_bytes']['median'] if v['allocated_bytes'] else None),
                                 value(v['allocated_bytes']['sample_SD'] if v['allocated_bytes'] else None),
                                 v['warm_requests']])
    text += table(['Archive result job', 'Cohort', 'Variant', 'Wall median s', 'Wall sample SD s',
                   'CPU median s', 'CPU sample SD s', 'Max observed approximate VmHWM MiB', 'Current RSS median MiB',
                   'Current RSS sample SD MiB', 'Allocated median bytes', 'Allocated sample SD bytes', 'Warm requests'], abs_rows)
    text += ('Each absolute median/SD uses five measured requests in that JVM. The RSS summary is the maximum '
             'observed approximate /proc VmHWM across warmup, JIT and measurement, not an exact physical '
             'lifetime peak. Legacy JSON fields retain their original HWM names. There is no per-request '
             'peak SD or proved accuracy bound. Intervals describe this approximate telemetry, not bounded '
             'error in true memory usage. Current RSS is an approximate '
             'post-request snapshot; cgroup peak includes charged cache/helpers. Allocated bytes '
             'are ThreadMXBean totals with management-boundary overhead, not live heap or RSS. '
             'Exact exploratory absolute samples/statistics remain in completed-screens.json.\n\n')
    bundle = analysis['bundle_external_validity']['raw_cohort']
    text += 'Bundle transfer check: one cohort, external-validity screen only; no CI and not pooled into BigQuery.\n\n'
    text += table(['Metric', 'ALL / STOCK ratio'], [[key, v] for key, v in bundle['ratios'].items()])
    text += ('Bundle absolute JVM values are in the preceding table. One cohort cannot establish '
             'significance or a universal workload improvement.\n\n')
    text += 'Separate instrumented ALL diagnostics: activation, not timing evidence\n\n'
    counts = diag['results'];counter_names = list(counts['bigquery']['counters'])
    text += table(['Counter', 'BigQuery', 'Bundle'], [[key, counts['bigquery']['counters'][key],
                  counts['bundle']['counters'][key]] for key in counter_names])
    text += ('All five paths activated on both workloads with matching six artifact/provenance/cap/stopped '
             'receipts. FSIV eligible counts are visits, not necessarily unique functions. These two '
             'instrumented requests were outside timings and are never used to estimate speed or memory benefit. '
             'Archive receipt: `' + DIAGNOSTIC + '`.\n\n')
    observed = amendment['observed']
    text += ('Post hoc telemetry-review amendment\n\n'
             'The color three-cohort benchmark runner completed successfully, but the original strict '
             'independent reviewer failed on STOCK cohort 3: reported VmHWM fell by '
             + str(observed['drop_KiB']) + ' KiB between warmup requests 7 and 8 ('
             + str(observed['previous_HWM_KiB']) + ' to ' + str(observed['HWM_KiB']) + ' KiB). '
             'The later maximum was ' + str(observed['later_final_HWM_KiB']) + ' KiB ('
             + str(observed['later_final_HWM_KiB']/1024) + ' MiB), strictly above the earlier sample. '
             'The numeric maximum, raw six-digest rows, timing and cgroup peak were unchanged.\n\n'
             'After observing this anomaly, the review policy was amended to permit only recorded '
             'warmup-only VmHWM dips later strictly exceeded. Measured VmHWM dips and any cgroup '
             'memory.peak dip remain fatal; every independent admission check was rerun. This was a '
             'post hoc REVIEW amendment, not a prespecified rule or benchmark-protocol tuning. The '
             'benchmark runner, flags, inputs and raw values were unchanged. Linux documents VmHWM '
             'as inaccurate; the exact cause and numerical error bound remain unproved. The absence '
             'of a change in this maximum does not establish precise RSS measurement.\n\n'
             'The original failed review and failed progress snapshot remain archive evidence at `'
             + FAILED_COLOR_REVIEW + '` and `results/review-telemetry-amendment-v1/`. The fixed plan '
             'resumed through `confirm_resume.py`; the mutable confirmation sequence retains the final '
             'closed state while its failure-time snapshot is preserved. The amendment note now records '
             'the completed full v2 PASS and links its accepted review and reviewer hashes. '
             'Documentation receipt: `' + HWM_DOCUMENTATION + '`.\n\n')
    text += ('Correctness and upstream readiness\n\n'
             'All seven compiled overlays and the shared driver have build receipts; focused probes passed '
             'for all five factors (coalescing: 1,497 actual-helper cases; polyfill: 4 controls). '
             'Every admitted warmup and measurement passed the stock stdout/stderr/exit/JS/map/manifest '
             'digests. Full upstream Closure suites, broad custom-extension behavior and universal error-path '
             'equivalence have not been run or established. ALL inherits each factor’s limitations above. '
             'Read the [historical upstream-readiness review](upstream-readiness.md), written before these '
             'holdouts; its pending-screen interpretations do not override the completed analysis here.\n\n'
             'Failure and recovery history\n\n'
             'The absent javac launcher attempt has retained directories but no build.json or captured '
             'exit value; no missing receipt is invented. The subsequent --release 21 attempt failed with '
             'exit 2 because release 21 support was unavailable (root diagnosed missing ct.sym). Matched '
             'Java21 compiler-module -source 21/-target 21 builds then passed; neither failure is silently '
             'converted to a factor-source result.\n\n'
             'STOCK/CONTROL screen v1 and v2 were rejected by the parent-memory guard with zero new OOM '
             'and clean stopped receipts. Before a retry, recorded POSIX_FADV_DONTNEED reclaimed file-cache '
             'pressure without changing content; it is not compiler RSS or GC tuning. v3 failed at initial '
             'memory.pressure lookup; no benchmark summary/stopped receipt exists for it, and missing PSI '
             'cannot be called zero. Completed runs use the frozen cache-aware-v3-PSIoptional policy, '
             'with measured local/direct-reclaim/available fault checks as proxies. PSI remained unavailable; '
             'absence of pressure is not proved. Historical aggregate OOM counters are distinct from new deltas.\n\n'
             'Color’s underlying screen runner exited 0 and independent review passed despite a failed outer '
             'sequence wrapper after transport loss. Its successful byte/cleanup evidence is retained alongside '
             'the failed wrapper; a final stdout-write failure is inferred, not proven. Remaining factors '
             'restarted with durable logs. Archive paths: `results/transport-recovery-v1.json`, '
             '`results/cache-reclaim-before-screen-v1.json`, `screen-sequence-v1.json`, '
             '`build/control-launcher-missing/` and `build/control-release-missing/`.\n\n'
             'Open work\n\n'
             'Memoizing immutable Color.hashCode is an explicitly unimplemented, unmeasured idea: first '
             'profile actual repeated hash work and verify immutability/equality/ownership, then test and '
             'measure any patch separately. Other open work includes upstream pass/error/custom-callback '
             'suites, dense coalescing workloads, retained-heap measurements for caches, more independent '
             'JVM cohorts and additional generated/large/chunked workloads. Existing factor screens do not '
             'justify assuming any unmeasured interaction or new gain.\n\n'
             'Method: same JDK 21, -Xmx3g and default collector, with actual 4 GiB / 2 CPUs per JVM, alternating sequential '
             'requests, matched 12–90 warmups, unchanged drift/JIT/spread criteria, fresh compiler/normal '
             'extern parsing every request, strict six digests and zero-new-OOM/stopped evidence. The inactive '
             'JVM is paused but its pages remain charged. No worker, extern AST or result cache is introduced. '
             'See [methodology](methodology.md), [evidence index](evidence-index.json) and the archive’s raw '
             'records. Paths require remapping and external pinned JDK/jar/corpus inputs; [reproduction '
             'notes](REPRODUCE.md) accompany the published snapshot.\n')
    return text, supported

def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--execute', action='store_true')
    args = parser.parse_args()
    if not args.execute:
        print('PREPARED ONLY: final analysis/reviews and root execution are required; report unchanged.')
        return
    require(Path(__file__).absolute() == ROOT/'finalize_report.py', 'exact experiment root required')
    analysis, final_reviews, screens, diag, amendment = load()
    text, supported = render(analysis, final_reviews, screens, diag, amendment)
    history = REPORT/'history/before-final-confirmation-render-v1'
    require(not history.exists(), 'final-render history exists; use an explicitly reviewed new version')
    copies = {'results/confirmation-analysis-v1/analysis.json': 'confirmation-analysis.json',
              'results/confirmation-analysis-v1/comparisons.csv': 'confirmation-comparisons.csv',
              'results/confirmation-analysis-v1/cohort-ratios.csv': 'confirmation-cohort-ratios.csv',
              'variants/java-upstream-readiness-v1.md': 'upstream-readiness.md'}
    for destination in copies.values():
        require(not (REPORT/destination).exists(), 'browsing copy already exists: ' + destination)
    require(not (REPORT/'rendered-final-status.json').exists(), 'final status already exists')
    # All evidence/format/schema gates complete before any report mutation.
    history.mkdir(parents=True)
    for name in ('README.md', 'methodology.md', 'evidence-index.json',
                 'results-template.json', 'completed-screens.json'):
        shutil.copyfile(REPORT/name, history/name)
    for source, destination in copies.items():
        shutil.copyfile(ROOT/source, REPORT/destination)
    (REPORT/'README.md').write_text(text)
    index = read(REPORT/'evidence-index.json')
    index['status'] = 'FINAL_RENDERED_AWAITING_ROOT_REVIEW'
    index['confirmation'] = {'status': 'COMPLETE_FRESH_PRESELECTED_HOLDOUT_ANALYSIS',
        'analysis_archive_path': ANALYSIS, 'analysis_browsing_copy': 'confirmation-analysis.json',
        'final_reviews': ['reviews/' + name + '/review.json' for name in JOBS],
        'sequence': 'confirmation-sequence-v1.json', 'screens_pooled': 0,
        'adjusted_primary_supported_candidates': supported, 'root_reviewed': False}
    index['benchmark_results'].update(confirmation='COMPLETE_PRESELECTED_FRESH_HOLDOUT_ANALYSIS',
                                      bundle='COMPLETE_ONE_COHORT_SCREEN_ONLY')
    index['fixed_confirmation_plan']['actual_confirmation_results_admitted'] = True
    index['fixed_confirmation_plan']['analysis_archive_path'] = ANALYSIS
    index['diagnostic_activation'] = {'archive_path': DIAGNOSTIC, 'performance_claim': False,
                                     'all_five_paths_both_workloads': True}
    index['post_hoc_VmHWM_review_amendment'] = {
        'original_note': HWM_AMENDMENT, 'original_note_record': amendment,
        'failed_original_review': FAILED_COLOR_REVIEW,
        'failure_snapshot': 'results/review-telemetry-amendment-v1/sequence-at-failure.json',
        'documentation': HWM_DOCUMENTATION, 'prespecified': False,
        'benchmark_runner_flags_inputs_raw_values_changed': False,
        'review_policy': 'recorded warmup-only dip later strictly exceeded; measured/cgroup dips fatal',
        'root_cause_proved': False, 'numerical_error_bound': None,
        'RSS_metric': 'maximum observed approximate /proc VmHWM across warmup/JIT/measurement',
        'accepted_after_complete_PASS_rereview': True}
    write(REPORT/'evidence-index.json', index)
    template = read(REPORT/'results-template.json')
    template['status'] = 'FINAL_RENDERED_AWAITING_ROOT_REVIEW'
    template['confirmation'] = {'status': 'COMPLETE_PRESELECTED_FRESH_HOLDOUT_ANALYSIS',
        'analysis': ANALYSIS, 'browsing_copy': 'confirmation-analysis.json',
        'comparisons': analysis['comparisons'], 'bundle': analysis['bundle_external_validity'],
        'root_reviewed': False, 'screen_observations_pooled': 0}
    write(REPORT/'results-template.json', template)
    completed = read(REPORT/'completed-screens.json')
    completed['pending'] = []
    completed['RSS_metric_clarification'] = ('Legacy HWM field names denote maximum observed approximate '
        '/proc VmHWM across warmup/JIT/measurement, not an exact physical peak; no numerical error bound. '
        'Post hoc holdout review amendment is preserved separately; original screen values are unchanged.')
    completed['followup_status'] = {'confirmation': 'COMPLETE_SEPARATE_ANALYSIS',
        'bundle': 'COMPLETE_SEPARATE_ONE_COHORT_SCREEN', 'analysis': ANALYSIS}
    write(REPORT/'completed-screens.json', completed)
    method = """The completed Java transfer study uses Closure Compiler v20261015 and the frozen confirmation-plan-v1.json. Seven one-cohort screens selected color and ALL for fresh BigQuery holdouts; both selected comparisons have three independent paired-JVM cohorts with five measured pairs per cohort. The separate ALL bundle result has one cohort and is an external-validity screen, not confirmation. No screen observation enters holdout intervals. Diagnostics are outside timing results.

STOCK is the unmodified Maven jar. CONTROL and every factor/ALL overlay the same nine source families with matched flags, mechanical dependency relocation and all generated nested classes. CONTROL/STOCK is an experimental-artifact comparison, not a constant recompilation penalty. Candidate holdouts compare directly with STOCK. No percentages are added, multiplied or corrected using a separate cohort.

Every request creates a fresh CommandLineRunner/Compiler and parses normal externs. There is no worker, parsed-extern or compiler-result cache. Only the named polyfill factor shares immutable default resource metadata. All warmup and measured requests must match six exact stock digests: stdout, stderr, exit, JS, source map and input manifest. Raw streams/digests and failures remain in the archive; overwritten historical large artifacts are not independently rehashable.

Two persistent JVMs run in actual 4 GiB, swap-zero, 2-CPU/affinity 0–1 cgroups using the same JDK 21, -Xmx3g and default collector. Injected JVM flags are cleared. The inactive JVM is paused; its pages remain charged. Alternating warmup reverses order each round; both must settle together after 12–90 requests each. Criteria stay at last-4/prior-4 median drift at most 5%, last-4 JIT/wall at most 2%, and last-4 max/min at most 1.20. Five measured AB/BA pairs alternate; the odd count gives one order three appearances, with cohort start order alternating.

Actual completed runner policy is cache-aware-v3-PSIoptional. Parent headroom includes capped reclaimable inactive-file/slab accounting; OOM must remain zero. Warm reclamation is recorded/allowed. Measured local high/max/direct scan/direct steal and available major-fault deltas are zero-required. PSI is unavailable, never zero; these proxies cannot prove absence of pressure. Request/total bounds and disk/headroom guards remain recorded. Rejected pressure/missing-PSI attempts and transport recovery are retained separately.

Ratios are candidate/baseline: below 1 is less cost. The primary estimator is the geometric mean of three within-cohort candidate/STOCK median-wall ratios. Mean/summed wall, median/mean CPU, HWM and allocation are sensitivities. A ratio of medians, median paired ratio and mean of paired ratios are different estimators. Raw ratios, absolute medians, sample SD and original samples remain available; within-JVM request SD is descriptive, not independent treatment variance.

The preselected family has two median-wall comparisons. The adjusted primary criterion is upper bound < 1 from the Bonferroni familywise 95% log-t interval (individual 97.5%, 2 degrees of freedom). Log-t assumes independent approximately normal log-cohort effects; three cohorts cannot test this assumption. Whole-cohort percentile bootstrap 95% intervals are discrete and confined to three observed cohorts. The final renderer copies intervals from the completed analysis without recomputing them. Secondary intervals carry no additional adjusted winner or RSS-significance claim.

Legacy HWM fields mean the maximum observed approximate /proc VmHWM per JVM/cohort across warmup, JIT and measurement, not an exact physical peak; no numerical error bound is proved. A post hoc review amendment permits only recorded warmup-only VmHWM dips later strictly exceeded; measured VmHWM or cgroup peak dips remain fatal. The original failed review and sequence snapshot are preserved, with every gate rerun and no runner/flag/input/raw-data change. The rule was not prespecified, and the root cause is unproved. Current RSS is an approximate post-request snapshot; cgroup memory.peak includes charged cache/helpers. Allocated bytes are ThreadMXBean totals across JVM threads with management-boundary overhead, not live heap or RSS; unsupported values remain unavailable. Do not exchange these memory windows.

Independent PASS reviews, settled byte-identical summaries and zero-new-OOM/stopped receipts establish the admitted result stages. They do not replace full upstream pass suites or universal custom-extension/error-path parity, which remain unrun/unproved. Source/cache lifetime caveats and the historical upstream-readiness review accompany the patches. No Go/Java result is updated. Root must independently review the final report before the separate publisher grant.
"""
    (REPORT/'methodology.md').write_text(method)
    write(REPORT/'rendered-final-status.json', {'status': 'FINAL_RENDERED_AWAITING_ROOT_REVIEW',
        'source_analysis': ANALYSIS, 'intervals_recomputed': False, 'root_reviewed': False,
        'original_evidence_modified': False, 'build_benchmark_archive_performed': False,
        'adjusted_primary_supported_candidates': supported})
    print(json.dumps({'status': 'FINAL_RENDERED_AWAITING_ROOT_REVIEW', 'README': str(REPORT/'README.md'),
                      'adjusted_primary_supported_candidates': supported, 'intervals_recomputed': False}))

if __name__ == '__main__':
    main()
