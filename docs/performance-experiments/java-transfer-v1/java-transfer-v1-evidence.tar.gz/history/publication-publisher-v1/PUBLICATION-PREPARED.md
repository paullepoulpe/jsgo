Local publisher: SOURCE PREPARED ONLY

publish_java_transfer.py has been AST-parsed, never imported/executed. No archive,
reproduction-inputs directory or publication-worktree destination was created.
No timing, process/Docker inspection or bulk hash runs during source preparation.

After all timings and diagnostics stop, root must finish report/analysis review,
fill publication-root-grant-TEMPLATE.json with11 actual closed JSON SHA pins,
publisher/plan/final-report SHA pins and explicit closure flags, then save it as
publication-root-grant-v1.json in this root. The default template is blocked.

Only then the local command is:

    python3 /workspace/jsgo-java-experiments/transfer-v1/publish_java_transfer.py --execute

Without --execute it prints PREPARED ONLY and returns without inspecting runtime
or hashing evidence. It never runs Java/Go/tests/benchmarks or git/network actions.
Local docker ps is used only during actual publication for fail-closed idle checks.
It requires readable /proc, local Docker access and enough free storage for the
compressed archive, copied report and a streaming verification pass.

Required closure dependencies

- confirmation-sequence-v1.json has exactly the three planned completed jobs,
  finished_unix and no active/failed/review_failed field.
- The three named independent reviews are PASS with STOCK/color-cache or STOCK/ALL,
  BigQuery3cohorts/bundle1,5pairs each, strict6digests and no Java-versus-Go claim.
- Each result stopped-proof has no cleanup/owned-process/container leftovers or
  new OOM. All three actual metadata files are hash-pinned in the root grant.
- results/confirmation-analysis-v1/analysis.json has the existing producer's COMPLETE
  status, both3cohort comparisons, zero pooled screen observations and the separate
  one-cohort bundle disposition. Root must review statistics/claims, not merely
  the status. The publisher does not recompute the analysis or infer a winner.
- The final report README, publisher and fixed confirmation-plan hashes are pinned.
  All experiment producers must remain closed for the complete capture interval.

Reproduction-inputs

The publisher creates a NEW reproduction-inputs directory in this experiment only
at actual execution. It verifies and copies each of the BigQuery and bundle spec,
stock six-output oracle and oracle-metadata against their actual runtime metadata
hashes. It reads the frozen run-v3.py PINS assignment with ast.literal_eval (never
imports it), requires those pins to equal both runtime helper maps and copies the
exact recorded paired_cli.py/cgroup_exec.py snapshots. External JDK, stock jar,
container image and full corpus payloads are not copied. The copied manifest retains
external identities/input-manifest/path mapping; README explains remapping and
unbundled prerequisites. Shared driver, generated classes, source/build receipts
and all frozen helper/controller versions already within the experiment are archived.

Snapshot mechanics

The fixed NEW destination is /workspace/jsgo-publish-records/docs/performance-experiments/java-transfer-v1.
Report contents, history and normalized patches are copied under that destination.
The full experiment's ordinary files become java-transfer-v1-evidence.tar.gz.
No previous archive/destination is modified. Existing reproduction-inputs, destination,
staging directory or archive is refused. Staging is a new sibling of the destination.
A failed attempt leaves partial new paths for root inspection; nothing is deleted
or silently overwritten. Root must review such paths before choosing recovery or
another version; this script intentionally is not a destructive retry tool.

Directory symlinks and file symlinks are never traversed/opened; excluded paths and
literal targets are recorded. __pycache__/.pyc and other non-regular paths are excluded
with reasons. Consequently external generated/inputs corpus links contribute metadata,
not dataset copies. Regular classes, diagnostics, probes, raw requests, source/build
receipts, launches, failures and frozen versions are preserved. Original source modes,
uid/gid and mtime are in evidence-members.json; tar ownership/time and gzip time are
normalized for deterministic encoding of fixed input content, with lexically sorted
regular members. Hash/stream validation checks every archive member and rejects links,
duplicate/unsafe/unexpected paths without extracting anything. A second complete
inventory must match, and idle must still hold before final destination rename.

Limits / remaining root checks

This is source-reviewed preparation, not a dry run. Disk demand, Python/tar streaming,
Docker accessibility, actual final schemas and full archive verification remain untested.
No shared runtime lock exists: root's all-files-closed promise and no-new-runtime
scheduling is required; process/container checks at boundaries cannot prove no short
unrelated work occurred between them. Source symlink avoidance and inventory hashes
protect capture integrity, but root still decides whether all reported claims and
universal API-compatibility caveats are correct. Archive metadata cannot make a
nonportable absolute-path benchmark command runnable without remapping. Large overwritten
historical artifacts unavailable before this cut remain unavailable, as already disclosed
by independent reviews; recorded streams/digests and current files are retained.
