This is a source-only Java-vs-Java benchmark harness. Nothing here compiles or
generates compiler variants, downloads inputs, builds images, or publishes results.
Root must review the build/semantic controls and grant each benchmark invocation.

`CliFactors.java` follows the established `CliPaired.java` protocol: a new
CommandLineRunner/Compiler and stock extern parsing for every request. Its only
additions are initialization-free target-class origin/hash records, VM metadata,
and an optional VM-wide ThreadMXBean allocated-byte counter. It writes compiler
stdout/stderr/exit to real files; the controller hashes all six required outputs
after every warmup and measured request. Fixed output artifacts are overwritten
only after the previous request passes. Per-request streams, metrics, digests,
and failure logs remain; the harness does not duplicate large JS/maps per warmup.

Root compiles this one driver once against the pinned shaded jar. Use a dedicated
driver output directory containing only CliFactors*.class. Compile CONTROL and
every factor/ALL from the same nine original Java source families, with identical
javac flags and relocated imports; STOCK uses the unmodified jar. New nested
factor helpers may change emitted class sets, but all nine top classes must be
present and no other source family may be overlaid. All other compiler classes
come from the identical pinned jar. Classpath order is overlay, jar, shared driver.

`build-manifest.template.json` defines the required root-produced build receipt.
Fill actual absolute paths, source-family names, class hashes, driver hashes and
validation status after compilation and root build review. Semantic probe results remain separate; every benchmark request still requires six output digests. The benchmark refuses
an unresolved or non-PASS build manifest. Runtime target-class hashes and CodeSource
locations must match the selected overlay or stock jar before warmup begins.

Each invocation compares one baseline/candidate on one immutable spec. At most
two persistent JVMs reside, each in its own actual 4 GiB, swap-zero, CPU2 cgroup
with affinity 0–1. Both use the same Java21 installation, `-Xmx3g`, and default
collector. Injected JVM flags are cleared. The inactive container is paused, so
its background JIT/GC cannot compete; its resident pages remain charged. Outer
memory headroom (1 GiB default), disk, OOM and request/total-time bounds reject
pressure or interrupted runs. These guards cannot make two 4 GiB reservations
fit a smaller parent cgroup; parent pressure invalidates a cohort.

Warmup alternates both JVMs, reversing order on successive rounds. It ends only
when both settle in the same round, with at least12 and at most90 requests each:
last4/prior4 median drift ≤5%, last4 compilation-MXBean JIT time/wall ≤2%, and
last4 max/min ≤1.20. Missing JIT monitoring or failure to settle rejects timing.
Then five sequential measured AB/BA pairs run; initial direction is seeded and
reverses each pair. Five is odd, so one direction occurs three times; fresh cohort
start order alternates. Every request must match the pinned stock six-digest
oracle, including diagnostic streams, exit, JS, map and manifest.

Use CONTROL versus STOCK first to measure recompilation/relocation effects.
Then screen CONTROL versus each of the five factors and ALL, one cohort/five
pairs. Generated BigQuery and bundleN1 use the existing exact specs/oracles. A
practical staged schedule screens BigQuery first, then bundle for promising
factors, recording every selection decision. With minimum warmup, one pair cohort
has34 requests: roughly2–3minutes for BigQuery and5–6minutes for bundle; startup,
first cold requests, and additional settling add time. Max90 allows190 requests
and is a rejection bound, not a target. Confirm promising ALL/factors against
STOCK using three fresh pair-of-JVM cohorts, five pairs per cohort. Optional
coalescing stress must be a separate labelled deterministic spec with an actual
stock oracle; the harness does not synthesize stress or infer activation.

Example invocation after root has filled actual receipt/grant paths:

    python3 bench/run.py --manifest build/benchmark-build-manifest.json \
      --baseline CONTROL --candidate ALL --spec /absolute/spec.json \
      --oracle /absolute/stock-java-oracle-digests.json \
      --oracle-metadata /absolute/metadata.json \
      --jar /workspace/jsgo/.cache/closure-compiler-v20261015-maven.jar \
      --java-home /usr/lib/jvm/java-21-openjdk-amd64 \
      --image python@sha256:70729b46c69b4f1e97c4822c1af3df53a1476cf5ddc6c087c0c10bc3a5678c2f \
      --out /absolute/new-output --cohorts 1 --pairs 5 \
      --runtime-grant /absolute/root-runtime-grant.json

`--cohorts 3` enables independent-cohort confidence intervals. Grant fields: runner_sha256, manifest_sha256, spec_sha256, out,
baseline, candidate, cohorts, pairs, and allowed_stages=["benchmark"]. Default
request bound is300seconds; total bound is14400seconds. Existing output paths
are rejected; keep failed/unsettled evidence and use a new path for any retry.

Reports include individual elapsed/process CPU/current RSS/allocation rows,
mean/median/range/sample SD/variance, same-pair time/CPU/current-RSS ratios, and
one final JVM lifetime-HWM ratio per cohort. Allocation is total allocated bytes
across JVM threads when supported, with small metric-boundary overhead; it is
not live heap or RSS. Missing support is reported as null. Lifetime HWM includes
warmup/JIT and is explicitly separate from per-request current RSS and cgroup
memory.peak (which also includes charged cache). Confirmatory 95% intervals
resample whole independent cohorts10,000times, using geometric means of cohort
median ratios; three cohorts produce discrete, limited intervals. A single
screening cohort gets no CI. No Java-vs-Go claim follows from this harness.

Accept results only when summary.json is PASS **and** stopped-proof.json has
zero OOM deltas, no cleanup errors, no owned containers/drivers and no active
compiler processes. The script removes only its recorded owned container IDs.

For three-cohort confirmation, the bootstrap interval is discrete and cannot
reveal effects outside the three observed cohort ratios. A complementary
Student t interval on log(cohort median ratio), with df=2 and t0.975=4.302653,
can be reported as exp(mean(log r) ±4.302653*SD(log r)/sqrt(3)). It is
assumption-based (independent approximately normal log-cohort effects), not a
distribution-free guarantee. Show both, retain all three raw ratios, and avoid
claiming precision from the fifteen correlated requests. This complement is
not silently substituted for the frozen runner's bootstrap result.
