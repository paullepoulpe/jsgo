"""Aggregate two preselected fresh Java holdouts, never exploratory screens.

Standard-library JSON reads/statistics only. No imports of benchmark helpers,
hashes, JVMs, builds, Docker, archive operations, or measured-directory writes.
"""
from pathlib import Path
import argparse,csv,json,math,random,statistics,traceback
T95_DF2=4.302652729911275
T975_DF2=6.20534681657
JAR='d6864ebf70bca5ba6e237898de6611a389aaf8b933c2549036ced4a684b664b6'
def require(ok,message):
 if not ok:raise ValueError(message)
def same(a,b,label):require(a==b,label)
def read(path):return json.loads(Path(path).read_text())
def close(a,b,label):require(math.isclose(a,b,rel_tol=1e-11,abs_tol=1e-11),label)
def zero(events):require(not any(events.get(k,0) for k in ('oom','oom_kill','oom_group_kill')),'OOM evidence')
def stats(values):
 values=list(values);require(values and all(math.isfinite(x) and x>0 for x in values),'nonpositive/invalid ratios')
 return {'raw':values,'count':len(values),'geomean':math.exp(statistics.mean(math.log(x) for x in values)),'mean':statistics.mean(values),'median':statistics.median(values),'min':min(values),'max':max(values),'sample_SD':statistics.stdev(values) if len(values)>1 else None}
def t_interval(values,critical,confidence):
 require(len(values)==3,'t interval requires exactlythree independent cohorts');logs=[math.log(x) for x in values];mean=statistics.mean(logs);sd=statistics.stdev(logs);half=critical*sd/math.sqrt(3)
 return {'geomean':math.exp(mean),'lower':math.exp(mean-half),'upper':math.exp(mean+half),'confidence':confidence,'df':2,'critical_t':critical,'log_cohort_SD':sd,'assumption':'independent approximately normal log-cohort effects; cannot test normality withthree observations'}
def bootstrap(values,seed):
 require(len(values)==3,'bootstrap requires exactlythree independent cohorts');logs=[math.log(x) for x in values];rng=random.Random(seed);samples=sorted(math.exp(statistics.mean(rng.choices(logs,k=3))) for _ in range(10000))
 return {'geomean':math.exp(statistics.mean(logs)),'lower':samples[250],'upper':samples[9749],'confidence':.95,'resamples':10000,'seed':seed,'unit':'whole pair-of-JVM cohort','limitation':'three-cohort discrete percentile interval confined to observed cohort range'}
def inverse(interval):return {'geomean':1/interval['geomean'],'lower':1/interval['upper'],'upper':1/interval['lower']}
def metric_summary(values,seed,primary):
 require(len(values)==3,'three fresh cohort ratios required');boot=bootstrap(values,seed);t=t_interval(values,T95_DF2,.95)
 result={'candidate_over_STOCK':stats(values),'STOCK_over_candidate':stats([1/x for x in values]),'bootstrap95_candidate_over_STOCK':boot,'bootstrap95_STOCK_over_candidate':inverse(boot),'log_t95_candidate_over_STOCK':t,'log_t95_STOCK_over_candidate':inverse(t),'inference_role':'preselected primary median-wall endpoint' if primary else 'secondary descriptive sensitivity; no adjusted significance claim'}
 if primary:
  adjusted=t_interval(values,T975_DF2,.975);result.update(bonferroni_family95_log_t_candidate_over_STOCK=adjusted,bonferroni_family95_log_t_STOCK_over_candidate=inverse(adjusted),familywise_supported_reduction=adjusted['upper']<1)
 return result
def identity(spec):return {k:spec[k] for k in ('argv','links','inputs','artifacts')}|{'absent_artifacts':spec.get('absent_artifacts',[]),'builtin_externs':spec['same_work']['builtin_externs']}
def validate_result(review_path,candidate,cohort_count):
 r=read(review_path);same(r['status'],'PASS independent Java-factor review','independent review notPASS');same(r['baseline'],'STOCK','directSTOCK comparison required');same(r['candidate'],candidate,'wrong holdoutcandidate')
 same(r['cohorts'],cohort_count,'wrong independentcohort count');same(r['pairs_per_cohort'],5,'fivepairs required');same(r['strict_digests_every_request'],6,'strict6gate');require(r['all_graceful_driver_exit_codes_zero'],'driverteardown failure')
 require(r['Java_vs_Go_claim'] is False,'unexpectedGo claim');same(r['runner_policy_version'],'cache-aware-v3-PSIoptional','mixed runnerpolicy notadmitted')
 root=Path(r['results']).resolve();require(not (root/'failure.json').exists(),'failed result');m=read(root/'metadata.json');s=read(root/'summary.json');stop=read(root/'stopped-proof.json')
 same(s['status'],'PASS settled byteidentical Java-vs-Java','underlyingrunner status');require(s['complete'],'underlyingincomplete');same(s['baseline'],'STOCK','underlyingbaseline');same(s['candidate'],candidate,'underlyingcandidate')
 for obj in (m,r):same(obj['cohorts'],cohort_count,'cohortmetadata mismatch')
 same(m['pairs'],5,'pairmetadata mismatch');same(m['min_warmup'],12,'warmminimum');same(m['max_warmup'],90,'warmmaximum');same(m['jar_sha256'],JAR,'pinnedstock jar');same(m['java_flags'],['-Xmx3g'],'JVM flags')
 same(m['runner_sha256'],r['runner_sha256'],'runneridentity');same(m['manifest_sha256'],r['manifest_sha256'],'buildmanifest identity');same(m['runner_policy_version'],r['runner_policy_version'],'guardpolicy identity')
 require(not stop['cleanup_errors'] and not stop['remaining_owned_containers'] and not stop['remaining_owned_driver_processes'] and not stop['active_compilers'],'stoppedproof failure');zero(stop['outer_OOM_delta'])
 same(len(r['per_cohort']),cohort_count,'reviewcohort count');same(len(s['cohorts']),cohort_count,'runnercohort count');containers=[];rows=[]
 for index,(cohort,raw) in enumerate(zip(r['per_cohort'],s['cohorts']),1):
  same(cohort['cohort'],index,'cohortordering');same(raw['cohort'],index,'rawcohortordering');same(set(cohort['variants']),{'STOCK',candidate},'cohortvariants')
  directory=root/('cohort-'+str(index));same(read(directory/'cohort-summary.json'),raw,'rawcohort receipt')
  variants={}
  for name in ('STOCK',candidate):
   v=cohort['variants'][name];w=raw['variants'][name];require(v['settling']['stable'],'unsettledJVM');same(v['warm_requests'],w['warm_requests'],'warmcountreceipt');require(12<=v['warm_requests']<=90,'warmcountbounds')
   for metric,rawmetric in [('wall_seconds','wall_seconds'),('CPU_seconds','CPU_seconds'),('current_RSS_MiB','current_RSS_MiB')]:
    values=v[metric]['raw'];same(len(values),5,'rawfive samples');same(values,w[rawmetric]['raw'],'review/rawsamples mismatch');close(v[metric]['median'],statistics.median(values),'rawmedian');close(v[metric]['mean'],statistics.mean(values),'rawmean')
   close(v['final_lifetime_HWM_MiB'],w['final_lifetime_HWM_MiB'],'lifetime HWMreceipt');require(v['final_lifetime_HWM_MiB']>0,'invalidHWM')
   if v['allocated_bytes'] is not None:same(v['allocated_bytes']['raw'],w['allocated_bytes']['raw'],'rawallocationreceipt');same(len(v['allocated_bytes']['raw']),5,'allocation samples')
   owned=read(directory/name/'owned-driver.json');containers.append(owned['container']);variants[name]=v
  same(variants['STOCK']['warm_requests'],variants[candidate]['warm_requests'],'matchedwarmupcounts')
  base,new=variants['STOCK'],variants[candidate]
  values={'median_wall':statistics.median(new['wall_seconds']['raw'])/statistics.median(base['wall_seconds']['raw']),'mean_wall':statistics.mean(new['wall_seconds']['raw'])/statistics.mean(base['wall_seconds']['raw']),'median_CPU':statistics.median(new['CPU_seconds']['raw'])/statistics.median(base['CPU_seconds']['raw']),'mean_CPU':statistics.mean(new['CPU_seconds']['raw'])/statistics.mean(base['CPU_seconds']['raw']),'lifetime_HWM':new['final_lifetime_HWM_MiB']/base['final_lifetime_HWM_MiB']}
  if base['allocated_bytes'] is not None and new['allocated_bytes'] is not None:
   values['median_allocated_bytes']=statistics.median(new['allocated_bytes']['raw'])/statistics.median(base['allocated_bytes']['raw']);values['mean_allocated_bytes']=statistics.mean(new['allocated_bytes']['raw'])/statistics.mean(base['allocated_bytes']['raw'])
  for independent_metric,runner_metric in [('median_wall','elapsed'),('median_CPU','CPU'),('lifetime_HWM','RSS_lifetimeHWM')]:close(values[independent_metric],raw['candidate_over_baseline'][runner_metric],'derivedcohort ratio')
  rows.append({'cohort':index,'ratios':values,'absolute':{name:{'wall_median_s':v['wall_seconds']['median'],'wall_mean_s':v['wall_seconds']['mean'],'wall_SD_s':v['wall_seconds']['sample_SD'],'wall_CV':v['wall_seconds']['CV'],'CPU_median_s':v['CPU_seconds']['median'],'CPU_mean_s':v['CPU_seconds']['mean'],'lifetime_HWM_MiB':v['final_lifetime_HWM_MiB'],'allocated_median_bytes':v['allocated_bytes']['median'] if v['allocated_bytes'] else None,'allocated_mean_bytes':v['allocated_bytes']['mean'] if v['allocated_bytes'] else None,'warm_requests':v['warm_requests']} for name,v in variants.items()}})
 same(len(set(containers)),2*cohort_count,'freshdistinctJVM IDs required');same({x['container'] for x in stop['owned_cleanup']},set(containers),'cleanupownership')
 for cleanup in stop['owned_cleanup']:require(cleanup.get('removed') is True and cleanup.get('driver_exit')==0 and not cleanup.get('fallback_removed'),'nonzero/fallbackteardown')
 return {'review_path':str(Path(review_path).resolve()),'results':str(root),'candidate':candidate,'cohort_rows':rows,'container_ids':containers,'metadata':m,'review':r,'workload':identity(read(m['spec']))}
def main():
 p=argparse.ArgumentParser(description=__doc__);p.add_argument('--color-review',type=Path,required=True);p.add_argument('--all-review',type=Path,required=True);p.add_argument('--bundle-all-review',type=Path);p.add_argument('--out',type=Path,required=True);p.add_argument('--seed',type=int,default=20261117);a=p.parse_args();out=a.out.resolve();require(not out.exists(),'new reportdirectory required')
 color=validate_result(a.color_review,'color-cache',3);all_result=validate_result(a.all_review,'ALL',3);selected=[color,all_result]
 same(color['workload'],all_result['workload'],'holdouts must use identicalBigQuerywork');require(color['results']!=all_result['results'],'distinct holdoutjobs required')
 for key in ('runner_sha256','manifest_sha256','java_home','java_executable_sha256','java_flags','driver_source_sha256','driver'):
  same(color['metadata'][key],all_result['metadata'][key],'matchedholdout setting '+key)
 same(color['review']['VM'],all_result['review']['VM'],'matchedJDKcollector/heap');same(len(set(color['container_ids']+all_result['container_ids'])),12,'fresh12JVMs required')
 bundle=validate_result(a.bundle_all_review,'ALL',1) if a.bundle_all_review else None
 if bundle:
  require(bundle['workload']!=color['workload'],'bundle must be differentworkload');require(not set(bundle['container_ids'])&set(color['container_ids']+all_result['container_ids']),'bundleJVMreuse')
  for key in ('runner_sha256','manifest_sha256','java_home','java_executable_sha256','java_flags','driver_source_sha256','driver'):same(bundle['metadata'][key],color['metadata'][key],'matchedbundle setting '+key)
 for result in selected+([bundle] if bundle else []):require(not out.is_relative_to(Path(result['results'])),'output must beoutside measuredresults')
 analyses={};csv_rows=[];raw_csv=[]
 for comparison_index,result in enumerate(selected):
  candidate=result['candidate'];rows=result['cohort_rows'];common=set.intersection(*(set(row['ratios']) for row in rows));require({'median_wall','mean_wall','median_CPU','mean_CPU','lifetime_HWM'}<=common,'mandatorysensitivities absent')
  metrics={}
  for metric_index,metric in enumerate(sorted(common)):
   values=[row['ratios'][metric] for row in rows];metric_result=metric_summary(values,a.seed+comparison_index*100+metric_index,metric=='median_wall');metrics[metric]=metric_result
   primary=metric=='median_wall';csv_rows.append({'comparison':candidate+'/STOCK','metric':metric,'role':'PRIMARY' if primary else 'SENSITIVITY','raw_cohort_1':values[0],'raw_cohort_2':values[1],'raw_cohort_3':values[2],'geomean_candidate_over_STOCK':metric_result['candidate_over_STOCK']['geomean'],'geomean_STOCK_over_candidate':metric_result['STOCK_over_candidate']['geomean'],'bootstrap95_lower':metric_result['bootstrap95_candidate_over_STOCK']['lower'],'bootstrap95_upper':metric_result['bootstrap95_candidate_over_STOCK']['upper'],'log_t95_lower':metric_result['log_t95_candidate_over_STOCK']['lower'],'log_t95_upper':metric_result['log_t95_candidate_over_STOCK']['upper'],'family95_log_t_lower':metric_result['bonferroni_family95_log_t_candidate_over_STOCK']['lower'] if primary else None,'family95_log_t_upper':metric_result['bonferroni_family95_log_t_candidate_over_STOCK']['upper'] if primary else None,'familywise_supported_reduction':metric_result.get('familywise_supported_reduction')})
   for row in rows:raw_csv.append({'candidate':candidate,'cohort':row['cohort'],'metric':metric,'candidate_over_STOCK':row['ratios'][metric],'STOCK_over_candidate':1/row['ratios'][metric]})
  analyses[candidate]={'review_path':result['review_path'],'results':result['results'],'cohort_rows':rows,'metrics':metrics,'allocation_availability':'allthreecohorts' if 'median_allocated_bytes' in common else 'unavailable inatleastonecohort; noallocationCI','screen_observations_pooled':0}
 supported=[name for name,value in analyses.items() if value['metrics']['median_wall']['familywise_supported_reduction']]
 report={'status':'COMPLETE preselected freshholdout analysis','selection':'color-cache andALL selectedbeforeholdouts; previousCONTROLscreens exploratoryonly, zeroobservationspooled','primary_endpoint':'geomean ofthree withincohort median-wall candidate/STOCK ratios','primary_family':{'comparisons':['color-cache/STOCK','ALL/STOCK'],'count':2,'family_confidence':.95,'method':'Bonferroni two-sided97.5% logt interval eachcomparison,df2,t=6.20534681657','any_winner_familywise_supported':bool(supported),'supported_candidates':supported,'interpretation':'Familywise evidence only underindependent approximately normal logcohort effects; otherwise descriptive, withthreecohorts normalitycannotbechecked'},'comparisons':analyses,'bundle_external_validity':{'status':'ONE_COHORT_EXTERNAL_VALIDITY_SCREEN_NOT_CONFIRMATION','review_path':bundle['review_path'],'results':bundle['results'],'raw_cohort':bundle['cohort_rows'][0],'confidence_interval':None,'pooled_into_BigQuery':False} if bundle else {'status':'NOT PROVIDED; no crossworkloadclaim'},'source_provenance':{'runner_sha256':color['metadata']['runner_sha256'],'manifest_sha256':color['metadata']['manifest_sha256'],'VM':color['review']['VM'],'PSI_telemetry':color['review']['PSI_telemetry']},'limits':['Three freshpair-of-JVM cohorts aretheonly inferentialunit; fivepersistentJVMrequests arecorrelated.','Bootstrap95 isdiscreteandconfinedtothreeobservedcohorts; logt assumesapproximately normalindependentlogeffects.','Onlytwo median-wall primarycomparisons receivefamilywise adjustment; meanwall/CPU/HWM/allocation sensitivities aredescriptive, notextraconfirmedwins.','CONTROLvsSTOCK screenisnot afixedpenalty; no correction or multiplicationofseparatefactorpercentages applied.','HWM includeswarmup/JIT; allocatedbytesandpostrequestcurrentRSS aredifferentmemorywindows.','Zero directreclaim proxies withunavailablePSI isnot proof ofzeroPSI.','A bundleonecohortscreen checks workloadtransfer only; cannotestablish significance or universalperformance.'],'Java_vs_Go_claim':False,'benchmarks_executed_by_this_helper':False}
 out.mkdir(parents=True);(out/'analysis.json').write_text(json.dumps(report,indent=2,allow_nan=False)+'\n')
 for name,rows in [('comparisons.csv',csv_rows),('cohort-ratios.csv',raw_csv)]:
  with (out/name).open('w',newline='') as f:writer=csv.DictWriter(f,fieldnames=list(rows[0]));writer.writeheader();writer.writerows(rows)
 print(json.dumps({'status':report['status'],'out':str(out),'any_winner_familywise_supported':bool(supported),'supported_candidates':supported,'primary_ratios':{name:value['metrics']['median_wall']['candidate_over_STOCK']['raw'] for name,value in analyses.items()}},indent=2))
if __name__=='__main__':main()
