"""Source/receipt JSON only: never compiles or starts a JVM/container.

Run by root after identical shared driver and seven overlays have built.
The resulting manifest proves builds/provenance, not compiler semantic parity.
"""
from pathlib import Path
import argparse,hashlib,json
R=Path(__file__).resolve().parent;ROOT=R.parent
def read(p):return json.loads(Path(p).read_text())
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
p=argparse.ArgumentParser();p.add_argument('--driver-directory',required=True,type=Path);p.add_argument('--driver-build-proof',required=True,type=Path);p.add_argument('--out',required=True,type=Path);a=p.parse_args();assert not a.out.exists()
proof=read(a.driver_build_proof);assert proof['status']=='PASS' and proof['exit']==0
driver_flags=proof.get('javac_flags',proof['argv'][proof['argv'].index('-source'):proof['argv'].index('-cp')])
driver_classes={str(p.relative_to(a.driver_directory)):sha(p) for p in sorted(a.driver_directory.rglob('*.class'))};assert driver_classes and all(rel.startswith('CliFactors') for rel in driver_classes)
assert proof['source_sha256']==sha(R/'CliFactors.java') and driver_classes==proof['classes']
control=read(ROOT/'build/control/build.json');assert control['status']=='PASS' and control['exit']==0
prefix='com/google/javascript/jscomp/';families=[rel.removeprefix(prefix).removesuffix('.java') for rel in control['source_files']];assert len(families)==9
variants={'STOCK':{'overlay':None,'classes':{}}};receipts={}
for disk,name in [('control','CONTROL'),('fsiv-lazy','fsiv-lazy'),('namespace-lazy','namespace-lazy'),('coalesce-bitset','coalesce-bitset'),('color-cache','color-cache'),('polyfill-cache','polyfill-cache'),('all','ALL')]:
 path=ROOT/'build'/disk/'build.json';b=read(path);assert b['status']=='PASS' and b['exit']==0 and b['javac_flags']==control['javac_flags'] and b['source_files']==control['source_files'] and b['published_jar_sha256']==control['published_jar_sha256'] and b['original_sources']==control['original_sources'] and b['source_jar_sha256']==control['source_jar_sha256']
 assert set(b['effective_sources'])==set(control['effective_sources'])
 variants[name]={'overlay':b['classpath_overlay'],'javac_flags':b['javac_flags'],'compiled_source_families':families,'classes':b['classes'],'build_proof':str(path),'build_proof_sha256':sha(path),'selected_factors':b['selected_factors']};receipts[name]=sha(path)
m={'status':'PASS_BUILD_VALIDATION','semantic_parity_status':'NOT INFERRED from compilation; root probes separate; all benchmark warmup and measurement requests must pass strict6digest oracle','jar_sha256':control['published_jar_sha256'],'source_jar_sha256':control['source_jar_sha256'],'unmodified_compiler_classes_outside_overlays':True,'java_version':'21.0.12.1','java_home':'/usr/lib/jvm/java-21-openjdk-amd64','compiler_source_families':families,'javac_flags':control['javac_flags'],'driver_javac_flags':driver_flags,'driver':{'directory':str(a.driver_directory.resolve()),'source_sha256':sha(R/'CliFactors.java'),'javac_flags':driver_flags,'classes':driver_classes,'build_proof':str(a.driver_build_proof.resolve()),'build_proof_sha256':sha(a.driver_build_proof)},'variants':variants,'compiler_build_receipt_sha256':receipts}
a.out.parent.mkdir(parents=True,exist_ok=True);a.out.write_text(json.dumps(m,indent=2)+'\n');print(json.dumps({'out':str(a.out),'sha256':sha(a.out),'variants':list(variants),'family_count':len(families)}))
