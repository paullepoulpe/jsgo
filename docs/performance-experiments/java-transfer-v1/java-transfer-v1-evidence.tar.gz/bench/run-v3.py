"""Paired warm Java classpath factors. PREPARE ONLY until root grants runtime.

One baseline/candidate pair of persistent JVMs per independent cohort. Both do
fresh CommandLineRunner/Compiler/extern parsing each request. Every request is
six-digest gated; only one JVM is unfrozen at any time.
"""
from pathlib import Path
import argparse,collections,hashlib,json,math,os,random,re,selectors,signal,statistics,subprocess,sys,time,traceback,types
sys.dont_write_bytecode=True
HERE=Path(__file__).resolve().parent
HELP=Path('/workspace/jsgo-round4-bench/tools/bench')
PINS={'paired_cli.py':'914a9c97eb5cb66fa786d01a2f43599b781327c89b51fe0e4fef3ab207fd0854','cgroup_exec.py':'3b19b27b04a146b3793b917ab1eef30573ca92bcff06360acfb964ac7b6d025e'}
JAR='d6864ebf70bca5ba6e237898de6611a389aaf8b933c2549036ced4a684b664b6'
def read(p):return json.loads(Path(p).read_text())
def save(p,v):p=Path(p);p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(v,indent=2,allow_nan=False)+'\n')
def sha(p):
 h=hashlib.sha256()
 with Path(p).open('rb') as f:
  for block in iter(lambda:f.read(1<<20),b''):h.update(block)
 return h.hexdigest()
def counters(s):return {k:int(v) for k,v in (line.split() for line in s.replace(';','\n').splitlines())}
def zero(d):assert not any(d.get(k,0) for k in ('oom','oom_kill','oom_group_kill'))
def outer():
 c=Path('/sys/fs/cgroup');state={n:(c/n).read_text().strip() for n in ('memory.current','memory.max','memory.events','memory.events.local','memory.stat')}
 state['memory.pressure']=(c/'memory.pressure').read_text().strip() if (c/'memory.pressure').exists() else None
 return state
def memory_headroom(state):
 maximum=int(state['memory.max']);current=int(state['memory.current']);stat=counters(state['memory.stat'])
 return max(0,min(maximum,maximum-current+stat.get('inactive_file',0)+stat.get('slab_reclaimable',0)))
def pressure_totals(text):
 result={}
 for line in text.splitlines():
  fields=line.split();result[fields[0]]=int(dict(item.split('=',1) for item in fields[1:])['total'])
 assert set(result)=={'some','full'};return result
def pressure_changes(before,after):
 a,b=counters(before['memory.events.local']),counters(after['memory.events.local']);sa,sb=counters(before['memory.stat']),counters(after['memory.stat'])
 assert all(key in sa and key in sb for key in ('pgscan_direct','pgsteal_direct')),'directreclaim counters unavailable'
 pa=pressure_totals(before['memory.pressure']) if before['memory.pressure'] is not None else None;pb=pressure_totals(after['memory.pressure']) if after['memory.pressure'] is not None else None
 changes={'local_high':b.get('high',0)-a.get('high',0),'local_max':b.get('max',0)-a.get('max',0)}
 for key in ('pgscan_direct','pgsteal_direct','pgmajfault'):changes[key]=sb[key]-sa[key] if key in sa and key in sb else None
 for key in ('some','full'):changes['PSI_'+key+'_total_us']=pb[key]-pa[key] if pa is not None and pb is not None else None
 return changes
def oom_delta(before,after):return {k:counters(after['memory.events']).get(k,0)-counters(before['memory.events']).get(k,0) for k in ('oom','oom_kill','oom_group_kill')}
def stats(v):return {'raw':v,'mean':statistics.mean(v),'median':statistics.median(v),'min':min(v),'max':max(v),'sample_stdev':statistics.stdev(v) if len(v)>1 else None,'sample_variance':statistics.variance(v) if len(v)>1 else None}
def stability(rows):
 if len(rows)<12:return {'stable':False,'reason':'minimum12 warm requests'}
 old,new=rows[-8:-4],rows[-4:];drift=statistics.median(r['wall_s'] for r in new)/statistics.median(r['wall_s'] for r in old)-1
 monitored=all(r['jit_before_ms']>=0 and r['jit_after_ms']>=r['jit_before_ms'] for r in new)
 jit=sum(r['jit_after_ms']-r['jit_before_ms'] for r in new)/(1000*sum(r['wall_s'] for r in new)) if monitored else None
 spread=max(r['wall_s'] for r in new)/min(r['wall_s'] for r in new)
 return {'stable':abs(drift)<=.05 and jit is not None and jit<=.02 and spread<=1.20,'last4_vs_prior4_median_drift':drift,'last4_JIT_time_over_wall':jit,'last4_max_over_min':spread,'thresholds':{'drift':.05,'JIT':.02,'spread':1.20}}
def cohort_ci(values,seed):
 if len(values)<3:return None
 logs=[math.log(v) for v in values];rng=random.Random(seed);boot=sorted(math.exp(statistics.mean(rng.choices(logs,k=len(logs)))) for _ in range(10000))
 return {'geomean':math.exp(statistics.mean(logs)),'ci95_low':boot[250],'ci95_high':boot[9749],'independent_cohorts':len(values),'bootstrap':'10000 whole independent-cohort resamples; geometric mean of cohort median ratios; 3cohorts yields discrete limited intervals','seed':seed}
def active():
 rows=[]
 for p in Path('/proc').iterdir():
  if not p.name.isdigit():continue
  try:
   state=(p/'stat').read_text().split()[2];comm=(p/'comm').read_text().strip();exe=Path((p/'cmdline').read_bytes().split(b'\0')[0].decode()).name
   if state!='Z' and (comm in ('go','compile','link','java','javac') or comm.startswith('jsgo') or exe.endswith('.test')):rows.append({'pid':int(p.name),'comm':comm,'exe':exe})
  except (OSError,IndexError,UnicodeDecodeError):pass
 return rows
def cap(fields):
 assert fields[:3]==['READY','4294967296','0'] and fields[4] in ('0-1','0,1');q,p=map(int,fields[3].split());assert q==2*p
def work_identity(s):return {k:s[k] for k in ('argv','links','inputs','artifacts')}|{'absent_artifacts':s.get('absent_artifacts',[]),'builtin_externs':s['same_work']['builtin_externs']}
def validate_classes(manifest,jar):
 assert manifest['status']=='PASS_BUILD_VALIDATION' and manifest['jar_sha256']==JAR
 assert manifest['unmodified_compiler_classes_outside_overlays'] is True and len(manifest['compiler_source_families'])==9
 assert manifest['javac_flags'] and manifest['java_version']=='21.0.12.1'
 expected_families=set(manifest['compiler_source_families']);variants=manifest['variants'];assert 'STOCK' in variants and 'CONTROL' in variants
 controls=variants['CONTROL'];assert set(controls['compiled_source_families'])==expected_families
 classset=set(controls['classes']);assert classset
 jar_entries=None
 import zipfile
 with zipfile.ZipFile(jar) as z:
  roots={'com/google/javascript/jscomp/'+family+'.class' for family in expected_families}
  jar_entries={n:hashlib.sha256(z.read(n)).hexdigest() for n in roots}
 for name,v in variants.items():
  assert re.fullmatch('[A-Za-z0-9_.-]+',name)
  if name=='STOCK':assert v['overlay'] is None and v['classes']=={};continue
  assert v['javac_flags']==manifest['javac_flags'] and set(v['compiled_source_families'])==expected_families
  assert roots<=set(v['classes']),'all9 source families must be compiled; factor nestedhelpers may differ'
  root=Path(v['overlay']);assert root.is_absolute() and root.is_dir()
  assert {str(p.relative_to(root)) for p in root.rglob('*.class')}==set(v['classes'])
  for rel,h in v['classes'].items():
   assert rel.startswith('com/google/javascript/jscomp/') and rel.removeprefix('com/google/javascript/jscomp/').removesuffix('.class').split('$')[0] in expected_families
   assert sha(root/rel)==h
 driver=manifest['driver'];assert driver['source_sha256']==sha(HERE/'CliFactors.java')
 assert driver['javac_flags']==manifest['driver_javac_flags']
 assert {str(p.relative_to(driver['directory'])) for p in Path(driver['directory']).rglob('*.class')}==set(driver['classes'])
 for rel,h in driver['classes'].items():assert rel.startswith('CliFactors') and sha(Path(driver['directory'])/rel)==h
 return jar_entries
class JVM:
 def __init__(self,name,variant,work,engine,helper,args,spec,origins,expected):
  self.name=name;self.v=variant;self.work=work;self.e=engine;self.h=helper;self.args=args;self.spec=spec;self.process=None;self.cid=None;self.stderr=None;self.paused=False;self.pending=b'';self.expected=expected
  helper.workspace(work,spec);(work/'argv.txt').write_text('\n'.join(spec['argv'])+'\n');(work/'classes.txt').write_text('\n'.join(origins)+'\n')
  cp=([variant['overlay']] if variant['overlay'] else [])+[args.jar,args.driver]
  command=['python3',str(helper.HERE/'cgroup_exec.py'),str(Path(args.java_home)/'bin/java'),'-Xmx3g','-cp',os.pathsep.join(cp),'CliFactors',str(work/'argv.txt'),str(work/'classes.txt')]
  save(work/'jvm-command.json',{'command':command,'environment':'LC_ALL=C.UTF-8 only plus container PATH; injectedJVMoptions cleared','variant':name,'classpath_overlay_first':True})
  self.cid=engine.create(work,command,java=True);self.stderr=(work/'driver.stderr').open('wb')
  self.process=subprocess.Popen(helper.DOCKER+['start','-a','-i',self.cid],stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=self.stderr,env=engine.env,start_new_session=True,bufsize=0)
  save(work/'owned-driver.json',{'container':self.cid,'pid':self.process.pid,'pgid':self.process.pid,'workdir':str(work)})
 def line(self,deadline,check):
  sel=selectors.DefaultSelector();sel.register(self.process.stdout,selectors.EVENT_READ)
  try:
   while b'\n' not in self.pending:
    check();assert time.monotonic()<deadline,'boundedJava request timeout'
    ready=sel.select(min(.25,max(0,deadline-time.monotonic())))
    if ready:
     block=os.read(self.process.stdout.fileno(),65536);assert block,'JVM protocolEOF'
     self.pending+=block;assert len(self.pending)<1048576
   line,self.pending=self.pending.split(b'\n',1);return line.decode('UTF-8')
  finally:sel.close()
 def ready(self,check):
  deadline=time.monotonic()+self.args.request_timeout;origins={};vm=None
  while True:
   fields=self.line(deadline,check).split('\t')
   if fields[0]=='VM':
    assert len(fields)==4 and fields[1].startswith('21.') and 0<int(fields[3])<=3*1024**3 and vm is None;vm={'runtime_version':fields[1],'collectors':fields[2],'max_heap_bytes':int(fields[3])}
   elif fields[0]=='CLASS':
    assert len(fields)==4 and fields[1] not in origins;origins[fields[1]]={'location':fields[2],'sha256':fields[3]}
   else:cap(fields);break
  assert vm and set(origins)==set(self.expected)
  from urllib.parse import urlparse,unquote
  location=Path(self.v['overlay'] or self.args.jar).resolve()
  for name,row in origins.items():assert Path(unquote(urlparse(row['location']).path)).resolve()==location and row['sha256']==self.expected[name]
  save(self.work/'ready.json',{'caps':fields,'loaded_target_classes':origins,'VM':vm});self.pause()
 def pause(self):
  if self.cid and not self.paused:self.e.call('pause',self.cid,stdout=subprocess.DEVNULL,timeout=15);self.paused=True
 def request(self,number,kind,check):
  for rel in self.spec['artifacts']+self.spec.get('absent_artifacts',[]):(self.work/rel).unlink(missing_ok=True)
  parent_before=outer()
  assert self.paused;self.e.call('unpause',self.cid,stdout=subprocess.DEVNULL,timeout=15);self.paused=False
  try:
   self.process.stdin.write((str(number)+'\t'+kind+'\n').encode());self.process.stdin.flush()
   values=self.line(time.monotonic()+self.args.request_timeout,check).split('\t')
   assert len(values)==17 and values[:3]==['RESULT',str(number),kind],values
   names=['wall_ns','cpu_ns','gc_count','gc_ms','jit_before_ms','jit_after_ms','rss_kib','hwm_kib','exit','cgroup_peak_bytes']
   row=dict(zip(names,map(int,values[3:13])));row.update(kind=kind,request=number,variant=self.name,wall_s=row['wall_ns']/1e9,cpu_s=row['cpu_ns']/1e9,rss_mib=row['rss_kib']/1024,peak_rss_mib=row['hwm_kib']/1024,cgroup_events=values[13],allocation_before=int(values[14]),allocation_after=int(values[15]),cgroup_current_bytes=int(values[16]))
   row['allocated_bytes']=row['allocation_after']-row['allocation_before'] if row['allocation_before']>=0 and row['allocation_after']>=row['allocation_before'] else None
   assert row['exit']==0 and row['cgroup_peak_bytes']<=4294967296;zero(counters(row['cgroup_events']))
   parent_after=outer();changes=pressure_changes(parent_before,parent_after)
   row['parent_pressure']={'before':parent_before,'after':parent_after,'changes':changes,'envelope':'beforeunpause toRESULT; artifacthashingexcluded','zero_required':kind=='measure'}
   save(self.work/'protocol'/str(number)/'parent-pressure.json',row['parent_pressure'])
   if kind=='measure':assert all(value==0 for value in changes.values() if value is not None),'measured parentmemory pressure/reclaim: '+str(changes)
  finally:self.pause()
  # Artifacts are overwritten next request only after all six current digests gate.
  row['digests']=self.h.digests(self.work,self.spec,self.work/'protocol'/str(number));save(self.work/'protocol'/str(number)/'row.json',row);return row
 def close(self):
  actions=[]
  if self.cid:
   if self.paused:
    self.e.call('unpause',self.cid,stdout=subprocess.DEVNULL,timeout=15);self.paused=False
   if self.process and self.process.poll() is None:
    try:self.process.stdin.write(b'STOP\n');self.process.stdin.flush();self.process.wait(timeout=15)
    except (OSError,subprocess.TimeoutExpired):
     for sig in (signal.SIGTERM,signal.SIGKILL):
      if self.process.poll() is not None:break
      try:os.killpg(self.process.pid,sig)
      except ProcessLookupError:pass
      try:self.process.wait(timeout=5)
      except subprocess.TimeoutExpired:pass
   self.e.call('rm','-f',self.cid,stdout=subprocess.DEVNULL,timeout=15);self.e.containers.discard(self.cid);actions.append({'container':self.cid,'removed':True,'driver_exit':self.process.returncode if self.process else None})
   self.cid=None
  if self.stderr:self.stderr.close()
  return actions
def main():
 p=argparse.ArgumentParser(description=__doc__)
 for key in ('manifest','baseline','candidate','spec','oracle','oracle-metadata','jar','java-home','image','out','runtime-grant'):p.add_argument('--'+key,required=True)
 p.add_argument('--cohorts',type=int,choices=(1,3),default=1);p.add_argument('--pairs',type=int,default=5);p.add_argument('--min-warmup',type=int,default=12);p.add_argument('--max-warmup',type=int,default=90);p.add_argument('--request-timeout',type=int,default=300);p.add_argument('--total-timeout',type=int,default=14400);p.add_argument('--seed',type=int,default=20261020);p.add_argument('--readonly-bind',action='append',default=[]);p.add_argument('--minimum-outer-headroom',type=int,default=1<<30);p.add_argument('--minimum-disk-free',type=int,default=1<<30)
 args=p.parse_args();root=Path(args.out).resolve();assert not root.exists();assert args.pairs==5 and args.min_warmup==12 and 12<=args.max_warmup<=90
 grant=read(args.runtime_grant);assert grant['runner_sha256']==sha(Path(__file__)) and grant['manifest_sha256']==sha(args.manifest) and grant['spec_sha256']==sha(args.spec) and grant['out']==str(root) and grant['baseline']==args.baseline and grant['candidate']==args.candidate and grant['cohorts']==args.cohorts and grant['pairs']==args.pairs and 'benchmark' in grant['allowed_stages']
 assert not active();manifest=read(args.manifest);assert args.baseline!=args.candidate
 assert sha(args.jar)==JAR and '@sha256:' in args.image
 stock_hashes=validate_classes(manifest,args.jar);assert args.baseline in manifest['variants'] and args.candidate in manifest['variants'];assert args.java_home==manifest['java_home']
 root.mkdir();frozen=root/'helper-snapshots';frozen.mkdir();helpers={}
 for rel,h in PINS.items():
  source=HELP/rel;assert sha(source)==h;target=frozen/rel;target.write_bytes(source.read_bytes());helpers[rel]=h
 m=types.ModuleType('frozen_java_pair_support');m.__file__=str(frozen/'paired_cli.py');exec(compile((frozen/'paired_cli.py').read_bytes(),m.__file__,'exec'),m.__dict__)
 spec=read(args.spec);assert all('\n' not in v and '\r' not in v and '\x00' not in v for v in spec['argv']);identity=m.input_identity(spec)
 oracle=read(args.oracle);om=read(args.oracle_metadata);assert om.get('jar_sha256',om.get('java_jar_sha256'))==JAR and work_identity(om['spec'])==work_identity(spec) and om['input_manifest']==identity
 assert set(oracle)=={'stdout','stderr','exit',*spec['artifacts'],*spec.get('absent_artifacts',[])} and len(oracle)==6 and oracle['exit']==hashlib.sha256(b'0\n').hexdigest()
 args.driver=manifest['driver']['directory'];args.binary=args.jar
 args.readonly_bind=sorted(set(args.readonly_bind+[v for v in spec['links'].values()]+[v['overlay'] for v in manifest['variants'].values() if v['overlay']]))
 names=[args.baseline,args.candidate];engine=m.Engine(args)
 engine_call=engine.call
 def bounded_call(*argv,**kwargs):kwargs.setdefault('timeout',15);return engine_call(*argv,**kwargs)
 engine.call=bounded_call
 assert not engine.call('ps','-q',capture_output=True,text=True,timeout=15).stdout.strip()
 started=time.monotonic();before=outer();cohorts=[];owned=[];cleanup=[];rng=random.Random(args.seed)
 def check():
  now=outer();zero(oom_delta(before,now));assert memory_headroom(now)>=args.minimum_outer_headroom,'cache-aware outer memory headroom guard';assert time.monotonic()-started<args.total_timeout,'total bound';disk=os.statvfs(root);assert disk.f_bavail*disk.f_frsize>=args.minimum_disk_free,'disk guard'
 def unchanged():assert sha(args.manifest)==grant['manifest_sha256'] and sha(args.spec)==grant['spec_sha256']
 save(root/'metadata.json',vars(args)|{'manifest':manifest,'manifest_sha256':sha(args.manifest),'runner_sha256':sha(Path(__file__)),'runtime_grant_sha256':sha(args.runtime_grant),'spec_sha256':sha(args.spec),'oracle_sha256':sha(args.oracle),'oracle_metadata_sha256':sha(args.oracle_metadata),'input_manifest':identity,'helpers':helpers,'jar_sha256':JAR,'driver_source_sha256':sha(HERE/'CliFactors.java'),'java_executable_sha256':sha(Path(args.java_home)/'bin/java'),'java_runtime_dependencies':m.java_runtime_dependencies(args.java_home),'java_flags':['-Xmx3g'],'collector':'JDK21 default collector; no collector flag','allocation_metric':'VM-wide ThreadMXBean total allocated bytes if supported; counter-boundary management overhead included; not live heap or RSS','memory_window':'Per-variant JVM lifetime HWM including warmup/JIT/measurement, one final HWM per cohort; per-request current RSS separately','runner_policy_version':'cache-aware-v3-PSIoptional','runner_path':str(Path(__file__).resolve()),'pressure_telemetry':{'required_zero_when_measuring':['local_high','local_max','pgscan_direct','pgsteal_direct'],'optional_zero_if_available':['pgmajfault','PSI_some_total_us','PSI_full_total_us'],'unavailable_PSI':'null; no zeroPSI claim; directreclaim counters are proxies, not PSI'},'resident_policy':'twoJVMonly; inactivecontainer paused; pagesremaincharged; cache-awareheadroom=max-current+inactive_file+slab_reclaimable cappedmax;1GiBguard every250ms;zeroOOMalways; measuredlocalhigh/max/directscan/directsteal/availablemajfaultZERO;PSIZEROonlyifavailable;warmreclamationrecordedallowed','same_work':'freshCommandLineRunner/Compiler and externparse EVERYrequest; no source/extern/result cache; samefixedargv/input/artifacts','statistics':'screen1cohort has noCI; confirm3independentbaseline+candidateJVMpairs; wholecohortresamplingonly'});save(root/'oracle.json',oracle)
 try:
  for cohort_index in range(1,args.cohorts+1):
   check();unchanged();directory=root/('cohort-'+str(cohort_index));directory.mkdir();jvms={};warm={name:[] for name in names};measured={name:[] for name in names};pairs=[];c_before=outer()
   try:
    start_order=names[:] if cohort_index%2 else names[::-1]
    for name in start_order:
     v=manifest['variants'][name];classmap=v['classes'] if v['overlay'] else stock_hashes
     # Root families only: initialization-free loading proves firstclasspath origin.
     origins=['com.google.javascript.jscomp.'+family.replace('/','.') for family in sorted(manifest['compiler_source_families'])]
     expected={name:classmap[name.replace('.','/')+'.class'] for name in origins}
     j=JVM(name,v,directory/name,engine,m,args,spec,origins,expected);owned.append(j);jvms[name]=j;j.ready(check)
    for warm_index in range(1,args.max_warmup+1):
     order=names[:] if (warm_index+cohort_index)%2 else names[::-1]
     for name in order:
      check();unchanged();row=jvms[name].request(warm_index,'warmup',check);assert row['digests']==oracle,'warmup strict6DIFF '+name;warm[name].append(row)
     stable={name:stability(warm[name]) for name in names};save(directory/'warmup.json',{'rows':warm,'stability':stable});print('cohort',cohort_index,'warmup',warm_index,{n:v['stable'] for n,v in stable.items()},flush=True)
     if warm_index>=args.min_warmup and all(v['stable'] for v in stable.values()):break
    else:raise RuntimeError('UNSETTLED warmup atmax90; no accepted timing')
    first=rng.randrange(2)
    for pair_index in range(1,args.pairs+1):
     order=names[:] if (pair_index+first)%2 else names[::-1];pair={'pair':pair_index,'order':order,'rows':{}}
     for name in order:
      check();unchanged();number=len(warm[name])+pair_index;row=jvms[name].request(number,'measure',check);assert row['digests']==oracle,'measured strict6DIFF '+name;measured[name].append(row);pair['rows'][name]=row
     pairs.append(pair);save(directory/'pairs.json',pairs);print('cohort',cohort_index,'pair',pair_index,'PASS6',flush=True)
    # Lifetime HWM at the last request includes all preceding warmup+measure work.
    variants={name:{'wall_seconds':stats([r['wall_s'] for r in measured[name]]),'CPU_seconds':stats([r['cpu_s'] for r in measured[name]]),'current_RSS_MiB':stats([r['rss_mib'] for r in measured[name]]),'final_lifetime_HWM_MiB':max(r['peak_rss_mib'] for r in warm[name]+measured[name]),'allocated_bytes':stats([r['allocated_bytes'] for r in measured[name]]) if all(r['allocated_bytes'] is not None for r in measured[name]) else None,'warm_requests':len(warm[name]),'settling':stability(warm[name])} for name in names}
    b,v=args.baseline,args.candidate;ratios={'elapsed':variants[v]['wall_seconds']['median']/variants[b]['wall_seconds']['median'],'CPU':variants[v]['CPU_seconds']['median']/variants[b]['CPU_seconds']['median'],'RSS_lifetimeHWM':variants[v]['final_lifetime_HWM_MiB']/variants[b]['final_lifetime_HWM_MiB']}
    if variants[b]['allocated_bytes'] and variants[v]['allocated_bytes']:ratios['allocated_bytes']=variants[v]['allocated_bytes']['median']/variants[b]['allocated_bytes']['median']
    paired={metric:stats([p['rows'][v][key]/p['rows'][b][key] for p in pairs]) for metric,key in [('elapsed','wall_s'),('CPU','cpu_s'),('current_RSS','rss_mib')]}
    c_after=outer();zero(oom_delta(c_before,c_after));cohort={'cohort':cohort_index,'variants':variants,'candidate_over_baseline':ratios,'same_pair_ratios':paired,'outer_before':c_before,'outer_after':c_after};cohorts.append(cohort);save(directory/'cohort-summary.json',cohort)
   finally:
    for j in jvms.values():cleanup+=j.close()
    check();unchanged();assert m.input_identity(spec)==identity
   save(root/'progress.json',{'completed_cohorts':cohorts})
  summary={'status':'PASS settled byteidentical Java-vs-Java','complete':len(cohorts)==args.cohorts,'baseline':args.baseline,'candidate':args.candidate,'cohorts':cohorts,'confidence_unit':'freshindependent pair-of-JVM cohort; no perrequestpseudo-replication','ratios':{metric:{'cohort_values':[c['candidate_over_baseline'][metric] for c in cohorts],'cohort_statistics':stats([c['candidate_over_baseline'][metric] for c in cohorts]),'whole_cohort_bootstrap95':cohort_ci([c['candidate_over_baseline'][metric] for c in cohorts],args.seed+index)} for index,metric in enumerate(cohorts[0]['candidate_over_baseline'])},'direction':'candidate/baseline;<1 lowercost','Java_vs_Go_claim':False,'source_manifest_sha256':sha(args.manifest)}
  save(root/'summary.json',summary);print(json.dumps(summary['ratios'],indent=2))
 except BaseException as error:
  save(root/'failure.json',{'status':'REJECTED no acceptedperformanceclaim','type':type(error).__name__,'message':str(error),'traceback':traceback.format_exc(),'outer':outer()});raise
 finally:
  errors=[]
  for j in owned:
   try:cleanup+=j.close()
   except BaseException as e:errors.append(repr(e))
  # Cleanup only exact engine-owned IDs. Never remove unrelated containers.
  for cid in list(engine.containers):
   try:engine.call('rm','-f',cid,stdout=subprocess.DEVNULL,timeout=15);engine.containers.discard(cid);cleanup.append({'container':cid,'fallback_removed':True})
   except BaseException as e:errors.append(repr(e))
  for j in owned:
   if j.process and j.process.poll() is None:
    for sig in (signal.SIGTERM,signal.SIGKILL):
     if j.process.poll() is not None:break
     try:os.killpg(j.process.pid,sig)
     except ProcessLookupError:pass
     try:j.process.wait(timeout=5)
     except subprocess.TimeoutExpired:pass
  after=outer();proof={'owned_cleanup':cleanup,'cleanup_errors':errors,'remaining_owned_containers':sorted(engine.containers),'active_compilers':active(),'remaining_owned_driver_processes':[j.process.pid for j in owned if j.process and j.process.poll() is None],'outer_before':before,'outer_after':after,'outer_OOM_delta':oom_delta(before,after)};save(root/'stopped-proof.json',proof);assert not errors and not proof['remaining_owned_containers'] and not proof['active_compilers'] and not proof['remaining_owned_driver_processes'];zero(proof['outer_OOM_delta'])
if __name__=='__main__':main()
