"""Independent post-run Java-factor review; never imports the benchmark runner.

Read only completed results. Write JSON/CSV to a NEW directory outside results.
No JVM, compiler, Docker, benchmark, or full-JAR/binary hashing is performed.
Only small protocol streams, source files, driver classes and nine stock class
entries are hashed. Historical large output artifacts were intentionally reused;
their six recorded digests are checked against the fixed oracle on every row.
"""
from pathlib import Path
import argparse,collections,csv,hashlib,json,math,random,statistics,traceback,zipfile
from urllib.parse import urlparse,unquote
JAR_SHA='d6864ebf70bca5ba6e237898de6611a389aaf8b933c2549036ced4a684b664b6'
def read(p):return json.loads(Path(p).read_text())
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def require(ok,message):
 if not ok:raise ValueError(message)
def same(a,b,label):require(a==b,label)
def close(a,b,label):require(math.isclose(a,b,rel_tol=1e-11,abs_tol=1e-11),label)
def zero(d,label):require(not any(d.get(k,0) for k in ('oom','oom_kill','oom_group_kill')),label)
def counters(s):return {k:int(v) for k,v in (line.split() for line in s.replace(';','\n').splitlines())}
def delta(before,after):return {k:counters(after['memory.events']).get(k,0)-counters(before['memory.events']).get(k,0) for k in ('oom','oom_kill','oom_group_kill')}
def pressure_totals(text):
 if text is None:return None
 out={}
 for line in text.splitlines():
  fields=line.split();out[fields[0]]=int(dict(item.split('=',1) for item in fields[1:])['total'])
 same(set(out),{'some','full'},'PSI dimensions');return out
def check_pressure(row,protocol,runner_policy):
 if runner_policy=='raw-current-v1':require('parent_pressure' not in row,'unexpectedv1pressure schema');return {'PSI':'NOT_RECORDED_v1'}
 pressure=row['parent_pressure'];same(read(protocol/'parent-pressure.json'),pressure,'retained parent pressure')
 before,after=pressure['before'],pressure['after'];a,b=counters(before['memory.events.local']),counters(after['memory.events.local']);sa,sb=counters(before['memory.stat']),counters(after['memory.stat'])
 changes={'local_high':b.get('high',0)-a.get('high',0),'local_max':b.get('max',0)-a.get('max',0)}
 if runner_policy=='cache-aware-v3-PSIoptional':
  for key in ('pgscan_direct','pgsteal_direct'):require(key in sa and key in sb,'required reclaim counter missing')
  for key in ('pgscan_direct','pgsteal_direct','pgmajfault'):changes[key]=sb[key]-sa[key] if key in sa and key in sb else None
 pa,pb=pressure_totals(before['memory.pressure']),pressure_totals(after['memory.pressure'])
 for key in ('some','full'):changes['PSI_'+key+'_total_us']=pb[key]-pa[key] if pa is not None and pb is not None else None
 same(pressure['changes'],changes,'recomputed memory pressure deltas');same(pressure['zero_required'],row['kind']=='measure','measuredpressure policy')
 require(all(v is None or v>=0 for v in changes.values()),'decreasing pressure counters')
 if row['kind']=='measure':require(all(v is None or v==0 for v in changes.values()),'measured memory pressure/reclaim')
 for state in (before,after):
  maximum,current=int(state['memory.max']),int(state['memory.current']);st=counters(state['memory.stat']);headroom=max(0,min(maximum,maximum-current+st.get('inactive_file',0)+st.get('slab_reclaimable',0)))
  require(0<=headroom<=maximum,'cache-aware headroom geometry')
 zero(delta(before,after),'request parentOOM')
 return {'PSI':'AVAILABLE' if pa is not None and pb is not None else 'UNAVAILABLE_no_zeroPSI_claim','changes':changes}
def stats(values):
 values=list(values);sd=statistics.stdev(values) if len(values)>1 else None;mean=statistics.mean(values)
 return {'raw':values,'count':len(values),'mean':mean,'median':statistics.median(values),'min':min(values),'max':max(values),'sample_SD':sd,'sample_variance':statistics.variance(values) if len(values)>1 else None,'CV':sd/mean if sd is not None and mean else None}
def runner_stats(values):
 s=stats(values);return {'raw':s['raw'],'mean':s['mean'],'median':s['median'],'min':s['min'],'max':s['max'],'sample_stdev':s['sample_SD'],'sample_variance':s['sample_variance']}
def check_runner_stats(actual,values,label):
 expected=runner_stats(values);same(set(actual),set(expected),label+' statistic fields')
 for k,v in expected.items():
  if isinstance(v,float):close(actual[k],v,label+' '+k)
  else:same(actual[k],v,label+' '+k)
def bootstrap(values,seed):
 if len(values)!=3:return None
 logs=[math.log(v) for v in values];rng=random.Random(seed);resamples=sorted(math.exp(statistics.mean(rng.choices(logs,k=3))) for _ in range(10000))
 return {'geomean':math.exp(statistics.mean(logs)),'ci95_low':resamples[250],'ci95_high':resamples[9749],'independent_cohorts':3,'seed':seed,'resamples':10000,'unit':'whole independent pair-of-JVM cohort median ratio','limitation':'three observations; discrete bootstrap confined to observed cohort range'}
def t_interval(values):
 if len(values)!=3:return None
 logs=[math.log(v) for v in values];mean=statistics.mean(logs);sd=statistics.stdev(logs);half=4.302652729911275*sd/math.sqrt(3)
 return {'geomean':math.exp(mean),'ci95_low':math.exp(mean-half),'ci95_high':math.exp(mean+half),'df':2,'critical_t':4.302652729911275,'log_cohort_SD':sd,'unit':'three independent cohort log ratios','assumption':'approximately normal independent log-cohort effects; not distribution-free'}
def invert(interval):
 if interval is None:return None
 return {'geomean':1/interval['geomean'],'ci95_low':1/interval['ci95_high'],'ci95_high':1/interval['ci95_low']}
def settling(rows):
 require(len(rows)>=12,'fewer than12 warm requests');a,b=rows[-8:-4],rows[-4:]
 drift=statistics.median(r['wall_s'] for r in b)/statistics.median(r['wall_s'] for r in a)-1
 require(all(r['jit_before_ms']>=0 and r['jit_after_ms']>=r['jit_before_ms'] for r in b),'JIT monitoring unavailable')
 jit=sum(r['jit_after_ms']-r['jit_before_ms'] for r in b)/(1000*sum(r['wall_s'] for r in b));spread=max(r['wall_s'] for r in b)/min(r['wall_s'] for r in b)
 require(abs(drift)<=.05 and jit<=.02 and spread<=1.20,'warm target unsettled')
 return {'last4_vs_prior4_median_drift':drift,'last4_JIT_time_over_wall':jit,'last4_max_over_min':spread,'stable':True}
def csv_write(path,rows):
 with Path(path).open('w',newline='') as f:
  writer=csv.DictWriter(f,fieldnames=list(rows[0]));writer.writeheader();writer.writerows(rows)
def review(root,manifest_path,telemetry_anomalies=None):
 if telemetry_anomalies is None:telemetry_anomalies=[]
 require(not (root/'failure.json').exists(),'failure evidence present: no accepted result')
 summary=read(root/'summary.json');stopped=read(root/'stopped-proof.json');m=read(root/'metadata.json');oracle=read(root/'oracle.json')
 same(summary['status'],'PASS settled byteidentical Java-vs-Java','summary status');require(summary['complete'],'incomplete summary')
 require(not stopped['cleanup_errors'] and not stopped['remaining_owned_containers'] and not stopped['active_compilers'] and not stopped['remaining_owned_driver_processes'],'not stopped cleanly');zero(stopped['outer_OOM_delta'],'outerOOM')
 zero(delta(stopped['outer_before'],stopped['outer_after']),'outerOOM recomputation')
 require(m['cohorts'] in (1,3) and m['pairs']==5 and m['min_warmup']==12 and 12<=m['max_warmup']<=90,'protocol counts')
 names=[m['baseline'],m['candidate']];same(summary['baseline'],names[0],'baseline');same(summary['candidate'],names[1],'candidate')
 require(len(set(names))==2,'identical variants');same(len(summary['cohorts']),m['cohorts'],'cohort count')
 same(m['jar_sha256'],JAR_SHA,'pinned jar');same(m['java_flags'],['-Xmx3g'],'JVM flags')
 same(sha(manifest_path),m['manifest_sha256'],'manifest receipt hash')
 manifest=m['manifest'];same(read(manifest_path),manifest,'full manifest contents');same(manifest['status'],'PASS_BUILD_VALIDATION','build validation');same(manifest['jar_sha256'],JAR_SHA,'manifest jar')
 known={'c182fd88207911128d0ae50fcbb4a12a6457b490dd30d27f85e078bb98ab2745':('run.py','raw-current-v1'),'f33090da81d66328dcb8c366d8e36f7214b65dae746c45dd207f2af2571895ef':('run-v2.py','cache-aware-v2'),'2eca9cede566627bc2511f660f32830bce039b47c4b101d194c2918348470d16':('run-v3.py','cache-aware-v3-PSIoptional')}
 require(m['runner_sha256'] in known,'unreviewed runner source version');runner_name,runner_policy=known[m['runner_sha256']];same(sha(Path(__file__).with_name(runner_name)),m['runner_sha256'],'actual pinned runner source')
 if runner_policy!='raw-current-v1':same(m['runner_policy_version'],runner_policy,'runner policy version')
 same(manifest['driver']['source_sha256'],m['driver_source_sha256'],'shared driver source')
 require(manifest['unmodified_compiler_classes_outside_overlays'],'compiler class provenance')
 same(len(manifest['compiler_source_families']),9,'nine recompiled families')
 driver=manifest['driver'];require(Path(driver['directory']).resolve()==Path(m['driver']).resolve(),'driver path')
 for rel,h in driver['classes'].items():same(sha(Path(driver['directory'])/rel),h,'shared driver class '+rel)
 same(sha(m['spec']),m['spec_sha256'],'spec hash');spec=read(m['spec']);same(sha(m['oracle']),m['oracle_sha256'],'oracle hash');same(read(m['oracle']),oracle,'oracle content')
 same(sha(m['oracle_metadata']),m['oracle_metadata_sha256'],'oracle provenance hash')
 same(set(oracle),{'stdout','stderr','exit',*spec['artifacts'],*spec.get('absent_artifacts',[])},'six digest coverage');same(len(oracle),6,'six oracle digests')
 same(oracle['exit'],hashlib.sha256(b'0\n').hexdigest(),'successful oracle')
 for key,value in oracle.items():
  if key in spec.get('absent_artifacts',[]):same(value,None,'absence digest')
  else:require(isinstance(value,str) and len(value)==64,'invalid digest '+key)
 grant=read(m['runtime_grant']);same(sha(m['runtime_grant']),m['runtime_grant_sha256'],'grant receipt hash')
 for field in ('baseline','candidate','cohorts','pairs'):same(grant[field],m[field],'grant '+field)
 same(grant['runner_sha256'],m['runner_sha256'],'runner pin');same(grant['manifest_sha256'],m['manifest_sha256'],'manifest pin');same(grant['spec_sha256'],m['spec_sha256'],'spec pin');same(Path(grant['out']).resolve(),root,'grant output')
 # Small target class entries only. Do not rehash the large jar or binaries.
 families=manifest['compiler_source_families'];class_names=['com.google.javascript.jscomp.'+family.replace('/','.') for family in sorted(families)]
 stock_hashes={}
 if 'STOCK' in names:
  with zipfile.ZipFile(m['jar']) as z:
   stock_hashes={name:hashlib.sha256(z.read(name.replace('.','/')+'.class')).hexdigest() for name in class_names}
 rows_csv=[];cohort_csv=[];all_measured={n:[] for n in names};independent=[];container_ids=[];vm_versions=[]
 for index,reported in enumerate(summary['cohorts'],1):
  same(reported['cohort'],index,'cohort index');directory=root/('cohort-'+str(index));same(read(directory/'cohort-summary.json'),reported,'retained cohort summary')
  warm=read(directory/'warmup.json');pairs=read(directory/'pairs.json');same(set(warm['rows']),set(names),'warm variants');same(len(pairs),5,'five pairs')
  require(len(warm['rows'][names[0]])==len(warm['rows'][names[1]]),'unmatched warm request counts')
  measured={n:[] for n in names}
  for pair_index,pair in enumerate(pairs,1):
   same(pair['pair'],pair_index,'pair index');same(set(pair['rows']),set(names),'pair variants');same(sorted(pair['order']),sorted(names),'pair order')
   if pair_index>1:same(pair['order'],pairs[pair_index-2]['order'][::-1],'AB/BA alternation')
   for name in names:measured[name].append(pair['rows'][name])
  variants={}
  for name in names:
   v=manifest['variants'][name];work=directory/name;ready=read(work/'ready.json');command=read(work/'jvm-command.json');owned=read(work/'owned-driver.json');config=read(work/'container-config.json');caps=ready['caps']
   require(len(caps)==5 and caps[:3]==['READY','4294967296','0'] and caps[4] in ('0-1','0,1'),'kernel caps');quota,period=map(int,caps[3].split());same(quota,2*period,'CPU quota')
   host=config['host_config'];same(host['Memory'],4294967296,'Docker memory');same(host['MemorySwap'],4294967296,'Docker swap');same(host['NanoCpus'],2000000000,'Docker CPU');same(host['CpusetCpus'],'0,1','Docker cpuset');same(host['NetworkMode'],'none','Docker network')
   same(config['id'],owned['container'],'owned container');same(Path(owned['workdir']).resolve(),work.resolve(),'owned workdir');same(owned['pid'],owned['pgid'],'owned driver processgroup');container_ids.append(config['id'])
   vm=ready['VM'];require(vm['runtime_version'].startswith('21.') and 0<vm['max_heap_bytes']<=3221225472,'Java21/maxheap');vm_versions.append(vm)
   cp=([v['overlay']] if v['overlay'] else [])+[m['jar'],m['driver']]
   expected=['python3',str(root/'helper-snapshots/cgroup_exec.py'),str(Path(m['java_home'])/'bin/java'),'-Xmx3g','-cp',':'.join(cp),'CliFactors',str(work/'argv.txt'),str(work/'classes.txt')]
   same(command['command'],expected,'exact Java command/classpath/defaultflags');same((work/'argv.txt').read_text().splitlines(),spec['argv'],'compiler arguments')
   same(set(ready['loaded_target_classes']),set(class_names),'target class coverage')
   for cls,origin in ready['loaded_target_classes'].items():
    expected_location=Path(v['overlay'] or m['jar']).resolve();same(Path(unquote(urlparse(origin['location']).path)).resolve(),expected_location,'loaded class origin '+cls)
    expected_hash=v['classes'][cls.replace('.','/')+'.class'] if v['overlay'] else stock_hashes[cls];same(origin['sha256'],expected_hash,'loaded class digest '+cls)
   warms=warm['rows'][name];require(12<=len(warms)<=m['max_warmup'],'warm request count');settled=settling(warms);same(warm['stability'][name]['stable'],True,'recorded settling')
   for k,val in settled.items():
    if k!='stable':close(warm['stability'][name][k],val,'settling '+k)
   combined=warms+measured[name];last_hwm=last_peak=0
   for request_index,row in enumerate(combined,1):
    kind='warmup' if request_index<=len(warms) else 'measure';same(row['variant'],name,'row variant');same(row['kind'],kind,'row kind');same(row['request'],request_index,'request sequence')
    protocol=work/'protocol'/str(request_index);same(read(protocol/'row.json'),row,'retained protocol row')
    pressure_result=check_pressure(row,protocol,runner_policy)
    same(row['digests'],oracle,'strict all6 digests');same(row['exit'],0,'compiler exit');zero(counters(row['cgroup_events']),'request cgroupOOM')
    require(row['cgroup_peak_bytes']<=4294967296 and row['cgroup_current_bytes']<=4294967296,'request cgroup memory')
    if row['cgroup_peak_bytes']<last_peak:
     anomaly={'metric':'cgroup_memory_peak_bytes','cohort':index,'variant':name,'request':request_index,'kind':kind,'before':last_peak,'after':row['cgroup_peak_bytes'],'allowed':False}
     telemetry_anomalies.append(anomaly);error=ValueError('nonmonotonic cgroup lifetime peak: '+repr(anomaly));error.telemetry_anomalies=telemetry_anomalies;raise error
    if row['peak_rss_mib']<last_hwm:
     previous=combined[request_index-2]
     anomaly={'metric':'proc_VmHWM_kib','cohort':index,'variant':name,'prior_request':previous['request'],'request':request_index,'kind':kind,'before':previous['hwm_kib'],'after':row['hwm_kib'],'delta_kib':row['hwm_kib']-previous['hwm_kib'],'allowed':False,'later_strictly_larger_sample':None}
     telemetry_anomalies.append(anomaly)
     later=next((future for future in combined[request_index:] if future['hwm_kib']>previous['hwm_kib']),None) if kind=='warmup' else None
     if later is None:
      error=ValueError('VmHWM decrease is measured or lacks a later strictly larger sample: '+repr(anomaly));error.telemetry_anomalies=telemetry_anomalies;raise error
     # Both the anomalous row above and its superseding proof must match the
     # retained per-request protocol before any exception is admitted.
     later_protocol=work/'protocol'/str(later['request'])/'row.json'
     same(read(later_protocol),later,'retained superseding VmHWM protocol row')
     anomaly.update(allowed=True,later_strictly_larger_sample={'request':later['request'],'kind':later['kind'],'hwm_kib':later['hwm_kib'],'retained_protocol':str(later_protocol)},retained_protocol_rows_exact=True)
    last_hwm=row['peak_rss_mib'];last_peak=row['cgroup_peak_bytes']
    close(row['wall_s'],row['wall_ns']/1e9,'elapsed conversion');close(row['cpu_s'],row['cpu_ns']/1e9,'CPU conversion');close(row['rss_mib'],row['rss_kib']/1024,'RSS conversion');close(row['peak_rss_mib'],row['hwm_kib']/1024,'HWM conversion')
    require(row['wall_s']>0 and row['cpu_s']>=0 and row['rss_mib']>0 and row['peak_rss_mib']>0,'invalid metrics')
    allocation=row['allocation_after']-row['allocation_before'] if row['allocation_before']>=0 and row['allocation_after']>=row['allocation_before'] else None;same(row['allocated_bytes'],allocation,'VMwide allocation delta')
    # Retained per-request stream hashes are small; large JS/maps are NOT duplicated.
    for stream in ('stdout','stderr','exit'):same(sha(protocol/stream),oracle[stream],'retained '+stream+' bytes')
    rows_csv.append({'cohort':index,'variant':name,'kind':kind,'request':request_index,'wall_s':row['wall_s'],'CPU_s':row['cpu_s'],'RSS_current_MiB':row['rss_mib'],'HWM_lifetime_MiB':row['peak_rss_mib'],'allocated_bytes':allocation,'GC_count':row['gc_count'],'GC_ms':row['gc_ms'],'JIT_delta_ms':row['jit_after_ms']-row['jit_before_ms'],'strict_digests':6,'PSI_telemetry':pressure_result['PSI']})
   all_measured[name].extend(measured[name]);wall=[r['wall_s'] for r in measured[name]];cpu=[r['cpu_s'] for r in measured[name]];rss=[r['rss_mib'] for r in measured[name]];alloc=[r['allocated_bytes'] for r in measured[name]]
   reported_variant=reported['variants'][name];check_runner_stats(reported_variant['wall_seconds'],wall,'wall stats');check_runner_stats(reported_variant['CPU_seconds'],cpu,'CPU stats');check_runner_stats(reported_variant['current_RSS_MiB'],rss,'RSS stats')
   hwm=max(r['peak_rss_mib'] for r in combined);close(reported_variant['final_lifetime_HWM_MiB'],hwm,'cohort lifetime HWM');same(reported_variant['warm_requests'],len(warms),'warm count')
   allocation_stats=stats(alloc) if all(v is not None for v in alloc) else None
   if allocation_stats:check_runner_stats(reported_variant['allocated_bytes'],alloc,'allocation stats')
   else:same(reported_variant['allocated_bytes'],None,'unsupported allocation metric')
   variants[name]={'wall_seconds':stats(wall),'CPU_seconds':stats(cpu),'current_RSS_MiB':stats(rss),'final_lifetime_HWM_MiB':hwm,'allocated_bytes':allocation_stats,'warm_requests':len(warms),'settling':settled}
   cohort_csv.append({'cohort':index,'variant':name,'warm_requests':len(warms),'wall_median_s':statistics.median(wall),'wall_mean_s':statistics.mean(wall),'wall_sample_SD_s':statistics.stdev(wall),'wall_CV':statistics.stdev(wall)/statistics.mean(wall),'CPU_median_s':statistics.median(cpu),'HWM_lifetime_MiB':hwm,'allocated_median_bytes':statistics.median(alloc) if allocation_stats else None})
  base,candidate=names;b,v=variants[base],variants[candidate];ratios={'elapsed':v['wall_seconds']['median']/b['wall_seconds']['median'],'CPU':v['CPU_seconds']['median']/b['CPU_seconds']['median'],'RSS_lifetimeHWM':v['final_lifetime_HWM_MiB']/b['final_lifetime_HWM_MiB']}
  if b['allocated_bytes'] and v['allocated_bytes']:ratios['allocated_bytes']=v['allocated_bytes']['median']/b['allocated_bytes']['median']
  same(set(reported['candidate_over_baseline']),set(ratios),'cohort ratio fields')
  for key,val in ratios.items():close(reported['candidate_over_baseline'][key],val,'cohort '+key+' ratio')
  paired={metric:[pair['rows'][candidate][field]/pair['rows'][base][field] for pair in pairs] for metric,field in [('elapsed','wall_s'),('CPU','cpu_s'),('current_RSS','rss_mib')]}
  for metric,values in paired.items():check_runner_stats(reported['same_pair_ratios'][metric],values,'same-pair '+metric)
  zero(delta(reported['outer_before'],reported['outer_after']),'cohort outerOOM');independent.append({'cohort':index,'variants':variants,'candidate_over_baseline':ratios,'same_pair_ratios':{k:stats(v) for k,v in paired.items()}})
 same(len(set(container_ids)),2*m['cohorts'],'two distinct JVMs/cohort');same(len(stopped['owned_cleanup']),len(container_ids),'one graceful cleanup per JVM')
 same({row['container'] for row in stopped['owned_cleanup']},set(container_ids),'owned cleanup identity')
 for row in stopped['owned_cleanup']:require(row.get('removed') is True and row.get('driver_exit')==0 and not row.get('fallback_removed'),'nonzero or nongraceful driver teardown')
 require(all(v==vm_versions[0] for v in vm_versions),'JVM versions/collectors/maxheap differ')
 summary_ratios={}
 for offset,metric in enumerate(independent[0]['candidate_over_baseline']):
  values=[c['candidate_over_baseline'][metric] for c in independent];reported=summary['ratios'][metric];same(reported['cohort_values'],values,'cohort ratio observations');check_runner_stats(reported['cohort_statistics'],values,'cohort ratio stats')
  ci=bootstrap(values,m['seed']+offset);ti=t_interval(values)
  if ci:
   for key in ('geomean','ci95_low','ci95_high'):close(reported['whole_cohort_bootstrap95'][key],ci[key],'bootstrap '+metric+' '+key)
  else:same(reported['whole_cohort_bootstrap95'],None,'single-cohort no CI')
  summary_ratios[metric]={'candidate_over_baseline':stats(values),'geomean_candidate_over_baseline':math.exp(statistics.mean(map(math.log,values))),'baseline_over_candidate':stats([1/v for v in values]),'geomean_baseline_over_candidate':math.exp(statistics.mean(-math.log(v) for v in values)),'bootstrap95_candidate_over_baseline':ci,'bootstrap95_baseline_over_candidate':invert(ci),'log_t95_df2_candidate_over_baseline':ti,'log_t95_df2_baseline_over_candidate':invert(ti)}
 pooled={name:{'elapsed_seconds_DESCRIPTIVE_ONLY':stats([r['wall_s'] for r in rows]),'CPU_seconds_DESCRIPTIVE_ONLY':stats([r['cpu_s'] for r in rows]),'current_RSS_MiB_DESCRIPTIVE_ONLY':stats([r['rss_mib'] for r in rows]),'lifetime_HWM_MiB_one_per_cohort':stats([c['variants'][name]['final_lifetime_HWM_MiB'] for c in independent]),'allocated_bytes_DESCRIPTIVE_ONLY':stats([r['allocated_bytes'] for r in rows]) if all(r['allocated_bytes'] is not None for r in rows) else None} for name,rows in all_measured.items()}
 report={'status':'PASS independent Java-factor review','results':str(root),'baseline':names[0],'candidate':names[1],'cohorts':m['cohorts'],'pairs_per_cohort':5,'warmup_requests':sum(len(read(root/('cohort-'+str(i))/'warmup.json')['rows'][name]) for i in range(1,m['cohorts']+1) for name in names),'measured_requests':10*m['cohorts'],'strict_digests_every_request':6,'all_graceful_driver_exit_codes_zero':True,'per_cohort':independent,'pooled_descriptive_statistics':pooled,'ratios':summary_ratios,'VM':vm_versions[0],'stopped_proof_sha256':sha(root/'stopped-proof.json'),'runner_sha256':m['runner_sha256'],'runner_policy_version':runner_policy,'manifest_sha256':m['manifest_sha256'],'PSI_telemetry':sorted({row['PSI_telemetry'] for row in rows_csv}),'limits':['Large overwritten historical artifacts are unavailable for rehash; every recorded six-digest row equals pinned stock oracle; retained stdout/stderr/exit rehashed.','JAR and compiler executables not bulk-rehashed; nine stock target-class entries and shared driver classes checked.','Elapsed and CPU/allocated ratios use within-cohort medians. RSS ratio uses one full lifetime HWM per JVM/cohort including warmup and JIT.','CurrentRSS is a postrequest snapshot; cgroup peak includes cache and is not process RSS.','No CI from individual persistent-JVM requests; pooled request SD/CV is descriptive.','Three-cohort bootstrap is discrete; log Student t(df2) assumes approximately normal independent log-cohort effects.','Sequential/pause chronology follows the pinned runner source; no independent absolute request-timestamp overlap instrumentation.','MissingPSI is explicitly unavailable, never zero. v3 measuredlocalhigh/max/directscan/directsteal/availablemajfault checks are proxies, not proof of zeroPSI.'],'Java_vs_Go_claim':False}
 report['reviewer_version']='v2-warmup-VmHWM-amendment'
 report['telemetry_anomalies']=telemetry_anomalies
 report['reviewer_amendment']={'timing':'Adopted after observing STOCK cohort3 warmup7-to8 VmHWM decrease of60KiB in color-cache holdout; not prespecified','original_reviewer':'review-results.py unchanged; its failure retained','policy':'Only warmup VmHWM decreases with an exact retained later strictly larger sample can pass; measured VmHWM and any cgroup-peak decrease remain fatal; no size tolerance, smoothing, request/cohort exclusion or metric recomputation','uniform_application':'All variants and cohorts; all original byte/protocol/settling/provenance/caps/pressure/cleanup/statistics checks remain required'}
 report['RSS_definition']='Maximum observed /proc/self/status VmHWM sample over warmup and measurement, documented inaccurate; not an exact continuously observed lifetime maximum. No numerical accuracy bound is inferred. Current RSS and cgroup peak retain their separate windows.'
 report['limits'].append('VmHWM is documented inaccurate; every admitted warmup-only decrease and later strictly larger retained sample is disclosed. This post-observation reviewer amendment does not alter recorded values or max-sample ratios.')
 return report,rows_csv,cohort_csv
def main():
 p=argparse.ArgumentParser(description=__doc__);p.add_argument('--results',required=True,type=Path);p.add_argument('--out',required=True,type=Path);p.add_argument('--manifest',type=Path,default=Path(__file__).with_name('build-manifest.json'));a=p.parse_args();root=a.results.resolve();out=a.out.resolve()
 require(not out.exists(),'review output already exists');require(not out.is_relative_to(root),'review output must be outside measured result directory');out.mkdir(parents=True)
 telemetry_anomalies=[]
 try:
  report,rows,cohorts=review(root,a.manifest,telemetry_anomalies);csv_write(out/'rows.csv',rows);csv_write(out/'cohorts.csv',cohorts)
  ratios=[{'metric':name,'geomean_candidate_over_baseline':v['geomean_candidate_over_baseline'],'geomean_baseline_over_candidate':v['geomean_baseline_over_candidate'],'bootstrap95_low':v['bootstrap95_candidate_over_baseline']['ci95_low'] if v['bootstrap95_candidate_over_baseline'] else None,'bootstrap95_high':v['bootstrap95_candidate_over_baseline']['ci95_high'] if v['bootstrap95_candidate_over_baseline'] else None,'log_t95_df2_low':v['log_t95_df2_candidate_over_baseline']['ci95_low'] if v['log_t95_df2_candidate_over_baseline'] else None,'log_t95_df2_high':v['log_t95_df2_candidate_over_baseline']['ci95_high'] if v['log_t95_df2_candidate_over_baseline'] else None} for name,v in report['ratios'].items()];csv_write(out/'ratios.csv',ratios)
 except BaseException as error:
  report={'status':'FAIL independent Java-factor review','results':str(root),'error':str(error),'traceback':traceback.format_exc(),'reviewer_version':'v2-warmup-VmHWM-amendment','telemetry_anomalies':telemetry_anomalies};(out/'review.json').write_text(json.dumps(report,indent=2)+'\n');raise
 (out/'review.json').write_text(json.dumps(report,indent=2,allow_nan=False)+'\n');print(json.dumps({'status':report['status'],'out':str(out),'ratios':report['ratios']},indent=2))
if __name__=='__main__':main()
