#!/usr/bin/env python3
"""Build isolated Java class overlays; preserve every original artifact."""
import argparse, hashlib, json, os, re, subprocess, time, zipfile
from pathlib import Path

ROOT = Path(__file__).resolve().parent
SOURCE = Path('/workspace/jsgo/.cache/closure-src')
SOURCE_JAR = Path('/workspace/jsgo/.cache/closure-src.jar')
JAR = Path('/workspace/jsgo/.cache/closure-compiler-v20261015-maven.jar')
JAVA = Path('/usr/lib/jvm/java-21-openjdk-amd64/bin')
PREFIX = 'com/google/javascript/jscomp/'
FILES = [PREFIX + n for n in (
    'FlowSensitiveInlineVariables.java', 'GlobalNamespace.java',
    'CoalesceVariableNames.java', 'LiveVariablesAnalysis.java',
    'disambiguate/ColorGraphNodeFactory.java', 'PolyfillUsageFinder.java',
    'RemoveUnusedCode.java', 'RewritePolyfills.java', 'IsolatePolyfills.java')]
FACTORS = ['fsiv-lazy', 'namespace-lazy', 'coalesce-bitset', 'color-cache', 'polyfill-cache']

def sha(data): return hashlib.sha256(data).hexdigest()
def file_sha(p): return sha(Path(p).read_bytes())
def save(p, x): p.write_text(json.dumps(x, indent=2, allow_nan=False) + '\n')

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('variant', choices=['control', *FACTORS, 'all'])
    a = ap.parse_args()
    dest = ROOT / 'build' / a.variant
    if dest.exists(): raise RuntimeError('preserve prior build; existing destination ' + str(dest))
    assert file_sha(SOURCE_JAR) == '4d38166975b61466aa3b02b0d2d38160b855dd7f7e1f6171069fc84974bac45a'
    assert file_sha(JAR) == 'd6864ebf70bca5ba6e237898de6611a389aaf8b933c2549036ced4a684b664b6'
    selected = FACTORS if a.variant == 'all' else ([] if a.variant == 'control' else [a.variant])
    replacement = {}
    for factor in selected:
        paths = list((ROOT / 'variants' / factor / 'src').rglob('*.java'))
        assert paths, factor
        for p in paths:
            rel = p.relative_to(ROOT / 'variants' / factor / 'src').as_posix()
            assert rel in FILES and rel not in replacement, rel
            replacement[rel] = p
    dest.mkdir(parents=True)
    (dest / 'src').mkdir(); (dest / 'classes').mkdir()
    originals = {}; effective = {}; transformed = {}; paths = []
    with zipfile.ZipFile(SOURCE_JAR) as z:
        for rel in FILES:
            original = z.read(rel)
            assert (SOURCE / rel).read_bytes() == original, rel
            originals[rel] = sha(original)
            data = replacement[rel].read_bytes() if rel in replacement else original
            effective[rel] = sha(data)
            # The release jar relocates its dependencies. Preserve Java code and
            # map those same package names to the jar's already compiled types.
            text = re.sub(r'(?<![\w.])com\.google\.(common|auto|errorprone|gson|protobuf|j2objc|thirdparty)(?=\.)',
                          r'com.google.javascript.jscomp.jarjar.com.google.\1', data.decode())
            out = dest / 'src' / rel; out.parent.mkdir(parents=True, exist_ok=True)
            out.write_text(text); transformed[rel] = file_sha(out); paths.append(str(out))
    flags = ['--release', '21', '-g', '-proc:none', '-implicit:none', '-encoding', 'UTF-8']
    compiler = [str(JAVA / 'java'), '-Xmx1g', '-m', 'jdk.compiler/com.sun.tools.javac.Main']
    argv = [*compiler, *flags, '-classpath', str(JAR), '-sourcepath', str(dest / 'src'),
            '-d', str(dest / 'classes'), *paths]
    meta = {'variant': a.variant, 'status': 'STARTED', 'selected_factors': selected,
            'published_jar': str(JAR), 'published_jar_sha256': file_sha(JAR),
            'source_jar_sha256': file_sha(SOURCE_JAR), 'original_sources': originals,
            'effective_sources': effective, 'relocated_sources': transformed,
            'source_files': FILES, 'javac_flags': flags, 'argv': argv,
            'javac_version': subprocess.check_output([*compiler, '-version'], text=True).strip(),
            'classpath_overlay': str(dest / 'classes'), 'started_unix': time.time()}
    save(dest / 'build.json', meta)
    env = dict(os.environ)
    for key in ('JAVA_TOOL_OPTIONS', '_JAVA_OPTIONS', 'JDK_JAVA_OPTIONS'): env.pop(key, None)
    with (dest / 'stdout').open('wb') as out, (dest / 'stderr').open('wb') as err:
        p = subprocess.run(argv, stdout=out, stderr=err, env=env, timeout=180)
    meta.update(status='PASS' if p.returncode == 0 else 'FAILED', exit=p.returncode, ended_unix=time.time())
    meta['classes'] = {str(p.relative_to(dest / 'classes')): file_sha(p) for p in sorted((dest / 'classes').rglob('*.class'))}
    meta['class_count'] = len(meta['classes'])
    save(dest / 'build.json', meta)
    print(json.dumps({'variant': a.variant, 'status': meta['status'], 'class_count': meta['class_count'], 'root': str(dest)}))
    raise SystemExit(p.returncode)

if __name__ == '__main__': main()
