#!/usr/bin/env python3
"""Resume the fixed plan after an independently reviewed telemetry amendment."""
import json, subprocess, time
from pathlib import Path
ROOT = Path(__file__).resolve().parent

def main():
    sequence = ROOT / 'confirmation-sequence-v1.json'
    progress = json.loads(sequence.read_text())
    first = 'confirm-bigquery-stock-color-cache-v1'
    assert progress['review_failed'] == first and not progress['completed']
    review = json.loads((ROOT / 'reviews' / first / 'review.json').read_text())
    assert review['status'] == 'PASS independent Java-factor review'
    assert (ROOT / 'results/review-telemetry-amendment-v1/sequence-at-failure.json').exists()
    summary = json.loads((ROOT / 'results' / first / 'summary.json').read_text())
    progress['completed'].append({'name': first, 'ratios': {k: v['cohort_values'] for k, v in summary['ratios'].items()}})
    progress.pop('review_failed')
    progress['resumed_after_review_amendment'] = 'results/review-telemetry-amendment-v1/amendment.json'
    progress['resumed_unix'] = time.time()
    for task, cohorts in [('bigquery', 3), ('bundle', 1)]:
        name = 'confirm-' + task + '-stock-all-v1'
        progress['active'] = name
        sequence.write_text(json.dumps(progress, indent=2) + '\n')
        result = subprocess.run(['python3', str(ROOT / 'launch.py'), task, 'STOCK', 'ALL', name, '--cohorts', str(cohorts)])
        if result.returncode:
            progress['failed'] = name
            sequence.write_text(json.dumps(progress, indent=2) + '\n')
            raise SystemExit(result.returncode)
        logs = ROOT / 'launches' / name
        with (logs / 'review.stdout').open('wb') as out, (logs / 'review.stderr').open('wb') as err:
            result = subprocess.run(['python3', str(ROOT / 'bench/review-results-v2.py'), '--results', str(ROOT / 'results' / name), '--out', str(ROOT / 'reviews' / name), '--manifest', str(ROOT / 'bench/build-manifest.json')], stdout=out, stderr=err)
        if result.returncode:
            progress['review_failed'] = name
            sequence.write_text(json.dumps(progress, indent=2) + '\n')
            raise SystemExit(result.returncode)
        summary = json.loads((ROOT / 'results' / name / 'summary.json').read_text())
        row = {'name': name, 'ratios': {k: v['cohort_values'] for k, v in summary['ratios'].items()}}
        progress['completed'].append(row)
        sequence.write_text(json.dumps(progress, indent=2) + '\n')
        print(json.dumps(row), flush=True)
    progress.pop('active', None)
    progress['finished_unix'] = time.time()
    sequence.write_text(json.dumps(progress, indent=2) + '\n')

if __name__ == '__main__':
    main()
