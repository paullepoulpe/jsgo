#!/usr/bin/env python3
"""Compile separate correctness probes, keeping their classes out of timing overlays."""
import hashlib, json, os, re, subprocess, time
from pathlib import Path
ROOT = Path(__file__).resolve().parent
JAVA = '/usr/lib/jvm/java-21-openjdk-amd64/bin/java'
JAR = '/workspace/jsgo/.cache/closure-compiler-v20261015-maven.jar'
CASES = {
 'fsiv-lazy': ('com.google.javascript.jscomp.FsivLazyProbe', ['stock','control','fsiv-lazy','all']),
 'color-cache': ('com.google.javascript.jscomp.disambiguate.ColorGraphNodeFactoryCacheProbe', ['stock','control','color-cache','all']),
 'coalesce-bitset': ('CoalesceBitSetProbe', ['coalesce-bitset','all']),
 'polyfill-cache': ('com.google.javascript.jscomp.PolyfillsDefaultCacheTest', ['polyfill-cache','all']),
}
def main():
 dest=ROOT/'results'/'focused-probes-v1'
 dest.mkdir()
 env=dict(os.environ)
 for k in ('JAVA_TOOL_OPTIONS','_JAVA_OPTIONS','JDK_JAVA_OPTIONS'): env.pop(k,None)
 results=[]
 for factor,(name,variants) in CASES.items():
  d=dest/factor; d.mkdir(); (d/'classes').mkdir()
  p=next((ROOT/'variants'/factor).rglob(name.split('.')[-1]+'.java'))
  source=p.read_text()
  text=re.sub(r'(?<![\w.])com\.google\.(common|auto|errorprone|gson|protobuf|j2objc|thirdparty)(?=\.)',r'com.google.javascript.jscomp.jarjar.com.google.\1',source)
  copied=d/p.name; copied.write_text(text)
  cp=str(ROOT/'build'/factor/'classes')+':'+JAR
  argv=[JAVA,'-Xmx1g','-m','jdk.compiler/com.sun.tools.javac.Main','-source','21','-target','21','-g','-proc:none','-implicit:none','-encoding','UTF-8','-cp',cp,'-d',str(d/'classes'),str(copied)]
  started=time.time(); p1=subprocess.run(argv,capture_output=True,env=env,timeout=120)
  (d/'javac.stdout').write_bytes(p1.stdout); (d/'javac.stderr').write_bytes(p1.stderr)
  row={'factor':factor,'compile_exit':p1.returncode,'compile_argv':argv,'source_sha256':hashlib.sha256(source.encode()).hexdigest(),'runs':[]}
  if p1.returncode==0:
   for variant in variants:
    parts=[str(d/'classes')]
    if variant!='stock': parts.append(str(ROOT/'build'/variant/'classes'))
    parts.append(JAR)
    run=[JAVA,'-Xmx1g','-cp',':'.join(parts),name]
    if factor=='fsiv-lazy': run.append('lazy' if variant in ('all',factor) else 'stock')
    x=subprocess.run(run,capture_output=True,env=env,timeout=120)
    (d/(variant+'.stdout')).write_bytes(x.stdout); (d/(variant+'.stderr')).write_bytes(x.stderr)
    row['runs'].append({'variant':variant,'exit':x.returncode,'argv':run})
   if factor=='fsiv-lazy' and all(x['exit']==0 for x in row['runs']):
    outputs=[['\t'.join(l.split('\t')[:2]) for l in (d/(v+'.stdout')).read_text().splitlines()] for v in variants]
    row['byte_gate']=all(x==outputs[0] for x in outputs)
  row['status']='PASS' if p1.returncode==0 and all(x['exit']==0 for x in row['runs']) and row.get('byte_gate',True) else 'FAILED'
  row['seconds']=time.time()-started; results.append(row)
  (dest/'results.json').write_text(json.dumps(results,indent=2)+'\n')
  print(json.dumps({'factor':factor,'status':row['status']}),flush=True)
 if any(x['status']!='PASS' for x in results): raise SystemExit(1)
if __name__=='__main__': main()
