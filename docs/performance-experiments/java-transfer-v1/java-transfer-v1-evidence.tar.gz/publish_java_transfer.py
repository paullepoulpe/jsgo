#!/usr/bin/env python3
"""Prepare-only by default. Root may publish CLOSED evidence locally with --execute.

No compiler, benchmark, git mutation, or network publication is performed. Execution
creates reproduction-inputs in the experiment, then a new local immutable snapshot.
"""
import argparse
import ast
import contextlib
import gzip
import hashlib
import json
import os
from pathlib import Path, PurePosixPath
import shutil
import stat
import subprocess
import sys
import tarfile

sys.dont_write_bytecode = True
ROOT = Path('/workspace/jsgo-java-experiments/transfer-v1')
DEST = Path('/workspace/jsgo-publish-records/docs/performance-experiments/java-transfer-v1')
JOBS = {'confirm-bigquery-stock-color-cache-v1': ('color-cache', 3),
        'confirm-bigquery-stock-all-v1': ('ALL', 3),
        'confirm-bundle-stock-all-v1': ('ALL', 1)}
ANALYSIS = 'results/confirmation-analysis-v1/analysis.json'
SEQUENCE = 'confirmation-sequence-v1.json'
ARCHIVE = 'java-transfer-v1-evidence.tar.gz'
DOCKER_HOST = 'unix:///var/run/docker.sock'
DOCKER_DROP = {'DOCKER_HOST', 'DOCKER_CONTEXT', 'DOCKER_TLS',
               'DOCKER_TLS_VERIFY', 'DOCKER_CERT_PATH'}
REPRO_NOTE = '''Reproducing this snapshot requires path remapping and external pinned inputs.

The evidence archive contains the experiment's regular source/build/probe/diagnostic,
launch, raw-request, failure, review and frozen-version records. It does not contain
the external JDK, stock Closure jar, container image or benchmark dataset payloads.
Symlinks are metadata only and are never followed or stored as archive links.

reproduction-inputs/workloads/{bigquery,bundle}/ contains exact spec, six-output
oracle and oracle-metadata bytes verified against the actual completed runner's
metadata pins. helpers/ contains the two exact pinned helper sources; the experiment
already contains the shared CliFactors.java/classes, overlay sources/classes,
build receipts and frozen runner/reviewer/analysis sources. manifest.json maps copies
back to original absolute paths, hashes and runtime metadata.

Obtain the pinned Closure v20261015 Maven jar and matching sources, the recorded
Java21 installation/dependencies, immutable container-image digest and the exact
external corpus described by each spec, oracle metadata and runtime input_manifest.
Check their recorded hashes before running. Do not replace input files with different
versions or compare to old timing rows. Dependency relocation and all generated
nested classes must follow build receipts; STOCK remains the unmodified jar.

Original paths are intentionally retained in receipts. Remap spec argv/input/cwd
paths, ROOT/HELP/JDK/jar/image/overlay/driver paths and mounts into your isolated
workspace. Use a NEW version of each adapted helper/manifest and record its hashes;
existing runtime grants and original machine paths are not portable authorization.
Retain originals alongside adaptations. Whole upstream suites and custom-extension
boundaries are separate from these strict byte gates and narrow focused probes.

Follow report/methodology or methodology.md: actual4GiB/CPU2/default collector,
fresh compiler+extern parsing per request, matched settling, sequential alternating
JVM requests, strict six digests, fresh independent cohorts and stopped/zeroOOM.
Current RSS, process-lifetime HWM, container peak and allocated bytes have different
windows. Missing PSI is unavailable, not zero. Screens are excluded from holdout CI.
This local publisher neither runs those steps nor establishes a new speed claim.
'''

def require(ok, message):
    if not ok:
        raise RuntimeError(message)

def relative(value):
    p = PurePosixPath(value)
    require(isinstance(value, str) and value and not p.is_absolute()
            and all(x not in ('', '.', '..') for x in value.split('/'))
            and '\\' not in value, 'unsafe relative path: ' + str(value))
    return p.as_posix()

def no_symlinks(path):
    p = Path(path)
    require(p.is_absolute(), 'absolute path required')
    for item in [*reversed(p.parents), p]:
        require(not item.is_symlink(), 'symlink path component: ' + str(item))
    return p

@contextlib.contextmanager
def opened(path):
    path = no_symlinks(Path(path))
    fd = os.open(path, os.O_RDONLY | getattr(os, 'O_NOFOLLOW', 0))
    with os.fdopen(fd, 'rb') as stream:
        before = os.fstat(stream.fileno())
        require(stat.S_ISREG(before.st_mode), 'not a regular file: ' + str(path))
        yield stream, before
        after = os.fstat(stream.fileno())
        require((before.st_dev, before.st_ino, before.st_size, before.st_mtime_ns,
                 before.st_ctime_ns) ==
                (after.st_dev, after.st_ino, after.st_size, after.st_mtime_ns,
                 after.st_ctime_ns), 'file changed while reading: ' + str(path))

def sha(path):
    digest = hashlib.sha256()
    with opened(path) as (stream, _):
        for block in iter(lambda: stream.read(1 << 20), b''):
            digest.update(block)
    return digest.hexdigest()

def read(path):
    with opened(path) as (stream, info):
        require(info.st_size <= 64 << 20, 'oversized JSON: ' + str(path))
        return json.load(stream)

def save(path, value):
    with Path(path).open('x', encoding='utf-8') as stream:
        json.dump(value, stream, indent=2, sort_keys=True, allow_nan=False)
        stream.write('\n')

def pointer(value, key):
    require(key.startswith('/'), 'JSON pointer must begin with /')
    for item in key.split('/')[1:]:
        item = item.replace('~1', '/').replace('~0', '~')
        value = value[int(item)] if isinstance(value, list) else value[item]
    return value

def output_guards(grant=None):
    """Logging must not mutate any captured member after the final inventory."""
    checked = {}
    for fd, label in ((1, 'stdout'), (2, 'stderr')):
        info = os.fstat(fd)
        # Actual publication requires durable external regular-file logs. This also
        # avoids an opaque pipe whose downstream tee could write inside ROOT.
        require(stat.S_ISREG(info.st_mode), 'publication ' + label + ' must be an external regular log')
        target_text = os.readlink('/proc/self/fd/' + str(fd))
        require(not target_text.endswith(' (deleted)'), 'deleted publication log target')
        target = no_symlinks(Path(target_text))
        require(not target.is_relative_to(ROOT), 'publication log target is inside ROOT: ' + str(target))
        current = target.stat()
        require((current.st_dev, current.st_ino) == (info.st_dev, info.st_ino),
                'publication log pathname/descriptor mismatch')
        if grant is not None:
            expected = no_symlinks(Path(grant['outer_' + label + '_path']))
            require(expected == target, 'publication log differs from root grant: ' + label)
        checked[label] = {'path': str(target), 'dev': info.st_dev, 'ino': info.st_ino}
    if grant is not None:
        require(grant['outer_publication_logs_receipts_outside_root'] is True,
                'external outer-launch log/receipt commitment missing')
        receipt = no_symlinks(Path(grant['outer_launcher_receipt_path']))
        require(not receipt.is_relative_to(ROOT), 'outer launcher receipt must stay outside ROOT')
        require(receipt not in (Path(checked['stdout']['path']), Path(checked['stderr']['path'])),
                'outer launcher receipt overlaps a live log')
    return checked

def idle():
    active = []
    for path in Path('/proc').iterdir():
        if not path.name.isdigit() or int(path.name) == os.getpid():
            continue
        try:
            if (path/'stat').read_text().split()[2] == 'Z':
                continue
            comm = (path/'comm').read_text().strip()
            argv = [os.fsdecode(x) for x in (path/'cmdline').read_bytes().split(b'\0') if x]
            exe = Path(argv[0]).name if argv else ''
            controller = any(arg.startswith(str(ROOT) + '/') and arg.endswith('.py')
                             and Path(arg) != Path(__file__).absolute() for arg in argv)
            if (comm in ('go', 'compile', 'link', 'java', 'javac')
                    or comm.startswith('jsgo') or exe.endswith('.test') or controller):
                active.append({'pid': int(path.name), 'comm': comm, 'executable': exe})
        except (FileNotFoundError, ProcessLookupError):
            continue
    require(not active, 'active compiler/controller processes: ' + repr(active))
    docker_env = {key: value for key, value in os.environ.items() if key not in DOCKER_DROP}
    check = subprocess.run(['docker', '--host=' + DOCKER_HOST, 'ps',
                            '--format', '{{.ID}}\t{{.Names}}'],
                           env=docker_env, capture_output=True, text=True, timeout=30, check=False)
    require(check.returncode == 0 and not check.stdout.strip(),
            'cannot prove empty running-container set: ' + check.stderr + check.stdout)
    return {'active_compiler_controller_processes': [], 'running_containers': [],
            'docker_ps_exit': 0, 'docker_host': DOCKER_HOST,
            'docker_environment_keys_removed': sorted(DOCKER_DROP)}

def zero_stopped(path):
    value = read(path)
    for key in ('cleanup_errors', 'remaining_owned_containers', 'active_compilers',
                'remaining_owned_driver_processes'):
        require(value[key] == [], 'not stopped: ' + str(path) + ':' + key)
    require(all(value['outer_OOM_delta'].get(key) == 0
                for key in ('oom', 'oom_kill', 'oom_group_kill')), 'nonzero OOM: ' + str(path))
    return value

def mandatory_receipts():
    values = {SEQUENCE, ANALYSIS}
    for job in JOBS:
        values.update({'reviews/' + job + '/review.json',
                       'results/' + job + '/stopped-proof.json',
                       'results/' + job + '/metadata.json'})
    return values

def gates(grant):
    require(grant['schema'] == 'jsgo-java-transfer-publication-grant-v1', 'grant schema')
    require(grant['publisher_revision'] == 2, 'publisher revision')
    require(grant['reviewed_by'] == 'root' and grant['review_status'] == 'CLOSED_ROOT_REVIEWED',
            'root review required')
    require('publish-local' in grant['allowed_stages'], 'publish-local grant missing')
    for key in ('runtime_stopped', 'all_experiment_files_closed', 'report_reviewed_final',
                'confirmation_sequence_reviewed', 'confirmation_analysis_reviewed'):
        require(grant[key] is True, 'closure/review flag false: ' + key)
    require(grant['publisher_sha256'] == sha(Path(__file__)), 'publisher pin')
    require(grant['confirmation_plan_sha256'] == sha(ROOT/'confirmation-plan-v1.json'), 'plan pin')
    require(grant['report_README_sha256'] == sha(ROOT/'report/README.md'), 'final report pin')
    checks = grant['closed_receipt_checks']
    require(len({x['path'] for x in checks}) == len(checks), 'duplicate receipt path')
    require(mandatory_receipts() <= {x['path'] for x in checks}, 'missing mandatory closure receipts')
    for check in checks:
        path = ROOT/relative(check['path'])
        require(sha(path) == check['sha256'], 'receipt hash mismatch: ' + str(path))
        value = read(path)
        for expected in check.get('required_values', []):
            require(pointer(value, expected['pointer']) == expected['equals'],
                    'receipt field mismatch: ' + check['path'] + expected['pointer'])
    sequence = read(ROOT/SEQUENCE)
    require(isinstance(sequence['finished_unix'], (int, float)), 'sequence unfinished')
    require(not any(x in sequence for x in ('active', 'failed', 'review_failed')), 'sequence active/failed')
    require(len(sequence['completed']) == 3 and
            {x['name'] for x in sequence['completed']} == set(JOBS), 'closed sequence jobs')
    for job, (candidate, cohorts) in JOBS.items():
        review = read(ROOT/'reviews'/job/'review.json')
        require(review['status'] == 'PASS independent Java-factor review', 'independent review failed')
        require(review['candidate'] == candidate and review['baseline'] == 'STOCK', 'review variants')
        require(review['cohorts'] == cohorts and review['pairs_per_cohort'] == 5
                and review['measured_requests'] == cohorts * 10
                and review['strict_digests_every_request'] == 6, 'review counts/bytes')
        require(review['Java_vs_Go_claim'] is False, 'unexpected Go claim')
        zero_stopped(ROOT/'results'/job/'stopped-proof.json')
    analysis = read(ROOT/ANALYSIS)
    require(analysis['status'] == 'COMPLETE preselected freshholdout analysis', 'analysis incomplete')
    require(set(analysis['comparisons']) == {'color-cache', 'ALL'}, 'holdout comparison set')
    for candidate, value in analysis['comparisons'].items():
        require(value['screen_observations_pooled'] == 0 and len(value['cohort_rows']) == 3,
                'screen pooling or incomplete holdout: ' + candidate)
    require(analysis['bundle_external_validity']['status'] ==
            'ONE_COHORT_EXTERNAL_VALIDITY_SCREEN_NOT_CONFIRMATION'
            and analysis['bundle_external_validity']['pooled_into_BigQuery'] is False,
            'bundle status/pooling')
    require(analysis['Java_vs_Go_claim'] is False, 'analysis Go claim')

def runner_pins():
    tree = ast.parse((ROOT/'bench/run-v3.py').read_text())
    for node in tree.body:
        if isinstance(node, ast.Assign) and any(isinstance(t, ast.Name) and t.id == 'PINS'
                                               for t in node.targets):
            value = ast.literal_eval(node.value)
            require(set(value) == {'paired_cli.py', 'cgroup_exec.py'}, 'unexpected runner helpers')
            return value
    raise RuntimeError('runner PINS not found')

def reproduction():
    target = ROOT/'reproduction-inputs'
    require(not target.exists() and not target.is_symlink(), 'reproduction-inputs already exists')
    pins = runner_pins()
    prepared = []
    workload_records = {}
    for task, job in [('bigquery', 'confirm-bigquery-stock-color-cache-v1'),
                      ('bundle', 'confirm-bundle-stock-all-v1')]:
        metadata_path = ROOT/'results'/job/'metadata.json'
        metadata = read(metadata_path)
        require(metadata['runner_sha256'] == sha(ROOT/'bench/run-v3.py'), 'actual runner source pin')
        require(metadata['helpers'] == pins, 'actual helper pins differ')
        records = []
        for label in ('spec', 'oracle', 'oracle_metadata'):
            source = no_symlinks(Path(metadata[label]))
            expected = metadata[label + '_sha256']
            require(sha(source) == expected, 'workload pin: ' + str(source))
            records.append({'kind': label, 'original': str(source), 'sha256': expected,
                            'copied': 'workloads/' + task + '/' + label + '.json'})
            prepared.append((source, records[-1]['copied'], expected))
        for name, expected in pins.items():
            source = ROOT/'results'/job/'helper-snapshots'/name
            require(sha(source) == expected, 'pinned helper snapshot: ' + str(source))
            if task == 'bigquery':
                prepared.append((source, 'helpers/' + name, expected))
        workload_records[task] = {'runtime_metadata': str(metadata_path.relative_to(ROOT)),
                                 'copies': records, 'input_manifest': metadata['input_manifest'],
                                 'external_jar': {'path': metadata['jar'], 'sha256': metadata['jar_sha256']},
                                 'external_java_home': metadata['java_home'],
                                 'external_java_dependencies': metadata['java_runtime_dependencies'],
                                 'image': metadata['image'], 'helpers': metadata['helpers']}
    # All source/hash checks happen before creating any new reproduction file.
    target.mkdir()
    for source, relative_path, expected in prepared:
        dest = target/relative(relative_path)
        dest.parent.mkdir(parents=True, exist_ok=True)
        with opened(source) as (stream, info), dest.open('xb') as output:
            require(info.st_size <= 64 << 20, 'unexpected reproduction payload size')
            shutil.copyfileobj(stream, output, 1 << 20)
        require(sha(dest) == expected, 'reproduction copy mismatch')
    save(target/'manifest.json', {'status': 'PIN_CHECKED_REPRODUCTION_INPUTS',
                                 'workloads': workload_records, 'external_payloads_copied': False})
    (target/'README.md').write_text(REPRO_NOTE)

def inventory():
    files, excluded = {}, []
    logs = output_guards()
    log_inodes = {(value['dev'], value['ino']) for value in logs.values()}
    def walk(path):
        for entry in sorted(os.scandir(path), key=lambda x: x.name):
            p = Path(entry.path); rel = relative(p.relative_to(ROOT).as_posix())
            info = entry.stat(follow_symlinks=False)
            if stat.S_ISLNK(info.st_mode):
                excluded.append({'path': rel, 'reason': 'symlink_never_followed',
                                 'target': os.readlink(p)})
            elif entry.name == '__pycache__' or entry.name.endswith('.pyc'):
                excluded.append({'path': rel, 'reason': 'python_cache'})
            elif stat.S_ISDIR(info.st_mode):
                walk(p)
            elif stat.S_ISREG(info.st_mode):
                require((info.st_dev, info.st_ino) not in log_inodes,
                        'publication log hardlinks a ROOT member: ' + rel)
                files[rel] = {'sha256': sha(p), 'bytes': info.st_size,
                              'mode': stat.S_IMODE(info.st_mode), 'mtime_ns': info.st_mtime_ns,
                              'uid': info.st_uid, 'gid': info.st_gid}
            else:
                excluded.append({'path': rel, 'reason': 'non_regular_never_opened',
                                 'mode': info.st_mode})
    walk(ROOT)
    return dict(sorted(files.items())), excluded

def verify_members(archive, files):
    seen = set()
    with tarfile.open(archive, mode='r|gz') as stream:
        for member in stream:
            name = relative(member.name)
            require(member.isfile() and name in files and name not in seen, 'unexpected archive member')
            expected = files[name]
            require(member.size == expected['bytes'] and member.mode == expected['mode'], 'tar metadata')
            digest = hashlib.sha256()
            source = stream.extractfile(member)
            require(source is not None, 'missing archive member bytes')
            for block in iter(lambda: source.read(1 << 20), b''):
                digest.update(block)
            require(digest.hexdigest() == expected['sha256'], 'archive member hash: ' + name)
            seen.add(name)
    require(seen == set(files), 'missing archive members')

def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--execute', action='store_true')
    parser.add_argument('--grant', type=Path, default=ROOT/'publication-root-grant-v1.json')
    args = parser.parse_args()
    if not args.execute:
        print('PREPARED ONLY: --execute requires final CLOSED root grant; no files/runtime inspected.')
        return
    output_guards()  # Before grant reads, reproduction writes or capture.
    require(__debug__, 'python -O disables validation')
    require(Path(__file__).absolute() == ROOT/'publish_java_transfer.py', 'publisher must stay in exact root')
    no_symlinks(ROOT); no_symlinks(DEST.parent)
    require(DEST.parent.is_dir() and not DEST.exists() and not DEST.is_symlink(), 'destination exists/missing parent')
    require(args.grant.absolute() == ROOT/'publication-root-grant-v1.json', 'exact root grant path required')
    grant = read(args.grant)
    before_output_guards = output_guards(grant)
    gates(grant)
    before_idle = idle()
    reproduction()
    before_capture_idle = idle()
    files, excluded = inventory()
    stage = DEST.with_name('.java-transfer-v1-staging-' + str(os.getpid()))
    require(not stage.exists() and not stage.is_symlink(), 'staging path exists')
    stage.mkdir()
    # Copy only regular report members, keeping patches/history under their relative paths.
    for rel, expected in files.items():
        if not rel.startswith('report/'):
            continue
        dest = stage/relative(rel.removeprefix('report/'))
        dest.parent.mkdir(parents=True, exist_ok=True)
        with opened(ROOT/rel) as (source, _), dest.open('xb') as output:
            shutil.copyfileobj(source, output, 1 << 20)
        require(sha(dest) == expected['sha256'], 'report copy mismatch: ' + rel)
    archive = stage/ARCHIVE
    require(not archive.exists(), 'archive already exists')
    with archive.open('xb') as raw:
        with gzip.GzipFile(filename='', mode='wb', fileobj=raw, mtime=0, compresslevel=6) as compressed:
            with tarfile.open(fileobj=compressed, mode='w|', format=tarfile.PAX_FORMAT) as tar:
                for rel, info in files.items():
                    member = tarfile.TarInfo(rel)
                    member.size = info['bytes']; member.mode = info['mode']
                    member.mtime = 0; member.uid = member.gid = 0
                    member.uname = member.gname = ''
                    with opened(ROOT/rel) as (source, _):
                        tar.addfile(member, source)
    verify_members(archive, files)  # Streaming verification only: never extract paths.
    after_files, after_excluded = inventory()
    require(files == after_files and excluded == after_excluded, 'experiment changed during capture')
    after_idle = idle()
    after_output_guards = output_guards(grant)
    require(before_output_guards == after_output_guards, 'publication log descriptors changed')
    manifest = {'schema': 'jsgo-java-transfer-evidence-members-v1',
                'archive': ARCHIVE, 'archive_sha256': sha(archive),
                'archive_bytes': archive.stat().st_size, 'source_root': str(ROOT),
                'files': files, 'excluded': excluded,
                'tar_policy': 'Sorted regular files only; no links; normalized tar/gzip time/ownership; original metadata below',
                'archive_member_hashes_verified_without_extraction': True}
    save(stage/'evidence-members.json', manifest)
    (stage/'REPRODUCE.md').write_text(REPRO_NOTE)
    save(stage/'publication-receipt.json', {'status': 'LOCAL_SNAPSHOT_VERIFIED',
         'root_grant_sha256': sha(args.grant), 'files': len(files), 'excluded': len(excluded),
         'archive_sha256': manifest['archive_sha256'], 'before_idle': before_idle,
         'before_capture_idle': before_capture_idle, 'after_idle': after_idle,
         'external_output_guards': after_output_guards,
         'compiler_benchmark_executed': False, 'git_or_network_actions': False})
    require(not DEST.exists() and not DEST.is_symlink(), 'destination appeared during publication')
    stage.rename(DEST)
    output_guards(grant)  # Final print is allowed only to the pinned external logs.
    print(json.dumps({'status': 'LOCAL_SNAPSHOT_VERIFIED', 'destination': str(DEST),
                      'archive_sha256': manifest['archive_sha256'], 'files': len(files)}))

if __name__ == '__main__':
    main()
