package com.google.javascript.jscomp;

import com.google.javascript.jscomp.jarjar.com.google.common.collect.Table;
import com.google.javascript.jscomp.deps.ModuleLoader.ResolutionMode;
import com.google.javascript.jscomp.modules.ModuleMapCreator;
import com.google.javascript.jscomp.modules.ModuleMetadataMap.ModuleMetadata;
import com.google.javascript.rhino.IR;
import com.google.javascript.rhino.InputId;
import com.google.javascript.rhino.Node;
import java.lang.reflect.Field;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Base64;
import java.util.Comparator;
import java.util.LinkedHashSet;
import java.util.List;

/** Same-source semantic transcript and lazy-context activation probe; not a timing harness. */
public final class NamespaceLazyProbe {
  private static final Field REF_TYPE = field(GlobalNamespace.Ref.class, "type");
  private static final Field NAME_BITS = field(GlobalNamespace.Name.class, "propertyBitSet");
  private static final Field MODULE_NAMES = field(GlobalNamespace.class, "nameMapByModule");

  private static Field field(Class<?> owner, String name) {
    try {
      Field f = owner.getDeclaredField(name);
      f.setAccessible(true);
      return f;
    } catch (ReflectiveOperationException e) {
      throw new AssertionError(e);
    }
  }

  private static CompilerOptions options() {
    CompilerOptions options = new CompilerOptions();
    options.setLanguageIn(CompilerOptions.LanguageMode.ECMASCRIPT_NEXT);
    options.setLanguageOut(CompilerOptions.LanguageMode.ECMASCRIPT_NEXT);
    return options;
  }

  private static void require(boolean condition, String message) {
    if (!condition) {
      throw new AssertionError(message);
    }
  }

  private static Compiler parsed(String file, String code, String externs) {
    Compiler compiler = new Compiler();
    compiler.init(List.of(SourceFile.fromCode("externs.js", externs)),
        List.of(SourceFile.fromCode(file, code)), options());
    compiler.parseForCompilation();
    require(compiler.getErrors().isEmpty(), file + ": " + compiler.getErrors());
    return compiler;
  }

  private static GlobalNamespace namespace(Compiler compiler) {
    return new GlobalNamespace(compiler, compiler.getRoot().getFirstChild(),
        compiler.getRoot().getLastChild());
  }

  private static String nodeKey(Node node) {
    if (node == null) {
      return "null";
    }
    return node.getToken() + ":" + node.getSourceFileName() + ":"
        + node.getLineno() + ":" + node.getCharno() + ":" + node.getQualifiedName();
  }

  private static void name(String label, GlobalNamespace.Name name) throws Exception {
    System.out.println("N\t" + label + "\t" + name.getFullName() + "\t"
        + NAME_BITS.getInt(name) + "\t" + name.getGlobalSets() + "\t"
        + name.getLocalSets() + "\t" + name.getTotalGets() + "\t"
        + name.getAliasingGets() + "\t" + name.getCallGets() + "\t"
        + name.getDeleteProps() + "\t" + name.getSubclassingGets() + "\t"
        + nodeKey(name.getDeclaration() == null ? null : name.getDeclaration().getNode()));
    for (GlobalNamespace.Ref ref : name.getRefs()) {
      System.out.println("R\t" + REF_TYPE.get(ref) + "\t" + nodeKey(ref.getNode())
          + "\t" + (ref.getChunk() == null ? "null" : ref.getChunk().getName())
          + "\t" + nodeKey(ref.scope == null ? null : ref.scope.getRootNode()));
    }
  }

  @SuppressWarnings("unchecked")
  private static void dump(String fixture, Compiler compiler, GlobalNamespace namespace)
      throws Exception {
    System.out.println("CASE\t" + fixture);
    // Preserve the insertion order of global names and each name's references.
    for (GlobalNamespace.Name name : namespace.getNameIndex().values()) {
      name("global", name);
    }
    Table<ModuleMetadata, String, GlobalNamespace.Name> table =
        (Table<ModuleMetadata, String, GlobalNamespace.Name>) MODULE_NAMES.get(namespace);
    List<Table.Cell<ModuleMetadata, String, GlobalNamespace.Name>> cells =
        new ArrayList<>(table.cellSet());
    // HashBasedTable iteration order is not a semantic contract; use stable module/name keys.
    cells.sort(Comparator.comparing((Table.Cell<ModuleMetadata, String, GlobalNamespace.Name> c) ->
        nodeKey(c.getRowKey().rootNode()) + ":" + c.getRowKey().moduleType()
            + ":" + c.getColumnKey()));
    for (Table.Cell<ModuleMetadata, String, GlobalNamespace.Name> cell : cells) {
      name("module:" + nodeKey(cell.getRowKey().rootNode()) + ":"
          + cell.getRowKey().moduleType(), cell.getValue());
    }
    System.out.println("AST\t" + Base64.getEncoder().encodeToString(
        compiler.toSource(compiler.getRoot().getLastChild()).getBytes(StandardCharsets.UTF_8)));
  }

  private static void syntaxAndExterns() throws Exception {
    Compiler compiler = parsed("syntax.js",
        "var ns={x:1,get y(){return 2},set y(v){},m(){return this.x}};"
        + "ns.more={...ns,z:3};var {x:alias=0,...rest}=ns;"
        + "function local(ns){ns.x++;return ns?.missing;}"
        + "class C {static field=ns.x;static method(){return ns.y;}method(){return ns.x;}}"
        + "ns.hasOwnProperty('x');delete ns.more;goog.provide('provided.branch');"
        + "provided.branch.value=ns.x;ext.custom=ns;",
        "var ext;ext.api=function(){};var goog;goog.provide=function(name){};");
    GlobalNamespace namespace = namespace(compiler);
    require(namespace.getOwnSlot("ns.x") != null, "object-literal property missing");
    require(namespace.getOwnSlot("ext").inExterns(), "extern classification missing");
    require(namespace.getOwnSlot("provided.branch.value") != null, "provide side effect missing");
    dump("syntax-externs", compiler, namespace);
  }

  private static void chunksAndPredicate() throws Exception {
    Compiler compiler = new Compiler();
    JSChunk base = new JSChunk("base");
    base.add(SourceFile.fromCode("base.js", "var shared={value:1};"));
    JSChunk left = new JSChunk("left");
    left.addDependency(base);
    left.add(SourceFile.fromCode("left.js", "shared.left=shared.value;"));
    JSChunk right = new JSChunk("right");
    right.addDependency(base);
    right.add(SourceFile.fromCode("right.js", "shared.right=shared.value;"));
    compiler.initChunks(List.of(), List.of(base, left, right), options());
    compiler.parseForCompilation();
    require(compiler.getErrors().isEmpty(), "chunk parse errors");
    GlobalNamespace namespace = namespace(compiler);
    GlobalNamespace.Name leftName = namespace.getOwnSlot("shared.left");
    require(leftName.getDeclaration().getChunk() == left, "left declaration lost its chunk");
    require(namespace.getOwnSlot("shared.right").getDeclaration().getChunk() == right,
        "right declaration lost its chunk");
    dump("chunk-dag", compiler, namespace);
    GlobalNamespace filtered = namespace(compiler);
    filtered.setShouldTraverseScriptPredicate(n -> !"right.js".equals(n.getSourceFileName()));
    require(filtered.getOwnSlot("shared.left") != null, "accepted script missing");
    require(filtered.getOwnSlot("shared.right") == null, "filtered script collected");
    dump("script-predicate", compiler, filtered);
  }

  private static void modules() throws Exception {
    Compiler compiler = new Compiler();
    compiler.init(List.of(SourceFile.fromCode("externs.js", "var goog;")), List.of(
        SourceFile.fromCode("global.js", "var shared={};"),
        SourceFile.fromCode("es.js", "export const local={answer:42};shared.es=local.answer;"),
        SourceFile.fromCode("goog.js", "goog.module('probe.goog');var local={answer:7};"
            + "exports.answer=local.answer;shared.goog=local.answer;"),
        SourceFile.fromCode("bundle.js", "goog.loadModule(function(exports){"
            + "goog.module('probe.bundle');var local={answer:9};exports.answer=local.answer;"
            + "shared.bundle=local.answer;return exports;});")), options());
    compiler.parseForCompilation();
    require(compiler.getErrors().isEmpty(), "module parse errors");
    Node externs = compiler.getRoot().getFirstChild();
    Node root = compiler.getRoot().getLastChild();
    new GatherModuleMetadata(compiler, false, ResolutionMode.BROWSER).process(externs, root);
    new ModuleMapCreator(compiler, compiler.getModuleMetadataMap()).process(externs, root);
    require(compiler.getErrors().isEmpty(), "module metadata errors: " + compiler.getErrors());
    GlobalNamespace namespace = namespace(compiler);
    namespace.getNameIndex();
    require(!((Table<?, ?, ?>) MODULE_NAMES.get(namespace)).isEmpty(), "module path inactive");
    require(namespace.getOwnSlot("shared.es") != null, "global assignment in ES module missing");
    require(namespace.getOwnSlot("shared.goog") != null, "global assignment in goog module missing");
    dump("modules", compiler, namespace);
  }

  private static void incremental() throws Exception {
    Compiler compiler = parsed("incremental.js", "var ns={};ns.before=1;", "");
    GlobalNamespace namespace = namespace(compiler);
    Scope supplied = namespace.getOwnSlot("ns").getDeclaration().scope;
    Node script = compiler.getRoot().getLastChild().getFirstChild();
    JSChunk sentinel = new JSChunk("supplied-context-only");
    for (int i = 0; i < 2; i++) {
      String property = i == 0 ? "added" : "nullChunk";
      Node access = IR.getprop(IR.name("ns"), property);
      Node statement = IR.exprResult(IR.assign(access, IR.number(7 + i))).srcrefTree(script);
      script.addChildToBack(statement);
      JSChunk chunk = i == 0 ? sentinel : null;
      LinkedHashSet<GlobalNamespace.AstChange> changes = new LinkedHashSet<>();
      changes.add(new GlobalNamespace.SimpleAstChange(access, chunk, supplied));
      namespace.scanNewNodes(changes);
      GlobalNamespace.Name added = namespace.getOwnSlot("ns." + property);
      require(added != null && added.getRefs().size() == 1, "incremental addition missing");
      GlobalNamespace.Ref ref = added.getDeclaration();
      require(ref.scope == supplied && ref.getChunk() == chunk, "supplied context replaced");
      namespace.scanNewNodes(changes);
      require(added.getRefs().size() == 1, "incremental rescan duplicated reference");
    }
    dump("incremental-supplied-context", compiler, namespace);
  }

  private static final class CountingCompiler extends Compiler {
    int inputRequests;

    @Override
    public CompilerInput getInput(InputId id) {
      inputRequests++;
      return super.getInput(id);
    }
  }

  private static void activation(boolean lazy) {
    CountingCompiler compiler = new CountingCompiler();
    compiler.init(List.of(), List.of(SourceFile.fromCode("irrelevant.js",
        "if(true){1+2;3*4;}while(false){5+6;}")), options());
    compiler.parseForCompilation();
    require(compiler.getErrors().isEmpty(), "activation parse errors");
    compiler.inputRequests = 0;
    GlobalNamespace namespace = new GlobalNamespace(compiler, compiler.getRoot().getLastChild());
    require(namespace.getNameIndex().isEmpty(), "name-free fixture unexpectedly has names");
    require(lazy ? compiler.inputRequests == 0 : compiler.inputRequests > 0,
        "unexpected lazy activation: requests=" + compiler.inputRequests + ", lazy=" + lazy);
    System.err.println("ACTIVATION\tnamespace-lazy=" + lazy + "\tinputRequests="
        + compiler.inputRequests);
  }

  public static void main(String[] args) throws Exception {
    require(args.length == 1
        && List.of("stock", "control", "namespace", "namespace-lazy", "all").contains(args[0]),
        "Expected stock, control, namespace (or namespace-lazy), or all");
    syntaxAndExterns();
    chunksAndPredicate();
    modules();
    incremental();
    activation(args[0].equals("namespace") || args[0].equals("namespace-lazy")
        || args[0].equals("all"));
    System.out.println("PASS\t5-semantic-cases\t1-activation-case");
  }
}
