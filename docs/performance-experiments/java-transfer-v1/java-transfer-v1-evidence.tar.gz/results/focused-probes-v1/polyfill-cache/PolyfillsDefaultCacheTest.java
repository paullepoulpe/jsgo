/*
 * Copyright 2026 The Closure Compiler Authors.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package com.google.javascript.jscomp;

import com.google.javascript.jscomp.CompilerOptions.LanguageMode;
import com.google.javascript.jscomp.PolyfillUsageFinder.Polyfill;
import com.google.javascript.jscomp.PolyfillUsageFinder.Polyfills;
import com.google.javascript.jscomp.resources.ResourceLoader;
import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;

/** Standalone focused source control; run in a fresh JVM, without requiring JUnit. */
public final class PolyfillsDefaultCacheTest {
  public static void main(String[] args) throws Exception {
    testConcurrentDefaultInitialization();
    testDefaultMatchesFreshTableInOrder();
    testAllDefaultPassesShareOnlyTable();
    testCustomTablesAndFailuresRemainIndependent();
    System.out.println("PASS PolyfillsDefaultCacheTest (4 controls)");
  }

  private static void testConcurrentDefaultInitialization() throws Exception {
    ExecutorService pool = Executors.newFixedThreadPool(8);
    CountDownLatch start = new CountDownLatch(1);
    List<Future<Polyfills>> results = new ArrayList<>();
    try {
      for (int i = 0; i < 16; i++) {
        results.add(pool.submit(() -> {
          start.await();
          return Polyfills.getDefault();
        }));
      }
      start.countDown();
      Polyfills first = results.get(0).get();
      for (Future<Polyfills> result : results) {
        require(result.get() == first, "concurrent default requests must share one table");
      }
    } finally {
      pool.shutdownNow();
    }
  }

  private static void testDefaultMatchesFreshTableInOrder() {
    Polyfills shared = Polyfills.getDefault();
    // This uses an original call-site anchor, independently of the new supplier's anchor.
    Polyfills fresh = Polyfills.fromTable(
        ResourceLoader.loadTextResource(RemoveUnusedCode.class, "js/polyfills.txt"));
    require(shared != fresh, "explicit fromTable remains a new table");
    for (LanguageMode mode : new LanguageMode[] {
        LanguageMode.ECMASCRIPT3, LanguageMode.ECMASCRIPT5, LanguageMode.ECMASCRIPT_NEXT}) {
      List<Polyfill> actual = shared.getPolyfillsNewerThan(mode);
      List<Polyfill> expected = fresh.getPolyfillsNewerThan(mode);
      require(actual.size() == expected.size(), "table query size: " + mode);
      for (int i = 0; i < actual.size(); i++) {
        Polyfill a = actual.get(i);
        Polyfill e = expected.get(i);
        require(a.nativeSymbol.equals(e.nativeSymbol)
                && a.nativeVersion.equals(e.nativeVersion)
                && a.polyfillVersion.equals(e.polyfillVersion)
                && a.library.equals(e.library)
                && a.kind == e.kind,
            "ordered polyfill value at " + mode + ":" + i);
      }
    }
  }

  private static void testAllDefaultPassesShareOnlyTable() throws Exception {
    Polyfills shared = Polyfills.getDefault();
    for (int i = 0; i < 2; i++) {
      Compiler compiler = new Compiler();
      compiler.initOptions(new CompilerOptions());
      RemoveUnusedCode remove = new RemoveUnusedCode.Builder(compiler).build();
      RewritePolyfills rewrite =
          new RewritePolyfills(compiler, true, false, LanguageMode.ECMASCRIPT3);
      IsolatePolyfills isolate = new IsolatePolyfills(compiler);
      require(field(remove, "polyfillsFromTable") == shared, "remove default table");
      require(field(rewrite, "polyfills") == shared, "rewrite default table");
      require(field(isolate, "polyfills") == shared, "isolate default table");
      require(field(remove, "compiler") == compiler, "remove compiler stays per pass");
      require(field(rewrite, "compiler") == compiler, "rewrite compiler stays per pass");
      require(field(isolate, "compiler") == compiler, "isolate compiler stays per pass");
    }
  }

  private static void testCustomTablesAndFailuresRemainIndependent() throws Exception {
    Polyfills shared = Polyfills.getDefault();
    List<Polyfill> before = shared.getPolyfillsNewerThan(LanguageMode.ECMASCRIPT3);
    Polyfills custom = Polyfills.fromTable("Example es6 es3 test/example");
    Compiler compiler = new Compiler();
    compiler.initOptions(new CompilerOptions());
    RewritePolyfills rewrite = new RewritePolyfills(
        compiler, compiler.getRuntimeJsLibManager(), custom, true, false,
        LanguageMode.ECMASCRIPT3);
    IsolatePolyfills isolate = new IsolatePolyfills(compiler, custom);
    PolyfillUsageFinder finder = new PolyfillUsageFinder(compiler, custom);
    require(field(rewrite, "polyfills") == custom, "custom rewrite injection preserved");
    require(field(isolate, "polyfills") == custom, "custom isolate injection preserved");
    require(field(finder, "polyfills") == custom, "custom finder injection preserved");
    require(custom.getPolyfillsNewerThan(LanguageMode.ECMASCRIPT3).size() == 1,
        "custom table parsed independently");
    for (int attempt = 0; attempt < 2; attempt++) {
      try {
        Polyfills.fromTable("broken");
        throw new AssertionError("malformed explicit table must throw on each call");
      } catch (IllegalArgumentException expected) {
        require(expected.getMessage().equals("Invalid table: too few tokens on line: broken"),
            "explicit parse exception unchanged");
      }
    }
    require(Polyfills.getDefault() == shared, "custom parse cannot replace default");
    require(shared.getPolyfillsNewerThan(LanguageMode.ECMASCRIPT3).equals(before),
        "custom table and failed parse cannot alter shared entries or their order");
  }

  private static Object field(Object owner, String name) throws Exception {
    Field field = owner.getClass().getDeclaredField(name);
    field.setAccessible(true);
    return field.get(owner);
  }

  private static void require(boolean condition, String message) {
    if (!condition) {
      throw new AssertionError(message);
    }
  }
}
