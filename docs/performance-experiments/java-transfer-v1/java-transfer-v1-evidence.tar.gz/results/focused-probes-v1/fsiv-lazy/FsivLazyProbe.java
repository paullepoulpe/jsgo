package com.google.javascript.jscomp;

import com.google.javascript.rhino.Node;
import java.lang.reflect.Field;
import java.nio.charset.StandardCharsets;
import java.util.Base64;
import java.util.List;

/** Focused pass probe; root runs the same source against stock and patched classes. */
public final class FsivLazyProbe {
  private record Fixture(String name, String source, boolean lazyAnalysisExpected) {}

  public static void main(String[] args) throws Exception {
    if (args.length != 1 || (!args[0].equals("stock") && !args[0].equals("lazy"))) {
      throw new IllegalArgumentException("Expected stock or lazy");
    }
    boolean lazy = args[0].equals("lazy");
    List<Fixture> fixtures =
        List.of(
            new Fixture("no-candidates", "function f(){var unused=1;return 0;}", false),
            new Fixture(
                "side-effect-rejected", "function f(){var x=externCall();return x;}", false),
            new Fixture(
                "loop-rejected",
                "function f(n){var x=1;while(n--){externSink(x);}}",
                false),
            new Fixture("valid-single", "function f(){var x=1;return x;}", true),
            new Fixture(
                "dependent-candidates", "function f(a){var x=a+1;var y=x*2;return y;}", true),
            new Fixture(
                "reject-then-valid",
                "function f(){var x=externCall();var y=1;return x+y;}",
                true),
            new Fixture(
                "function-state-reset",
                "function good(){var x=1;return x;}function unused(){var y=2;return 0;}",
                false));
    Field usesField = FlowSensitiveInlineVariables.class.getDeclaredField("reachingUses");
    usesField.setAccessible(true);
    for (Fixture fixture : fixtures) {
      Compiler compiler = new Compiler();
      CompilerOptions options = new CompilerOptions();
      options.setLanguageIn(CompilerOptions.LanguageMode.ECMASCRIPT_NEXT);
      options.setLanguageOut(CompilerOptions.LanguageMode.ECMASCRIPT_NEXT);
      compiler.init(
          List.of(
              SourceFile.fromCode(
                  "externs.js", "function externCall(){} function externSink(value){}")),
          List.of(SourceFile.fromCode(fixture.name() + ".js", fixture.source())),
          options);
      compiler.parseForCompilation();
      if (!compiler.getErrors().isEmpty()) {
        throw new AssertionError(fixture.name() + ": parse errors " + compiler.getErrors());
      }
      Node externs = compiler.getRoot().getFirstChild();
      Node root = compiler.getRoot().getLastChild();
      Normalize.createNormalizeForOptimizations(compiler).process(externs, root);
      FlowSensitiveInlineVariables pass = new FlowSensitiveInlineVariables(compiler);
      pass.process(externs, root);
      boolean analysisPresent = usesField.get(pass) != null;
      boolean expected = !lazy || fixture.lazyAnalysisExpected();
      if (analysisPresent != expected) {
        throw new AssertionError(
            fixture.name() + ": expected analysis=" + expected + ", got " + analysisPresent);
      }
      // The first two columns must match stock exactly. The final column checks lazy activation.
      String output = compiler.toSource(root);
      System.out.println(
          fixture.name()
              + "\t"
              + Base64.getEncoder().encodeToString(output.getBytes(StandardCharsets.UTF_8))
              + "\tanalysis="
              + analysisPresent);
    }
  }
}
