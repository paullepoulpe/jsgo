import java.lang.reflect.Constructor;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.BitSet;
import java.util.List;
import java.util.Random;

/** Correctness probe for the actual patched helper; not a timing benchmark. */
public final class CoalesceBitSetProbe {
  private static Constructor<?> constructor;
  private static Field liveSet;
  private static Method orInto;
  private static Method nextSetBit;
  private static int cases;

  private static final class Lattice {
    final Object actual;
    final BitSet snapshot;
    final int originalCapacity;

    Lattice(int width, BitSet input) throws Exception {
      actual = constructor.newInstance(width);
      BitSet owned = (BitSet) liveSet.get(actual);
      owned.or(input);
      snapshot = (BitSet) owned.clone();
      originalCapacity = owned.size();
    }

    int next(int from) throws Exception {
      return (Integer) nextSetBit.invoke(actual, from);
    }

    void addTo(BitSet destination) throws Exception {
      orInto.invoke(actual, destination);
    }

    void checkUnchanged() throws Exception {
      BitSet owned = (BitSet) liveSet.get(actual);
      check(owned.equals(snapshot), "source lattice was mutated");
      check(owned.size() == originalCapacity, "source lattice capacity changed");
    }
  }

  private static void check(boolean condition, String message) {
    if (!condition) {
      throw new AssertionError("case " + cases + ": " + message);
    }
  }

  private static BitSet bits(long mask) {
    return BitSet.valueOf(new long[] {mask});
  }

  private static void runCase(
      int width, Lattice[] states, BitSet eligible, BitSet params, int[][] crossings)
      throws Exception {
    cases++;
    BitSet[] rows = new BitSet[width];
    for (int i = 0; i < width; i++) {
      rows[i] = new BitSet();
    }
    // This is the changed production loop, invoking the real lattice helper and iterator.
    for (Lattice state : states) {
      for (int i = state.next(0); i >= 0; i = state.next(i + 1)) {
        state.addTo(rows[i]);
      }
    }
    // Model the unchanged LiveRangeChecker's symmetric additions.
    for (int[] crossing : crossings) {
      rows[crossing[0]].set(crossing[1]);
      rows[crossing[1]].set(crossing[0]);
    }

    List<Long> actualEdges = new ArrayList<>();
    List<Long> expectedEdges = new ArrayList<>();
    // Independent oracle: ask whether each variable pair overlaps in any original state.
    // Include the diagonal: the existing production condition skips i > j, not i >= j.
    for (int i = 0; i < width; i++) {
      for (int j = i; j < width; j++) {
        boolean overlap = false;
        for (Lattice state : states) {
          overlap |= state.snapshot.get(i) && state.snapshot.get(j);
        }
        for (int[] crossing : crossings) {
          overlap |= (i == crossing[0] && j == crossing[1])
              || (i == crossing[1] && j == crossing[0]);
        }
        check(rows[i].get(j) == overlap, "upper-triangle mismatch at " + i + "," + j);
        if (!eligible.get(i) || !eligible.get(j)) {
          continue;
        }
        long edge = ((long) i << 32) | j;
        boolean bothParams = params.get(i) && params.get(j);
        if (rows[i].get(j) || bothParams) {
          actualEdges.add(edge);
        }
        if (overlap || bothParams) {
          expectedEdges.add(edge);
        }
      }
    }
    check(actualEdges.equals(expectedEdges), "ordered edge sequence changed");
    for (Lattice state : states) {
      state.checkUnchanged();
    }
  }

  private static BitSet randomBits(Random random, int width, int divisor) {
    BitSet result = new BitSet(width);
    for (int i = 0; i < width; i++) {
      if (random.nextInt(divisor) == 0) {
        result.set(i);
      }
    }
    return result;
  }

  public static void main(String[] args) throws Exception {
    Class<?> lattice = Class.forName(
        "com.google.javascript.jscomp.LiveVariablesAnalysis$LiveVariableLattice");
    constructor = lattice.getDeclaredConstructor(int.class);
    constructor.setAccessible(true);
    liveSet = lattice.getDeclaredField("liveSet");
    liveSet.setAccessible(true);
    orInto = lattice.getDeclaredMethod("orInto", BitSet.class);
    orInto.setAccessible(true);
    nextSetBit = lattice.getDeclaredMethod("nextSetBit", int.class);
    nextSetBit.setAccessible(true);

    // Preserve already-set destination bits, source ownership, and independent destinations.
    Lattice source = new Lattice(130, bits(5));
    BitSet first = new BitSet();
    first.set(129);
    source.addTo(first);
    check(first.get(0) && first.get(2) && first.get(129), "destination union lost bits");
    first.clear();
    source.checkUnchanged();
    BitSet second = new BitSet();
    source.addTo(second);
    check(second.equals(bits(5)), "first destination aliased source or second destination");
    source.checkUnchanged();

    // Exhaustive pairs of live-in/live-out sets through five variables, including empty sets.
    for (int width = 0; width <= 5; width++) {
      BitSet eligible = new BitSet();
      eligible.set(0, width);
      for (int in = 0; in < (1 << width); in++) {
        for (int out = 0; out < (1 << width); out++) {
          runCase(width,
              new Lattice[] {new Lattice(width, bits(in)), new Lattice(width, bits(out))},
              eligible, bits(5), new int[0][]);
        }
      }
    }

    Random random = new Random(0xC0A1E5CEL);
    int[] widths = {1, 2, 31, 63, 64, 65, 99, 100, 127, 128, 129};
    for (int width : widths) {
      for (int repetition = 0; repetition < 12; repetition++) {
        Lattice[] states = new Lattice[6];
        for (int i = 0; i < states.length; i++) {
          states[i] = new Lattice(width, randomBits(random, width, 1 + (i % 4)));
        }
        // Reuse one source twice to cover shared in/out lattice identities.
        if ((repetition & 1) == 0) {
          states[5] = states[0];
        }
        int[][] crossings = new int[4][2];
        for (int[] crossing : crossings) {
          crossing[0] = random.nextInt(width);
          crossing[1] = random.nextInt(width);
        }
        runCase(width, states, randomBits(random, width, 2),
            randomBits(random, width, 3), crossings);
      }
    }
    System.out.println("PASS CoalesceBitSetProbe: " + cases + " cases; actual helper; no timing");
  }
}
