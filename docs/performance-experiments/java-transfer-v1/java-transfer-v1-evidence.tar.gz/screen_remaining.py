#!/usr/bin/env python3
"""Serial independent factor screens; never overlaps compiler processes."""
import json,subprocess,time
from pathlib import Path
ROOT=Path(__file__).resolve().parent
def main():
 sequence=ROOT/'screen-sequence-v2-remaining.json'
 assert not sequence.exists()
 progress={'started_unix':time.time(),'completed':[]}
 for factor in ['coalesce-bitset','polyfill-cache']:
  name='screen-bigquery-control-'+factor.lower()+'-v1'
  progress['active']=name;sequence.write_text(json.dumps(progress,indent=2)+'\n')
  p=subprocess.run(['python3',str(ROOT/'launch.py'),'bigquery','CONTROL',factor,name])
  if p.returncode:
   progress['failed']=name;sequence.write_text(json.dumps(progress,indent=2)+'\n');raise SystemExit(p.returncode)
  review=ROOT/'reviews'/name
  logs=ROOT/'launches'/name
  with (logs/'review.stdout').open('wb') as out,(logs/'review.stderr').open('wb') as err:
   p=subprocess.run(['python3',str(ROOT/'bench/review-results.py'),'--results',str(ROOT/'results'/name),'--out',str(review),'--manifest',str(ROOT/'bench/build-manifest.json')],stdout=out,stderr=err)
  if p.returncode:
   progress['review_failed']=name;sequence.write_text(json.dumps(progress,indent=2)+'\n');raise SystemExit(p.returncode)
  s=json.loads((ROOT/'results'/name/'summary.json').read_text())
  row={'name':name,'ratios':{k:v['cohort_values'] for k,v in s['ratios'].items()}}
  progress['completed'].append(row);sequence.write_text(json.dumps(progress,indent=2)+'\n');print(json.dumps(row),flush=True)
 progress.pop('active',None);progress['finished_unix']=time.time();sequence.write_text(json.dumps(progress,indent=2)+'\n')
if __name__=='__main__':main()
