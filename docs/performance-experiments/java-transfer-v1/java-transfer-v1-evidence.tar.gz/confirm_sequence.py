#!/usr/bin/env python3
"""Root-owned serial holdouts, with durable launch/review logs."""
import json, subprocess, time
from pathlib import Path

ROOT = Path(__file__).resolve().parent

def main():
    screen = json.loads((ROOT / 'screen-sequence-v2-remaining.json').read_text())
    assert 'finished_unix' in screen and 'active' not in screen and 'failed' not in screen
    sequence = ROOT / 'confirmation-sequence-v1.json'
    assert not sequence.exists()
    progress = {'started_unix': time.time(), 'plan': 'confirmation-plan-v1.json', 'completed': []}
    jobs = [('bigquery', 'color-cache', 3), ('bigquery', 'ALL', 3), ('bundle', 'ALL', 1)]
    for task, candidate, cohorts in jobs:
        name = 'confirm-' + task + '-stock-' + candidate.lower() + '-v1'
        progress['active'] = name
        sequence.write_text(json.dumps(progress, indent=2) + '\n')
        result = subprocess.run(['python3', str(ROOT / 'launch.py'), task, 'STOCK', candidate, name, '--cohorts', str(cohorts)])
        if result.returncode:
            progress['failed'] = name
            sequence.write_text(json.dumps(progress, indent=2) + '\n')
            raise SystemExit(result.returncode)
        logs = ROOT / 'launches' / name
        with (logs / 'review.stdout').open('wb') as out, (logs / 'review.stderr').open('wb') as err:
            result = subprocess.run(['python3', str(ROOT / 'bench/review-results.py'), '--results', str(ROOT / 'results' / name), '--out', str(ROOT / 'reviews' / name), '--manifest', str(ROOT / 'bench/build-manifest.json')], stdout=out, stderr=err)
        if result.returncode:
            progress['review_failed'] = name
            sequence.write_text(json.dumps(progress, indent=2) + '\n')
            raise SystemExit(result.returncode)
        summary = json.loads((ROOT / 'results' / name / 'summary.json').read_text())
        row = {'name': name, 'ratios': {key: value['cohort_values'] for key, value in summary['ratios'].items()}}
        progress['completed'].append(row)
        sequence.write_text(json.dumps(progress, indent=2) + '\n')
        print(json.dumps(row), flush=True)
    progress.pop('active', None)
    progress['finished_unix'] = time.time()
    sequence.write_text(json.dumps(progress, indent=2) + '\n')

if __name__ == '__main__':
    main()
