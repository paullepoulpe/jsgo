from pathlib import Path
import re
r=Path('/workspace/jsgo-node64/internal/rhino');p=r/'node.go';s=p.read_text()
s=s.replace('token Token // Type of the token of the node; NAME for example','meta uint32 // Packed token, subclass, color tag and common source length.')
s=s.replace('\tlength int32\n','').replace('\tkind        node_kind\n\ttypeIsColor bool\n','')
# Match formatting of the actual fields, without changing node_kind type declarations.
s=re.sub(r'\t(?:kind\s+node_kind|typeIsColor\s+bool)\n','',s)
s=s.replace('\tstr *string\n','').replace('\text *node_ext','\tpayload unsafe.Pointer')
s=s.replace('\tcooked *string\n','\tcooked *string\n str *string\n length int32\n token Token\n')
# Implement these helpers in node_packed.go, keeping numeric/template readers here.
a=s.index('// node_getExt returns');b=s.index('// node_number is',a);s=s[:a]+s[b:]
a=s.index('func (n *Node) nodeStringValue() string {');s=s[:a]+s[s.index('\n}',a)+2:]
s=s.replace('clone.str = n.str','')
s=s.replace('clone := newNode_StringNodeForClone(n.GetToken())\n\t\tNode_CopyBaseNodeFields','clone := newNode_StringNodeForClone(n.GetToken())\n clone.setNodeStringCell(n.nodeStringCell())\n\t\tNode_CopyBaseNodeFields')
s=re.sub(r'n\.kind = (node_kind\w+)',r'n.setNodeKind(\1)',s)
s=re.sub(r'n\.str = ([^\n]+)',r'n.setNodeStringCell(\1)',s)
# A trailing comment must sit outside the added call's closing parenthesis.
s=s.replace('rhinoStringPoolCell(raw) // raw)', 'rhinoStringPoolCell(raw)) // raw').replace('rhinoStringPoolCell(str) // RhinoStringPool is null-hostile.)','rhinoStringPoolCell(str)) // RhinoStringPool is null-hostile.')
s=s.replace('n.token = token','n.setPackedToken(token)').replace('return n.token\n','return n.packedToken()\n')
s=s.replace('return int(n.length)','return n.packedLength()').replace('n.length = int32(length)','n.setPackedLength(length)')
s=s.replace('dest.length = source.length','dest.SetLength(source.GetLength())').replace('n.length = other.length','n.SetLength(other.GetLength())')
s=s.replace('dest.typeOrColor, dest.typeIsColor = source.typeOrColor, source.typeIsColor','dest.typeOrColor = source.typeOrColor\n dest.setNodeColorTag(source.nodeColorTag())')
s=s.replace('n.typeOrColor, n.typeIsColor = other.typeOrColor, other.typeIsColor','n.typeOrColor = other.typeOrColor\n n.setNodeColorTag(other.nodeColorTag())')
s=s.replace('n.typeIsColor = false','n.setNodeColorTag(false)').replace('n.typeIsColor = x != nil','n.setNodeColorTag(x != nil)')
s=re.sub(r'(\b\w+)\.kind\b',r'\1.nodeKind()',s)
s=re.sub(r'(\b\w+)\.token\b',r'\1.GetToken()',s)
s=re.sub(r'(\b\w+)\.typeIsColor\b',r'\1.nodeColorTag()',s)
s=re.sub(r'(\b\w+)\.ext\b',r'\1.nodeExt()',s)
# Constant token predicates don't need the cold invalid-token path.
s=re.sub(r'n\.GetToken\(\) == (Token_\w+)',r'n.meta&nodeMetaTokenMask == uint32(\1)',s)
p.write_text(s)
p=r/'node_chunks.go';s=p.read_text().replace('n.token = token','n.SetToken(token)');p.write_text(s)
p=r/'node_private_clone.go';s=p.read_text();a=s.index('\tif n.ext != nil {');b=s.index('\n\tswitch n.kind',a);s=s[:a]+'\tn.copyPackedPayloadTo(clone)'+s[b:];s=s.replace('switch n.kind','switch n.nodeKind()');s=re.sub(r'clone.token = (Token_\w+)',r'clone.SetToken(\1)',s);p.write_text(s)
p=r/'node_compact_test.go';s=p.read_text().replace('!= 80','!= 64').replace('expected 80','expected 64');p.write_text(s)
