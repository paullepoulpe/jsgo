import os,signal,subprocess,time,pathlib,resource
root=pathlib.Path('/workspace/jsgo-native-parser'); results=pathlib.Path('/workspace/jsgo-results')
base=os.environ.copy();base.update(GOCACHE='/workspace/toolchains/cache',GOPATH='/workspace/toolchains/gopath',GOMAXPROCS='1')
peak=0;peak_actual=0
with (results/'native-parser-full-build.log').open('w') as log:
    buildenv=base.copy();buildenv['GOGC']='20'
    p=subprocess.Popen(['/workspace/toolchains/go1.27.2/bin/go','test','-p=1','-c','-o',str(results/'native-parsing-full.test'),'./internal/parsing'],cwd=root,env=buildenv,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
    while p.poll() is None:
        used=int(pathlib.Path('/sys/fs/cgroup/memory.current').read_text())
        peak=max(peak,used)
        stats=dict((key,int(value)) for key,value in (line.split() for line in pathlib.Path('/sys/fs/cgroup/memory.stat').read_text().splitlines()))
        actual=stats.get('anon',0)+stats.get('kernel',0)
        peak_actual=max(peak_actual,actual)
        if actual>7_500_000_000:
            log.write(f'\nStopped coordinated compile before cgroup OOM: anon+kernel={actual}, memory.current={used}\n');log.flush();os.killpg(p.pid,signal.SIGTERM);p.wait();break
        time.sleep(2)
    code=p.wait()
print('build_exit',code,'peak_cgroup_bytes',peak,'peak_anon_kernel_bytes',peak_actual,'max_child_rss_kib',resource.getrusage(resource.RUSAGE_CHILDREN).ru_maxrss,flush=True)
if code: raise SystemExit(code)
for native in ['0','1']:
    env=base.copy();env.update(GOGC='100',JSGO_EXPERIMENT_NATIVE_PARSER=native)
    with (results/('native-parser-full-mode'+native+'.log')).open('w') as log:
        p=subprocess.run([str(results/'native-parsing-full.test'),'-test.count=1','-test.timeout=15m'],cwd=root/'internal/parsing',env=env,stdout=log,stderr=subprocess.STDOUT)
    print('native',native,'test_exit',p.returncode,flush=True)
    if p.returncode: raise SystemExit(p.returncode)
