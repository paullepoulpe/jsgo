#!/usr/bin/env bash
set -euo pipefail
. /workspace/toolchains/env.sh
until [ -f /workspace/jsgo-results/layout-smoke/summary.json ] && python3 -c 'import json; assert "downlevel-whitespace" in json.load(open("/workspace/jsgo-results/layout-smoke/summary.json"))' >/dev/null 2>&1; do sleep 3; done
cd /workspace/jsgo-rename-conflicts
GOMAXPROCS=2 go build -buildvcs=false -p 2 -o /workspace/jsgo/bin/jsgo-rename-conflicts ./cmd/jsgo > /workspace/jsgo-results/build-rename-conflicts.log 2>&1
cd /workspace/jsgo-parallel-parse
GOMAXPROCS=2 go build -buildvcs=false -p 2 -o /workspace/jsgo/bin/jsgo-parallel ./cmd/jsgo > /workspace/jsgo-results/build-parallel.log 2>&1
GOMAXPROCS=2 go build -race -buildvcs=false -p 2 -o /workspace/jsgo/bin/jsgo-parallel-race ./cmd/jsgo > /workspace/jsgo-results/build-parallel-race.log 2>&1
python3 -u /workspace/jsgo-results/parallel-gates.py > /workspace/jsgo-results/parallel-gates.log 2>&1
