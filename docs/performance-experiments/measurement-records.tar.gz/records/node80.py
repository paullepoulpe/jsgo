from pathlib import Path
r=Path('/workspace/jsgo-node80/internal/rhino')
p=r/'rhino_string_pool.go';s=p.read_text().replace('make(map[string]string)','make(map[string]*string)')
s=s.replace('func RhinoStringPool_AddOrGet(s string) string {','func RhinoStringPool_AddOrGet(s string) string { return *rhinoStringPoolCell(s) }\n\n// Go-only: performance — immutable header shared by StringNodes.\nfunc rhinoStringPoolCell(s string) *string {')
s=s.replace('interned = strings.Clone(s)\n\t\trhinoStringPool_strings[interned] = interned','value := strings.Clone(s)\n\t\tinterned = &value\n\t\trhinoStringPool_strings[value] = interned')
p.write_text(s)
p=r/'node.go';s=p.read_text()
s=s.replace('kind node_kind\n\n\tjstypeOrColor any','kind node_kind\n typeIsColor bool\n\n // Go-only: language-adapter — a GC-tracked tagged pointer. JSTypeBase\n // already contains the concrete self interface, so nodes need not repeat it.\n typeOrColor unsafe.Pointer')
s=s.replace('\tstr string','\tstr *string')
s=s.replace('n.str = RhinoStringPool_AddOrGet(raw)', 'n.str = rhinoStringPoolCell(raw)').replace('n.str = RhinoStringPool_AddOrGet(str)', 'n.str = rhinoStringPoolCell(str)')
s=s.replace('n.str = stringPool.Get(rawOffset)', 'n.str = rhinoStringPoolCell(stringPool.Get(rawOffset))').replace('n.str = stringPool.Get(offset)', 'n.str = rhinoStringPoolCell(stringPool.Get(offset))')
s=s.replace('return n.str\n','return n.nodeStringValue()\n').replace('return n.str // raw','return n.nodeStringValue() // raw')
s=s.replace('RhinoStringPool_UncheckedEquals(n.str, node.str)', 'RhinoStringPool_UncheckedEquals(n.nodeStringValue(), node.nodeStringValue())').replace('RhinoStringPool_UncheckedEquals(n.str, castNode.str)', 'RhinoStringPool_UncheckedEquals(n.nodeStringValue(), castNode.nodeStringValue())')
s=s.replace('newNode_TemplateLiteralSubstringNode(n.node_cooked(), n.str)', 'newNode_TemplateLiteralSubstringNode(n.node_cooked(), n.nodeStringValue())')
s=s.replace('n.jstypeOrColor != nil', 'n.typeOrColor != nil').replace('jutil.ToJavaString(n.jstypeOrColor)','jutil.ToJavaString(n.typeOrColorValue())')
s=s.replace('!jutil.ObjectsEquals(n.jstypeOrColor, node.jstypeOrColor)', '!jutil.ObjectsEquals(n.typeOrColorValue(), node.typeOrColorValue())')
s=s.replace('dest.jstypeOrColor = source.jstypeOrColor', 'dest.typeOrColor, dest.typeIsColor = source.typeOrColor, source.typeIsColor').replace('n.jstypeOrColor = other.jstypeOrColor', 'n.typeOrColor, n.typeIsColor = other.typeOrColor, other.typeIsColor')
start=s.index('func (n *Node) GetJSType() JSType {');end=s.index('\n// GetJSTypeRequired',start)
s=s[:start]+'''func (n *Node) GetJSType() JSType {
 if n.typeOrColor == nil || n.typeIsColor { return nil }
 return (*JSTypeBase)(n.typeOrColor).self
}
'''+s[end:]
start=s.index('func (n *Node) SetJSType(x JSType) *Node {');end=s.index('\n// GetColor',start)
s=s[:start]+'''func (n *Node) SetJSType(x JSType) *Node {
 jutil.CheckStateMsg1(n.typeOrColor == nil || !n.typeIsColor, "%s", n)
 n.typeIsColor = false
 if jutil.IsNil(x) { n.typeOrColor = nil } else { n.typeOrColor = unsafe.Pointer(x.GetJSTypeBase()) }
 return n
}
'''+s[end:]
start=s.index('func (n *Node) GetColor() *colors.Color {');end=s.index('\n// Java: Node.setColor',start)
s=s[:start]+'''func (n *Node) GetColor() *colors.Color {
 if !n.typeIsColor { return nil }
 return (*colors.Color)(n.typeOrColor)
}
'''+s[end:]
start=s.index('func (n *Node) SetColor(x *colors.Color) *Node {');end=s.index('\n// CopyTypeFrom',start)
s=s[:start]+'''func (n *Node) SetColor(x *colors.Color) *Node {
 jutil.CheckStateMsg1(n.typeOrColor == nil || n.typeIsColor, "%s", n)
 n.typeOrColor = unsafe.Pointer(x)
 n.typeIsColor = x != nil
 return n
}
'''+s[end:]
s+='''
// Go-only: language-adapter — recover the Java Object field only for printing
// and equality; hot getters use the tagged pointer directly.
func (n *Node) typeOrColorValue() any {
 if n.typeOrColor == nil { return nil }
 if n.typeIsColor { return (*colors.Color)(n.typeOrColor) }
 return (*JSTypeBase)(n.typeOrColor).self
}

func (n *Node) nodeStringValue() string {
 if n.str == nil { return "" }
 return *n.str
}
'''
assert 'jstypeOrColor' not in s.replace('no jstypeOrColor','')
p.write_text(s)
