from pathlib import Path
p=Path('/workspace/jsgo-collections/internal/jutil/collections.go')
s=p.read_text()
s=s.replace('m          map[K]*lhmEntry[K, V] // nil until size exceeds lhmSmallSize', 'm          *lhmLarge[K, V] // nil until size exceeds lhmSmallSize',1)
anchor='// lhmSmallSize is the most entries'
pos=s.index(anchor)
s=s[:pos]+'''// Go-only: performance — allocate entries of larger maps in batches.
// The many empty and tiny maps retain their original representation.
type lhmLarge[K comparable, V any] struct {
	index map[K]*lhmEntry[K, V]
	entries Slab[lhmEntry[K, V]]
}

'''+s[pos:]
start=s.index('type LinkedHashMap[');end=s.index('// ObjectLinkedHashMap / ObjectLinkedHashSet',start)
a=s[start:end]
a=a.replace('h.m[k]', 'h.m.index[k]').replace('h.m[x.key]', 'h.m.index[x.key]')
a=a.replace('e := &lhmEntry[K, V]{key: k, value: v, prev: h.tail}', '''var e *lhmEntry[K, V]
	if h.m == nil {
		e = &lhmEntry[K, V]{}
	} else {
		e = h.m.entries.New()
	}
	*e = lhmEntry[K, V]{key: k, value: v, prev: h.tail}''')
a=a.replace('h.m = make(map[K]*lhmEntry[K, V], 2*h.size)', 'h.m = &lhmLarge[K, V]{index: make(map[K]*lhmEntry[K, V], 2*h.size)}')
a=a.replace('delete(h.m, e.key)', 'delete(h.m.index, e.key)')
a=a.replace('clear(h.m)', '''if h.m != nil {
		clear(h.m.index)
		h.m.entries = Slab[lhmEntry[K, V]]{}
	}''')
# Release removed payloads even if another live entry keeps its slab alive.
a=a.replace('h.removeEntry(e)\n\treturn e.value', 'old := e.value\n\th.removeEntry(e)\n\treturn old')
a=a.replace('h.unlink(e)\n}', 'h.unlink(e)\n\tvar key K\n\tvar value V\n\te.key, e.value = key, value\n}',1)
s=s[:start]+a+s[end:]
s=s.replace('buckets    map[int32]*olhmEntry[K, V] // nil until size exceeds lhmSmallSize', 'buckets    *olhmLarge[K, V] // nil until size exceeds lhmSmallSize',1)
anchor='// NewObjectLinkedHashMap returns an empty map.'
pos=s.index(anchor)
s=s[:pos]+'''// Go-only: performance — the object-equality map uses the same batched
// allocation after its small-map threshold.
type olhmLarge[K any, V any] struct {
	index map[int32]*olhmEntry[K, V]
	entries Slab[olhmEntry[K, V]]
}

'''+s[pos:]
start=s.index('type ObjectLinkedHashMap[');end=len(s)
a=s[start:end]
a=a.replace('h.buckets[hash]', 'h.buckets.index[hash]').replace('h.buckets[e.hash]', 'h.buckets.index[e.hash]')
a=a.replace('e = &olhmEntry[K, V]{key: k, hash: hash, value: v, prev: h.tail}', '''if h.buckets == nil {
		e = &olhmEntry[K, V]{}
	} else {
		e = h.buckets.entries.New()
	}
	*e = olhmEntry[K, V]{key: k, hash: hash, value: v, prev: h.tail}''')
a=a.replace('h.buckets = make(map[int32]*olhmEntry[K, V], 2*h.size)', 'h.buckets = &olhmLarge[K, V]{index: make(map[int32]*olhmEntry[K, V], 2*h.size)}')
a=a.replace('delete(h.buckets, hash)', 'delete(h.buckets.index, hash)')
a=a.replace('clear(h.buckets)', '''if h.buckets != nil {
		clear(h.buckets.index)
		h.buckets.entries = Slab[olhmEntry[K, V]]{}
	}''')
# Remove returns the saved old value after releasing key/value references.
startremove=a.index('func (h *ObjectLinkedHashMap[K, V]) Remove(k K) V')
endremove=a.index('// All',startremove)
b=a[startremove:endremove]
b=b.replace('\th.size--', '\told := e.value\n\th.size--',1)
b=b.replace('\treturn e.value', '\tvar key K\n\tvar value V\n\te.key, e.value = key, value\n\treturn old',1)
a=a[:startremove]+b+a[endremove:]
s=s[:start]+a+s[end:]
p.write_text(s)
