package main
import("fmt";"runtime";"runtime/debug")
type position struct{source *byte;offset,line,column int}
type range_ struct{start,end *position}
type node struct{p [10]*byte}
var positions []position
var ranges []range_
var nodes []node
func main(){debug.SetGCPercent(-1);for _,n:=range []int{31,32,63,64,127,128}{for _,kind:=range []string{"position32","range16","node80"}{var a,b runtime.MemStats;runtime.ReadMemStats(&a);for i:=0;i<1000;i++{switch kind{case "position32":positions=make([]position,n);case "range16":ranges=make([]range_,n);case "node80":nodes=make([]node,n)}};runtime.ReadMemStats(&b);fmt.Printf("%s count=%d allocated_bytes_per_batch=%d\n",kind,n,(b.TotalAlloc-a.TotalAlloc)/1000)}}}
