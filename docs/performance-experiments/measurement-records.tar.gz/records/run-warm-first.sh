#!/usr/bin/env bash
set -euo pipefail
. /workspace/toolchains/env.sh
cd /workspace/jsgo
until [ -x /workspace/jsgo/bin/gowarm-combined ]; do sleep 3; done
taskset -c 0,1 python3 -I -u tools/bench/warm_experiments.py --reference /workspace/jsgo-results/baseline --out /workspace/jsgo-results/warm-combined --binary /workspace/jsgo/bin/gowarm-combined --extern-cache --warmup 2 --iters 5 > /workspace/jsgo-results/warm-combined.log 2>&1
