from pathlib import Path
import json,statistics,subprocess,hashlib
lab=Path('/workspace/jsgo-results');repo=Path('/workspace/jsgo-delivery')
paired=json.loads((lab/'delivery-paired/summary.json').read_text())
worker=json.loads((lab/'production-worker/summary.json').read_text())
java={}
for task in paired:
 data=json.loads((lab/'final-java'/task/'java-warm.json').read_text())
 values=[r['wall_ms']/1000 for r in data['iterations'] if r['kind']=='measure']
 old=json.loads((lab/'baseline'/task/'java-cold.json').read_text())['runs'][0]['digests']
 new=json.loads((lab/'final-java'/task/'java-cold.json').read_text())['runs'][0]['digests']
 assert old==new,task+' Java reference outputs changed'
 assert not data['mismatch_vs_cold']
 java[task]={'median_s':statistics.median(values),'first_last_half_drift':statistics.median(values[5:])/statistics.median(values[:5])-1,'measured_s':values,'warmup':data['warmup'],'iters':data['iters']}
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
provenance={}
for label,path in [('original','/workspace/jsgo/bin/jsgo-go124'),('delivery','/workspace/jsgo/bin/jsgo-delivery'),('worker','/workspace/jsgo/bin/jsgo-worker')]:
 provenance[label]={'sha256':sha(path),'build_info':subprocess.run(['/workspace/toolchains/go1.27.2/bin/go','version','-m',path],capture_output=True,text=True,check=True).stdout}
cli_iterations={task:{label:json.loads((lab/'delivery-paired'/task/label/'jsgo.json').read_text())['runs'] for label in ['original','delivery']} for task in paired}
result={'full_build_iterations':cli_iterations,'source_base':'c9872522ef49054007c7ded25ee33b634c0ea989','candidate_commit':'4afb696c','paired_full_builds':paired,'fresh_java_warm':java,'production_worker':worker,'binaries':provenance,'measurement_machine':json.loads((lab/'delivery-paired/machine.json').read_text()),'method':{'affinity':[0,1],'go_cli_runs':5,'java_full_warmup':12,'java_full_measured':10,'java_small_warmup':100,'java_small_measured':30,'worker_warmup':10,'worker_measured':30,'worker_timing':'real JSON request/response including client decoding; every response byte-gated','runtime_gc':'default; no GOGC/GOMEMLIMIT changes in retained benchmarks'}}
(repo/'docs/performance-results.json').write_text(json.dumps(result,indent=2)+'\n')
rows=[]
for name,t in paired.items():
 before=t['variants']['original']['median_s'];after=t['variants']['delivery']['median_s'];jw=java[name]['median_s']
 rows.append(f'| {name} | {before:.3f}s | {after:.3f}s | {(1-after/before)*100:.1f}% | {jw:.3f}s |')
small=[]
for name,s in worker.items():small.append(f"| {name} | {s['worker_protocol_median_ms']:.2f}ms | {s['java_warm_median_ms']:.2f}ms | {s['speed_vs_java_warm']:.2f}x |")
text='''# Performance experiments, October 2026

The retained CLI improves every workload in the existing five-task suite.
Warm Java remains faster on those full builds. The persistent worker beats
warm Java on the held-out small WHITESPACE workload; that is a specific
workflow result, not a claim that Go generally outperforms HotSpot.

## Full compilations

Five interleaved runs per Go binary; medians below. Original is commit
`c9872522` built with Go 1.24.7. Candidate uses Go 1.27.2 and the repository's
existing PGO profile. Both use default runtime GC settings. Each invocation
recompiles the program and starts a new Go process.

| Workload | Original Go | Candidate Go | Less elapsed time | Fresh warm Java |
|---|---:|---:|---:|---:|
'''+ '\n'.join(rows)+'''

The candidate still needs roughly 11–34% less elapsed time, depending on the
workload, to equal these warmed JVM medians. The largest retained gain is on the
large SIMPLE bundle; the smallest is on full-build WHITESPACE.

The JVM column is a separate fresh run with 12 warm-up and 10 measured
iterations per workload, using the pinned Closure v20261015 jar and JDK
21.0.12.1. Both runtimes have the same two-core affinity on an AMD EPYC 9V74
host with a two-CPU container quota. No compilation, test execution or other
heavy task ran alongside timed compilations. CPU frequency is not locked;
small differences between experiment cohorts should not be treated as gains.

Every measured Go invocation must match Java's stdout, stderr, exit status,
JavaScript and source maps. Fresh Java reproduces its original reference.
These are end-to-end results, not sums of isolated optimization percentages.

## Repeated small applications

These small DOM-counter workloads were held out of PGO training. Java uses
100 warm-up and 30 measured iterations. Go uses the production `jsgo-worker`
JSON protocol, 10 warm-up and 30 measured requests, including request/response
transport and client decoding. All 40 responses and generated artifacts are
checked against Java for each workload.

| Workload | Go worker | Warm Java | Java time / Go time |
|---|---:|---:|---:|
'''+ '\n'.join(small)+'''

Only the WHITESPACE row is a Java win. User code is reread and compiled on
every request; this is not compiled-output replay. The worker clones immutable
built-in extern parse templates and creates a new compiler for each request.
See [worker usage](worker.md).

## Retained changes

- Allocate AST nodes and entries of larger ordered maps in batches, reducing
  per-object allocation and scan overhead. Break allocation groups between
  independent compilations to avoid retaining earlier ASTs transitively.
- Use an indexed reaching-definition lattice for functions with at most 64
  canonical variables, preserving TOP/BOTTOM, encounter order and the sparse
  fallback for larger or noncanonical cases.
- Remove the redundant inherited self interface from Var/TypedVar, reducing
  Var from 80 to 64 bytes. Cache immutable name hashes lazily; keep Java's
  name/scope-root equality and full hash formula.
- Store AST type/color and interned string references compactly, reducing
  Node from 96 to 80 bytes. Tagged pointers remain GC-tracked Go pointers.
- Reuse repeated immutable scanner positions. Long-lived comment positions
  retain independent allocation.
- Avoid redundant rename-conflict recording in larger scopes. Small scopes
  retain the cheaper original walk; bookkeeping preserves encounter order.
- Add a serialized persistent CLI worker with fresh compiler state and an
  immutable, bounded built-in extern parse cache. Clone JSDoc type expressions
  and transformations, preserve inline-type bits, and rebind source metadata.
- Pin Unicode 15 classification/case data from Go 1.24's BSD-licensed package
  so newer Go toolchains retain JDK 21 behavior. No JDK implementation source
  is used.

The normal one-shot CLI, flags and default GC settings remain unchanged.

## Rejected or unretained experiments

| Experiment | Finding |
|---|---|
| Toolchain alone | Roughly 0–3% on the original code; an unmodified upgrade breaks Unicode vectors. |
| Compact parser self references | Smaller parser objects, no useful elapsed-time improvement. |
| Eager variable-name hashing | Pays work for variables never used as hashed keys; lazy hashing was retained instead. |
| Global scope/variable/reference batches | Retained too much intermediate state and increased memory/time. Per-pass boundaries did not make this worthwhile. |
| Concrete scope lookup specialization | Mixed results, no reliable suite-wide gain. |
| Allocation sizes 16/31/63/127 | Confirmed lower allocator waste for several parser records; elapsed results were too small/mixed to retain. |
| Refreshing PGO | Little overall benefit over the existing profile. |
| 64-byte packed AST | Passed pointer checks, clone/original-name/overflow tests and byte gates, but memory savings did not establish a useful elapsed-time gain. |
| More GC headroom / GC disabled | Only a small remaining wall-time gain, sometimes slower. Bundle without GC used about 5.7GB. Defaults were retained. |
| Process-lifetime arenas | Bundle slowed from about 19.1s to 21.4s and RSS grew from about 560MB to 4GB. Rejected. |
| Parallel AST parsing | Targeted cases matched Java under the race detector, but measured gains were small. Default sequential behavior was retained. |

The first worker experiment exposed an allocation-lifetime bug: a partially
filled batch could connect successive compilers through its object graph.
Compiler allocation boundaries and private storage for retained templates fix
that chain. A 22-compilation check stayed near 270–300MB RSS rather than growing
on each iteration. That early leaking run is not used as performance evidence.

## Validation and limits

All packages passed their tests. The large jscomp test binary was compiled
separately with lower *build-time* GC headroom to fit the 8GB machine, then run
with default runtime GC; the test itself passed. Vet and license checks passed.
A compression comparison test now uses an explicit flush to guarantee different
valid deflate layouts, since newer Go versions may emit identical bytes for
`BestSpeed` and `BestCompression`; its payload/header assertions remain intact.

All ten held-out project builds matched Java, covering date-fns, highlight.js,
axios, ajv and Monaco inputs. Thirteen mixed worker requests also matched Java
and the ordinary CLI: source changes, output maps, warnings, parse errors, bad
flags, stdin, JSON streams, custom extern settings and output encoding. JVM
stack-frame differences use the repository's existing normalization rule.

For a fraction `f` of elapsed time accelerated by `k`, the ideal whole-build
speedup is `1 / ((1 - f) + f/k)` with other costs fixed. Even making a 30%
phase twice as fast gives only 1.18x overall. The GC experiments likewise show
that eliminating GC alone cannot remove the remaining large-build gap.

There is no defensible language-level theoretical maximum. HotSpot compiles
hot code to native code too. The remaining large-build gap calls for further
algorithmic work and reducing repeated analysis, rather than assuming a newer
Go compiler, smaller structs or disabling GC guarantees a win. This report
records a limited worker win and measured CLI improvements without redefining
the JVM baseline to make the other rows pass.

Raw medians, iteration data, binary hashes, build settings and machine metadata
are in [performance-results.json](performance-results.json).

## Reproduce

Build the baseline and candidate separately, then use prebuilt binaries during
measurement. The experiment harness refuses any run that changes Java's output.
Use `tools/bench/bench.py` to establish a fresh Java reference, and
`tools/bench/experiments.py` for interleaved Go variants. The worker benchmark
uses the production JSON request/response protocol. To reproduce the small-app
comparison separately, first prepare its warm Java reference and then run the
protocol harness below. Pin both commands to the same CPU set (for example
`taskset -c 0,1` on Linux) and keep heavy jobs off those CPUs.

```sh
go build -o bin/jsgo ./cmd/jsgo
go build -pgo=cmd/jsgo/default.pgo -o bin/jsgo-worker ./cmd/jsgo-worker
python3 -I tools/bench/bench.py run --jsgo bin/jsgo --out /tmp/jsgo-reference \\
  --tasks typed-app,bundle,downlevel-whitespace,downlevel-simple,checks-only \\
  --runs 5 --warmup 12 --warm-iters 10 --skip-trace

python3 -I tools/bench/bench.py run --skip-jsgo --out /tmp/jsgo-small-java \\
  --tasks small-advanced,small-simple,small-whitespace,small-checks \\
  --runs 1 --warmup 100 --warm-iters 30 --skip-trace
python3 -I tools/bench/worker_protocol.py --binary bin/jsgo-worker \\
  --reference /tmp/jsgo-small-java --out /tmp/jsgo-small-worker
```
'''
(repo/'docs/performance.md').write_text(text)
print('wrote final report and raw results')
