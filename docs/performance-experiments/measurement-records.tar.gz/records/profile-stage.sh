#!/usr/bin/env bash
set -euo pipefail
while pgrep -f '^python3 -I -u tools/bench/experiments.py --reference /workspace/jsgo-results/baseline --out /workspace/jsgo-results/toolchain' >/dev/null || pgrep -f '^/usr/bin/bash /workspace/jsgo-results/next-stage.sh' >/dev/null || pgrep -f '^bash /workspace/jsgo-results/next-stage.sh' >/dev/null; do sleep 5; done
. /workspace/toolchains/env.sh
cd /workspace/jsgo
GOMAXPROCS=2 go build -buildvcs=false -p 2 -pgo=cmd/jsgo/default.pgo -o bin/jsgo-profile ./tools/bench/profile
taskset -c 0,1 python3 -u /workspace/jsgo-results/profiles.py
