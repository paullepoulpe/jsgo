#!/usr/bin/env bash
set -euo pipefail
. /workspace/toolchains/env.sh
until [ -f /workspace/jsgo-results/final-java/checks-only/java-warm.json ]; do sleep 3; done
cd /workspace/jsgo
taskset -c 0,1 python3 -I -u tools/bench/experiments.py --reference /workspace/jsgo-results/baseline --out /workspace/jsgo-results/node64-pgo-smoke --tasks typed-app,bundle,downlevel-whitespace,downlevel-simple,checks-only --variant packed-old=/workspace/jsgo/bin/jsgo-node64 --variant packed-fresh=/workspace/jsgo/bin/jsgo-node64-fresh --runs 1 > /workspace/jsgo-results/node64-pgo-smoke.log 2>&1
taskset -c 0,1 python3 -I -u tools/bench/bench.py run --skip-jsgo --out /workspace/jsgo-results/small-final-java --tasks small-advanced,small-simple,small-whitespace,small-checks --runs 1 --warmup 100 --warm-iters 30 --skip-trace > /workspace/jsgo-results/small-final-java.log 2>&1
taskset -c 0,1 python3 -u /workspace/jsgo-results/measure-production-worker.py > /workspace/jsgo-results/production-worker.log 2>&1
