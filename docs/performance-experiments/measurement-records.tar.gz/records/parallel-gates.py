from pathlib import Path
import subprocess, os, json, hashlib
root=Path('/workspace/jsgo-results/parallel-gates'); root.mkdir(exist_ok=True)
jar='/workspace/jsgo/.cache/closure-compiler-v20261015.jar'
# Use the actual pinned jar name; no source/disassembly is read.
pin={}
for line in Path('/workspace/jsgo/tools/oracle/pin.env').read_text().splitlines():
 if line and not line.startswith('#') and '=' in line:
  k,v=line.split('=',1);pin[k]=v.strip('"')
jar='/workspace/jsgo/.cache/'+pin['CLOSURE_JAR']
sources=[]
for i in range(24):
 p=root/f'part{i:02d}.js';p.write_text(f'/** @param {{number}} value @return {{number}} */ function f{i}(value) {{ return value+{i}; }}\nvar name{i}="é😀\\ud800";\n')
 sources+=['--js',p.name]
(root/'error-a.js').write_text('function syntaxA( {\n')
(root/'error-b.js').write_text('let b = ;\n')
(root/'typed-warning.js').write_text('/** @type {string} */ var wrongType = 42;\n')
cases={
 'whitespace':['--compilation_level=WHITESPACE_ONLY']+sources,
 'simple':['--compilation_level=SIMPLE']+sources,
 'advanced':['--compilation_level=ADVANCED','--jscomp_warning=checkTypes']+sources,
 'errors':['--compilation_level=SIMPLE','--js','error-a.js','--js','error-b.js'],
 'warning':['--compilation_level=ADVANCED','--jscomp_warning=checkTypes']+sources+['--js','typed-warning.js'],
 'missing':['--compilation_level=SIMPLE','--js','does-not-exist.js'],
}
env={k:v for k,v in os.environ.items() if k not in ('GOGC','GODEBUG','GOMAXPROCS','JAVA_TOOL_OPTIONS','_JAVA_OPTIONS','JDK_JAVA_OPTIONS')}
env['LC_ALL']='C.UTF-8'
summary={}
for name,args in cases.items():
 args=['--num_parallel_threads=2']+args
 want=subprocess.run(['java','-jar',jar]+args,cwd=root,env=env,capture_output=True)
 # Race binary prints reports straight to OS stderr; any race is a hard failure.
 got=subprocess.run(['/workspace/jsgo/bin/jsgo-parallel-race']+args,cwd=root,env=env,capture_output=True)
 for label,r in [('java',want),('go',got)]:
  (root/f'{name}.{label}.stdout').write_bytes(r.stdout);(root/f'{name}.{label}.stderr').write_bytes(r.stderr)
 summary[name]={'java_exit':want.returncode,'go_exit':got.returncode,'stdout_match':want.stdout==got.stdout,'stderr_match':want.stderr==got.stderr}
 print(name,summary[name],flush=True)
 if got.returncode!=want.returncode or got.stdout!=want.stdout or got.stderr!=want.stderr:
  raise SystemExit('parallel/race gate failed: '+name)
(root/'summary.json').write_text(json.dumps(summary,indent=2))
