from pathlib import Path
import re
root=Path('/workspace/jsgo-compact-parser/internal/parser')
trees=sorted(m.group(1) for f in root.glob('*.go') for m in re.finditer(r'type (\w+) struct \{\s*ParseTreeBase\b', f.read_text()))
casts=re.findall(r'func \(t \*ParseTreeBase\) (As\w+)\(\) \*(\w+) \{', (root/'trees_parse_tree.go').read_text())
out=['// Go-only: language-adapter — compact self references for the closed parser', '// token/tree hierarchies. Each base is the first embedded field of its concrete', '// allocation. A non-pointer kind in existing padding replaces a two-word self', '// interface; reconstructing a pointer to that allocation preserves Go GC roots.', '// No pointer is converted to uintptr or stored outside the Go heap.', 'package parser', '', 'import "unsafe"', '']
for base,interface,types in [('ParseTreeBase','ParseTree',trees),('TokenBase','Token',['IdentifierToken','LiteralTokenBase','StringLiteralToken','TemplateLiteralToken','TokenBase'])]:
 out += [f'func (t *{base}) setSelf(self {interface}) {{', 'switch self.(type) {', 'case nil: t.selfKind = 0']
 for i,typ in enumerate(types,1): out += [f'case *{typ}: t.selfKind = {i}']
 out += ['default: panic("unregistered parser subclass")','}','}', f'func (t *{base}) getSelf() {interface} {{', 'switch t.selfKind {', 'case 0: return nil']
 for i,typ in enumerate(types,1): out += [f'case {i}: return (*{typ})(unsafe.Pointer(t))']
 out += ['default: panic("invalid parser self kind")','}','}']
 if base=='ParseTreeBase':
  for method,typ in casts: out += [f'func (t *{typ}) {method}() *{typ} {{ return t }}']
 else:
  out += ['func (t *IdentifierToken) AsIdentifier() *IdentifierToken { return t }', 'func (t *LiteralTokenBase) AsLiteral() LiteralToken { return t }', 'func (t *StringLiteralToken) AsLiteral() LiteralToken { return t }', 'func (t *TemplateLiteralToken) AsLiteral() LiteralToken { return t }', 'func (t *TemplateLiteralToken) AsTemplateLiteral() *TemplateLiteralToken { return t }']
for fn,field in [('trees_parse_tree.go','self ParseTree'),('token.go','self Token')]:
 p=root/fn;s=p.read_text().replace(field,'selfKind uint8').replace('t.self = self','t.setSelf(self)').replace('t.self.(', 't.getSelf().(').replace('parseTree := t.self','parseTree := t.getSelf()')
 p.write_text(s)
(root/'compact_self.go').write_text('\n'.join(out)+'\n')
print('Registered',len(trees),'trees and',len(casts),'concrete cast overrides')
