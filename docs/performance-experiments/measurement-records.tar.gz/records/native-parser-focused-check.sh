#!/usr/bin/env bash
set -euo pipefail
cd /workspace/jsgo-native-parser
mapfile -t parsing_sources < <(rg --files internal/parsing -g '*.go' -g '!**/*_test.go')
GOCACHE=/workspace/toolchains/cache GOPATH=/workspace/toolchains/gopath GOMAXPROCS=1 GOGC=30 \
  /workspace/toolchains/go1.27.2/bin/go test -p=1 -count=1 "${parsing_sources[@]}" \
  internal/parsing/native_parser_experiment_test.go
