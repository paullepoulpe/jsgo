#!/usr/bin/env bash
set -euo pipefail
. /workspace/toolchains/env.sh
export PATH=/workspace/toolchains/go1.27.2/bin:$PATH
until [ -f /workspace/jsgo-results/node64-paired/summary.json ] && python3 -c 'import json; assert "checks-only" in json.load(open("/workspace/jsgo-results/node64-paired/summary.json"))' >/dev/null 2>&1; do sleep 3; done
cd /workspace/jsgo-node64
GOMAXPROCS=2 go build -buildvcs=false -p 2 -pgo=cmd/jsgo/default.pgo -o /workspace/jsgo/bin/jsgo-node64-profile ./tools/bench/profile > /workspace/jsgo-results/build-node64-profile.log 2>&1
taskset -c 0,1 python3 -u /workspace/jsgo-results/profile-node64.py > /workspace/jsgo-results/profile-node64.log 2>&1
go tool pprof -proto -output=/workspace/jsgo-results/node64.pgo /workspace/jsgo-results/node64-profile/typed-app/cpu.pprof /workspace/jsgo-results/node64-profile/bundle/cpu.pprof /workspace/jsgo-results/node64-profile/downlevel-whitespace/cpu.pprof /workspace/jsgo-results/node64-profile/checks-only/cpu.pprof > /workspace/jsgo-results/merge-node64-pgo.log 2>&1
GOMAXPROCS=2 go build -buildvcs=false -p 2 -pgo=/workspace/jsgo-results/node64.pgo -o /workspace/jsgo/bin/jsgo-node64-fresh ./cmd/jsgo > /workspace/jsgo-results/build-node64-fresh.log 2>&1
