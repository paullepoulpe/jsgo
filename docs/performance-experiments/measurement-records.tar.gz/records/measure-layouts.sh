#!/usr/bin/env bash
set -euo pipefail
. /workspace/toolchains/env.sh
while [ ! -x /workspace/jsgo/bin/jsgo-compact-var ]; do
 if ! kill -0 16270 2>/dev/null || [[ "$(ps -o stat= -p 16270)" == Z* ]]; then exit 1; fi
 sleep 3
done
cd /workspace/jsgo
taskset -c 0,1 python3 -I -u tools/bench/warm_experiments.py --reference /workspace/jsgo-results/baseline --out /workspace/jsgo-results/worker-retention --binary /workspace/jsgo-results/gowarm-scope-gctrace --extern-cache --tasks downlevel-whitespace --warmup 2 --iters 20 > /workspace/jsgo-results/worker-retention.log 2>&1
taskset -c 0,1 python3 -I -u tools/bench/experiments.py --reference /workspace/jsgo-results/baseline --out /workspace/jsgo-results/layout-smoke --tasks typed-app,bundle,downlevel-whitespace --variant baseline=/workspace/jsgo/bin/jsgo-go124 --variant combined=/workspace/jsgo/bin/jsgo-combined --variant scope-chunks=/workspace/jsgo/bin/jsgo-scope-chunks --variant position-cache=/workspace/jsgo/bin/jsgo-position-cache --variant node80=/workspace/jsgo/bin/jsgo-node80 --variant compact-var=/workspace/jsgo/bin/jsgo-compact-var --runs 1 > /workspace/jsgo-results/layout-smoke.log 2>&1
