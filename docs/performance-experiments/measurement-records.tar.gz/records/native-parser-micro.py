import subprocess,pathlib,os,json,re,statistics
out=pathlib.Path('/workspace/jsgo-results/native-parser-micro');out.mkdir(exist_ok=True)
env=os.environ.copy();env.update(GOMAXPROCS='2',GOGC='100',JSGO_EXPERIMENT_NATIVE_PARSER='0')
data={label:[] for label in ['original','native']}
for round in range(5):
    labels=['original','native'] if round%2==0 else ['native','original']
    for label in labels:
        stem=out/f'{round}-{label}'
        native='true' if label=='native' else 'false'
        command=['taskset','-c','0,1','/workspace/jsgo-results/native-parsing-full.test','-test.run=^$','-test.bench=^BenchmarkNativeParserDataProgram/native='+native+'$','-test.benchmem','-test.benchtime=200ms','-test.count=1']
        with pathlib.Path(str(stem)+'.log').open('w') as log:
            p=subprocess.Popen(command,cwd='/workspace/jsgo-native-parser/internal/parsing',env=env,stdout=log,stderr=subprocess.STDOUT)
            _,status,usage=os.wait4(p.pid,0)
            p.returncode=os.waitstatus_to_exitcode(status)
        output=pathlib.Path(str(stem)+'.log').read_text()
        if p.returncode: raise RuntimeError(output)
        pathlib.Path(str(stem)+'.rss').write_text(str(usage.ru_maxrss))
        for line in output.splitlines():
            m=re.match(r'BenchmarkNativeParserDataProgram/.*?\s+(\d+)\s+(\d+) ns/op\s+[\d.]+ MB/s\s+(\d+) B/op\s+(\d+) allocs/op',line)
            if m:
                iterations,ns,b,allocs=map(int,m.groups());row=dict(round=round,iterations=iterations,ns=ns,bytes=b,allocs=allocs,peak_rss_kib=int(pathlib.Path(str(stem)+'.rss').read_text()))
                data[label].append(row);print(label,row,flush=True)
summary={label:{metric:statistics.median(row[metric] for row in rows) for metric in ['ns','bytes','allocs','peak_rss_kib']} for label,rows in data.items()}
(out/'summary.json').write_text(json.dumps(dict(samples=data,medians=summary),indent=2)+'\n')
print(json.dumps(summary,indent=2),flush=True)
