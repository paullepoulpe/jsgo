#!/usr/bin/env bash
set -euo pipefail
trap 'kill -CONT "$(cat /workspace/jsgo-results/candidate-stage.pid)" 2>/dev/null || true' EXIT
. /workspace/toolchains/env.sh
cd /workspace/jsgo
taskset -c 0,1 python3 -u /workspace/jsgo-results/profiles.py > /workspace/jsgo-results/profiles.log 2>&1
taskset -c 0,1 python3 -I -u tools/bench/experiments.py --reference /workspace/jsgo-results/baseline --out /workspace/jsgo-results/first-candidates --tasks typed-app,bundle,downlevel-whitespace --variant baseline=/workspace/jsgo/bin/jsgo-go124 --variant collections=/workspace/jsgo/bin/jsgo-collections --variant dataflow=/workspace/jsgo/bin/jsgo-dataflow --variant node-chunks=/workspace/jsgo/bin/jsgo-node-chunks --runs 3 > /workspace/jsgo-results/first-candidates.log 2>&1
