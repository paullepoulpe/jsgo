#!/usr/bin/env bash
set -euo pipefail
. /workspace/toolchains/env.sh
cd /workspace/jsgo-collections
GOMAXPROCS=2 go build -buildvcs=false -p 2 -o /workspace/jsgo/bin/jsgo-collections ./cmd/jsgo > /workspace/jsgo-results/build-collections.log 2>&1
cd /workspace/jsgo-dataflow
GOMAXPROCS=2 go test -p 2 ./internal/jscomp -run 'TestMustDefDenseStateDifferential|TestMustBeReachingVariableDefTest|TestFlowSensitiveInlineVariables' -count=1 > /workspace/jsgo-results/test-dataflow.log 2>&1
GOMAXPROCS=2 go build -buildvcs=false -p 2 -o /workspace/jsgo/bin/jsgo-dataflow ./cmd/jsgo > /workspace/jsgo-results/build-dataflow.log 2>&1
cd /workspace/jsgo-node-chunks
GOMAXPROCS=2 go test -p 2 ./internal/rhino > /workspace/jsgo-results/test-node-chunks.log 2>&1
GOMAXPROCS=2 go build -buildvcs=false -p 2 -o /workspace/jsgo/bin/jsgo-node-chunks ./cmd/jsgo > /workspace/jsgo-results/build-node-chunks.log 2>&1
cd /workspace/jsgo-extern-cache
GOMAXPROCS=2 go test -p 2 ./internal/parsing -run 'TestBuiltinExternCacheIsolation' -count=1 > /workspace/jsgo-results/test-extern-cache.log 2>&1
GOMAXPROCS=2 go build -buildvcs=false -p 2 -o /workspace/jsgo/bin/gowarm ./tools/bench/gowarm > /workspace/jsgo-results/build-gowarm.log 2>&1
cd /workspace/jsgo-var-hash
GOMAXPROCS=2 go build -buildvcs=false -p 2 -o /workspace/jsgo/bin/jsgo-var-hash ./cmd/jsgo > /workspace/jsgo-results/build-var-hash.log 2>&1
printf '\nAll Go1.24 candidates built.\n'
