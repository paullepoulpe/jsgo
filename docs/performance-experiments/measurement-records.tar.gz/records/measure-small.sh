#!/usr/bin/env bash
set -euo pipefail
. /workspace/toolchains/env.sh
until [ -x /workspace/jsgo/bin/jsgo-node64-fresh ]; do sleep 3; done
cd /workspace/jsgo
taskset -c 0,1 python3 -I -u tools/bench/bench.py run --jsgo /workspace/jsgo/bin/jsgo-next127 --out /workspace/jsgo-results/small-baseline --tasks small-advanced,small-simple,small-whitespace,small-checks --runs 3 --warmup 100 --warm-iters 30 --skip-trace > /workspace/jsgo-results/small-baseline.log 2>&1
taskset -c 0,1 python3 -I -u tools/bench/warm_experiments.py --reference /workspace/jsgo-results/small-baseline --out /workspace/jsgo-results/small-worker --binary /workspace/jsgo/bin/gowarm-next127 --extern-cache --tasks small-advanced,small-simple,small-whitespace,small-checks --warmup 10 --iters 30 > /workspace/jsgo-results/small-worker.log 2>&1
