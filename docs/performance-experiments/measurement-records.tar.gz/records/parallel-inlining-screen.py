#!/usr/bin/env python3
"""Incremental Go-only screen; Java artifacts gate correctness, not timing."""
import hashlib
import json
import os
from pathlib import Path
import random
import statistics
import sys
from types import SimpleNamespace

sys.dont_write_bytecode = True
sys.path.insert(0, '/workspace/jsgo-redesigns/tools/bench')
import bench
from thread_sweep import with_compiler_threads

root = Path('/workspace/jsgo-results/parallel-inlining-only-screen' if '--inlining-only' in sys.argv
            else '/workspace/jsgo-results/parallel-inlining-screen')
if root.exists():
    raise SystemExit('refusing to overwrite existing results')
binary = '/workspace/jsgo/bin/jsgo-cli-fsiv'
variants = {
    'control': {},
    'references': {'JSGO_EXPERIMENT_NATIVE_REFERENCES': '1'},
    'parallel-combined': {'JSGO_EXPERIMENT_NATIVE_REFERENCES': '1',
                          'JSGO_EXPERIMENT_PARALLEL_FSIV': '1'},
}
if '--inlining-only' in sys.argv:
    variants = {'control': {}, 'inlining': {'JSGO_EXPERIMENT_PARALLEL_FSIV': '1'}}
runner = bench.Runner(SimpleNamespace(cache=bench.default_cache(), out=str(root),
                                     nice=10, locale='C.UTF-8'))
env = {k: v for k, v in runner.go_env.items() if not k.startswith('JSGO_EXPERIMENT_')}
metadata = bench.machine_info(runner, {'path': binary, 'sha256': bench.sha256_file(binary)})
metadata.update({'scope': 'fresh Go CLI processes; same binary, compiler jobs=2',
                 'source_commit': 'a5a3b609',
                 'cpu_affinity': sorted(os.sched_getaffinity(0)),
                 'variant_environment': variants, 'runs': 2,
                 'java_role': 'stored artifact oracle only; NO Java timing ratios in this screen',
                 'memory_unit': 'MiB; median fresh process peak RSS'})
bench.save(str(root/'machine.json'), metadata)
summary = {}
rng = random.Random(20261018)
for task in bench.load_tasks(['typed-app', 'bundle']):
    name = task['name']
    reference = Path('/workspace/jsgo-results/final-java')/name
    expected = bench.load(str(reference/'java-cold.json'))['runs'][0]['digests']
    jobs = [with_compiler_threads(job, 2) for job in bench.load(str(reference/'jobs.json'))]
    runs = {label: [] for label in variants}
    for label in variants:
        destination = root/name/label
        destination.mkdir(parents=True)
        (destination/'java-cold').symlink_to(reference/'java-cold', target_is_directory=True)
        bench.save(str(destination/'jobs.json'), jobs)
    order = list(variants)
    rng.shuffle(order)
    for index in (1, 2):
        for label in order if index == 1 else list(reversed(order)):
            destination = root/name/label
            print(f'== {name}/{label}/round-{index}', flush=True)
            run = runner.measure_cold(task, jobs, str(destination), 'jsgo', index,
                                      lambda args: [binary]+args, env|variants[label])
            runs[label].append(run)
            if run['digests'] != expected:
                raise SystemExit(f'artifact mismatch: {name}/{label}')
            if index == 1 and bench.gate(task, jobs, str(destination)) != 'MATCH':
                raise SystemExit(f'compatibility mismatch: {name}/{label}')
            bench.save(str(destination/'jsgo.json'), {'runs': runs[label]})
    baseline = statistics.median(r['wall_s'] for r in runs['control'])
    summary[name] = {label: {'median_s': statistics.median(r['wall_s'] for r in values),
                             'median_peak_rss_mib': statistics.median(r['rss_mb'] for r in values),
                             'speed_vs_control': baseline/statistics.median(r['wall_s'] for r in values),
                             'runs': values, 'all_outputs_match': True}
                     for label, values in runs.items()}
    bench.save(str(root/'summary.json'), summary)
    print(json.dumps(summary[name], indent=2), flush=True)
