import os,json,time,base64,subprocess,pathlib,statistics,sys
sys.path.insert(0,'/workspace/jsgo/tools/bench')
import bench
root=pathlib.Path('/workspace/jsgo-results/production-worker');root.mkdir(exist_ok=True)
reference=pathlib.Path('/workspace/jsgo-results/small-final-java')
binary='/workspace/jsgo/bin/jsgo-worker'
env={k:v for k,v in os.environ.items() if k not in bench.GO_ENV_DROP};env['LC_ALL']='C.UTF-8'
summary={}
for name in ['small-advanced','small-simple','small-whitespace','small-checks']:
 task=bench.load_tasks([name])[0];ws=root/name;bench.make_workspace(str(ws),'/workspace/jsgo/.cache')
 args=bench.load(str(reference/name/'jobs.json'))[0]
 p=subprocess.Popen([binary],cwd=ws,env=env,stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=open(ws/'protocol.stderr','wb'))
 expected=bench.artifacts(task,str(reference/name/'java-cold/run-1'),0,True)
 rows=[];rss=[]
 try:
  for i in range(40):
   request=json.dumps({'id':i,'args':args}).encode()+b'\n'
   start=time.perf_counter();p.stdin.write(request);p.stdin.flush()
   response=json.loads(p.stdout.readline())
   stdout=base64.b64decode(response['stdout_base64']);stderr=base64.b64decode(response['stderr_base64'])
   end=time.perf_counter()
   assert response['id']==i
   # Check every response and output file after the timed request.
   got={'stdout':stdout,'stderr':stderr,'exit':(str(response['exit'])+'\n').encode()}
   for k,f in expected.items():
    if k not in got:got[k]=(ws/k).read_bytes() if (ws/k).exists() else None
    want=pathlib.Path(f).read_bytes() if pathlib.Path(f).exists() else None
    assert got[k]==want,(name,i,k)
   for line in pathlib.Path('/proc/'+str(p.pid)+'/status').read_text().splitlines():
    if line.startswith('VmHWM:'):rss.append(int(line.split()[1])/1024)
   if i>=10:rows.append((end-start)*1000)
  p.stdin.close();assert p.wait(timeout=10)==0
 finally:
  if p.poll() is None:p.kill();p.wait()
 warm=bench.load(str(reference/name/'java-warm.json'));j=[r['wall_ms'] for r in warm['iterations'] if r['kind']=='measure']
 summary[name]={'worker_protocol_median_ms':statistics.median(rows),'java_warm_median_ms':statistics.median(j),'speed_vs_java_warm':statistics.median(j)/statistics.median(rows),'worker_peak_rss_mb':max(rss),'all_40_responses_match_java':True,'measured_ms':rows,'java_measure_ms':j,'java_warmup':warm['warmup'],'java_iters':warm['iters']}
 bench.save(str(root/'summary.json'),summary)
 print(name,round(statistics.median(rows),3),'ms; Java',round(statistics.median(j),3),'ms;',round(summary[name]['speed_vs_java_warm'],3),'x; all 40 responses MATCH',flush=True)
