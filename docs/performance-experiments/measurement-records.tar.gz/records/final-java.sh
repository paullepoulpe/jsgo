#!/usr/bin/env bash
set -euo pipefail
. /workspace/toolchains/env.sh
until [ -f /workspace/jsgo-results/delivery-paired/summary.json ] && python3 -c 'import json; assert "checks-only" in json.load(open("/workspace/jsgo-results/delivery-paired/summary.json"))' >/dev/null 2>&1; do sleep 3; done
cd /workspace/jsgo
taskset -c 0,1 python3 -I -u tools/bench/bench.py run --skip-jsgo --out /workspace/jsgo-results/final-java --tasks typed-app,bundle,downlevel-whitespace,downlevel-simple,checks-only --runs 1 --warmup 12 --warm-iters 10 --skip-trace > /workspace/jsgo-results/final-java.log 2>&1
