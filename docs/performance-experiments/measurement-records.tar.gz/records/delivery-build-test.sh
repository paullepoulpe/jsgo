#!/usr/bin/env bash
set -euo pipefail
. /workspace/toolchains/env.sh
export PATH=/workspace/toolchains/go1.27.2/bin:$PATH
cd /workspace/jsgo-delivery
GOMAXPROCS=2 go build -buildvcs=false -p 2 -o /workspace/jsgo/bin/jsgo-delivery ./cmd/jsgo > /workspace/jsgo-results/build-delivery.log 2>&1
GOMAXPROCS=2 go build -buildvcs=false -p 2 -pgo=cmd/jsgo/default.pgo -o /workspace/jsgo/bin/jsgo-worker ./cmd/jsgo-worker > /workspace/jsgo-results/build-worker.log 2>&1
GOMAXPROCS=2 go build -buildvcs=false -p 2 -pgo=cmd/jsgo/default.pgo -o /workspace/jsgo/bin/gowarm-delivery ./tools/bench/gowarm > /workspace/jsgo-results/build-gowarm-delivery.log 2>&1
GOMAXPROCS=2 go test -p 2 ./... > /workspace/jsgo-results/test-delivery-full.log 2>&1
GOMAXPROCS=2 go vet -p 2 ./internal/... > /workspace/jsgo-results/vet-delivery.log 2>&1
go run ./tools/licenses -check > /workspace/jsgo-results/licenses-delivery.log 2>&1
