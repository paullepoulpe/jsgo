#!/usr/bin/env bash
set -euo pipefail
. /workspace/toolchains/env.sh
while kill -0 15515 2>/dev/null; do sleep 3; done
kill -TERM 14840 2>/dev/null || true
kill -CONT 14840 2>/dev/null || true
cd /workspace/jsgo-scope-chunks
GOMAXPROCS=2 go test -p 2 ./internal/jutil -run TestWeakSlab -count=1 > /workspace/jsgo-results/test-weak-slab.log 2>&1
GOMAXPROCS=2 go test -p 2 ./internal/rhino ./internal/parsing > /workspace/jsgo-results/test-cache-lifetime.log 2>&1
GOMAXPROCS=2 go build -buildvcs=false -p 2 -o /workspace/jsgo/bin/jsgo-scope-chunks ./cmd/jsgo > /workspace/jsgo-results/build-scope-chunks.log 2>&1
GOMAXPROCS=2 go build -buildvcs=false -p 2 -pgo=cmd/jsgo/default.pgo -o /workspace/jsgo/bin/gowarm-scope ./tools/bench/gowarm > /workspace/jsgo-results/build-gowarm-scope.log 2>&1
cd /workspace/jsgo-position-cache
GOMAXPROCS=2 go test -p 2 ./internal/parser ./internal/parsing > /workspace/jsgo-results/test-position-cache.log 2>&1
GOMAXPROCS=2 go build -buildvcs=false -p 2 -o /workspace/jsgo/bin/jsgo-position-cache ./cmd/jsgo > /workspace/jsgo-results/build-position-cache.log 2>&1
cd /workspace/jsgo-node80
GOMAXPROCS=2 go test -p 2 -gcflags=all=-d=checkptr=2 ./internal/rhino > /workspace/jsgo-results/test-node80.log 2>&1
GOMAXPROCS=2 go build -buildvcs=false -p 2 -o /workspace/jsgo/bin/jsgo-node80 ./cmd/jsgo > /workspace/jsgo-results/build-node80.log 2>&1
cd /workspace/jsgo-compact-var
GOMAXPROCS=2 go build -buildvcs=false -p 2 -o /workspace/jsgo/bin/jsgo-compact-var ./cmd/jsgo > /workspace/jsgo-results/build-compact-var.log 2>&1
