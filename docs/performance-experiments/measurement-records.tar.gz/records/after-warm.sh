#!/usr/bin/env bash
set -euo pipefail
. /workspace/toolchains/env.sh
while kill -0 14420 2>/dev/null; do sleep 3; done
cd /workspace/jsgo
taskset -c 0,1 python3 -I -u tools/bench/experiments.py --reference /workspace/jsgo-results/baseline --out /workspace/jsgo-results/second-candidates --tasks typed-app,bundle,downlevel-whitespace --variant baseline=/workspace/jsgo/bin/jsgo-go124 --variant compact-parser=/workspace/jsgo/bin/jsgo-compact-parser --variant var-hash=/workspace/jsgo/bin/jsgo-var-hash --variant combined=/workspace/jsgo/bin/jsgo-combined --runs 3 > /workspace/jsgo-results/second-candidates.log 2>&1
/workspace/jsgo-results/measure-memory-envelope.sh
cd /workspace/jsgo-scope-chunks
GOMAXPROCS=2 go test -p 2 ./internal/jutil -run TestWeakSlab -count=1 > /workspace/jsgo-results/test-weak-slab.log 2>&1
GOMAXPROCS=2 go test -p 2 ./internal/jscomp -run 'TestVarHashMatchesScopedName|TestScope|TestVarTest|TestReference' -count=1 > /workspace/jsgo-results/test-scope-chunks.log 2>&1
GOMAXPROCS=2 go build -buildvcs=false -p 2 -o /workspace/jsgo/bin/jsgo-scope-chunks ./cmd/jsgo > /workspace/jsgo-results/build-scope-chunks.log 2>&1
cd /workspace/jsgo-position-cache
GOMAXPROCS=2 go test -p 2 ./internal/parser ./internal/parsing > /workspace/jsgo-results/test-position-cache.log 2>&1
GOMAXPROCS=2 go build -buildvcs=false -p 2 -o /workspace/jsgo/bin/jsgo-position-cache ./cmd/jsgo > /workspace/jsgo-results/build-position-cache.log 2>&1
