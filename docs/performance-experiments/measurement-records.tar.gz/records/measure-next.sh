#!/usr/bin/env bash
set -euo pipefail
. /workspace/toolchains/env.sh
until [ -x /workspace/jsgo/bin/gowarm-next127 ]; do sleep 3; done
cd /workspace/jsgo
taskset -c 0,1 python3 -I -u tools/bench/experiments.py --reference /workspace/jsgo-results/baseline --out /workspace/jsgo-results/next-smoke --tasks typed-app,bundle,downlevel-whitespace,downlevel-simple,checks-only --variant combined=/workspace/jsgo/bin/jsgo-combined --variant rename-conflicts=/workspace/jsgo/bin/jsgo-rename-conflicts --variant parallel-two=/workspace/jsgo-results/jsgo-parallel-two --variant next124=/workspace/jsgo/bin/jsgo-next124 --variant next127=/workspace/jsgo/bin/jsgo-next127 --runs 1 > /workspace/jsgo-results/next-smoke.log 2>&1
taskset -c 0,1 python3 -I -u tools/bench/warm_experiments.py --reference /workspace/jsgo-results/baseline --out /workspace/jsgo-results/warm-next127 --binary /workspace/jsgo/bin/gowarm-next127 --extern-cache --warmup 2 --iters 5 > /workspace/jsgo-results/warm-next127.log 2>&1
