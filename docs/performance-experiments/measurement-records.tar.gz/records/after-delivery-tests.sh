#!/usr/bin/env bash
set -euo pipefail
. /workspace/toolchains/env.sh
# This readiness marker is written only after tests, vet and license checks.
until [ -f /workspace/jsgo-results/licenses-delivery.log ]; do sleep 3; done
python3 -u /workspace/jsgo-results/worker-protocol.py > /workspace/jsgo-results/worker-protocol.log 2>&1
cd /workspace/jsgo
taskset -c 0,1 python3 -I -u tools/bench/experiments.py --reference /workspace/jsgo-results/baseline --out /workspace/jsgo-results/delivery-paired --tasks typed-app,bundle,downlevel-whitespace,downlevel-simple,checks-only --variant original=/workspace/jsgo/bin/jsgo-go124 --variant delivery=/workspace/jsgo/bin/jsgo-delivery --runs 5 > /workspace/jsgo-results/delivery-paired.log 2>&1
