import json, os, subprocess, sys
from pathlib import Path
sys.path.insert(0,'/workspace/jsgo/tools/bench')
import bench
out=Path('/workspace/jsgo-results/node64-profile');out.mkdir(exist_ok=True)
env=dict(os.environ, LC_ALL='C.UTF-8')
for name in ('typed-app','bundle','downlevel-whitespace','checks-only'):
 task=bench.load_tasks([name])[0]
 ws=out/name;bench.make_workspace(str(ws),'/workspace/jsgo/.cache')
 args=bench.task_jobs(task,str(ws))[0]
 with (ws/'stdout').open('wb') as stdout, (ws/'stderr').open('wb') as stderr:
  p=subprocess.run(['/workspace/jsgo/bin/jsgo-node64-profile',str(ws/'cpu.pprof'),str(ws/'allocs.pprof')]+args,cwd=ws,env=env,stdout=stdout,stderr=stderr)
 (ws/'exit').write_text(str(p.returncode)+'\n')
 ref=Path('/workspace/jsgo-results/baseline')/name/'java-cold/run-1'
 arts=bench.artifacts(task,str(ws),0,True)
 assert all(bench.same_file(str(ref/k),path) for k,path in arts.items()),name+' profile outputs differ'
 print(name+': profile captured, outputs match Java',flush=True)
