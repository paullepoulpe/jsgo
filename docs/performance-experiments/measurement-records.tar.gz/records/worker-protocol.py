import base64, json, os, subprocess, pathlib, selectors
root=pathlib.Path('/workspace/jsgo-results/worker-protocol');root.mkdir(exist_ok=True)
worker='/workspace/jsgo/bin/jsgo-worker'
cli='/workspace/jsgo/bin/jsgo-delivery'
pin={}
for line in pathlib.Path('/workspace/jsgo/tools/oracle/pin.env').read_text().splitlines():
 if line and not line.startswith('#') and '=' in line:
  k,v=line.split('=',1);pin[k]=v.strip('"')
jar='/workspace/jsgo/.cache/'+pin['CLOSURE_JAR']
env=dict(os.environ,LC_ALL='C.UTF-8')
for k in ('GOGC','GODEBUG','GOMAXPROCS','JAVA_TOOL_OPTIONS','_JAVA_OPTIONS','JDK_JAVA_OPTIONS'):env.pop(k,None)
p=subprocess.Popen([worker],cwd=root,env=env,stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=open(root/'worker.stderr','wb'))
selector=selectors.DefaultSelector();selector.register(p.stdout,selectors.EVENT_READ)
source='/** @type {number} */ var count=1; window.alert("é😀"+count);\n'
cases=[
 ('help',['--help'],source,b''),
 ('version',['--version'],source,b''),
 ('whitespace',['--compilation_level=WHITESPACE_ONLY','--js','app.js'],source,b''),
 ('changed-source',['--compilation_level=WHITESPACE_ONLY','--js','app.js'],source.replace('count=1','count=7'),b''),
 ('simple-map',['--compilation_level=SIMPLE','--js','app.js','--js_output_file=out.js','--create_source_map=out.js.map'],source,b''),
 ('advanced-warning',['--compilation_level=ADVANCED','--jscomp_warning=checkTypes','--js','app.js'],'/** @type {string} */ var incorrect=42;window.alert(incorrect);\n',b''),
 ('parse-error',['--js','app.js'],'function broken( {',b''),
 ('bad-flag',['--invalid-worker-test-flag'],source,b''),
 ('stdin',['--compilation_level=WHITESPACE_ONLY','--js','-'],'ignored',source.encode()),
 ('json-streams',['--compilation_level=WHITESPACE_ONLY','--json_streams=BOTH'],'ignored',json.dumps([{'path':'stream.js','src':source}]).encode()),
 ('custom-externs',['--compilation_level=SIMPLE','--env=CUSTOM','--js','app.js'],'var counter=1;counter++;',b''),
 ('default-after-custom',['--compilation_level=WHITESPACE_ONLY','--js','app.js'],source,b''),
 ('iso-8859-1',['--compilation_level=WHITESPACE_ONLY','--charset=ISO-8859-1','--js','app.js'],source,b''),
]
summary={}
try:
 for index,(name,args,code,stdin) in enumerate(cases):
  (root/'app.js').write_text(code)
  outputs={}
  for who,argv in [('java',['java','-jar',jar]),('cli',[cli])]:
   for output in ('out.js','out.js.map'):(root/output).unlink(missing_ok=True)
   r=subprocess.run(argv+args,input=stdin,cwd=root,env=env,capture_output=True,timeout=60)
   outputs[who]=(r.returncode,r.stdout,r.stderr,{f:(root/f).read_bytes() if (root/f).exists() else None for f in ('out.js','out.js.map')})
   (root/f'{name}.{who}.stdout').write_bytes(r.stdout);(root/f'{name}.{who}.stderr').write_bytes(r.stderr)
  for output in ('out.js','out.js.map'):(root/output).unlink(missing_ok=True)
  p.stdin.write(json.dumps({'id':index,'args':args,'stdin_base64':base64.b64encode(stdin).decode()}).encode()+b'\n');p.stdin.flush()
  if not selector.select(timeout=60):raise AssertionError('worker blocked: '+name)
  line=p.stdout.readline()
  if not line:raise AssertionError('worker exited: '+name)
  response=json.loads(line)
  assert response['id']==index
  got=(response['exit'],base64.b64decode(response['stdout_base64'] or ''),base64.b64decode(response['stderr_base64'] or ''),{f:(root/f).read_bytes() if (root/f).exists() else None for f in ('out.js','out.js.map')})
  (root/f'{name}.worker.stdout').write_bytes(got[1]);(root/f'{name}.worker.stderr').write_bytes(got[2])
  # The port deliberately omits JVM stack frames; exception messages/status
  # and all other bytes still have to match.
  def normalized(t):return b'\n'.join(x for x in t.split(b'\n') if not (x.startswith(b'\tat ') or x.startswith(b'\t... ')))
  def canonical(t):return t[0],t[1],normalized(t[2]),t[3]
  summary[name]={'matches_cli':got==outputs['cli'],'matches_java':canonical(got)==canonical(outputs['java'])}
  print(name,summary[name],flush=True)
  assert all(summary[name].values()),name
 p.stdin.close();assert p.wait(timeout=10)==0
 (root/'summary.json').write_text(json.dumps(summary,indent=2))
finally:
 if p.poll() is None:p.kill();p.wait()
