from pathlib import Path
p=Path('/workspace/jsgo-dataflow/internal/jscomp/must_be_reaching_variable_def.go')
s=p.read_text()
s=s.replace('allVarsInFn *jutil.LinkedHashMap[string, *Var]\n}', 'allVarsInFn *jutil.LinkedHashMap[string, *Var]\n\t// Go-only: performance — local variable IDs shared by lattice states.\n\tlayout *mustDefLayout\n}',1)
s=s.replace('d.allVarsInFn = allVarsInFn\n', 'd.allVarsInFn = allVarsInFn\n\td.layout = newMustDefLayout(allVarsInFn)\n',1)
s=s.replace('reachingDef *jutil.ObjectLinkedHashMap[*Var, *MustBeReachingVariableDef_Definition]', 'reachingDef mustDefMap',1)
s=s.replace('reachingDef: jutil.NewObjectLinkedHashMap[*Var, *MustBeReachingVariableDef_Definition](),', 'reachingDef: newMustDefMap(nil),',1)
a=s.index('\tm := NewMustBeReachingVariableDef_MustDef()\n',s.index('func NewMustBeReachingVariableDef_MustDefCopy'))
b=s.index('\n}',a)
s=s[:a]+'\treturn &MustBeReachingVariableDef_MustDef{reachingDef: other.reachingDef.clone()}'+s[b:]
s=s.replace('mustDef.reachingDef.Equals(m.reachingDef)', 'mustDef.reachingDef.equals(&m.reachingDef)')
s=s.replace('resultMap *jutil.ObjectLinkedHashMap[*Var, *MustBeReachingVariableDef_Definition]', 'resultMap *mustDefMap')
s=s.replace('j.resultMap = j.result.reachingDef', 'j.resultMap = &j.result.reachingDef')
s=s.replace('return NewMustBeReachingVariableDef_MustDefWithVars(d.allVarsInFn.Values())', '''m := &MustBeReachingVariableDef_MustDef{reachingDef: newMustDefMap(d.layout)}
	for var_ := range d.allVarsInFn.Values() {
		m.reachingDef.Put(var_, NewMustBeReachingVariableDef_Definition(var_.GetScope().(*Scope).GetRootNode()))
	}
	return m''')
s=s.replace('return NewMustBeReachingVariableDef_MustDef()\n}', 'return &MustBeReachingVariableDef_MustDef{reachingDef: newMustDefMap(d.layout)}\n}',1)
s=s.replace('return NewMustBeReachingVariableDef_MustDefJoin()\n}', '''m := &MustBeReachingVariableDef_MustDef{reachingDef: newMustDefMap(d.layout)}
	return &MustBeReachingVariableDef_MustDefJoin{result: m, resultMap: &m.reachingDef}
}''',1)
p.write_text(s)
