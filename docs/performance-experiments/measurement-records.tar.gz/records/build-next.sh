#!/usr/bin/env bash
set -euo pipefail
. /workspace/toolchains/env.sh
until [ -f /workspace/jsgo-results/parallel-gates/summary.json ]; do sleep 3; done
cd /workspace/jsgo-next
GOMAXPROCS=2 go build -buildvcs=false -p 2 -o /workspace/jsgo/bin/jsgo-next124 ./cmd/jsgo > /workspace/jsgo-results/build-next124.log 2>&1
export PATH=/workspace/toolchains/go1.27.2/bin:$PATH
GOMAXPROCS=2 go build -buildvcs=false -p 2 -o /workspace/jsgo/bin/jsgo-next127 ./cmd/jsgo > /workspace/jsgo-results/build-next127.log 2>&1
GOMAXPROCS=2 go build -buildvcs=false -p 2 -pgo=cmd/jsgo/default.pgo -o /workspace/jsgo/bin/gowarm-next127 ./tools/bench/gowarm > /workspace/jsgo-results/build-gowarm-next127.log 2>&1
