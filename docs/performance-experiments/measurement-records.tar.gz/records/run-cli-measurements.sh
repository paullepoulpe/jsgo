#!/usr/bin/env bash
set -euo pipefail
. /workspace/toolchains/env.sh
export PATH=/workspace/toolchains/go1.27.2/bin:$PATH
cd /workspace/jsgo-redesigns
taskset -c 0,1 python3 -I -u tools/bench/experiments.py \
  --reference /workspace/jsgo-results/final-java \
  --out /workspace/jsgo-results/ordinary-cli-owned-screen \
  --tasks typed-app,bundle,downlevel-whitespace --runs 1 \
  --variant main=/workspace/jsgo/bin/jsgo-cli-main \
  --variant architecture-control=/workspace/jsgo/bin/jsgo-cli-owned \
  --variant parser=/workspace/jsgo/bin/jsgo-cli-owned \
  --variant cfg=/workspace/jsgo/bin/jsgo-cli-owned \
  --variant parser-cfg=/workspace/jsgo/bin/jsgo-cli-owned \
  --variant-env 'parser={"JSGO_EXPERIMENT_NATIVE_PARSER":"1"}' \
  --variant-env 'cfg={"JSGO_EXPERIMENT_NATIVE_CFG":"1"}' \
  --variant-env 'parser-cfg={"JSGO_EXPERIMENT_NATIVE_PARSER":"1","JSGO_EXPERIMENT_NATIVE_CFG":"1"}' \
  > /workspace/jsgo-results/ordinary-cli-owned-screen.log 2>&1
taskset -c 0,1 python3 -I -u tools/bench/thread_sweep.py \
  --binary /workspace/jsgo/bin/jsgo-cli-main \
  --reference /workspace/jsgo-results/final-java \
  --out /workspace/jsgo-results/ordinary-cli-threads \
  --tasks typed-app,downlevel-whitespace --threads 1,2,4 \
  --runs 3 --warmup 12 --warm-iters 10 \
  > /workspace/jsgo-results/ordinary-cli-threads.log 2>&1
