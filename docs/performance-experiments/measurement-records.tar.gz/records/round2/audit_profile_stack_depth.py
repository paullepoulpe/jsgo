import collections,json,os,re,subprocess
from pathlib import Path
BASE=Path('/workspace/jsgo-results/round2/parser-profiles-enabled')
GO='/workspace/toolchains/go1.27.2/bin/go'
ENV=dict(os.environ,GOCACHE='/workspace/.cache/go-build')
SOURCE=Path('/workspace/jsgo-round-module-names/internal/jscomp')
callbacks=set()
for p in SOURCE.glob('*.go'):
 if p.name.endswith('_test.go'):continue
 for c,method in re.findall(r'func\s+\(\w+\s+\*([A-Za-z0-9_]+)\)\s+(Process|ShouldTraverse|Visit|EnterScope|ExitScope)\(',p.read_text()):
  if c.startswith(('NodeTraversal','PhaseOptimizer','CombinedCompilerPass')) or c=='Compiler':continue
  callbacks.add(f'(*{c}).{method}')

def parse(path,typ):
 raw=subprocess.check_output([GO,'tool','pprof','-raw',str(path)],text=True,env=ENV,stderr=subprocess.DEVNULL)
 sample_text,locations=raw.split('Samples:\n',1)[1].split('\nLocations\n',1)
 columns=[v.removesuffix('[dflt]')for v in sample_text.splitlines()[0].split()];idx=columns.index(typ)
 blocks={};cur=None
 for line in locations.split('\nMappings',1)[0].splitlines():
  m=re.match(r'\s*(\d+): ',line)
  if m:cur=int(m[1]);blocks[cur]=line
  elif cur is not None:blocks[cur]+='\n'+line
 def funcs(block):
  return [re.sub(r'^\s*\d+:\s+0x[0-9a-f]+\s+M=\d+\s+', '', line).strip().split(' /',1)[0] for line in block.splitlines() if ' /' in line]
 for m in re.finditer(r'^\s*([\d \t]+):\s*([\d ]+)$',sample_text,re.M):
  vals=[int(v)for v in m[1].split()];ids=[int(v)for v in m[2].split()]
  fs=[f for i in ids for f in funcs(blocks[i])]
  yield vals[idx],ids,fs

out={'notes':['CPU fixed64PC slots; inline expansion/grouping means pprof locationIDs != captured PC count. Logical frame count>=64 flags saturation candidates, not proof by itself.','Oldest retained NodeTraversal frame is direct missing-parent-context evidence.','recognized callback context uses broad source-scanned Process/Visit/ShouldTraverse/EnterScope/ExitScope receivers; excludes genericdriver classes. Presence does not uniquely assign compiler pass, so missing counts are conservative.'],'recognized_callback_count':len(callbacks),'tasks':{}}
for task in ['typed-app','bundle','downlevel-whitespace','downlevel-simple','checks-only']:
 result={}
 for typ,ext,div in [('cpu/nanoseconds','cpu',1e9),('alloc_space/bytes','allocs',1048576)]:
  counts=collections.Counter();depthhist=collections.Counter();tailhist=collections.Counter();maxloc=maxframe=0
  for n,ids,fs in parse(BASE/task/f'profile.{ext}.pprof',typ):
   st='\n'.join(fs);leaf=fs[0]if fs else '';tail=fs[-1]if fs else ''
   walker='internal/jscomp.(*NodeTraversal).'in st
   getnext='internal/rhino.(*Node).GetNext'in leaf
   context=any(c in st for c in callbacks)
   entry_context=any(c in st for c in callbacks if c.endswith('.Process'))
   saturated=len(fs)>=64
   flags={'total':True,'logical_frames_ge64':saturated,'logical_frames_ge128':len(fs)>=128,'generic_traversal':walker,'generic_traversal_ge64':walker and saturated,'generic_traversal_no_process_entry':walker and not entry_context,'getnext_leaf_traversal_no_process_entry':getnext and walker and not entry_context,'generic_traversal_no_callback_context':walker and not context,'generic_traversal_ge64_no_callback_context':walker and saturated and not context,'oldest_is_generic_traversal': 'internal/jscomp.(*NodeTraversal).' in tail,'getnext_leaf':getnext,'getnext_leaf_ge64':getnext and saturated,'getnext_leaf_traversal_no_callback_context':getnext and walker and not context}
   for k,v in flags.items():
    if v:counts[k]+=n
   depthhist[len(fs)]+=n
   if walker and not context:tailhist[tail]+=n
   maxloc=max(maxloc,len(ids));maxframe=max(maxframe,len(fs))
  result[ext]={'unit':'seconds'if ext=='cpu'else'MiB','buckets':{k:round(v/div,6)for k,v in counts.items()},'max_location_count':maxloc,'max_logical_frames':maxframe,'depth_histogram':{str(k):round(v/div,6)for k,v in sorted(depthhist.items())},'unattributed_traversal_oldest_frame_top10':[(k,round(v/div,6))for k,v in tailhist.most_common(10)]}
 out['tasks'][task]=result
p=BASE.parent/'profile-stack-depth-audit.json';p.write_text(json.dumps(out,indent=2)+'\n')
for task,result in out['tasks'].items():
 print(task)
 for kind,data in result.items():print(kind,data['buckets'],'maxlogical',data['max_logical_frames'],'maxloc',data['max_location_count'],'tails',data['unattributed_traversal_oldest_frame_top10'][:3])
