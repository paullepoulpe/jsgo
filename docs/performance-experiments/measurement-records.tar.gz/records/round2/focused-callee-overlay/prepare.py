#!/usr/bin/env python3
"""Reduce test declarations only; keep real package/import path/production files."""
import argparse
import hashlib
import json
import re
from pathlib import Path

parser = argparse.ArgumentParser()
parser.add_argument('--root', type=Path, default=Path('/workspace/jsgo-round-work-elision'))
args = parser.parse_args()
root = args.root.resolve()
out = Path(__file__).resolve().parent
package = root / 'internal/jscomp'
keep = {
    'inline_callee_facts_test.go',
    'inline_argument_facts_test.go',
    'parallel_fsiv_test.go',
    'coding_convention_safety_test.go',
    'fsiv_scope_sharing_test.go',
}
for name in keep:
    if not (package / name).is_file():
        raise SystemExit('missing retained test: ' + name)

stub = out / 'excluded_test.go'
stub.write_text('package jscomp\n')

# Retain these three original helpers verbatim, without pulling in the large
# JUnit/assertion test-support dependency graph of the surrounding suite.
source = (package / 'function_argument_injector_test.go').read_text()
notice = source[:source.index('package jscomp')]
helpers = []
for name in ['FunctionArgumentInjectorTest_GetNameSupplier',
             'FunctionArgumentInjectorTest_FindCall',
             'FunctionArgumentInjectorTest_FindFunction']:
    match = re.search(r'^func ' + name + r'\([\s\S]*?^}\n', source, re.M)
    if match is None:
        raise SystemExit('missing helper ' + name)
    helpers.append(match.group())
helper_file = out / 'retained_helpers_test.go'
helper_file.write_text(notice + '''package jscomp

import (
 "github.com/paullepoulpe/jsgo/internal/jutil"
 "github.com/paullepoulpe/jsgo/internal/rhino"
)

''' + '\n'.join(helpers))

replacements = {}
for path in sorted(package.glob('*_test.go')):
    if path.name not in keep:
        replacements[str(path)] = str(stub)
replacements[str(package / 'function_argument_injector_test.go')] = str(helper_file)
(out / 'overlay.json').write_text(json.dumps({'Replace': replacements}, indent=2) + '\n')
manifest = {
    'root': str(root),
    'package_import_path': 'github.com/paullepoulpe/jsgo/internal/jscomp',
    'retained_original_tests': sorted(keep),
    'original_helpers_copied_verbatim': [h.split('(', 1)[0].removeprefix('func ') for h in helpers],
    'test_replacements': len(replacements),
    'production_replacements': 0,
    'retained_test_sha256': {name: hashlib.sha256((package/name).read_bytes()).hexdigest() for name in sorted(keep)},
}
(out / 'manifest.json').write_text(json.dumps(manifest, indent=2) + '\n')
print(json.dumps(manifest, indent=2))
