import hashlib,json,subprocess
from pathlib import Path
REPO=Path('/workspace/jsgo-round-compound-next')
OUT=Path('/workspace/jsgo-results/round2/next-profile-overlay')
EXPECTED='eecbcf44af08ed6743de5ce69eddce675a71ee93'
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=REPO,text=True).strip()==EXPECTED
assert not subprocess.check_output(['git','status','--porcelain'],cwd=REPO,text=True).strip(), 'source worktree must be clean'
OUT.mkdir(exist_ok=True)
# Reuse the existing main-only capture, generating into this isolated output.
main_generator=Path('/workspace/jsgo-results/round2/parser_profile_overlay.py')
generator=main_generator.read_text().replace("repo = Path('/workspace/jsgo-round-parser-native80')",f'repo = Path({str(REPO)!r})').replace("out = Path('/workspace/jsgo-results/round2/parser-profile-overlay')",f'out = Path({str(OUT)!r})')
assert str(REPO) in generator and str(OUT) in generator
exec(compile(generator,str(main_generator),'exec'),{})
replacements=json.loads((OUT/'overlay.json').read_text())['Replace']
counts={}
def edit(path,edit_fn):
 source=REPO/path
 before=source.read_text()
 after=edit_fn(before)
 target=OUT/source.name
 target.write_text(after)
 replacements[str(source)]=str(target)

def replace_exact(s,old,new,key,n=1):
 assert s.count(old)==n,(key,s.count(old),n)
 counts[key]=n
 return s.replace(old,new)

def phase(s):
 s=replace_exact(s,'import (','import (\n "context"\n "runtime/pprof"\n','phase_import')
 s=replace_exact(s,'\tn.factory.Create(p.compiler).Process(externs, root)','\tprofileDiagnosticPass(n.name, func() {\n\t\tn.factory.Create(p.compiler).Process(externs, root)\n\t})','named_factory_process')
 s+='''
// Diagnostic overlay only: label the actual compiler work without enabling
// CompilerOptions tracing or changing pass eligibility. Stock capture boundaries
// are disjoint: named passes, direct/custom passes, and prepass dependency scans.
// These profiles are diagnostic, never used as elapsed-time benchmark results.
func profileDiagnosticPass(name string, run func()) {
 pprof.Do(context.Background(), pprof.Labels("jsgo_pass", name), func(_ context.Context) { run() })
}
'''
 return s

def compiler(s):
 s=replace_exact(s,'\t\tpf.Create(c).Process(c.externsRoot, c.jsRoot)','\t\tprofileDiagnosticPass(pf.GetName(), func() {\n\t\t\tpf.Create(c).Process(c.externsRoot, c.jsRoot)\n\t\t})','compiler_factory_process',2)
 s=replace_exact(s,'func (c *Compiler) Process(p CompilerPass) {\n\tp.Process(c.externsRoot, c.jsRoot)\n}','func (c *Compiler) Process(p CompilerPass) {\n\tprofileDiagnosticPass("direct:"+reflect.TypeOf(p).String(), func() {\n\t\tp.Process(c.externsRoot, c.jsRoot)\n\t})\n}','compiler_direct_process')
 s=replace_exact(s,'\tfindDeps.Process(jutil.CheckNotNull(input.GetAstRoot(c)))','\tprofileDependencyRoot := jutil.CheckNotNull(input.GetAstRoot(c))\n\tprofileDiagnosticPass("FindModuleDependencies", func() {\n\t\tfindDeps.Process(profileDependencyRoot)\n\t})','find_dependencies_process')
 return s
edit('internal/jscomp/phase_optimizer.go',phase)
edit('internal/jscomp/compiler.go',compiler)
subprocess.check_call(['/workspace/toolchains/go1.27.2/bin/gofmt','-w',*replacements.values()])
(OUT/'overlay.json').write_text(json.dumps({'Replace':replacements},indent=2)+'\n')
hash_file=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
manifest={'source_commit':EXPECTED,'source_repo':str(REPO),'overlay':str(OUT/'overlay.json'),'overlay_sha256':hash_file(OUT/'overlay.json'),'generator':str(Path(__file__).resolve()),'generator_sha256':hash_file(__file__),'main_generator_sha256':hash_file(main_generator),'callsite_counts':{k:v for k,v in counts.items() if not k.endswith('_import')},'runtime_godebug_for_future_capture':'profstackdepth=512','cpu_max_stack_PCs':64,'compiler_tracer_options_changed':False,'profile_label':'jsgo_pass','files':[{'source':a,'source_sha256':hash_file(a),'replacement':b,'replacement_sha256':hash_file(b)} for a,b in replacements.items()],'limitations':['Labels do not remove the CPU64-PC limit; they preserve active pass attribution independently of retained root frames.','GODEBUG profstackdepth=512 increases heap stacks only. Go1.27.2 depth1024 capture failed with runtime bad profile stack count (1026 frames); failed attempt archived separately.','Default supplied profiling workloads have disjoint instrumentation boundaries. A custom pass that recursively starts another labeled boundary would require explicit parent context propagation; not a supported profile target.','pprof CPU labels inherit into goroutines started in the label scope; allocation profiles do not support pprof labels.','Use diagnostic captures for attribution/PGO training only; repeat byte gates. Profile instrumentation changes overhead, so do not report capture duration as production performance.']}
(OUT/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
print(json.dumps({'overlay':manifest['overlay'],'source_commit':EXPECTED,'callsite_counts':manifest['callsite_counts'],'files':len(manifest['files'])},indent=2))
