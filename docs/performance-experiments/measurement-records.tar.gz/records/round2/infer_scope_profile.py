import collections,json,re
from pathlib import Path
from pprof_data import load_profile
from label_hotspots import symbols
BASE=Path('/workspace/jsgo-results/round2')
out={}
for task in ['typed-app','checks-only']:
 result={}
 for kind,path,sample_type,div in [('cpu',BASE/'next-balanced-pgo'/f'{task}.merged.pprof',('cpu','nanoseconds'),1e9),('alloc',BASE/'next-profiles'/task/'profile.allocs.pprof',('alloc_space','bytes'),1048576)]:
  p=load_profile(path);loc=symbols(p);idx=p.sample_types.index(sample_type);buckets=collections.Counter();leafs=collections.Counter();outer=collections.Counter();inner=collections.Counter();flowcalls=collections.Counter()
  for s in p.samples:
   if kind=='cpu' and s.labels.get('jsgo_pass')!=['inferTypes']:continue
   n=s.values[idx];fs=[f for l in s.locations for f in loc[l]];st='\n'.join(fs)
   flow='LinkedFlowScope'in st;hamt='HamtPMap'in st
   oh=flow and any('HamtPMap[go.shape.*uint8,'in f for f in fs)
   ih=flow and any('HamtPMap[go.shape.string,'in f for f in fs)
   cats={'total':True,'flow':flow,'flow_hamt':flow and hamt,'outer_pointer_hamt':oh,'inner_string_hamt':ih,'flow_join':flow and 'FlowScopeJoinOp'in st,'flow_infer_slot':flow and '(*LinkedFlowScope).InferSlotType'in st,'overlay_infer':flow and '(*LinkedFlowScope_OverlayScope).Infer'in st,'flow_with_scope':flow and '(*LinkedFlowScope).WithSyntacticScope'in st}
   for k,v in cats.items():
    if v:buckets[k]+=n
   if flow:
    if fs:leafs[fs[0]]+=n
    own=next((f for f in fs if 'LinkedFlowScope'in f),'NONE');flowcalls[own]+=n
   if oh and fs:outer[fs[0]]+=n
   if ih and fs:inner[fs[0]]+=n
  def top(counter):return [(f.replace('github.com/paullepoulpe/jsgo/',''),round(n/div,4))for f,n in counter.most_common(25)]
  result[kind]={'path':str(path),'unit':'CPU seconds'in kind if False else ('CPU seconds'if kind=='cpu'else'sampled alloc MiB'),'buckets':{k:round(n/div,4)for k,n in buckets.items()},'flow_leaf_top':top(leafs),'outer_hamt_leaf_top':top(outer),'inner_hamt_leaf_top':top(inner),'nearest_flow_caller_top':top(flowcalls)}
 out[task]=result
p=BASE/'next-infer-scope-profile.json';p.write_text(json.dumps(out,indent=2)+'\n')
for task,info in out.items():
 print(task)
 for kind,row in info.items():print(kind,row['buckets'],'OUTER',row['outer_hamt_leaf_top'][:8],'INNER',row['inner_hamt_leaf_top'][:8],'CALLERS',row['nearest_flow_caller_top'][:8])
