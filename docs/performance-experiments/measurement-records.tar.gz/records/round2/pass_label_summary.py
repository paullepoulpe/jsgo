#!/usr/bin/env python3
"""Aggregate CPU samples by exact pprof label, including all unlabeled mass.

Uses the public protobuf schema, not retained function frames or text grep.
A sample is counted exactly once; ambiguous/multivalue pass labels fail.
"""
import argparse,hashlib,json
from pathlib import Path
from pprof_data import load_profile

TASKS=['typed-app','bundle','downlevel-whitespace','downlevel-simple','checks-only']

def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--profiles-root',required=True,type=Path)
    p.add_argument('--tasks',nargs='+',default=TASKS)
    p.add_argument('--profile-pattern',default='{task}/profile.cpu.pprof')
    p.add_argument('--label-key',default='jsgo_pass')
    p.add_argument('--out',required=True,type=Path)
    a=p.parse_args()
    if len(a.tasks)!=len(set(a.tasks)):
        p.error('duplicate tasks')
    result={'schema':1,'label_key':a.label_key,'method':'exclusive exact sample label; total includes unlabeled; no function-frame attribution','tasks':{}}
    for task in a.tasks:
        path=(a.profiles_root/a.profile_pattern.format(task=task)).resolve(strict=True)
        profile=load_profile(path)
        ci=profile.sample_types.index(('samples','count'))
        ti=profile.sample_types.index(('cpu','nanoseconds'))
        counts={}
        for sample in profile.samples:
            labels=sample.labels.get(a.label_key,[])
            if len(labels)>1:
                raise ValueError(f'ambiguous {a.label_key} labels: {labels}')
            key=labels[0] if labels else None
            bucket=counts.setdefault(key,[0,0,0])
            bucket[0]+=sample.values[ci]
            bucket[1]+=sample.values[ti]
            bucket[2]+=1
        total_count,total_ns=profile.totals()[ci],profile.totals()[ti]
        if not total_count or not total_ns:
            raise ValueError(f'empty CPU profile: {task}')
        def row(label,vals):
            return {'pass':label,'sample_count':vals[0],'cpu_ns':vals[1],'cpu_s':vals[1]/1e9,'sample_records':vals[2],'cpu_fraction':vals[1]/total_ns}
        passes=[row(k,v)for k,v in counts.items()if k is not None]
        passes.sort(key=lambda x:(-x['cpu_ns'],x['pass']))
        unlabeled=row(None,counts.get(None,[0,0,0]))
        labeled_ns=sum(x['cpu_ns']for x in passes)
        labeled_count=sum(x['sample_count']for x in passes)
        if labeled_ns+unlabeled['cpu_ns']!=total_ns or labeled_count+unlabeled['sample_count']!=total_count:
            raise ValueError('mass conservation failure')
        result['tasks'][task]={'path':str(path),'sha256':hashlib.sha256(path.read_bytes()).hexdigest(),
            'sample_types':profile.sample_types,'total_cpu_ns':total_ns,'total_cpu_s':total_ns/1e9,'total_sample_count':total_count,
            'labeled_cpu_ns':labeled_ns,'labeled_cpu_fraction':labeled_ns/total_ns,'unlabeled':unlabeled,'passes':passes}
        print(f"{task}: total={total_ns/1e9:.3f}s labeled={labeled_ns/total_ns:.1%} unlabeled={unlabeled['cpu_s']:.3f}s")
        for item in passes[:10]:print(f"  {item['cpu_s']:.3f}s {item['cpu_fraction']:.1%} {item['pass']}")
    ep=a.profiles_root/'environment.json'
    if ep.exists():
        result['capture_environment']=json.loads(ep.read_text())
        result['environment_sha256']=hashlib.sha256(ep.read_bytes()).hexdigest()
    a.out.write_text(json.dumps(result,indent=2)+'\n')

if __name__=='__main__':main()
