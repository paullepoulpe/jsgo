package jscomp

import (
	"bytes"
	"fmt"
	"runtime"
	"slices"
	"testing"
	"weak"

	"github.com/paullepoulpe/jsgo/internal/jutil"
	"github.com/paullepoulpe/jsgo/internal/rhino"
)

func scopeRecipeRecordFixture(t *testing.T, c *Compiler) (*scopeRecipeCLI, *SyntacticScopeCreator) {
	t.Helper()
	l := &scopeRecipeCLI{compiler: c}
	l.window = &scopeRecipeWindow{lease: l, entries: make(map[*rhino.Node]*scopeDeclarationRecipe)}
	c.scopeRecipeCLI = l
	creator := NewSyntacticScopeCreator(c)
	creator.stockRecipes = true // Unit oracle bypasses only the CLI entry fence.
	return l, creator
}

func TestScopeRecipesFreshBindingsAndOriginalScanDifferential(t *testing.T) {
	fixtures := [][]string{
		{`var g;function f(a){var a;var x;var x;if(a){var hoisted;let lexical;}return x;}`},
		{`function f({x:y},[z],a=outside,...rest){const {p,q:r}=outside;let [s,...tail]=rest;return ()=>y+z+a+r+s;}`},
		{`var f=function bleeding(a){var bleeding;try{throw a;}catch(e){var e;let local=e;use(local);}return bleeding;};`},
		{`function f(a){var arguments;const arrow=()=>{var arguments=a;return arguments;};return arrow();}`},
		{`function f(a){for(let i=0;i<a;i++){let x=i;use(x);}for(var k in a){var y=k;}switch(a){case 1:let z=2;use(z);}return y;}`},
		{`function f(a){class C {field=()=>a;static {let x=1;use(x);}method(b){let x=b;return x;}}use(C);return a;}`},
		{`goog.provide('legacy.namespace');var legacy={};function f(a){var x=a;return x;}`, `var global2;`},
		{`export function f(a){let x=a;return x;}`, `import {f} from './script0.js';use(f(outside));`},
		{`goog.module('example.module');var exports;function f(a){var x=a;return x;}exports.f=f;`},
		{`goog.loadModule(function(exports){goog.module('bundled.module');function f(a){var x=a;return x;}exports.f=f;return exports;});`},
	}
	for index, programs := range fixtures {
		t.Run(fmt.Sprint(index), func(t *testing.T) {
			c := stockScopeInsertionCompiler(t, programs...)
			l, creator := scopeRecipeRecordFixture(t, c)
			defer l.release()
			original := stockScopeInsertionSnapshot(t, c, NewSyntacticScopeCreator(c))
			recorded := stockScopeInsertionSnapshot(t, c, creator)
			l.window.replay = true
			replayed := stockScopeInsertionSnapshot(t, c, creator)
			if !slices.Equal(original.rows, recorded.rows) || !slices.Equal(original.rows, replayed.rows) {
				t.Fatalf("recipe binding/order lookup differs\noriginal:%v\nrecorded:%v\nreplayed:%v", original.rows, recorded.rows, replayed.rows)
			}
			if l.stats.HitScopes == 0 || l.stats.SavedScanNodes == 0 || l.stats.RecordedScopes == 0 || l.stats.PeakRecipeBytesEstimate == 0 {
				t.Fatalf("fixture did not replay a real recipe: %+v", l.stats)
			}
			for root, scope := range replayed.scopes {
				if scope == recorded.scopes[root] {
					t.Fatal("recipe reused a Scope")
				}
				for v := range scope.GetVarIterable() {
					if v == recorded.scopes[root].GetOwnSlot(v.GetName()) {
						t.Fatal("recipe reused a Var")
					}
				}
			}
			for root := range l.window.entries {
				if root.IsRoot() || root.IsScript() || NodeUtil_IsModuleScopeRoot(root) || root.IsFunction() || root.IsClass() {
					t.Fatal("unsupported scope was cached")
				}
			}
			t.Logf("real recipe counters: %+v", l.stats)
		})
	}
}

func TestScopeRecipesMutationsContextCloneAndCurrentInput(t *testing.T) {
	for _, mode := range []string{"owner-edit", "add-declaration", "nested-name-live", "nested-body-only", "context", "clone", "move-owner", "current-input"} {
		t.Run(mode, func(t *testing.T) {
			c := stockScopeInsertionCompiler(t, `function f(a){var x=a;function nested(b){var y=b;return y;}if(a){let z=x;use(z);}return use(x,nested);}`, `var other;`)
			l, creator := scopeRecipeRecordFixture(t, c)
			defer l.release()
			stockScopeInsertionSnapshot(t, c, creator)
			fn := c.GetJsRoot().GetFirstChild().GetFirstChild()
			body := fn.GetLastChild()
			var replacement *CompilerInput
			switch mode {
			case "owner-edit":
				body.GetFirstChild().GetFirstChild().SetString("renamed")
				c.ReportChangeToEnclosingScope(body)
			case "add-declaration":
				body.AddChildToFront(rhino.IR_Var(rhino.IR_Name("added")))
				c.ReportChangeToEnclosingScope(body)
			case "nested-name-live":
				nested := body.GetFirstChild().GetNext()
				nested.GetFirstChild().SetString("newNested")
				// Live declaration-name operations defend this boundary even if
				// only the nested FUNCTION stamp changes, without parent propagation.
				c.ReportChangeToChangeScope(nested)
			case "nested-body-only":
				nested := body.GetFirstChild().GetNext()
				nested.GetLastChild().GetFirstChild().GetFirstChild().SetString("changedLocal")
				c.ReportChangeToChangeScope(nested)
			case "context":
				body.SetIsSyntheticBlock(true)
			case "clone":
				body.ReplaceWith(body.CloneTree())
			case "move-owner":
				previousParent := fn.GetParent()
				c.GetJsRoot().GetLastChild().AddChildToBack(fn.Detach())
				c.ReportChangeToChangeScope(previousParent)
				c.ReportChangeToChangeScope(fn.GetParent())
			case "current-input":
				id := NodeUtil_GetInputId(body)
				replacement = NewCompilerInputWithInputIdAndIsExtern(c.GetInput(id).GetSourceFile(), id, false)
				c.putCompilerInput(replacement)
			}
			want := stockScopeInsertionSnapshot(t, c, NewSyntacticScopeCreator(c))
			l.window.replay = true
			got := stockScopeInsertionSnapshot(t, c, creator)
			if !slices.Equal(got.rows, want.rows) {
				t.Fatalf("mutated recipe differs: %s\n%v\n%v", mode, want.rows, got.rows)
			}
			switch mode {
			case "owner-edit", "add-declaration":
				if l.stats.OwnerInvalidations == 0 {
					t.Fatal("edited owner did not invalidate")
				}
			case "context", "move-owner":
				if l.stats.ContextInvalidations == 0 {
					t.Fatal("changed root context did not invalidate")
				}
			case "clone":
				if l.stats.MissScopes == 0 {
					t.Fatal("clone root reused original identity")
				}
			case "nested-name-live", "nested-body-only", "current-input":
				if l.stats.HitScopes == 0 {
					t.Fatal("live replay fixture only fell back")
				}
			}
			if mode == "nested-body-only" {
				if l.stats.OwnerInvalidations == 0 || l.window.entries[body].context.stamp != fn.GetChangeTime() {
					t.Fatal("nested-only edit must invalidate nested owner without invalidating outer owner")
				}
				before := l.stats.HitScopes
				creator.CreateScopeOfScope(body, got.scopes[fn])
				if l.stats.HitScopes != before+1 {
					t.Fatal("unchanged enclosing body did not replay across nested-only edit")
				}
			}
			if replacement != nil {
				for v := range got.scopes[body].GetVarIterable() {
					if v.GetInput() != replacement {
						t.Fatal("recipe retained old resolved input")
					}
				}
			}
		})
	}
}

func scopeRecipeFreshRunner(t *testing.T) (*CommandLineRunner, *scopeRecipeCLI) {
	t.Helper()
	r := NewCommandLineRunnerWithOutAndErr([]string{"--compilation_level=SIMPLE", "--env=CUSTOM", "--num_parallel_threads=1"}, jutil.NewPrintStream(&bytes.Buffer{}), jutil.NewPrintStream(&bytes.Buffer{}))
	r.compiler = r.CreateCompiler()
	options := r.CreateOptions()
	r.SetRunOptions(options)
	r.compiler.InitOptions(options)
	lease := r.ownCLIScopeRecipes()
	if lease == nil {
		t.Fatal("fresh stock CLI did not acquire recipe lease")
	}
	return r, lease
}

func TestScopeRecipesActualSimpleLifecycleAndSequence(t *testing.T) {
	t.Setenv("JSGO_EXPERIMENT_SCOPE_RECIPES", "1")
	r, lease := scopeRecipeFreshRunner(t)
	defer lease.release()
	c := r.compiler
	options := c.GetOptions()
	config := NewDefaultPassConfig(options)
	for _, list := range []*PassListBuilder{config.getEarlyOptimizationLoopPasses(), config.getMainOptimizationLoop()} {
		passes := list.Build()
		seenIV, seenRUC := false, false
		for _, factory := range passes {
			// Inspect the actual factory identities, matching production's fence.
			// The compiler is intentionally still fresh/RAW for the real Compile
			// below: constructing unrelated passes here would violate their
			// original normalized-stage preconditions (notably peepholes).
			if factory == config.inlineVariables || factory == config.inlineConstants || factory == config.earlyInlineVariables {
				// The IV constructor itself has no lifecycle precondition.
				iv, ok := factory.Create(c).(*InlineVariables)
				if !ok || !iv.builtinPass {
					t.Fatal("actual SIMPLE IV is not private builtin")
				}
				seenIV = true
				continue
			}
			if seenIV && !seenRUC {
				switch factory {
				case config.deadAssignmentsElimination, config.collapseObjectLiterals:
				case config.removeUnusedCode, config.removeUnusedCodeOnce:
					seenRUC = true
				default:
					t.Fatalf("unwhitelisted real SIMPLE factory between IV/RUC: %s", factory.GetName())
				}
			}
		}
		if !seenIV || !seenRUC {
			t.Fatal("actual SIMPLE list lacks reachable IV/RUC pair")
		}
	}
	compile := func(owner *Compiler) *Result {
		return owner.Compile([]*SourceFile{SourceFile_FromCode("externs.js", `var use;var outside;`)}, []*SourceFile{SourceFile_FromCode("input.js", `var counter=0;function f(a){var x=outside;for(var i=0;i<a;i++){x=use(x);counter+=x;}return x;}use(f(outside));`)}, owner.GetOptions())
	}
	baselineRunner, baselineLease := scopeRecipeFreshRunner(t)
	baselineLease.release() // Original compiler path, with identical fresh CLI options.
	baseline := baselineRunner.compiler
	if !compile(baseline).Success {
		t.Fatal("original SIMPLE lifecycle fixture failed")
	}
	result := compile(c)
	if !result.Success || lease.stats.Windows == 0 || lease.stats.ConsumedWindows == 0 || lease.stats.RecordedScopes == 0 || lease.stats.HitScopes == 0 || lease.stats.SavedScanNodes == 0 {
		t.Fatalf("real fresh CLI compiler lifecycle did not replay recipes: result=%t stats=%+v errors=%v", result.Success, lease.stats, c.GetErrors())
	}
	if !slices.Equal(functionFSIVSnapshot(baseline), functionFSIVSnapshot(c)) || baseline.GetRoot().ToStringTree() != c.GetRoot().ToStringTree() || fmt.Sprint(baseline.GetErrors()) != fmt.Sprint(c.GetErrors()) {
		t.Fatal("complete SIMPLE output/AST/change epochs/diagnostics differ from original")
	}
	if lease.window != nil || lease.activePass != nil {
		t.Fatal("optimizer retained recipe/pass after completion")
	}
	lease.release()
	if c.scopeRecipeCLI != nil || !lease.closed || lease.compiler != nil {
		t.Fatal("CLI lease survived release")
	}
	t.Logf("actual SIMPLE compile dispatch: %+v", lease.stats)
}

func TestScopeRecipesPublicCustomAndLifecycleFences(t *testing.T) {
	t.Setenv("JSGO_EXPERIMENT_SCOPE_RECIPES", "1")
	c := stockScopeInsertionCompiler(t, `function f(a){var x=a;return x;}`)
	creator := NewSyntacticScopeCreator(c)
	pass := newBuiltinInlineVariables(c, InlineVariables_Mode_ALL)
	creator.enableStockScopeRecipes(pass, c.GetExternsRoot(), c.GetJsRoot())
	if creator.stockRecipes {
		t.Fatal("public initialized compiler acquired recipe path")
	}
	for _, mode := range []string{"stock", "custom-handler", "custom-compiler", "wrong-pass", "wrong-root", "closed"} {
		t.Run(mode, func(t *testing.T) {
			l, creator := scopeRecipeRecordFixture(t, c)
			defer l.release()
			l.activePass = pass
			root := c.GetJsRoot()
			switch mode {
			case "custom-handler":
				creator.redeclarationHandler = &stockScopeInsertionRedeclarations{}
			case "custom-compiler":
				creator.compiler = &stockScopeInsertionInputObserver{AbstractCompiler: c}
			case "wrong-pass":
				l.activePass = nil
			case "wrong-root":
				root = root.CloneTree()
			case "closed":
				l.closed = true
			}
			creator.enableStockScopeRecipes(pass, c.GetExternsRoot(), root)
			if creator.stockRecipes != (mode == "stock") {
				t.Fatal("creator recipe fence failed")
			}
			// Keep release's actual lifecycle cleanup test separate from the
			// intentionally forged closed flag used to exercise this guard.
			l.closed = false
		})
	}
}

func TestScopeRecipesControllerConsumptionSkipsAndExceptions(t *testing.T) {
	for _, mode := range []string{"consume", "intermediates", "skip", "other-pass", "lifecycle", "exception"} {
		t.Run(mode, func(t *testing.T) {
			c := newFunctionFSIVTestCompiler(t, 1, `function f(a){var x=outside;for(var i=0;i<a;i++){x=use(x);}return x;}use(f(outside));`)
			c.GetOptions().SetInlineLocalVariables(true)
			c.GetOptions().SetRemoveUnusedVariables(CompilerOptions_Reach_LOCAL_ONLY)
			c.SetExternProperties(jutil.NewLinkedHashSet[string]())
			l := &scopeRecipeCLI{compiler: c}
			c.scopeRecipeCLI = l
			defer l.release()
			p := NewPhaseOptimizer(c, nil)
			c.phaseOptimizer = p
			config := c.GetPassConfig().(*DefaultPassConfig)
			ivFactory := config.inlineVariables
			p.processScopeRecipePass(ivFactory.Create(c), ivFactory, c.GetExternsRoot(), c.GetJsRoot())
			if l.window == nil || len(l.window.entries) == 0 || l.stats.RecordedScanNodes == 0 {
				t.Fatal("controller fixture failed to populate recipes")
			}
			if mode == "intermediates" {
				for _, factory := range []*PassFactory{config.deadAssignmentsElimination, config.collapseObjectLiterals} {
					p.processScopeRecipePass(factory.Create(c), factory, c.GetExternsRoot(), c.GetJsRoot())
					if l.window == nil {
						t.Fatal("actual whitelisted SIMPLE phase closed recipe window")
					}
				}
			}
			switch mode {
			case "skip":
				p.closeScopeRecipeWindow("skipped_pass")
			case "other-pass":
				called := 0
				p.processScopeRecipePass(CompilerPassFunc(func(*rhino.Node, *rhino.Node) { called++ }), nil, c.GetExternsRoot(), c.GetJsRoot())
				if called != 1 {
					t.Fatal("unknown pass callback schedule changed")
				}
			case "lifecycle":
				c.SetLifeCycleStage(AbstractCompiler_LifeCycleStage_RAW)
				p.processScopeRecipePass(CompilerPassFunc(func(*rhino.Node, *rhino.Node) {}), nil, c.GetExternsRoot(), c.GetJsRoot())
				c.SetLifeCycleStage(AbstractCompiler_LifeCycleStage_NORMALIZED)
			case "exception":
				c.GetJsRoot().GetFirstChild().AddChildToBack(rhino.NewNodeWithChild(rhino.Token_VAR, rhino.NewNode(rhino.Token_NAME)))
			}
			factory := config.removeUnusedCode
			pass := factory.Create(c).(*RemoveUnusedCode)
			failed := false
			jutil.Try(func() { p.processScopeRecipePass(pass, factory, c.GetExternsRoot(), c.GetJsRoot()) }, func(e jutil.Throwable) { failed = true })
			if failed != (mode == "exception") {
				t.Fatal("unexpected controller failure schedule")
			}
			if l.window != nil || l.activePass != nil || pass.scopeCreator.stockRecipes {
				t.Fatal("controller retained window/pass/creator after consumer exit")
			}
			if mode == "consume" || mode == "intermediates" {
				if l.stats.HitScopes == 0 || l.stats.ConsumedWindows != 1 {
					t.Fatalf("eligible consumer only fell back: %+v", l.stats)
				}
			} else if l.stats.HitScopes != 0 {
				t.Fatal("closed/failed window replayed declarations")
			}
			if mode == "exception" && l.stats.ExceptionClosures != 1 {
				t.Fatal("populated recipe window survived exception")
			}
			if mode == "skip" && l.stats.SkippedClosures != 1 {
				t.Fatal("skipped phase failed to retire recipes")
			}
		})
	}
}

func TestScopeRecipesLeaseEligibilityBeforeFreshInit(t *testing.T) {
	t.Setenv("JSGO_EXPERIMENT_SCOPE_RECIPES", "1")
	for _, mode := range []string{"stock", "flag-off", "custom-runner", "test-mode", "initialized", "observer", "custom-pass", "typed", "restore", "save"} {
		t.Run(mode, func(t *testing.T) {
			r := sourceLockRunner(t)
			switch mode {
			case "flag-off":
				t.Setenv("JSGO_EXPERIMENT_SCOPE_RECIPES", "")
			case "custom-runner":
				r.self = &sourceLockCustomRunner{AbstractCommandLineRunner: r}
			case "test-mode":
				r.testMode = true
			case "initialized":
				r.compiler.Init(nil, []*SourceFile{SourceFile_FromCode("x.js", "var x;")}, r.compiler.GetOptions())
			case "observer":
				r.compiler.changeTracker.AddChangeHandler(&functionFSIVCustomObserver{})
			case "custom-pass":
				r.compiler.GetOptions().AddCustomPass(CustomPassExecutionTime_BEFORE_OPTIMIZATION_LOOP, CompilerPassFunc(func(*rhino.Node, *rhino.Node) {}))
			case "typed":
				r.config.typedAstListInputFilename = jutil.StringPtr("typed")
			case "restore":
				r.config.continueSavedCompilationFileName = jutil.StringPtr("saved")
			case "save":
				r.config.saveCompilationStateToFilename = jutil.StringPtr("saved")
			}
			lease := r.ownCLIScopeRecipes()
			if (lease != nil) != (mode == "stock") {
				t.Fatal("fresh CLI lease eligibility changed")
			}
			if lease != nil {
				lease.release()
			}
			if r.compiler.scopeRecipeCLI != nil {
				t.Fatal("lease leaked outside owned CLI lifecycle")
			}
		})
	}
}

//go:noinline
func scopeRecipeScopeLifetimeFixture(t *testing.T) (*Compiler, *scopeRecipeCLI, weak.Pointer[Scope]) {
	t.Helper()
	c := stockScopeInsertionCompiler(t, `function f(a){var x=a;return x;}`)
	l, creator := scopeRecipeRecordFixture(t, c)
	fn := c.GetJsRoot().GetFirstChild().GetFirstChild()
	global := creator.CreateScopeOfScope(c.GetRoot(), nil)
	parameters := creator.CreateScopeOfScope(fn, global)
	body := creator.CreateScopeOfScope(fn.GetLastChild(), parameters)
	return c, l, weak.Make(body)
}

func TestScopeRecipesDoNotRetainResolvedScopeGraphs(t *testing.T) {
	c, l, discarded := scopeRecipeScopeLifetimeFixture(t)
	defer l.release()
	collected := false
	for range 10 {
		runtime.GC()
		if discarded.Value() == nil {
			collected = true
			break
		}
	}
	if !collected || len(l.window.entries) == 0 {
		t.Fatal("live recipe retained original Scope/Var graph or recorded nothing")
	}
	runtime.KeepAlive(c)
	runtime.KeepAlive(l)
}
