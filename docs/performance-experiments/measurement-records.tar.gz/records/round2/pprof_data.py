"""Small standard-library reader for the public profile.proto wire schema.

Only sample types, values and string labels are interpreted. All other fields
are preserved verbatim when replacing sample values; no symbolization occurs.
"""
import gzip
from dataclasses import dataclass
from pathlib import Path


def varint(data, pos=0):
    value = shift = 0
    while pos < len(data) and shift < 70:
        byte = data[pos]
        pos += 1
        value |= (byte & 127) << shift
        if byte < 128:
            if value >= 1 << 64:
                raise ValueError('varint exceeds uint64')
            return value, pos
        shift += 7
    raise ValueError('truncated/oversized varint')


def encode_varint(value):
    value &= (1 << 64) - 1
    result = bytearray()
    while value >= 128:
        result.append((value & 127) | 128)
        value >>= 7
    result.append(value)
    return bytes(result)


def fields(data):
    pos = 0
    while pos < len(data):
        key, pos = varint(data, pos)
        number, wire = key >> 3, key & 7
        if not number:
            raise ValueError('protobuf field zero')
        if wire == 0:
            value, pos = varint(data, pos)
        elif wire == 2:
            size, pos = varint(data, pos)
            end = pos + size
            if end > len(data):
                raise ValueError('truncated bytes field')
            value, pos = data[pos:end], end
        elif wire in (1, 5):
            end = pos + (8 if wire == 1 else 4)
            if end > len(data):
                raise ValueError('truncated fixed field')
            value, pos = data[pos:end], end
        else:
            raise ValueError(f'unsupported protobuf wire type {wire}')
        yield number, wire, value


def encode_fields(items):
    result = bytearray()
    for number, wire, value in items:
        result += encode_varint(number << 3 | wire)
        if wire == 0:
            result += encode_varint(value)
        elif wire == 2:
            result += encode_varint(len(value)) + value
        else:
            result += value
    return bytes(result)


def integers(items, number, signed=False):
    result = []
    for num, wire, value in items:
        if num != number:
            continue
        if wire == 0:
            result.append(value)
        elif wire == 2:
            pos = 0
            while pos < len(value):
                v, pos = varint(value, pos)
                result.append(v)
        else:
            raise ValueError('integer has invalid wire type')
    return [v - (1 << 64) if signed and v >= 1 << 63 else v for v in result]


def scalar(items, number, default=0):
    values = [v for n, w, v in items if n == number and w == 0]
    return values[-1] if values else default


@dataclass
class Sample:
    raw_fields: list
    values: list
    locations: tuple
    labels: dict


@dataclass
class Profile:
    raw_fields: list
    sample_types: list
    samples: list

    def totals(self):
        return [sum(s.values[i] for s in self.samples) for i in range(len(self.sample_types))]

    def encode_with_values(self, values):
        if len(values) != len(self.samples):
            raise ValueError('sample count changed')
        replacements = iter(values)
        output = []
        for number, wire, value in self.raw_fields:
            if number == 2:
                row = next(replacements)
                if len(row) != len(self.sample_types):
                    raise ValueError('sample value count changed')
                sample_fields = [(n, w, v) for n, w, v in fields(value) if n != 2]
                sample_fields.append((2, 2, b''.join(encode_varint(v) for v in row)))
                value = encode_fields(sample_fields)
            output.append((number, wire, value))
        return gzip.compress(encode_fields(output), mtime=0)


def parse_bytes(data):
    if data.startswith(b'\x1f\x8b'):
        data = gzip.decompress(data)
    top = list(fields(data))
    table = [v.decode('utf-8') for n, w, v in top if n == 6 and w == 2]
    if not table or table[0] != '':
        raise ValueError('invalid profile string table')
    def string(index):
        if not 0 <= index < len(table):
            raise ValueError('invalid string-table index')
        return table[index]
    types = []
    samples = []
    for n, w, value in top:
        if n == 1:
            f = list(fields(value))
            types.append((string(scalar(f, 1)), string(scalar(f, 2))))
        elif n == 2:
            f = list(fields(value))
            labels = {}
            for ln, lw, label in f:
                if ln != 3:
                    continue
                lf = list(fields(label))
                # Numeric labels have no str field; keep them uninterpreted.
                if any(k == 2 and wire == 0 for k, wire, _ in lf):
                    labels.setdefault(string(scalar(lf, 1)), []).append(string(scalar(lf, 2)))
            samples.append(Sample(f, integers(f, 2, True), tuple(integers(f, 1)), labels))
    if not types or any(len(s.values) != len(types) for s in samples):
        raise ValueError('missing/mismatched sample types')
    return Profile(top, types, samples)


def load_profile(path):
    return parse_bytes(Path(path).read_bytes())
