import unittest
from pprof_data import encode_fields,encode_varint,parse_bytes,fields
from balanced_pgo import equal_mass_values


def fixture(counts=(1,1,1),first=('samples','count')):
    strings=['',first[0],first[1],'cpu','nanoseconds','jsgo_pass','inferTypes']
    top=[]
    for a,b in [(1,2),(3,4)]:top.append((1,2,encode_fields([(1,0,a),(2,0,b)])))
    label=encode_fields([(1,0,5),(2,0,6)])
    for count in counts:
        top.append((2,2,encode_fields([(1,2,encode_varint(7)),(2,2,encode_varint(count)+encode_varint(count*10000000)),(3,2,label)])))
    top.extend((6,2,x.encode())for x in strings)
    top.append((31,2,b'unknown preserved'))
    return parse_bytes(encode_fields(top))


class PgoToolsTest(unittest.TestCase):
    def test_exact_mass_and_all_sample_identity_preserved(self):
        p=fixture()
        rows=equal_mass_values(p,1000000)
        self.assertEqual([row[0]for row in rows],[333334,333333,333333])
        q=parse_bytes(p.encode_with_values(rows))
        self.assertEqual(q.totals(),[1000000,10000000000000])
        self.assertEqual([s.locations for s in p.samples],[s.locations for s in q.samples])
        self.assertEqual([s.labels for s in p.samples],[s.labels for s in q.samples])
        self.assertEqual([f for f in p.raw_fields if f[0]!=2],[f for f in q.raw_fields if f[0]!=2])
    def test_nonuniform_counts_preserve_proportional_weight(self):
        rows=equal_mass_values(fixture((1,3,6)),1000000)
        self.assertEqual([r[0]for r in rows],[100000,300000,600000])
    def test_refuses_silent_downscale_or_wrong_sample_type(self):
        with self.assertRaises(ValueError):equal_mass_values(fixture((10,10)),19)
        with self.assertRaises(ValueError):equal_mass_values(fixture(first=('cpu','nanoseconds')),1000000)
    def test_refuses_empty_zero_negative_samples_and_truncated_protobuf(self):
        for counts in [(),(0,),(1,-1)]:
            with self.assertRaises(ValueError):equal_mass_values(fixture(counts),1000000)
        with self.assertRaises(ValueError):list(fields(b'\x32\x05bad'))

if __name__=='__main__':unittest.main()
