import argparse, json, os, re, subprocess
from pathlib import Path

BASE = Path('/workspace/jsgo-results/round2')
GO = '/workspace/toolchains/go1.27.2/bin/go'
ENV = dict(os.environ, GOCACHE='/workspace/.cache/go-build')
TASKS = ['typed-app', 'bundle', 'downlevel-whitespace', 'downlevel-simple', 'checks-only']
parser = argparse.ArgumentParser()
parser.add_argument('--candidate', default='parser-profiles')
parser.add_argument('--output', default='parser-profile-analysis-flags-off.json')
parser.add_argument('--controls', default='profiles,parser-profiles')
args = parser.parse_args()

def raw_samples(path, sample_type='cpu/nanoseconds'):
    raw = subprocess.check_output([GO, 'tool', 'pprof', '-raw', str(path)], text=True,
                                  env=ENV, stderr=subprocess.DEVNULL)
    sample_text, location_text = raw.split('Samples:\n', 1)[1].split('\nLocations\n', 1)
    columns = [v.removesuffix('[dflt]') for v in sample_text.splitlines()[0].split()]
    value_index = columns.index(sample_type)
    locations, current = {}, None
    for line in location_text.split('\nMappings', 1)[0].splitlines():
        match = re.match(r'\s*(\d+): ', line)
        if match:
            current = int(match.group(1))
            locations[current] = line
        elif current is not None:
            locations[current] += '\n' + line
    samples = []
    for match in re.finditer(r'^\s*([\d \t]+):\s*([\d ]+)$', sample_text, re.M):
        values = [int(v) for v in match.group(1).split()]
        samples.append((values[value_index], '\n'.join(locations[int(i)] for i in match.group(2).split())))
    return samples

def categories(path, sample_type='cpu/nanoseconds'):
    result = dict.fromkeys(['total', 'front', 'native_attempt', 'native_nonfragment',
                            'original_fragment', 'original_whole', 'original_whole_under_native',
                            'front_without_entry_context',
                            'old_parser', 'ir_factory', 'scanner', 'jsdoc', 'gc', 'scope_scan',
                            'remove_unused', 'references', 'fsiv', 'type_inference'], 0)
    for ns, stack in raw_samples(path, sample_type):
        native = ('internal/parsing.nativeParserAttempt' in stack or
                  '(*nativeParser).' in stack)
        fragment = '(*nativeParser).originalFragment' in stack
        whole = 'internal/parsing.parserRunnerParseUncached' in stack
        front = 'internal/parsing.' in stack or 'internal/parser.' in stack
        flags = {
            'total': True,
            'front': front,
            'native_attempt': native,
            'native_nonfragment': native and not fragment,
            'original_fragment': fragment,
            'original_whole': whole,
            'original_whole_under_native': whole and 'parserRunnerParseWithNativeFallback' in stack,
            'front_without_entry_context': front and not native and not whole,
            'old_parser': 'internal/parser.(*Parser)' in stack,
            'ir_factory': 'internal/parsing.(*IRFactory' in stack,
            'scanner': 'internal/parser.(*Scanner)' in stack,
            'jsdoc': 'internal/parsing.(*JsDoc' in stack,
            'gc': any(s in stack for s in ('runtime.gcBgMarkWorker', 'runtime.gcAssistAlloc', 'runtime.gcStart')),
            'scope_scan': '(*SyntacticScopeCreator_ScopeScanner)' in stack,
            'remove_unused': '(*RemoveUnusedCode)' in stack,
            'references': '(*ReferenceCollector)' in stack or '(*ReferenceCollector_CollectorCallback)' in stack,
            'fsiv': '(*FlowSensitiveInlineVariables)' in stack,
            'type_inference': '(*TypeInference)' in stack or '(*TypeInferencePass)' in stack,
        }
        for key, present in flags.items():
            if present:
                result[key] += ns
    divisor = 1e9 if sample_type == 'cpu/nanoseconds' else 1
    return {key: value/divisor for key, value in result.items()}

def top(path, allocation=False):
    args = [GO, 'tool', 'pprof', '-top', '-nodecount=35', '-nodefraction=0']
    if allocation:
        args += ['-alloc_space']
    return subprocess.check_output(args+[str(path)], text=True, env=ENV, stderr=subprocess.DEVNULL)

output = {}
for group in dict.fromkeys(args.controls.split(',')+[args.candidate]):
    output[group] = {}
    for task in TASKS:
        directory = BASE/group/task
        stats = json.loads((directory/'profile.memstats.json').read_text())
        before, after = stats['before'], stats['after']
        output[group][task] = {
            'cpu_s': categories(directory/'profile.cpu.pprof'),
            'sampled_alloc_bytes': categories(directory/'profile.allocs.pprof', 'alloc_space/bytes'),
            'mem': {key: after[key]-before[key] for key in
                    ['TotalAlloc', 'Mallocs', 'NumGC', 'PauseTotalNs']},
            'end_heap_alloc': after['HeapAlloc'], 'exit': stats['exit'],
            'cpu_top': top(directory/'profile.cpu.pprof'),
            'alloc_top': top(directory/'profile.allocs.pprof', True),
        }
        print(group, task, json.dumps({'cpu_s': output[group][task]['cpu_s'],
                                      'mem': output[group][task]['mem']}), flush=True)
(BASE/args.output).write_text(json.dumps(output, indent=2)+'\n')
