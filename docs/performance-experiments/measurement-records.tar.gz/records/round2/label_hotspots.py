#!/usr/bin/env python3
"""Exact label-filtered flat/cumulative CPU attribution from existing profiles."""
import argparse,collections,hashlib,json
from pathlib import Path
from pprof_data import load_profile,fields,scalar

SELECT={'typed-app':['inferTypes','checkTypes'],'checks-only':['inferTypes','checkTypes','checkAccessControls'],
'bundle':['inlineFunctions','inlineVariables','flowSensitiveInlineVariables','removeUnusedCode'],
'downlevel-whitespace':[None,'rewriteCommonJsModules','normalize'],'downlevel-simple':['flowSensitiveInlineVariables','removeUnusedCode']}

def symbols(profile):
 table=[v.decode('utf8')for n,w,v in profile.raw_fields if n==6]
 names={}
 for n,w,v in profile.raw_fields:
  if n==5:
   fs=list(fields(v));names[scalar(fs,1)]=table[scalar(fs,2)]
 locs={}
 for n,w,v in profile.raw_fields:
  if n==4:
   fs=list(fields(v));locs[scalar(fs,1)]=[names[scalar(list(fields(x)),1)]for ln,lw,x in fs if ln==4]
 return locs

def main():
 p=argparse.ArgumentParser(description=__doc__);p.add_argument('--root',required=True,type=Path);p.add_argument('--pattern',default='{task}.merged.pprof');p.add_argument('--out',required=True,type=Path);a=p.parse_args();out={'method':'exact single jsgo_pass label; cumulative ancestry remains CPU64-truncated; flat is actual innermost symbol','tasks':{}}
 for task,labels in SELECT.items():
  path=a.root/a.pattern.format(task=task);prof=load_profile(path);locs=symbols(prof);idx=prof.sample_types.index(('cpu','nanoseconds'));total=prof.totals()[idx];result={}
  for label in labels:
   flat=collections.Counter();cum=collections.Counter();mass=records=0
   for sample in prof.samples:
    values=sample.labels.get('jsgo_pass',[])
    if values!=([label]if label is not None else []):continue
    n=sample.values[idx];mass+=n;records+=1
    fs=[f for location in sample.locations for f in locs[location]]
    if fs:flat[fs[0]]+=n
    for f in set(fs):cum[f]+=n
   def rows(counter):return [{'function':f.replace('github.com/paullepoulpe/jsgo/',''),'cpu_s':n/1e9,'fraction_of_label':n/mass if mass else 0,'fraction_of_task':n/total}for f,n in counter.most_common(100)]
   result['UNLABELED'if label is None else label]={'cpu_s':mass/1e9,'fraction_of_task':mass/total,'sample_records':records,'flat':rows(flat),'cumulative':rows(cum)}
   print(task,label,'CPU',mass/1e9,round(mass/total*100,2),'%')
   for r in rows(flat)[:12]:print(f" {r['cpu_s']:.3f} {r['fraction_of_label']:.1%} {r['function']}")
  out['tasks'][task]={'profile':str(path),'sha256':hashlib.sha256(path.read_bytes()).hexdigest(),'total_cpu_s':total/1e9,'labels':result}
 a.out.write_text(json.dumps(out,indent=2)+'\n')

if __name__=='__main__':main()
