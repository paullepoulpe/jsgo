#!/usr/bin/env python3
"""Audit existing frontend heap512 and CPU64 profiles without new captures."""
import collections
import json
from pathlib import Path
from pprof_data import load_profile
from label_hotspots import symbols

BASE = Path('/workspace/jsgo-results/round2')

def analyze(task, profile_kind):
    root = BASE / 'structural-profiles' / task
    path = root / ('profile.live.pprof' if profile_kind == 'heap' else 'profile.cpu.pprof')
    p = load_profile(path)
    locations = symbols(p)
    kinds = [('alloc_objects', 'count'), ('alloc_space', 'bytes')] if profile_kind == 'heap' else [('cpu', 'nanoseconds')]
    indices = [p.sample_types.index(kind) for kind in kinds]
    totals = [0] * len(indices)
    buckets = collections.defaultdict(lambda: [0] * len(indices))
    sites = collections.defaultdict(lambda: [0] * len(indices))
    contexts = collections.defaultdict(lambda: [0] * len(indices))
    for sample in p.samples:
        fs = [f.removeprefix('github.com/paullepoulpe/jsgo/') for loc in sample.locations for f in locations.get(loc, [])]
        stack = '\n'.join(fs)
        values = [sample.values[i] for i in indices]
        leaf = fs[0] if fs else '(no symbol)'
        front = 'internal/parser.' in stack or 'internal/parsing.' in stack
        native = 'nativeParserAttempt' in stack
        fragment = '(*nativeParser).originalFragmentAt' in stack
        legacy = 'parserRunnerParseUncached' in stack
        context = 'native-fragment' if fragment else 'whole-original' if legacy else 'native-direct' if native else 'other-or-truncated'
        cats = {
            'frontend_inclusive': front,
            'scanner': 'internal/parser.(*Scanner).' in stack,
            'positions_ranges': 'SourcePosition' in stack or 'SourceRange' in stack,
            'line_scanner': 'internal/parser.(*LineNumberScanner).' in stack,
            'sourcefile_utf16': 'internal/parser.NewSourceFile' in stack and 'StringToUTF16' in stack,
            'string_to_utf16': 'internal/jutil.StringToUTF16' in stack,
            'string_from_utf16': 'internal/jutil.StringFromUTF16' in stack,
            'scanner_string_from_utf16': 'internal/jutil.StringFromUTF16' in stack and 'internal/parser.(*Scanner).' in stack,
            'parse_tree': 'ParseTree' in stack or 'TreeBase' in stack,
            'native_attempt': native,
            'native_fragment': fragment,
            'whole_original': legacy,
        }
        keys = [(buckets, cat) for cat, present in cats.items() if present]
        if front:
            keys.append((sites, leaf))
            keys.append((contexts, context))
        for cat, present in cats.items():
            if present:
                keys.append((contexts, cat + '/' + context))
        for bucket, key in keys:
            for i, value in enumerate(values): bucket[key][i] += value
        for i, value in enumerate(values): totals[i] += value
    def rows(bucket):
        return [{'key': key, 'values': values,
                 'fractions': [value / total if total else 0 for value, total in zip(values, totals)]}
                for key, values in sorted(bucket.items(), key=lambda row: row[1][-1], reverse=True)]
    return {'path': str(path), 'sample_types': kinds, 'totals': totals,
            'buckets_inclusive': rows(buckets), 'frontend_leaf_exclusive': rows(sites)[:50],
            'contexts': rows(contexts)}

out = {'method': 'Existing post-GC heap allocation columns (heap512) and CPU64. '
       'Inclusive categories overlap. Allocation leafs/contexts exclusive within frontend. '
       'CPU ancestry can lose outer roots; flat leafs remain actual sampled PCs.', 'tasks': {}}
for task in ['downlevel-whitespace', 'bundle', 'typed-app', 'checks-only']:
    out['tasks'][task] = {kind: analyze(task, kind) for kind in ['heap', 'cpu']}
path = BASE / 'frontend-allocation-audit.json'
path.write_text(json.dumps(out, indent=2) + '\n')
for task, result in out['tasks'].items():
    print('\nTASK', task)
    for kind, data in result.items():
        div = 1048576 if kind == 'heap' else 1e9
        print(kind, 'total', data['totals'])
        for row in data['buckets_inclusive']:
            print(row['key'], round(row['values'][-1] / div, 4), round(row['fractions'][-1] * 100, 2))
