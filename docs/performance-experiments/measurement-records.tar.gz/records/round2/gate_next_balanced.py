import json,subprocess
from pathlib import Path
r=Path('/workspace/jsgo-results/round2')
flags={'JSGO_EXPERIMENT_NATIVE_CFG': '1', 'JSGO_EXPERIMENT_NATIVE_LOCAL_FLOW': '1', 'JSGO_EXPERIMENT_NATIVE_REFERENCES': '1', 'JSGO_EXPERIMENT_INLINE_ARGUMENT_FACTS': '1', 'JSGO_EXPERIMENT_PARALLEL_FSIV': '1', 'JSGO_EXPERIMENT_NATIVE_PARSER': '1', 'JSGO_EXPERIMENT_NATIVE_PARSER_ALLOCATOR': '1', 'JSGO_EXPERIMENT_READONLY_CALLEE_FACTS': '1', 'JSGO_EXPERIMENT_FSIV_SCOPE_SHARING': '1', 'JSGO_EXPERIMENT_INVERTER_NOOP': '1', 'JSGO_EXPERIMENT_EMPTY_PASS_PROOFS': '1', 'JSGO_EXPERIMENT_REFERENCE_BATCHES': '1', 'JSGO_EXPERIMENT_PARALLEL_COALESCE': '1', 'GOGC': '60'}
for binary,label in [('jsgo-next-balanced-l4','gates-next-balanced-l4'),('jsgo-next-balanced-newinliner','gates-next-balanced-newinliner')]:
 cmd=['taskset','-c','0,1','python3',str(r/'gate_combined.py'),str(r/'bin'/binary),label,'1,2',json.dumps(flags)]
 (r/(label+'-command.json')).write_text(json.dumps(cmd,indent=2)+'\n')
 with (r/(label+'.log')).open('w') as f: subprocess.run(cmd,stdout=f,stderr=subprocess.STDOUT,check=True)
