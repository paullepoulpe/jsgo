// Port of com/google/javascript/jscomp/FunctionArgumentInjectorTest.java @ closure-compiler v20261015
// (test/com/google/javascript/jscomp/FunctionArgumentInjectorTest.java)

/*
 * Copyright 2009 The Closure Compiler Authors.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package jscomp

import (
 "fmt"
 "strings"
 "github.com/paullepoulpe/jsgo/internal/jutil"
 "github.com/paullepoulpe/jsgo/internal/rhino"
)

func FunctionArgumentInjectorTest_GetNameSupplier() func() string {
	i := 0
	return func() string {
		v := jutil.ToJavaString(i) // String.valueOf(i++)
		i++
		return v
	}
}

func FunctionArgumentInjectorTest_FindCall(n *rhino.Node, name string) *rhino.Node {
	if NodeUtil_IsNormalOrOptChainCall(n) {
		var callee *rhino.Node
		if NodeUtil_IsNormalOrOptChainGetProp(n.GetFirstChild()) {
			callee = n.GetFirstFirstChild()
			// Only "call" is supported at this point.
			jutil.CheckArgument(callee.GetParent().GetString() == "call")
		} else {
			callee = n.GetFirstChild()
		}

		if callee.IsName() && callee.GetString() == name {
			return n
		}
	}

	for c := n.GetFirstChild(); c != nil; c = c.GetNext() {
		result := FunctionArgumentInjectorTest_FindCall(c, name)
		if result != nil {
			return result
		}
	}

	return nil
}

func FunctionArgumentInjectorTest_FindFunction(n *rhino.Node, name string) *rhino.Node {
	if n.IsFunction() {
		if n.GetFirstChild().GetString() == name {
			return n
		}
	}

	for c := n.GetFirstChild(); c != nil; c = c.GetNext() {
		result := FunctionArgumentInjectorTest_FindFunction(c, name)
		if result != nil {
			return result
		}
	}

	return nil
}

type coreG3Collector struct {
	BasicErrorManagerBase
	reports []string
}

func newCoreG3Collector() *coreG3Collector {
	c := &coreG3Collector{}
	c.InitBasicErrorManagerBase(c)
	return c
}

func (c *coreG3Collector) Report(level *CheckLevel, error *JSError) {
	c.reports = append(c.reports, level.String()+" "+error.String())
	c.BasicErrorManagerBase.Report(level, error)
}

func (c *coreG3Collector) Println(level *CheckLevel, error *JSError) {}

func (c *coreG3Collector) PrintSummary() {}


func typedScopeDump_varLine(v *TypedVar) string {
	type_ := v.GetType()
	ann := "-"
	if type_ != nil && !v.IsTypeInferred() {
		jutil.Try(func() {
			ann = type_.ToAnnotationString(rhino.JSType_Nullability_EXPLICIT)
		}, func(e jutil.IRuntimeException) {
			ann = "!" + typedScopeDump_simpleClassName(e)
		})
	}
	node := "null"
	if v.GetNameNode() != nil {
		node = typedScopeDump_pos(v.GetNameNode())
	}
	return fmt.Sprintf("V %s | %s | %s | inferred=%t esc=%t once=%t input=%s node=%s",
		v.GetName(), typedScopeDump_typeString(type_), ann, v.IsTypeInferred(),
		v.IsMarkedEscaped(), v.IsMarkedAssignedExactlyOnce(), v.GetInputName(), node)
}

func typedScopeDump_simpleClassName(e jutil.Throwable) string {
	s := e.Error()
	if i := strings.Index(s, ": "); i >= 0 {
		s = s[:i]
	}
	return s[strings.LastIndexByte(s, '.')+1:]
}

func typedScopeDump_typeString(type_ rhino.JSType) (s string) {
	if type_ == nil {
		return "null"
	}
	jutil.Try(func() {
		s = type_.String()
	}, func(e jutil.IRuntimeException) {
		s = "!" + typedScopeDump_simpleClassName(e)
	})
	return s
}

func typedScopeDump_pos(n *rhino.Node) string {
	return fmt.Sprintf("%s@%d:%d", n.GetToken(), n.GetLineno(), n.GetCharno())
}
