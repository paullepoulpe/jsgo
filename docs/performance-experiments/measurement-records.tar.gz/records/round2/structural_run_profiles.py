import json, os, subprocess, sys
from pathlib import Path
sys.path.insert(0, '/workspace/jsgo-cli-next/tools/bench')
import bench

root = Path('/workspace/jsgo-results/round2/structural-profiles')
env = {k:v for k,v in os.environ.items() if k not in bench.GO_ENV_DROP and not k.startswith('JSGO_EXPERIMENT_')}
flags = json.loads(Path('/workspace/jsgo-results/round2/structural-runtime-flags.json').read_text())
flags['GODEBUG']='profstackdepth=512'
env.update(flags)
root.mkdir(parents=True, exist_ok=False)
(root/'environment.json').write_text(json.dumps({'flags':flags,'runtime_gc':'default GC; diagnostic heap depth 512; jsgo_pass labels and SourceFile counters','affinity':sorted(os.sched_getaffinity(0)),'source_commit':'5b720eade60c0b3af3a6cebea49beb579ec55685','binary':'/workspace/jsgo-results/round2/bin/jsgo-structural-prof','sha256':bench.sha256_file('/workspace/jsgo-results/round2/bin/jsgo-structural-prof')},indent=2))
env['LC_ALL']='C.UTF-8'
for task in bench.load_tasks(['typed-app','bundle','downlevel-whitespace','downlevel-simple','checks-only']):
    name=task['name']
    ws=root/name
    bench.make_workspace(str(ws), '/workspace/jsgo/.cache')
    args=bench.task_jobs(task,str(ws))[0]+["--num_parallel_threads=1"]
    with (ws/'stdout').open('wb') as stdout, (ws/'stderr').open('wb') as stderr:
        result=subprocess.run(['/workspace/jsgo-results/round2/bin/jsgo-structural-prof']+args,cwd=ws,
          env=dict(env,JSGO_PROFILE_PREFIX=str(ws/'profile'),JSGO_SOURCE_LOCK_DIAGNOSTIC_JSON=str(ws/'source-lock.json')),stdout=stdout,stderr=stderr,timeout=300)
    (ws/'exit').write_text(str(result.returncode)+'\n')
    ref=Path('/workspace/jsgo-results/round2/baseline')/name/'java-cold/run-1'
    arts=bench.artifacts(task,str(ws),0,True)
    assert result.returncode==int((ref/'exit').read_text()),name+' exit differs'
    assert all(bench.same_file(str(ref/k),path) for k,path in arts.items()),name+' artifacts differ'
    print(name+': profile captured; byte gate passed',flush=True)
