import json
from pathlib import Path

repo = Path('/workspace/jsgo-round-parser-native80')
out = Path('/workspace/jsgo-results/round2/parser-profile-overlay')
out.mkdir(exist_ok=True)
main = repo / 'cmd/jsgo/main.go'
src = main.read_text()
src = src.replace('"os"', '"os"\n "runtime"\n "runtime/pprof"\n "encoding/json"')
src = src.replace('jscomp.CommandLineRunner_Main(os.Args[1:])', '''
 prefix := os.Getenv("JSGO_PROFILE_PREFIX")
 f, err := os.Create(prefix + ".cpu.pprof")
 if err != nil { panic(err) }
 if err := pprof.StartCPUProfile(f); err != nil { panic(err) }
 var before, after runtime.MemStats
 runtime.ReadMemStats(&before)
 runner := jscomp.NewCommandLineRunner(os.Args[1:])
 code := 0
 runner.SetExitCodeReceiver(func(c int) { code = c })
 if runner.ShouldRunCompiler() { runner.Run() }
 if runner.HasErrors() { code = -1 }
 runtime.ReadMemStats(&after)
 pprof.StopCPUProfile()
 f.Close()
 af, err := os.Create(prefix + ".allocs.pprof")
 if err != nil { panic(err) }
 pprof.Lookup("allocs").WriteTo(af, 0)
 af.Close()
 mf, err := os.Create(prefix + ".memstats.json")
 if err != nil { panic(err) }
 json.NewEncoder(mf).Encode(map[string]any{"before":before,"after":after,"exit":code})
 mf.Close()
 // This GC is outside the compilation interval; live heap is a separate diagnostic.
 runtime.GC()
 hf, err := os.Create(prefix + ".live.pprof")
 if err != nil { panic(err) }
 pprof.Lookup("heap").WriteTo(hf, 0)
 hf.Close()
 os.Exit(code)
''')
target = out / 'main.go'
target.write_text(src)
(out / 'overlay.json').write_text(json.dumps({'Replace': {str(main): str(target)}}))
