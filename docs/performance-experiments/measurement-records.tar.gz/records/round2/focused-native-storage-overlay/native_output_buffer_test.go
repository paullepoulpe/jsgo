package jscomp

import (
	"bytes"
	"fmt"
	"os"
	"path/filepath"
	"slices"
	"strings"
	"testing"

	"github.com/paullepoulpe/jsgo/internal/jutil"
)

func TestNativeOutputBufferUTF16DifferentialAndSnapshots(t *testing.T) {
	for _, ascii := range []bool{false, true} {
		t.Run(fmt.Sprint(ascii), func(t *testing.T) {
			buffer, oracle := newOutputCodeBuffer(0, ascii), jutil.NewStringBuilder()
			var snapshots, saved []string
			check := func() {
				t.Helper()
				if buffer.Length() != oracle.Length() || buffer.String() != oracle.String() {
					t.Fatalf("UTF16 content differs: %q/%d want %q/%d", buffer.String(), buffer.Length(), oracle.String(), oracle.Length())
				}
				for i := range oracle.Length() {
					if buffer.CharAt(i) != oracle.CharAt(i) {
						t.Fatalf("UTF16 position %d changed", i)
					}
				}
				if !slices.Equal(snapshots, saved) {
					t.Fatal("later buffer mutation changed an immutable String snapshot")
				}
				snapshots = append(snapshots, buffer.String())
				saved = append(saved, strings.Clone(oracle.String()))
			}
			appendText := func(s string) { buffer.Append(s); oracle.Append(s); check() }
			appendChar := func(c uint16) { buffer.AppendChar(c); oracle.AppendChar(c); check() }
			insert := func(i int, c uint16) { buffer.InsertChar(i, c); oracle.InsertChar(i, c); check() }
			resize := func(n int) { buffer.SetLength(n); oracle.SetLength(n); check() }
			failure := func(run func()) (text string) {
				jutil.Try(run, func(e jutil.Throwable) { text = e.Error() })
				return text
			}
			checkBounds := func() {
				t.Helper()
				for _, index := range []int{-1, buffer.Length(), buffer.Length() + 1} {
					if got, want := failure(func() { buffer.CharAt(index) }), failure(func() { oracle.CharAt(index) }); got == "" || got != want {
						t.Fatalf("CharAt exception changed: %q vs %q", got, want)
					}
				}
				for _, index := range []int{-1, buffer.Length() + 1} {
					if got, want := failure(func() { buffer.InsertChar(index, '\n') }), failure(func() { oracle.InsertChar(index, '\n') }); got == "" || got != want {
						t.Fatalf("InsertChar exception changed: %q vs %q", got, want)
					}
				}
				if got, want := failure(func() { buffer.SetLength(-1) }), failure(func() { oracle.SetLength(-1) }); got == "" || got != want {
					t.Fatalf("SetLength exception changed: %q vs %q", got, want)
				}
			}

			check()
			appendText(strings.Repeat("abc", 900))
			insert(0, '[')
			insert(buffer.Length(), ']')
			insert(15, '\n')
			appendChar(0)
			resize(buffer.Length() + 3)
			resize(8)
			if ascii && buffer.wide != nil {
				t.Fatal("ordinary ASCII output did not use byte storage")
			}
			checkBounds() // exercise manual ASCII checks before promotion
			appendChar(0xD83D)
			appendText(jutil.StringFromChar(0xDE00))
			if !strings.HasSuffix(buffer.String(), "😀") {
				t.Fatal("separately appended surrogate halves did not combine")
			}
			insert(buffer.Length()-1, '\n') // split a surrogate pair by UTF-16 index
			appendText("é𐐷\xed\xa0\x80\xff")
			insert(0, 0xDC00)
			resize(0)
			appendText("ASCII again")
			if buffer.wide == nil {
				t.Fatal("promotion was not permanent across reset")
			}
			checkBounds()
		})
	}
}

func newNativeOutputCompiler(t *testing.T, pretty bool, source string) (*Compiler, *cliSourceFileOwnership) {
	t.Helper()
	r := sourceLockRunner(t)
	c, options := r.compiler, r.compiler.GetOptions()
	options.SetLanguageIn(CompilerOptions_LanguageMode_ECMASCRIPT_NEXT)
	options.SetLanguageOut(CompilerOptions_LanguageMode_ECMASCRIPT_NEXT)
	options.SetOutputCharset(jutil.StandardCharsets_UTF_8)
	options.SetPrettyPrint(pretty)
	options.SetLineLengthThreshold(28)
	path := "out.js.map"
	options.SetSourceMapOutputPath(&path)
	files := []*SourceFile{SourceFile_FromCode("first.js", source), SourceFile_FromCode("second.js", `function second(value){return value+2;} second(3);`)}
	owned := r.ownCLISourceFiles(nil, files)
	if owned == nil {
		t.Fatal("stock CLI fixture did not acquire ownership")
	}
	c.Init(nil, files, options)
	c.ParseInputs()
	if c.GetErrorCount() != 0 {
		owned.release()
		t.Fatalf("output fixture did not parse: %v", c.GetErrors())
	}
	return c, owned
}

func TestNativeOutputBufferActualPrinterMappingsAndJoin(t *testing.T) {
	t.Setenv("JSGO_EXPERIMENT_CLI_SOURCE_LOCK", "1")
	for _, pretty := range []bool{false, true} {
		for _, unicode := range []bool{false, true} {
			t.Run(fmt.Sprintf("pretty=%v/unicode=%v", pretty, unicode), func(t *testing.T) {
				source := `function first(value){return value ? "abcdefghijklmnop" : "qrstuvwxyz";} first(3);`
				if unicode {
					source = `function first(value){return value ? "é😀" : "\ud800";} first(3);`
				}
				var results [2][]string
				for i, flag := range []string{"", "1"} {
					t.Setenv("JSGO_EXPERIMENT_ASCII_OUTPUT_BUFFER", flag)
					c, owned := newNativeOutputCompiler(t, pretty, source)
					defer owned.release()
					tracker := newCompiler_SingleBinaryLicenseTracker(c)
					probe := &nativeOutputBufferProbe{}
					for script := c.GetJsRoot().GetFirstChild(); script != nil; script = script.GetNext() {
						builder := c.newOutputCodePrinterBuilder(script, false, tracker)
						builder.nativeOutputProbe = probe
						printed := builder.BuildWithSourceMappings()
						results[i] = append(results[i], printed.source)
						for _, mapping := range printed.mappings {
							results[i] = append(results[i], mapping.String())
						}
					}
					if (probe.printers == 2 && probe.asciiPrinters > 0 && probe.units > 0) != (i == 1) {
						t.Fatalf("no real private buffer generation: %+v flag=%q", probe, flag)
					}
					if i == 1 && unicode && probe.promotedPrinters == 0 {
						t.Fatal("UTF8 output did not exercise UTF16 promotion")
					}
					join := c.newOutputCodeBuilder(tracker)
					if (join.sb.wide == nil) != (i == 1) {
						t.Fatal("compiler join buffer did not select the guarded representation")
					}
					join.Append("first\n").Append("second")
					old := join.String()
					join.Reset()
					join.Append("third😀\nlast")
					results[i] = append(results[i], old, join.String(), fmt.Sprint(join.GetLineIndex()), fmt.Sprint(join.GetColumnIndex()), fmt.Sprint(join.EndsWith("last")))
					results[i] = append(results[i], c.ToSource())
					var sourceMap strings.Builder
					name := "out.js"
					c.GetSourceMap().AppendTo(&sourceMap, &name)
					results[i] = append(results[i], sourceMap.String())
					owned.release()
					if nativeOutputBufferCompilerSafe(c) {
						t.Fatal("native representation escaped the CLI ownership lifetime")
					}
				}
				if !slices.Equal(results[0], results[1]) {
					t.Fatalf("printer/maps/join/reset/suffix output changed\ngot %v\nwant %v", results[1], results[0])
				}
			})
		}
	}
}

type nativeOutputCustomFactory struct {
	delegate CodePrinter_Builder_CodeGeneratorFactory
	wide     bool
	called   bool
}

func (f *nativeOutputCustomFactory) GetCodeGenerator(format CodePrinter_Format, consumer CodeConsumer) CodeGenerator {
	f.called = true
	f.wide = consumer.(CodePrinter_MappedCodePrinter).GetCodePrinter_MappedCodePrinterBase().code.wide != nil
	return f.delegate.GetCodeGenerator(format, consumer)
}

func TestNativeOutputBufferPublicCustomAndProxyFallback(t *testing.T) {
	t.Setenv("JSGO_EXPERIMENT_CLI_SOURCE_LOCK", "1")
	t.Setenv("JSGO_EXPERIMENT_ASCII_OUTPUT_BUFFER", "1")
	if NewCompiler_CodeBuilder().sb.wide == nil || NewCodePrinter_CompactCodePrinter(false, 20, false, SourceMap_DetailLevel_ALL, nil).code.wide == nil || NewCodePrinter_PrettyCodePrinter(20, false, SourceMap_DetailLevel_ALL, nil).code.wide == nil {
		t.Fatal("public constructor changed representation")
	}
	c, owned := newNativeOutputCompiler(t, false, `var value=1;`)
	defer owned.release()
	tracker := newCompiler_SingleBinaryLicenseTracker(c)
	proxy := *tracker
	if nativeOutputBufferLicenseSafe(&proxy, c) {
		t.Fatal("copied license tracker redirected self callbacks")
	}
	if c.newOutputCodeBuilder(&proxy).sb.wide == nil || c.newOutputCodePrinterBuilder(c.GetJsRoot().GetFirstChild(), false, &proxy).nativeOutputBuffer {
		t.Fatal("copied license tracker bypassed original buffer")
	}
	builder := c.newOutputCodePrinterBuilder(c.GetJsRoot().GetFirstChild(), false, tracker)
	factory := &nativeOutputCustomFactory{delegate: builder.codeGeneratorFactory}
	builder.SetCodeGeneratorFactory(factory)
	probe := &nativeOutputBufferProbe{}
	builder.nativeOutputProbe = probe
	if builder.Build() == "" || !factory.called || !factory.wide || probe.printers != 0 {
		t.Fatal("custom code generator did not use original wide path")
	}
	public := NewCodePrinter_Builder(c.GetJsRoot()).SetCompilerOptions(c.GetOptions())
	public.nativeOutputProbe = probe
	if public.Build() == "" || probe.printers != 0 {
		t.Fatal("public builder activated private output path")
	}
	c.changeTracker.AddChangeHandler(&sourceLockCustomObserver{})
	if nativeOutputBufferCompilerSafe(c) || c.newOutputCodeBuilder(tracker).sb.wide == nil {
		t.Fatal("custom observer bypassed fallback")
	}
}

func TestNativeOutputBufferActualCLILifecycle(t *testing.T) {
	t.Setenv("JSGO_EXPERIMENT_CLI_SOURCE_LOCK", "1")
	path := filepath.Join(t.TempDir(), "input.js")
	source := `/** @license output fixture */ function publish(seed) { function sum(a){return a+1+2;} window['result']=[sum(seed),"é😀"]; } publish(3);`
	if err := os.WriteFile(path, []byte(source), 0600); err != nil {
		t.Fatal(err)
	}
	for _, level := range []string{"WHITESPACE", "ADVANCED"} {
		t.Run(level, func(t *testing.T) {
			var outputs [2][]string
			for i, flag := range []string{"", "1"} {
				t.Setenv("JSGO_EXPERIMENT_ASCII_OUTPUT_BUFFER", flag)
				var out, errors bytes.Buffer
				r := NewCommandLineRunnerWithOutAndErr([]string{"--compilation_level=" + level, "--num_parallel_threads=2", "--charset=UTF-8", "--language_in=ECMASCRIPT_NEXT", "--js=" + path}, jutil.NewPrintStream(&out), jutil.NewPrintStream(&errors))
				status := r.DoRun()
				if status != 0 {
					t.Fatalf("original/optimized CLI failed: %d %s", status, errors.String())
				}
				outputs[i] = []string{out.String(), errors.String(), fmt.Sprint(status)}
				if nativeOutputBufferCompilerSafe(r.GetCompiler()) {
					t.Fatal("DoRun left private output ownership active")
				}
			}
			if !slices.Equal(outputs[0], outputs[1]) {
				t.Fatalf("real CLI output/diagnostics/exit changed\ngot %v\nwant %v", outputs[1], outputs[0])
			}
		})
	}
}
