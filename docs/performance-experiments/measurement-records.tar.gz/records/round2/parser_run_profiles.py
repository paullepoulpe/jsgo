import json, os, subprocess, sys
from pathlib import Path
sys.path.insert(0, '/workspace/jsgo-cli-next/tools/bench')
import bench

root = Path('/workspace/jsgo-results/round2/parser-profiles')
env = {k:v for k,v in os.environ.items() if k not in bench.GO_ENV_DROP}
env['LC_ALL']='C.UTF-8'
for task in bench.load_tasks(['typed-app','bundle','downlevel-whitespace','downlevel-simple','checks-only']):
    name=task['name']
    ws=root/name
    bench.make_workspace(str(ws), '/workspace/jsgo/.cache')
    args=bench.task_jobs(task,str(ws))[0]
    with (ws/'stdout').open('wb') as stdout, (ws/'stderr').open('wb') as stderr:
        result=subprocess.run(['/workspace/jsgo-results/round2/bin/jsgo-parser80-prof']+args,cwd=ws,
          env=dict(env,JSGO_PROFILE_PREFIX=str(ws/'profile')),stdout=stdout,stderr=stderr,timeout=300)
    (ws/'exit').write_text(str(result.returncode)+'\n')
    ref=Path('/workspace/jsgo-results/round2/baseline')/name/'java-cold/run-1'
    arts=bench.artifacts(task,str(ws),0,True)
    assert result.returncode==int((ref/'exit').read_text()),name+' exit differs'
    assert all(bench.same_file(str(ref/k),path) for k,path in arts.items()),name+' artifacts differ'
    print(name+': profile captured; byte gate passed',flush=True)
