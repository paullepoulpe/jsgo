import json, os, subprocess, sys
from pathlib import Path
sys.path.insert(0, '/workspace/jsgo-cli-next/tools/bench')
import bench

root = Path('/workspace/jsgo-results/round2/next-extra-profiles')
env = {k:v for k,v in os.environ.items() if k not in bench.GO_ENV_DROP and not k.startswith('JSGO_EXPERIMENT_')}
flags = {'JSGO_EXPERIMENT_NATIVE_CFG': '1', 'JSGO_EXPERIMENT_NATIVE_LOCAL_FLOW': '1', 'JSGO_EXPERIMENT_NATIVE_REFERENCES': '1', 'JSGO_EXPERIMENT_INLINE_ARGUMENT_FACTS': '1', 'JSGO_EXPERIMENT_PARALLEL_FSIV': '1', 'JSGO_EXPERIMENT_NATIVE_PARSER': '1', 'JSGO_EXPERIMENT_NATIVE_PARSER_ALLOCATOR': '1', 'JSGO_EXPERIMENT_READONLY_CALLEE_FACTS': '1', 'JSGO_EXPERIMENT_FSIV_SCOPE_SHARING': '1', 'JSGO_EXPERIMENT_INVERTER_NOOP': '1', 'JSGO_EXPERIMENT_EMPTY_PASS_PROOFS': '1', 'JSGO_EXPERIMENT_REFERENCE_BATCHES': '1', 'JSGO_EXPERIMENT_PARALLEL_COALESCE': '1', 'GOGC': '200', 'GODEBUG': 'profstackdepth=512'}
env.update(flags)
root.mkdir(parents=True, exist_ok=False)
(root/'environment.json').write_text(json.dumps({'flags':flags,'runtime_gc':'GOGC=200; diagnostic heap depth 512; jsgo_pass labels','affinity':sorted(os.sched_getaffinity(0)),'source_commit':'eecbcf44af08ed6743de5ce69eddce675a71ee93','binary':'/workspace/jsgo-results/round2/bin/jsgo-next-prof','sha256':bench.sha256_file('/workspace/jsgo-results/round2/bin/jsgo-next-prof')},indent=2))
env['LC_ALL']='C.UTF-8'
for task in bench.load_tasks(['typed-app','downlevel-whitespace','downlevel-simple']):
    for repetition in range({"typed-app":1,"downlevel-whitespace":7,"downlevel-simple":2}[task["name"]]):
        name=task['name']
        ws=root/name/f'run-{repetition+1}'
        bench.make_workspace(str(ws), '/workspace/jsgo/.cache')
        args=bench.task_jobs(task,str(ws))[0]+["--num_parallel_threads=1"]
        with (ws/'stdout').open('wb') as stdout, (ws/'stderr').open('wb') as stderr:
            result=subprocess.run(['/workspace/jsgo-results/round2/bin/jsgo-next-prof']+args,cwd=ws,
              env=dict(env,JSGO_PROFILE_PREFIX=str(ws/'profile')),stdout=stdout,stderr=stderr,timeout=300)
        (ws/'exit').write_text(str(result.returncode)+'\n')
        ref=Path('/workspace/jsgo-results/round2/baseline')/name/'java-cold/run-1'
        arts=bench.artifacts(task,str(ws),0,True)
        assert result.returncode==int((ref/'exit').read_text()),name+' exit differs'
        assert all(bench.same_file(str(ref/k),path) for k,path in arts.items()),name+' artifacts differ'
        print(name+f' repeat {repetition+1}: profile captured; byte gate passed',flush=True)
