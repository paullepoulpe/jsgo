#!/usr/bin/env python3
"""Create source-only counters overlay; no build, no source-tree mutation."""
import argparse
import hashlib
import json
import subprocess
from pathlib import Path

p = argparse.ArgumentParser()
p.add_argument('--repo', type=Path, default=Path('/workspace/jsgo-structural-next'))
p.add_argument('--merge-overlay', type=Path, help='Compose disjoint profile/main overlays; reject same-file collisions')
args = p.parse_args()
repo = args.repo.resolve()
out = Path(__file__).resolve().parent
assert not subprocess.check_output(['git', 'status', '--porcelain'], cwd=repo, text=True).strip(), 'clean frozen source required'
commit = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=repo, text=True).strip()
replacements = {} if args.merge_overlay is None else json.loads(args.merge_overlay.read_text())['Replace'].copy()
assert all(Path(k).is_relative_to(repo) for k in replacements), 'merged overlay must target this exact frozen worktree'
counts = {}

def replace(s, old, new, label):
    assert s.count(old) == 1, (label, s.count(old))
    counts[label] = 1
    return s.replace(old, new)

def edit(name, fn):
    source = repo / 'internal/jscomp' / name
    assert str(source) not in replacements, ('overlay collision', source)
    target = out / name
    target.write_text(fn(source.read_text()))
    replacements[str(source)] = str(target)

def runner(s):
    return replace(s, 'func (r *AbstractCommandLineRunnerBase) DoRun() int {',
        'func (r *AbstractCommandLineRunnerBase) DoRun() int {\n\tdefer sourceLockDiagWrite()', 'runner_flush_after_owner_release')

def owner(s):
    s = replace(s, 'func (r *AbstractCommandLineRunnerBase) ownCLISourceFiles(externs, sources []*SourceFile) *cliSourceFileOwnership {',
        'func (r *AbstractCommandLineRunnerBase) ownCLISourceFiles(externs, sources []*SourceFile) *cliSourceFileOwnership {\n\tsourceLockDiagBeforeOwnership(r, externs, sources)', 'ownership_attempt')
    s = replace(s, 'if file == nil || seen[file] {\n\t\t\t\treturn nil',
        'if file == nil || seen[file] {\n\t\t\t\tsourceLockDiagOwnershipResult("nil_or_aliased_file", file, 0)\n\t\t\t\treturn nil', 'ownership_alias_rejection')
    s = replace(s, '\t\t\tdefault:\n\t\t\t\treturn nil',
        '\t\t\tdefault:\n\t\t\t\tsourceLockDiagOwnershipResult("unsupported_loader", file, 0)\n\t\t\t\treturn nil', 'ownership_loader_rejection')
    s = replace(s, '\treturn &cliSourceFileOwnership{files: handles}',
        '\tsourceLockDiagOwnershipResult("", nil, len(handles))\n\treturn &cliSourceFileOwnership{files: handles}', 'ownership_success')
    s = replace(s, '\tif file.code == nil {\n\t\tfile.setCodeAndDoBookkeeping',
        '\tif file.code == nil {\n\t\tsourceLockDiagCount(&sourceLockDiag.ownedLoadAttempts)\n\t\tfile.setCodeAndDoBookkeeping', 'owned_cold_attempt')
    s = replace(s, '\t\tfile.setCodeAndDoBookkeeping(jutil.StringPtr(l.SourceFile_CodeLoader.LoadUncachedCode()))',
        '\t\tfile.setCodeAndDoBookkeeping(jutil.StringPtr(l.SourceFile_CodeLoader.LoadUncachedCode()))\n\t\tsourceLockDiagCount(&sourceLockDiag.ownedLoadSuccesses)\n\t\tsourceLockDiagBytes(&sourceLockDiag.ownedLoadedBytes, file.code)', 'owned_cold_success')
    return s

def source(s):
    s = replace(s, 'func (f *SourceFile) GetCode() string {',
        'func (f *SourceFile) GetCode() string {\n\tsourceLockDiagCount(&sourceLockDiag.getCode)', 'get_code')
    s = replace(s, 'if loader, ok := f.loader.(*cliOwnedSourceLoader); ok {\n\t\tif code := loader.cached.Load(); code != nil {\n\t\t\treturn *code',
        'if loader, ok := f.loader.(*cliOwnedSourceLoader); ok {\n\t\tsourceLockDiagCount(&sourceLockDiag.ownedGetCode)\n\t\tif code := loader.cached.Load(); code != nil {\n\t\t\tsourceLockDiagCount(&sourceLockDiag.ownedCachedGetCode)\n\t\t\treturn *code', 'owned_get_code_hits')
    s = replace(s, '\t\t\t\tf.SetCodeAndDoBookkeeping(jutil.StringPtr(f.loader.LoadUncachedCode()))',
        '\t\t\t\tsourceLockDiagCount(&sourceLockDiag.monitorLoadAttempts)\n\t\t\t\tf.SetCodeAndDoBookkeeping(jutil.StringPtr(f.loader.LoadUncachedCode()))\n\t\t\t\tsourceLockDiagCount(&sourceLockDiag.monitorLoadSuccesses)\n\t\t\t\tsourceLockDiagBytes(&sourceLockDiag.monitorLoadedBytes, f.code)', 'monitor_cold_load')
    s = replace(s, 'func (f *SourceFile) GetCodeReader() jutil.JavaReader {',
        'func (f *SourceFile) GetCodeReader() jutil.JavaReader {\n\tsourceLockDiagCount(&sourceLockDiag.getReader)', 'reader_calls')
    s = replace(s, 'if loader, ok := f.loader.(*cliOwnedSourceLoader); ok {\n\t\tif code := loader.cached.Load(); code != nil {\n\t\t\treturn jutil.NewStringReader(*code)',
        'if loader, ok := f.loader.(*cliOwnedSourceLoader); ok {\n\t\tsourceLockDiagCount(&sourceLockDiag.ownedReader)\n\t\tif code := loader.cached.Load(); code != nil {\n\t\t\tsourceLockDiagCount(&sourceLockDiag.ownedCachedReader)\n\t\t\treturn jutil.NewStringReader(*code)', 'owned_reader_hits')
    s = replace(s, '\t\t\tif reader := loader.SourceFile_CodeLoader.OpenUncachedReader(); reader != nil {\n\t\t\t\treturn reader',
        '\t\t\tif reader := loader.SourceFile_CodeLoader.OpenUncachedReader(); reader != nil {\n\t\t\t\tsourceLockDiagCount(&sourceLockDiag.ownedStreamingReader)\n\t\t\t\treturn reader', 'owned_streaming_reader')
    s = replace(s, 'func (f *SourceFile) SetCodeAndDoBookkeeping(sourceCode *string) {',
        'func (f *SourceFile) SetCodeAndDoBookkeeping(sourceCode *string) {\n\tsourceLockDiagCount(&sourceLockDiag.setCode)\n\tif sourceCode == nil { sourceLockDiagCount(&sourceLockDiag.clearCode) }', 'setter_calls')
    s = replace(s, 'func (f *SourceFile) SetCodeAndDoBookkeeping(sourceCode *string) {\n\tsourceLockDiagCount(&sourceLockDiag.setCode)\n\tif sourceCode == nil { sourceLockDiagCount(&sourceLockDiag.clearCode) }\n\tif loader, ok := f.loader.(*cliOwnedSourceLoader); ok {',
        'func (f *SourceFile) SetCodeAndDoBookkeeping(sourceCode *string) {\n\tsourceLockDiagCount(&sourceLockDiag.setCode)\n\tif sourceCode == nil { sourceLockDiagCount(&sourceLockDiag.clearCode) }\n\tif loader, ok := f.loader.(*cliOwnedSourceLoader); ok {\n\t\tsourceLockDiagCount(&sourceLockDiag.ownedSetCode)', 'owned_setter_calls')
    return s

edit('abstract_command_line_runner.go', runner)
edit('source_file_cli_lock.go', owner)
edit('source_file.go', source)
new_file = str(repo / 'internal/jscomp/source_lock_diagnostic_overlay.go')
assert not Path(new_file).exists() and new_file not in replacements
replacements[new_file] = str(out / 'diagnostic.go')
subprocess.check_call(['/workspace/toolchains/go1.27.2/bin/gofmt', '-w', *[v for k,v in replacements.items() if Path(v).parent == out]])
(out/'overlay.json').write_text(json.dumps({'Replace': replacements}, indent=2)+'\n')
sha = lambda p: hashlib.sha256(Path(p).read_bytes()).hexdigest()
manifest = {'source_repo':str(repo), 'source_commit':commit, 'diagnostic_only':True,
    'json_environment':'JSGO_SOURCE_LOCK_DIAGNOSTIC_JSON', 'callsite_counts':counts,
    'overlay_sha256':sha(out/'overlay.json'), 'production_files_modified':False,
    'files':[{'source':k, 'source_sha256':sha(k) if Path(k).exists() else None,
        'replacement':v, 'replacement_sha256':sha(v)} for k,v in replacements.items()]}
(out/'manifest.json').write_text(json.dumps(manifest, indent=2)+'\n')
print(json.dumps({'overlay':str(out/'overlay.json'), 'commit':commit, 'hook_counts':counts},indent=2))
