package jscomp

import (
	"os"
	"sync"
	"sync/atomic"
	"weak"

	"github.com/paullepoulpe/jsgo/internal/jutil"
)

// Known loaders never call back into SourceFile while loading/reading. The
// private CLI owner can therefore use a nonrecursive lock rather than obtaining
// a runtime goroutine ID for every monitor entry and exit. No SourceFile field
// or global file registry is added; the original loader/monitor is restored at
// the CLI lifecycle boundary. Public constructors and custom loaders are intact.
type cliOwnedSourceLoader struct {
	SourceFile_CodeLoader
	mu     sync.Mutex
	cached atomic.Pointer[string]
}

func (l *cliOwnedSourceLoader) getCodeLocked(file *SourceFile) string {
	if file.code == nil {
		sourceLockDiagCount(&sourceLockDiag.ownedLoadAttempts)
		file.setCodeAndDoBookkeeping(jutil.StringPtr(l.SourceFile_CodeLoader.LoadUncachedCode()))
		sourceLockDiagCount(&sourceLockDiag.ownedLoadSuccesses)
		sourceLockDiagBytes(&sourceLockDiag.ownedLoadedBytes, file.code)
	}
	l.cached.Store(file.code)
	return *file.code
}

type cliSourceFileOwnership struct {
	// Dependency pruning rebuilds inputsById without discarded inputs. Restore
	// handles must not extend those files' raw-code or AST lifetimes until DoRun
	// returns. A surviving input itself retains its wrapper until restoration.
	files []weak.Pointer[SourceFile]
}

func (o *cliSourceFileOwnership) release() {
	for _, handle := range o.files {
		if file := handle.Value(); file != nil {
			loader := file.loader.(*cliOwnedSourceLoader)
			file.loader = loader.SourceFile_CodeLoader
		}
	}
	o.files = nil
}

// This executes after the exact stock runner creates fresh files, before
// Compiler.Init publishes them into compiler inputs or any parallel pool.
// DoRun joins all compiler jobs before returning/throwing, including buffered
// prebuild failures; its defer restores loaders on early output/error returns.
func (r *AbstractCommandLineRunnerBase) ownCLISourceFiles(externs, sources []*SourceFile) *cliSourceFileOwnership {
	sourceLockDiagBeforeOwnership(r, externs, sources)
	if os.Getenv("JSGO_EXPERIMENT_CLI_SOURCE_LOCK") != "1" {
		return nil
	}
	runner, stock := r.self.(*CommandLineRunner)
	c := r.compiler
	if !stock || runner == nil || &runner.AbstractCommandLineRunnerBase != r || r.self.IsInTestMode() ||
		c == nil || c.GetRoot() != nil || c.GetOptions() == nil || c.changeTracker == nil ||
		r.config.typedAstListInputFilename != nil || r.config.continueSavedCompilationFileName != nil ||
		r.config.saveCompilationStateToFilename != nil || c.GetOptions().customPasses != nil ||
		!parallelFSIVObserversSafe(c) {
		return nil
	}
	// Reject aliases and unknown loaders before installing anything. Standard
	// CLI creates distinct SourceFile objects for ordinary/zip/JSON/stdin input.
	seen := make(map[*SourceFile]bool, len(externs)+len(sources))
	files := make([]*SourceFile, 0, len(externs)+len(sources))
	for _, group := range [][]*SourceFile{externs, sources} {
		for _, file := range group {
			if file == nil || seen[file] {
				sourceLockDiagOwnershipResult("nil_or_aliased_file", file, 0)
				return nil
			}
			switch file.loader.(type) {
			case *SourceFile_CodeLoader_Preloaded, *SourceFile_CodeLoader_OnDisk, *SourceFile_CodeLoader_AtZip:
			default:
				sourceLockDiagOwnershipResult("unsupported_loader", file, 0)
				return nil
			}
			seen[file] = true
			files = append(files, file)
		}
	}
	handles := make([]weak.Pointer[SourceFile], 0, len(files))
	for _, file := range files {
		loader := &cliOwnedSourceLoader{SourceFile_CodeLoader: file.loader}
		loader.cached.Store(file.code)
		file.loader = loader
		handles = append(handles, weak.Make(file))
	}
	sourceLockDiagOwnershipResult("", nil, len(handles))
	return &cliSourceFileOwnership{files: handles}
}
