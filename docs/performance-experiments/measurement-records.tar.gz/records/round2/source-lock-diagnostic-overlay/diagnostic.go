package jscomp

import (
	"encoding/json"
	"fmt"
	"os"
	"sync"
	"sync/atomic"
)

// DIAGNOSTIC OVERLAY ONLY. This file and its hooks are absent from timed builds.
// JSON goes to a dedicated file, never through compiler output or its options.
var sourceLockDiag = struct {
	path                                                            string
	mu                                                              sync.Mutex
	ownership                                                       []map[string]any
	getCode, ownedGetCode, ownedCachedGetCode                       atomic.Uint64
	ownedLoadAttempts, ownedLoadSuccesses, ownedLoadedBytes         atomic.Uint64
	monitorLoadAttempts, monitorLoadSuccesses, monitorLoadedBytes   atomic.Uint64
	getReader, ownedReader, ownedCachedReader, ownedStreamingReader atomic.Uint64
	setCode, ownedSetCode, clearCode                                atomic.Uint64
}{path: os.Getenv("JSGO_SOURCE_LOCK_DIAGNOSTIC_JSON")}

func sourceLockDiagCount(counter *atomic.Uint64) {
	if sourceLockDiag.path != "" {
		counter.Add(1)
	}
}

func sourceLockDiagBytes(counter *atomic.Uint64, code *string) {
	if sourceLockDiag.path != "" && code != nil {
		counter.Add(uint64(len(*code)))
	}
}

func sourceLockDiagBeforeOwnership(r *AbstractCommandLineRunnerBase, externs, sources []*SourceFile) {
	if sourceLockDiag.path == "" {
		return
	}
	record := map[string]any{
		"flag":         os.Getenv("JSGO_EXPERIMENT_CLI_SOURCE_LOCK"),
		"runner_type":  fmt.Sprintf("%T", r.self),
		"extern_files": len(externs), "source_files": len(sources),
		"wrapped_files": 0, "rejection": "",
	}
	loaders := map[string]int{}
	alreadyLoaded := 0
	for _, files := range [][]*SourceFile{externs, sources} {
		for _, file := range files {
			if file == nil {
				loaders["<nil source>"]++
				continue
			}
			loaders[fmt.Sprintf("%T", file.loader)]++
			if file.code != nil {
				alreadyLoaded++
			}
		}
	}
	record["loader_types"] = loaders
	record["already_loaded_files"] = alreadyLoaded
	runner, stock := r.self.(*CommandLineRunner)
	c := r.compiler
	reason := ""
	switch {
	case record["flag"] != "1":
		reason = "flag_disabled"
	case !stock || runner == nil || &runner.AbstractCommandLineRunnerBase != r:
		reason = "custom_runner"
	case r.self.IsInTestMode():
		reason = "test_mode"
	case c == nil:
		reason = "nil_compiler"
	case c.GetRoot() != nil:
		reason = "compiler_already_initialized"
	case c.GetOptions() == nil:
		reason = "nil_options"
	case c.changeTracker == nil:
		reason = "nil_change_tracker"
	case r.config.typedAstListInputFilename != nil:
		reason = "typed_ast"
	case r.config.continueSavedCompilationFileName != nil:
		reason = "restore_compilation"
	case r.config.saveCompilationStateToFilename != nil:
		reason = "save_compilation"
	case c.GetOptions().customPasses != nil:
		reason = "custom_passes"
	case !parallelFSIVObserversSafe(c):
		reason = "unsupported_observers"
	}
	if c != nil && c.GetOptions() != nil {
		o := c.GetOptions()
		record["threads"] = o.GetNumParallelThreads()
		record["error_manager_type"] = fmt.Sprintf("%T", c.errorManager)
		record["coding_convention_type"] = fmt.Sprintf("%T", c.GetCodingConvention())
		record["coding_convention_safe"] = parallelFSIVConventionSafe(c.GetCodingConvention())
		record["error_manager_safe"] = parallelFSIVErrorManagerSafe(c.errorManager)
		record["default_redeclaration_handler_type"] = fmt.Sprintf("%T", SyntacticScopeCreator_DEFAULT_REDECLARATION_HANDLER)
		record["error_handler_type"] = fmt.Sprintf("%T", o.GetErrorHandler())
		record["debug_log_directory"] = o.GetDebugLogDirectory()
		record["check_determinism"] = o.GetCheckDeterminism()
		record["tracer_mode"] = fmt.Sprint(o.GetTracerMode())
		if c.changeTracker != nil {
			handlers := []string{}
			for _, h := range c.changeTracker.codeChangeHandlers.Slice() {
				handlers = append(handlers, fmt.Sprintf("%T", h))
			}
			record["change_handler_types"] = handlers
		}
	}
	record["rejection"] = reason
	sourceLockDiag.mu.Lock()
	sourceLockDiag.ownership = append(sourceLockDiag.ownership, record)
	sourceLockDiag.mu.Unlock()
}

func sourceLockDiagOwnershipResult(reason string, file *SourceFile, wrapped int) {
	if sourceLockDiag.path == "" {
		return
	}
	sourceLockDiag.mu.Lock()
	defer sourceLockDiag.mu.Unlock()
	if len(sourceLockDiag.ownership) == 0 {
		return
	}
	record := sourceLockDiag.ownership[len(sourceLockDiag.ownership)-1]
	if reason != "" {
		record["rejection"] = reason
	}
	record["wrapped_files"] = wrapped
	if file != nil {
		record["rejected_file"] = file.GetName()
		record["rejected_loader_type"] = fmt.Sprintf("%T", file.loader)
	}
}

func sourceLockDiagWrite() {
	if sourceLockDiag.path == "" {
		return
	}
	sourceLockDiag.mu.Lock()
	defer sourceLockDiag.mu.Unlock()
	output := map[string]any{
		"diagnostic_only": true, "ownership": sourceLockDiag.ownership,
		"get_code":                  sourceLockDiag.getCode.Load(),
		"owned_get_code":            sourceLockDiag.ownedGetCode.Load(),
		"owned_cached_get_code":     sourceLockDiag.ownedCachedGetCode.Load(),
		"owned_load_attempts":       sourceLockDiag.ownedLoadAttempts.Load(),
		"owned_load_successes":      sourceLockDiag.ownedLoadSuccesses.Load(),
		"owned_loaded_utf8_bytes":   sourceLockDiag.ownedLoadedBytes.Load(),
		"monitor_load_attempts":     sourceLockDiag.monitorLoadAttempts.Load(),
		"monitor_load_successes":    sourceLockDiag.monitorLoadSuccesses.Load(),
		"monitor_loaded_utf8_bytes": sourceLockDiag.monitorLoadedBytes.Load(),
		"get_reader":                sourceLockDiag.getReader.Load(),
		"owned_reader":              sourceLockDiag.ownedReader.Load(),
		"owned_cached_reader":       sourceLockDiag.ownedCachedReader.Load(),
		"owned_streaming_reader":    sourceLockDiag.ownedStreamingReader.Load(),
		"set_code":                  sourceLockDiag.setCode.Load(),
		"owned_set_code":            sourceLockDiag.ownedSetCode.Load(),
		"clear_code":                sourceLockDiag.clearCode.Load(),
	}
	data, err := json.MarshalIndent(output, "", "  ")
	if err == nil {
		_ = os.WriteFile(sourceLockDiag.path, append(data, '\n'), 0600)
	}
}
