import json,subprocess,os
from pathlib import Path
r=Path("/workspace/jsgo-results/round2")
e=dict(os.environ,PATH="/workspace/toolchains/go1.27.2/bin:"+os.environ["PATH"],GOCACHE="/workspace/toolchains/cache",GOPATH="/workspace/toolchains/gopath",GOTOOLCHAIN="local")
with (r/"followup-screen.log").open("w") as f:
 subprocess.run(json.loads((r/"followup-screen-command.json").read_text()),env=e,stdout=f,stderr=subprocess.STDOUT,check=True)
