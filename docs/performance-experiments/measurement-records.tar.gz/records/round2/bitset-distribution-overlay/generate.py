#!/usr/bin/env python3
"""Untimed, diagnostic-only overlay for the old slice-backed BitSet.

No source tree is mutated. Call counts are NOT heap allocations: compiler
escape elimination and native liveness' value-array initialization differ.
"""
import argparse
import json
from pathlib import Path


def replace_once(source, old, new):
    if source.count(old) != 1:
        raise RuntimeError(f"expected one source match: {old!r}")
    return source.replace(old, new)


parser = argparse.ArgumentParser()
parser.add_argument("--repo", required=True)
parser.add_argument("--out", required=True)
args = parser.parse_args()
repo, out = Path(args.repo).resolve(), Path(args.out).resolve()
out.mkdir(parents=True, exist_ok=True)
replacements = {}


def put(relative, source):
    target = out / relative.replace("/", "_")
    target.write_text(source)
    replacements[str(repo / relative)] = str(target)


bitset = (repo / "internal/jutil/bitset.go").read_text()
if "words []uint64" not in bitset or "large *largeBitSetWords" in bitset:
    raise RuntimeError("requires the original slice-backed BitSet")
bitset = replace_once(bitset, 'import (', 'import (\n\t"encoding/json"\n\t"os"\n\t"sync"\n\t"sync/atomic"')
bitset = replace_once(bitset, 'func NewBitSet() *BitSet { return &BitSet{} }', '''func NewBitSet() *BitSet {
    bitSetDiagnostic.constructors[0][0].Add(1)
    return &BitSet{}
}''')
bitset = replace_once(bitset, '''		b.words = append(b.words, make([]uint64, wordIndex+1-len(b.words))...)''', '''        previousCapacity := cap(b.words)
        b.words = append(b.words, make([]uint64, wordIndex+1-len(b.words))...)
        if cap(b.words) != previousCapacity {
            bitSetDiagnostic.growth[bitSetDiagnosticBucket(previousCapacity)][bitSetDiagnosticBucket(cap(b.words))].Add(1)
            bitSetDiagnostic.growthWords.Add(uint64(cap(b.words)-previousCapacity))
        }''')
bitset = replace_once(bitset, '''	return &BitSet{words: append([]uint64(nil), b.words...)}''', '''    words := append([]uint64(nil), b.words...)
    bitSetDiagnostic.constructors[2][bitSetDiagnosticBucket(cap(words))].Add(1)
    bitSetDiagnostic.cloneSource[bitSetDiagnosticBucket(cap(b.words))][bitSetDiagnosticBucket(len(b.words))].Add(1)
    return &BitSet{words: words}''')
bitset += '''
// Diagnostic overlay only: atomics preserve counter correctness for N>1;
// counters retain no BitSet/AST/scope references and alter no compiler guard.
var bitSetDiagnostic struct {
    constructors [3][4]atomic.Uint64
    cloneSource [4][4]atomic.Uint64
    growth [4][4]atomic.Uint64
    growthWords atomic.Uint64
    once sync.Once
}
func bitSetDiagnosticBucket(words int) int {
    if words <= 2 { return words }
    return 3
}
// DiagnosticBitSetDump exists only in the overlay, never in production.
func DiagnosticBitSetDump() {
    path := os.Getenv("JSGO_BITSET_DIAGNOSTIC_PATH")
    if path == "" { return }
    bitSetDiagnostic.once.Do(func() {
        var constructors [3][4]uint64
        var cloneSource, growth [4][4]uint64
        for i := range constructors { for j := range constructors[i] {
            constructors[i][j] = bitSetDiagnostic.constructors[i][j].Load()
        } }
        for i := range growth { for j := range growth[i] {
            growth[i][j] = bitSetDiagnostic.growth[i][j].Load()
            cloneSource[i][j] = bitSetDiagnostic.cloneSource[i][j].Load()
        } }
        report := struct {
            Note string
            Buckets [4]string
            ConstructorRows [3]string
            Constructors [3][4]uint64
            CloneSourceCapacityByUsedWords [4][4]uint64
            CapacityGrowthFromByTo [4][4]uint64
            CapacityGrowthWords uint64
        }{
            Note: "Untimed diagnostic call/event counts, NOT mallocs, retained objects, bytes or RSS. Zero-value creation is not observed; constructor temporary copies are counted. Package initialization is included. Rows and columns use Buckets.",
            Buckets: [4]string{"0", "1", "2", ">2"},
            ConstructorRows: [3]string{"default", "reserved", "clone"},
            Constructors: constructors,
            CloneSourceCapacityByUsedWords: cloneSource,
            CapacityGrowthFromByTo: growth,
            CapacityGrowthWords: bitSetDiagnostic.growthWords.Load(),
        }
        data, err := json.MarshalIndent(report, "", "  ")
        if err != nil { panic(err) }
        if err := os.WriteFile(path, append(data, '\\n'), 0600); err != nil { panic(err) }
    })
}
'''
put("internal/jutil/bitset.go", bitset)

size = (repo / "internal/jutil/bit_set_size.go").read_text()
size = replace_once(size, '''	return &BitSet{words: make([]uint64, 0, (nbits+63)>>6)}''', '''    words := make([]uint64, 0, (nbits+63)>>6)
    bitSetDiagnostic.constructors[1][bitSetDiagnosticBucket(cap(words))].Add(1)
    return &BitSet{words: words}''')
put("internal/jutil/bit_set_size.go", size)

system = (repo / "internal/jutil/system.go").read_text()
system = replace_once(system, 'func System_Exit(status int) {', 'func System_Exit(status int) {\n\tDiagnosticBitSetDump()')
put("internal/jutil/system.go", system)

main = (repo / "cmd/jsgo/main.go").read_text()
main = replace_once(main, 'func main() {', 'func main() {\n\tdefer jutil.DiagnosticBitSetDump()')
put("cmd/jsgo/main.go", main)
(out / "overlay.json").write_text(json.dumps({"Replace": replacements}, indent=2) + "\n")
print(out / "overlay.json")
