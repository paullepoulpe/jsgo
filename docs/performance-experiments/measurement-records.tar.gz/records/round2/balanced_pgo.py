#!/usr/bin/env python3
"""Build equal-task-mass PGO from byte-gated CPU captures; never run workloads.

Merge repetitions within each task, then normalize the actual first
samples/count column to exactly one million per task. Proportional integer
rounding uses largest remainders, preserving every positive sample. Labels,
locations and all non-value protobuf fields remain unchanged.
"""
import argparse, hashlib, json, os, subprocess
from datetime import datetime, timezone
from pathlib import Path
from pprof_data import load_profile

TASKS = ['typed-app', 'bundle', 'downlevel-whitespace', 'downlevel-simple', 'checks-only']
GO = '/workspace/toolchains/go1.27.2/bin/go'


def sha(path):
    h = hashlib.sha256()
    with Path(path).open('rb') as f:
        for block in iter(lambda: f.read(1024 * 1024), b''):
            h.update(block)
    return h.hexdigest()


def equal_mass_values(profile, target):
    if profile.sample_types[0] != ('samples', 'count'):
        raise ValueError(f'first sample type must be samples/count: {profile.sample_types}')
    if ('cpu', 'nanoseconds') not in profile.sample_types:
        raise ValueError('CPU sample type missing')
    if not profile.samples or any(s.values[0] <= 0 or any(v < 0 for v in s.values) for s in profile.samples):
        raise ValueError('empty, nonpositive-count, or negative CPU samples')
    raw = profile.totals()[0]
    if target < raw:
        raise ValueError(f'target {target} < input count {raw}; raise target to avoid dropping rare samples')
    rows = [[0] * len(profile.sample_types) for _ in profile.samples]
    for column in range(len(profile.sample_types)):
        quotients, remainders = [], []
        for sample in profile.samples:
            q, r = divmod(sample.values[column] * target, raw)
            quotients.append(q)
            remainders.append(r)
        total = (sum(s.values[column] for s in profile.samples) * target * 2 + raw) // (2 * raw)
        missing = total - sum(quotients)
        if not 0 <= missing <= len(rows):
            raise ValueError('invalid rounding remainder')
        for index in sorted(range(len(rows)), key=lambda i: (-remainders[i], i))[:missing]:
            quotients[index] += 1
        for i, q in enumerate(quotients):
            if q >= 1 << 63:
                raise ValueError('scaled profile overflows int64')
            rows[i][column] = q
    if sum(row[0] for row in rows) != target or any(row[0] <= 0 for row in rows):
        raise ValueError('normalized first-column mass or sample preservation failed')
    return rows


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--profiles-root', required=True, type=Path)
    p.add_argument('--extras-root', action='append', default=[], type=Path)
    p.add_argument('--tasks', nargs='+', default=TASKS)
    p.add_argument('--profile-pattern', default='{task}/profile.cpu.pprof')
    p.add_argument('--out', required=True, type=Path)
    p.add_argument('--binary', required=True, type=Path)
    p.add_argument('--source-repo', required=True, type=Path)
    p.add_argument('--source-commit', required=True)
    p.add_argument('--allow-source-head-difference', action='store_true', help='verify training commit git blobs instead of requiring current checkout HEAD')
    p.add_argument('--overlay-manifest', required=True, type=Path)
    p.add_argument('--environment', type=Path, help='defaults to profiles-root/environment.json')
    p.add_argument('--target-mass', type=int, default=1000000)
    p.add_argument('--go', default=GO)
    a = p.parse_args()
    if len(a.tasks) != len(set(a.tasks)) or a.target_mass <= 0:
        p.error('task names must be unique and target positive')
    for task in a.tasks:
        if '/' in task or task in ('.', '..'):
            p.error('task names must be directory components')
    env_path = a.environment or a.profiles_root / 'environment.json'
    environment = json.loads(env_path.read_text())
    binary = a.binary.resolve(strict=True)
    binary_sha = sha(binary)
    if Path(environment['binary']).resolve() != binary or environment['sha256'] != binary_sha:
        raise ValueError('capture binary identity does not match')
    if environment['source_commit'] != a.source_commit or not isinstance(environment.get('flags'), dict):
        raise ValueError('capture source/flags provenance missing or mismatched')
    head = subprocess.check_output(['git', '-C', str(a.source_repo), 'rev-parse', 'HEAD'], text=True).strip()
    if head != a.source_commit and not a.allow_source_head_difference:
        raise ValueError('source worktree HEAD mismatch; explicit --allow-source-head-difference required')
    resolved_commit = subprocess.check_output(['git', '-C', str(a.source_repo), 'rev-parse', a.source_commit + '^{commit}'], text=True).strip()
    if resolved_commit != a.source_commit:
        raise ValueError('source commit must be an exact full git commit')
    overlay = json.loads(a.overlay_manifest.read_text())
    if overlay['source_commit'] != a.source_commit:
        raise ValueError('overlay source mismatch')
    for item in overlay['files']:
        relative = Path(item['source']).relative_to(a.source_repo.resolve())
        frozen_source = subprocess.check_output(['git', '-C', str(a.source_repo), 'show', a.source_commit + ':' + str(relative)])
        if hashlib.sha256(frozen_source).hexdigest() != item['source_sha256'] or sha(item['replacement']) != item['replacement_sha256']:
            raise ValueError('overlay frozen source/replacement changed')
    if sha(overlay['overlay']) != overlay['overlay_sha256']:
        raise ValueError('overlay map changed')
    inputs = {}
    extra_provenance = []
    for extra in a.extras_root:
        if not extra.is_dir():
            raise ValueError(f'missing extras root {extra}')
        ep = extra / 'environment.json'
        if ep.exists():
            data = json.loads(ep.read_text())
            for key in ('sha256', 'source_commit', 'flags'):
                if key in data and data[key] != environment[key]:
                    raise ValueError(f'extra capture {key} mismatch: {extra}')
            extra_provenance.append({'path': str(ep.resolve()), 'sha256': sha(ep), 'metadata': data})
    for task in a.tasks:
        files = [(a.profiles_root / a.profile_pattern.format(task=task)).resolve(strict=True)]
        for extra in a.extras_root:
            for run in sorted((extra / task).glob('run-*')):
                if not run.is_dir():
                    raise ValueError(f'expected repetition directory: {run}')
                files.append((run / 'profile.cpu.pprof').resolve(strict=True))
        if len(files) != len(set(files)):
            raise ValueError(f'duplicate profile input for {task}')
        for f in files:
            profile = load_profile(f)
            # Validate even an individual input before merge can mask a problem.
            equal_mass_values(profile, max(a.target_mass, profile.totals()[0]))
        inputs[task] = files
    a.out.mkdir(parents=True, exist_ok=False)
    toolenv = dict(os.environ, GOCACHE=os.environ.get('GOCACHE', '/workspace/.cache/go-build'))
    commands = []
    def pprof_merge(paths, output):
        cmd = [a.go, 'tool', 'pprof', '-proto', '-output=' + str(output)] + [str(x) for x in paths]
        commands.append(cmd)
        subprocess.run(cmd, check=True, env=toolenv, stdout=subprocess.DEVNULL)
    rows = []
    normalized_files = []
    for task, files in inputs.items():
        merged = a.out / (task + '.merged.pprof')
        pprof_merge(files, merged)
        original = load_profile(merged)
        normalized = a.out / (task + '.normalized.pprof')
        normalized.write_bytes(original.encode_with_values(equal_mass_values(original, a.target_mass)))
        checked = load_profile(normalized)
        if checked.sample_types != original.sample_types or len(checked.samples) != len(original.samples):
            raise ValueError('normalized profile shape changed')
        if any(x.locations != y.locations or x.labels != y.labels for x, y in zip(original.samples, checked.samples)):
            raise ValueError('normalization changed stack/label identity')
        if checked.totals()[0] != a.target_mass or any(s.values[0] <= 0 for s in checked.samples):
            raise ValueError('task normalization dropped samples or changed mass')
        normalized_files.append(normalized)
        rows.append({'task': task, 'inputs': [{'path': str(f), 'sha256': sha(f), 'bytes': f.stat().st_size} for f in files],
                     'raw_totals': original.totals(), 'sample_types': original.sample_types,
                     'sample_records': len(original.samples), 'normalized_sample_records': len(checked.samples),
                     'scale_numerator': a.target_mass, 'scale_denominator': original.totals()[0],
                     'normalized_totals': checked.totals(), 'target_count_mass': a.target_mass,
                     'merged_profile': str(merged), 'merged_sha256': sha(merged),
                     'normalized_profile': str(normalized), 'normalized_sha256': sha(normalized)})
    balanced = a.out / 'balanced.pgo'
    pprof_merge(normalized_files, balanced)
    combined = load_profile(balanced)
    if combined.sample_types[0] != ('samples', 'count') or combined.totals()[0] != a.target_mass * len(a.tasks):
        raise ValueError('balanced merge lost a task or sample mass')
    manifest = {'schema': 1, 'created_utc': datetime.now(timezone.utc).isoformat(), 'tasks': a.tasks,
                'weighting': 'equal first samples/count mass per task; repetitions merged before normalization',
                'integer_rounding': 'largest remainders, exact column totals, deterministic ties by original sample order',
                'source_commit': a.source_commit, 'current_worktree_head': head, 'source_head_difference_explicitly_allowed': a.allow_source_head_difference, 'source_repo': str(a.source_repo.resolve()), 'binary': str(binary), 'binary_sha256': binary_sha,
                'capture_environment': environment, 'environment_path': str(env_path.resolve()), 'environment_sha256': sha(env_path),
                'extra_provenance': extra_provenance, 'overlay_manifest': str(a.overlay_manifest.resolve()),
                'overlay_manifest_sha256': sha(a.overlay_manifest), 'overlay_metadata': overlay,
                'go_version': subprocess.check_output([a.go, 'version'], text=True).strip(),
                'normalizer': str(Path(__file__).resolve()), 'normalizer_sha256': sha(__file__),
                'profile_reader_sha256': sha(Path(__file__).with_name('pprof_data.py')),
                'task_weights': rows, 'commands': commands, 'balanced_profile': str(balanced.resolve()),
                'balanced_sha256': sha(balanced), 'balanced_sample_types': combined.sample_types,
                'balanced_totals': combined.totals(), 'input_files_total': sum(len(v) for v in inputs.values()),
                'note': 'Capture byte gates must be validated by the capture runner; this helper does not execute compiler workloads.'}
    (a.out / 'manifest.json').write_text(json.dumps(manifest, indent=2) + '\n')
    print(json.dumps({'profile': str(balanced), 'sha256': manifest['balanced_sha256'], 'tasks': a.tasks,
                      'input_files': manifest['input_files_total'], 'first_count_mass': combined.totals()[0]}, indent=2))


if __name__ == '__main__':
    main()
