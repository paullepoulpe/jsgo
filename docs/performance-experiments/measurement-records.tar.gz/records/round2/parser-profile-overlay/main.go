// Command jsgo is the Go port of Closure Compiler's command-line front end:
// `jsgo <args>` behaves like `java -jar closure-compiler.jar <args>`
// (CommandLineRunner.main).
package main

import (
	"os"
 "runtime"
 "runtime/pprof"
 "encoding/json"

	"github.com/paullepoulpe/jsgo/internal/jscomp"
	"github.com/paullepoulpe/jsgo/internal/jutil"
)

func main() {
	// Go-only: language-adapter — the JVM's startup and shutdown around
	// CommandLineRunner.main:
	//   - System.err encodes text with native.encoding (the locale's
	//     codeset; US-ASCII in the C/POSIX locale). System.out is left as
	//     UTF-8: the runner prints only ASCII text to it and writes
	//     everything else as bytes it has already encoded.
	//   - An exception that escapes main is reported by the default
	//     uncaught-exception handler as `Exception in thread "main" ` and
	//     the stack trace on System.err, and the JVM exits with status 1.
	//   - main returning normally exits with status 0.
	jutil.System_SetErr(jutil.NewPrintStreamWithCharset(os.Stderr, jutil.System_NativeCharset()))
	defer func() {
		r := recover()
		if r == nil {
			return
		}
		t, ok := r.(jutil.Throwable)
		if !ok {
			t = jutil.AsThrowable(r)
		}
		err := jutil.System_Err()
		err.Print("Exception in thread \"main\" ")
		jutil.Throwable_PrintStackTrace(t, err)
		err.Flush()
		os.Exit(1)
	}()
	
 prefix := os.Getenv("JSGO_PROFILE_PREFIX")
 f, err := os.Create(prefix + ".cpu.pprof")
 if err != nil { panic(err) }
 if err := pprof.StartCPUProfile(f); err != nil { panic(err) }
 var before, after runtime.MemStats
 runtime.ReadMemStats(&before)
 runner := jscomp.NewCommandLineRunner(os.Args[1:])
 code := 0
 runner.SetExitCodeReceiver(func(c int) { code = c })
 if runner.ShouldRunCompiler() { runner.Run() }
 if runner.HasErrors() { code = -1 }
 runtime.ReadMemStats(&after)
 pprof.StopCPUProfile()
 f.Close()
 af, err := os.Create(prefix + ".allocs.pprof")
 if err != nil { panic(err) }
 pprof.Lookup("allocs").WriteTo(af, 0)
 af.Close()
 mf, err := os.Create(prefix + ".memstats.json")
 if err != nil { panic(err) }
 json.NewEncoder(mf).Encode(map[string]any{"before":before,"after":after,"exit":code})
 mf.Close()
 // This GC is outside the compilation interval; live heap is a separate diagnostic.
 runtime.GC()
 hf, err := os.Create(prefix + ".live.pprof")
 if err != nil { panic(err) }
 pprof.Lookup("heap").WriteTo(hf, 0)
 hf.Close()
 os.Exit(code)

}
