// Port of com/google/javascript/jscomp/FunctionArgumentInjectorTest.java @ closure-compiler v20261015
// (test/com/google/javascript/jscomp/FunctionArgumentInjectorTest.java)

/*
 * Copyright 2009 The Closure Compiler Authors.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package jscomp

import (
 "fmt"
 "io"
 "github.com/paullepoulpe/jsgo/internal/diagnostic"
 "strings"
 "github.com/paullepoulpe/jsgo/internal/jutil"
 "github.com/paullepoulpe/jsgo/internal/rhino"
)

func FunctionArgumentInjectorTest_GetNameSupplier() func() string {
	i := 0
	return func() string {
		v := jutil.ToJavaString(i) // String.valueOf(i++)
		i++
		return v
	}
}

func FunctionArgumentInjectorTest_FindCall(n *rhino.Node, name string) *rhino.Node {
	if NodeUtil_IsNormalOrOptChainCall(n) {
		var callee *rhino.Node
		if NodeUtil_IsNormalOrOptChainGetProp(n.GetFirstChild()) {
			callee = n.GetFirstFirstChild()
			// Only "call" is supported at this point.
			jutil.CheckArgument(callee.GetParent().GetString() == "call")
		} else {
			callee = n.GetFirstChild()
		}

		if callee.IsName() && callee.GetString() == name {
			return n
		}
	}

	for c := n.GetFirstChild(); c != nil; c = c.GetNext() {
		result := FunctionArgumentInjectorTest_FindCall(c, name)
		if result != nil {
			return result
		}
	}

	return nil
}

func FunctionArgumentInjectorTest_FindFunction(n *rhino.Node, name string) *rhino.Node {
	if n.IsFunction() {
		if n.GetFirstChild().GetString() == name {
			return n
		}
	}

	for c := n.GetFirstChild(); c != nil; c = c.GetNext() {
		result := FunctionArgumentInjectorTest_FindFunction(c, name)
		if result != nil {
			return result
		}
	}

	return nil
}

type coreG3Collector struct {
	BasicErrorManagerBase
	reports []string
}

func newCoreG3Collector() *coreG3Collector {
	c := &coreG3Collector{}
	c.InitBasicErrorManagerBase(c)
	return c
}

func (c *coreG3Collector) Report(level *CheckLevel, error *JSError) {
	c.reports = append(c.reports, level.String()+" "+error.String())
	c.BasicErrorManagerBase.Report(level, error)
}

func (c *coreG3Collector) Println(level *CheckLevel, error *JSError) {}

func (c *coreG3Collector) PrintSummary() {}


func typedScopeDump_varLine(v *TypedVar) string {
	type_ := v.GetType()
	ann := "-"
	if type_ != nil && !v.IsTypeInferred() {
		jutil.Try(func() {
			ann = type_.ToAnnotationString(rhino.JSType_Nullability_EXPLICIT)
		}, func(e jutil.IRuntimeException) {
			ann = "!" + typedScopeDump_simpleClassName(e)
		})
	}
	node := "null"
	if v.GetNameNode() != nil {
		node = typedScopeDump_pos(v.GetNameNode())
	}
	return fmt.Sprintf("V %s | %s | %s | inferred=%t esc=%t once=%t input=%s node=%s",
		v.GetName(), typedScopeDump_typeString(type_), ann, v.IsTypeInferred(),
		v.IsMarkedEscaped(), v.IsMarkedAssignedExactlyOnce(), v.GetInputName(), node)
}

func typedScopeDump_simpleClassName(e jutil.Throwable) string {
	s := e.Error()
	if i := strings.Index(s, ": "); i >= 0 {
		s = s[:i]
	}
	return s[strings.LastIndexByte(s, '.')+1:]
}

func typedScopeDump_typeString(type_ rhino.JSType) (s string) {
	if type_ == nil {
		return "null"
	}
	jutil.Try(func() {
		s = type_.String()
	}, func(e jutil.IRuntimeException) {
		s = "!" + typedScopeDump_simpleClassName(e)
	})
	return s
}

func typedScopeDump_pos(n *rhino.Node) string {
	return fmt.Sprintf("%s@%d:%d", n.GetToken(), n.GetLineno(), n.GetCharno())
}

func removeUnusedOracleOptions() *CompilerOptions {
	options := NewCompilerOptions()
	options.SetLanguageIn(CompilerOptions_LanguageMode_ECMASCRIPT_NEXT)
	options.SetLanguageOut(CompilerOptions_LanguageMode_NO_TRANSPILE)
	// VarCheck declares the undeclared names (as the checks phase does before these passes run);
	// its "undefined variable" errors would only repeat in every run.
	options.SetWarningLevel(DiagnosticGroups_UNDEFINED_VARIABLES, CheckLevel_OFF)
	return options
}

func removeUnusedOracleNewCompiler(rel string, src string) *Compiler {
	compiler := NewCompilerWithOutStream(jutil.NewPrintStream(io.Discard))
	compiler.Init(
		[]*SourceFile{SourceFile_FromCode("externs.js", removeUnusedOracleExterns)},
		[]*SourceFile{SourceFile_FromCode(rel, src)},
		removeUnusedOracleOptions())
	compiler.Parse()
	return compiler
}

func removeUnusedOraclePrepare(c *Compiler) {
	externs := c.GetExternsRoot()
	js := c.GetJsRoot()
	NewVarCheck(c).Process(externs, js)
	Normalize_CreateNormalizeForOptimizations(c).Process(externs, js)
	NewGatherGetterAndSetterProperties(c).Process(externs, js)
	NewGatherExternProperties(c, GatherExternProperties_Mode_OPTIMIZE).Process(externs, js)
}

var removeUnusedOracleExterns = strings.Join([]string{
	"var window;",
	"var document;",
	"var console;",
	"var Arguments;",
	"/** @constructor @param {*=} opt_value @return {!Object} */",
	"function Object(opt_value) {}",
	"/** @type {Function} */ Object.defineProperties = function() {};",
	"/** @type {Function} */ Object.defineProperty = function() {};",
	"/** @constructor @param {...*} var_args @return {!Array} */",
	"function Array(var_args) {}",
	"/** @constructor @param {*=} message */ function Error(message) {}",
	"/** @nosideeffects */ function externPure() {}",
	"function alert(a) {}",
	"",
}, "\n")

type unusedWorkLog struct {
	*diagnostic.NoOpLogFile
	events *[]string
}

func (l *unusedWorkLog) LogString(value string) diagnostic.LogFile {
	*l.events = append(*l.events, "log:"+value)
	return l
}

type unusedWorkCustomConvention struct{ CodingConvention }

var CompilerTestCase_DEFAULT_EXTERNS = NewTestExternsBuilder().
	AddArray().
	AddIterable().
	AddObject().
	AddUndefined().
	AddFunction().
	AddString().
	AddPromise().
	AddClosureExterns().
	AddITemplateArray().
	Build()

var CompilerTypeTestCase_DEFAULT_EXTERNS = CompilerTestCase_DEFAULT_EXTERNS
