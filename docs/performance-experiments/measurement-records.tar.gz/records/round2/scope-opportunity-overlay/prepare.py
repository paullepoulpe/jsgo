#!/usr/bin/env python3
"""Generate a separate scope-counter overlay; never modify the source worktree."""
import argparse
import hashlib
import json
import subprocess
from pathlib import Path

parser = argparse.ArgumentParser()
parser.add_argument('--root', type=Path, default=Path('/workspace/jsgo-round-compound-next'))
parser.add_argument('--base-overlay', type=Path, help='Optional existing diagnostic overlay to compose without changing it')
args = parser.parse_args()
root = args.root.resolve()
out = Path(__file__).resolve().parent
base = {} if args.base_overlay is None else json.loads(args.base_overlay.read_text())['Replace']
replace = dict(base)
files = []

def patch(relative, edits):
    original = root / relative
    source = Path(base.get(str(original), original)).read_text()
    before = source
    for old, new in edits:
        if source.count(old) != 1:
            raise SystemExit(f'{relative}: expected one occurrence, got {source.count(old)}: {old[:100]!r}')
        source = source.replace(old, new, 1)
    target = out / original.name
    target.write_text(source)
    replace[str(original)] = str(target)
    files.append({'source': str(original), 'input_sha256': hashlib.sha256(before.encode()).hexdigest(), 'replacement': str(target)})

patch('internal/jscomp/phase_optimizer.go', [
    ('type PhaseOptimizer struct {', 'type PhaseOptimizer struct {\n\tscopeOpportunity *scopeOpportunityDiagnostic // Overlay-only, released at Process exit.'),
    ('func (p *PhaseOptimizer) Process(externs *rhino.Node, root *rhino.Node) {', '''func (p *PhaseOptimizer) Process(externs *rhino.Node, root *rhino.Node) {
	p.scopeOpportunity = scopeOpportunityStart(p)
	defer func() { p.scopeOpportunity.finish(); p.scopeOpportunity = nil }()'''),
    ('func (n *PhaseOptimizer_NamedPass) Process(externs *rhino.Node, root *rhino.Node) {\n\tp := n.outer', '''func (n *PhaseOptimizer_NamedPass) Process(externs *rhino.Node, root *rhino.Node) {
	p := n.outer
	finishScopeOpportunityPass := p.scopeOpportunity.begin(n.name)
	defer finishScopeOpportunityPass()'''),
])

patch('internal/jscomp/syntactic_scope_creator.go', [
    ('type SyntacticScopeCreator struct {', 'type SyntacticScopeCreator struct {\n\tscopeOpportunityConsumer, scopeOpportunityPhase string // Overlay-only.'),
    ('func (c *SyntacticScopeCreator) CreateScopeOfScope(n *rhino.Node, parent *Scope) *Scope {', '''func (c *SyntacticScopeCreator) CreateScopeOfScope(n *rhino.Node, parent *Scope) *Scope {
	scopeObservation := scopeOpportunityPrepare(c)'''),
    ('\tscanner.Populate()\n\treturn scope', '\tscanner.scopeOpportunity = scopeObservation\n\tscanner.Populate()\n\tscopeOpportunityRecord(c, scope, scopeObservation)\n\treturn scope'),
    ('type SyntacticScopeCreator_ScopeScanner struct {', 'type SyntacticScopeCreator_ScopeScanner struct {\n\tscopeOpportunity *scopeOpportunityObservation // Overlay-only.'),
    ('jutil.CheckStateMsg1(n.IsName() || n.IsImportStar(), "Invalid node for declareVar: %s", n)', '''jutil.CheckStateMsg1(n.IsName() || n.IsImportStar(), "Invalid node for declareVar: %s", n)
	s.scopeOpportunity.declaration(s,n)'''),
    ('func (s *SyntacticScopeCreator_ScopeScanner) DeclareImplicitGoogNamespaceFromCall(sc *Scope, exprCall *rhino.Node) {', '''func (s *SyntacticScopeCreator_ScopeScanner) DeclareImplicitGoogNamespaceFromCall(sc *Scope, exprCall *rhino.Node) {
	if s.scopeOpportunity != nil { s.scopeOpportunity.unsafe = true }'''),
])
patch('internal/jscomp/inline_variables.go', [
    ('NewSyntacticScopeCreator(iv.compiler),', 'scopeOpportunitySelectedCreator(iv.compiler, "inline_variables"),'),
])
patch('internal/jscomp/flow_sensitive_inline_variables.go', [
    ('\t\tSetCallback(f).\n\t\tTraverseRoots(externs, root)', '\t\tSetCallback(f).\n\t\tSetScopeCreator(scopeOpportunitySelectedCreator(f.compiler, "serial_fsiv")).\n\t\tTraverseRoots(externs, root)'),
])
patch('internal/jscomp/fsiv_scope_sharing.go', [
    ('\tvars := NodeUtil_GetAllVarsDeclaredInFunction(compiler, w, functionScope)\n\tw.recording = false\n\tDataFlowAnalysis_ComputeEscaped(functionScope, escaped, compiler, w, vars.GetAllVariables())', '''	previousScopeOpportunityPhase := w.delegate.scopeOpportunityPhase
	defer func() { if w.delegate != nil { w.delegate.scopeOpportunityPhase = previousScopeOpportunityPhase } }()
	w.delegate.scopeOpportunityPhase = "all_vars"
	vars := NodeUtil_GetAllVarsDeclaredInFunction(compiler, w, functionScope)
	w.recording = false
	w.delegate.scopeOpportunityPhase = "escaped"
	DataFlowAnalysis_ComputeEscaped(functionScope, escaped, compiler, w, vars.GetAllVariables())'''),
    ('\tvars := NodeUtil_GetAllVarsDeclaredInFunction(f.compiler, creator, body.GetParent())\n\tDataFlowAnalysis_ComputeEscaped(body.GetParent(), escaped, f.compiler, creator, vars.GetAllVariables())', '''	previousScopeOpportunityPhase := creator.scopeOpportunityPhase
	defer func() { creator.scopeOpportunityPhase = previousScopeOpportunityPhase }()
	creator.scopeOpportunityPhase = "all_vars"
	vars := NodeUtil_GetAllVarsDeclaredInFunction(f.compiler, creator, body.GetParent())
	creator.scopeOpportunityPhase = "escaped"
	DataFlowAnalysis_ComputeEscaped(body.GetParent(), escaped, f.compiler, creator, vars.GetAllVariables())'''),
])

implementation = out / 'scope_opportunity_diagnostic.go'
replace[str(root / 'internal/jscomp/scope_opportunity_diagnostic.go')] = str(implementation)
test = out / 'scope_opportunity_diagnostic_test.go'
if test.exists():
    replace[str(root / 'internal/jscomp/scope_opportunity_diagnostic_test.go')] = str(test)

# Formatting only; this does not compile, analyze or execute the Go package.
gofmt = Path('/workspace/toolchains/go1.27.2/bin/gofmt')
subprocess.run([str(gofmt), '-w', *[entry['replacement'] for entry in files], str(implementation), *([str(test)] if test.exists() else [])], check=True)
(out / 'overlay.json').write_text(json.dumps({'Replace': replace}, indent=2)+'\n')
for entry in files:
    entry['replacement_sha256'] = hashlib.sha256(Path(entry['replacement']).read_bytes()).hexdigest()
manifest = {
    'source_root': str(root),
    'source_commit': subprocess.check_output(['git','rev-parse','HEAD'], cwd=root, text=True).strip(),
    'base_overlay': None if args.base_overlay is None else str(args.base_overlay.resolve()),
    'source_only_unbuilt': True,
    'compiler_tracer_options_changed': False,
    'scope_var_compiler_fields_changed': False,
    'no_actual_scope_reuse': True,
    'output_env': 'JSGO_SCOPE_OPPORTUNITY_JSONL',
    'files': files,
    'implementation_sha256': hashlib.sha256(implementation.read_bytes()).hexdigest(),
    'test_sha256': hashlib.sha256(test.read_bytes()).hexdigest() if test.exists() else None,
    'map_model_source_sha256': {name: hashlib.sha256((root / 'internal/jutil' / name).read_bytes()).hexdigest() for name in ['collections.go','slab.go']},
    'overlay_sha256': hashlib.sha256((out/'overlay.json').read_bytes()).hexdigest(),
}
(out / 'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
print(json.dumps(manifest,indent=2))
