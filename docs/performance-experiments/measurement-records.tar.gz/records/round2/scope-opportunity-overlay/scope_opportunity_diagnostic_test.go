package jscomp

import (
	"encoding/json"
	"os"
	"path/filepath"
	"testing"

	"github.com/paullepoulpe/jsgo/internal/rhino"
)

func scopeOpportunityTestSetup(t *testing.T) (*Compiler, *scopeOpportunityDiagnostic, *rhino.Node) {
	t.Helper()
	t.Setenv("JSGO_SCOPE_OPPORTUNITY_JSONL", filepath.Join(t.TempDir(), "opportunities.jsonl"))
	c := newFunctionFSIVTestCompiler(t, 1, `function f(a){var x=a;use(x);return a;}use(f);`)
	p := NewPhaseOptimizer(c, nil)
	c.phaseOptimizer = p
	d := scopeOpportunityStart(p)
	p.scopeOpportunity = d
	t.Cleanup(func() { d.finish(); c.phaseOptimizer = nil; p.scopeOpportunity = nil })
	var fn *rhino.Node
	var visit func(*rhino.Node)
	visit = func(n *rhino.Node) {
		if n.IsFunction() && fn == nil {
			fn = n
		}
		for ch := n.GetFirstChild(); ch != nil; ch = ch.GetNext() {
			visit(ch)
		}
	}
	visit(c.GetJsRoot())
	if fn == nil {
		t.Fatal("fixture has no function")
	}
	return c, d, fn
}
func scopeOpportunityTestConstruction(c *Compiler, d *scopeOpportunityDiagnostic, fn *rhino.Node) (*Scope, *Scope, *Scope) {
	creator := scopeOpportunitySelectedCreator(c, "inline_variables")
	global := creator.CreateScopeOfScope(c.GetRoot(), nil)
	function := creator.CreateScopeOfScope(fn, global)
	body := creator.CreateScopeOfScope(fn.GetLastChild(), function)
	return global, function, body
}
func scopeOpportunityTestCount(d *scopeOpportunityDiagnostic, key string) uint64 {
	return d.active.Buckets[key].Scopes
}
func TestScopeOpportunityRealConstructorsRemainFreshAndCountCrossPass(t *testing.T) {
	c, d, fn := scopeOpportunityTestSetup(t)
	end := d.begin(PassNames_INLINE_VARIABLES)
	_, firstFn, firstBody := scopeOpportunityTestConstruction(c, d, fn)
	before := functionFSIVSnapshot(c)
	end()
	end = d.begin(PassNames_INLINE_VARIABLES)
	_, secondFn, secondBody := scopeOpportunityTestConstruction(c, d, fn)
	if firstFn == secondFn || firstBody == secondBody || firstBody.GetVar("x") == secondBody.GetVar("x") {
		t.Fatal("diagnostic reused real objects")
	}
	for _, policy := range []string{"function_epoch", "exact_declarations"} {
		if got := scopeOpportunityTestCount(d, policy+"/inline_variables/outer/cross_pass_opportunity"); got != 3 {
			t.Fatalf("%s cross-pass scopes=%d, want3", policy, got)
		}
	}
	// Constructors are observational: actual compiler output and change reports
	// remain exactly as before the second round of real scanner construction.
	after := functionFSIVSnapshot(c)
	if len(before) != len(after) {
		t.Fatal("construction changed compiler snapshot")
	}
	for i := range before {
		if before[i] != after[i] {
			t.Fatal("construction changed output or epochs")
		}
	}
	end()
}
func TestScopeOpportunityEpochAndExactPoliciesDivergeForBodyOnlyChange(t *testing.T) {
	c, d, fn := scopeOpportunityTestSetup(t)
	end := d.begin(PassNames_INLINE_VARIABLES)
	scopeOpportunityTestConstruction(c, d, fn)
	end()
	body := fn.GetLastChild()
	body.AddChildToBack(rhino.IR_ExprResult(rhino.IR_Number(1)))
	c.ReportChangeToEnclosingScope(body)
	end = d.begin(PassNames_INLINE_VARIABLES)
	scopeOpportunityTestConstruction(c, d, fn)
	if scopeOpportunityTestCount(d, "function_epoch/inline_variables/outer/function_epoch_changed") != 1 || scopeOpportunityTestCount(d, "function_epoch/inline_variables/outer/parent_generation_changed") != 1 {
		t.Fatal("function epoch miss did not invalidate its child generation")
	}
	if scopeOpportunityTestCount(d, "exact_declarations/inline_variables/outer/cross_pass_opportunity") != 3 {
		t.Fatal("exact declaration proof lost body-only opportunity")
	}
	end()
}
func TestScopeOpportunityGlobalDeclarationChangeInvalidatesDescendants(t *testing.T) {
	c, d, fn := scopeOpportunityTestSetup(t)
	end := d.begin(PassNames_INLINE_VARIABLES)
	scopeOpportunityTestConstruction(c, d, fn)
	end()
	declaration := rhino.IR_Var(rhino.IR_Name("added"))
	c.GetJsRoot().GetFirstChild().AddChildToBack(declaration)
	c.ReportChangeToEnclosingScope(declaration)
	end = d.begin(PassNames_INLINE_VARIABLES)
	scopeOpportunityTestConstruction(c, d, fn)
	for _, policy := range []string{"function_epoch", "exact_declarations"} {
		// Global ROOT has no epoch even though its SCRIPT declaration changed.
		if scopeOpportunityTestCount(d, policy+"/inline_variables/outer/declarations_changed_epoch_same") != 1 || scopeOpportunityTestCount(d, policy+"/inline_variables/outer/parent_generation_changed") != 2 {
			t.Fatal("root proof miss failed to cascade for " + policy)
		}
	}
	end()
}
func TestScopeOpportunityDetectsDirectMapMutationAndReleasesOnFinish(t *testing.T) {
	c, d, fn := scopeOpportunityTestSetup(t)
	end := d.begin(PassNames_INLINE_VARIABLES)
	_, _, body := scopeOpportunityTestConstruction(c, d, fn)
	end()
	body.ClearVarsInternal() // Deliberately no compiler change report or hooks.
	end = d.begin(PassNames_INLINE_VARIABLES)
	scopeOpportunityTestConstruction(c, d, fn)
	for _, policy := range []string{"function_epoch", "exact_declarations"} {
		if scopeOpportunityTestCount(d, policy+"/inline_variables/outer/cached_scope_or_var_mutated") != 1 {
			t.Fatal("direct map mutation escaped snapshot validation")
		}
	}
	end()
	path := d.path
	d.finish()
	for i := range d.policies {
		if d.policies[i].entries != nil || d.policies[i].physical != nil {
			t.Fatal("finish retained graph")
		}
	}
	b, err := os.ReadFile(path)
	if err != nil {
		t.Fatal(err)
	}
	var report map[string]any
	if err = json.Unmarshal(b, &report); err != nil {
		t.Fatal(err)
	}
}

func TestScopeOpportunityDetectsPublicVarReinitialization(t *testing.T) {
	c, d, fn := scopeOpportunityTestSetup(t)
	end := d.begin(PassNames_INLINE_VARIABLES)
	_, _, body := scopeOpportunityTestConstruction(c, d, fn)
	end()
	var variable *Var
	for v := range body.GetVarIterable() {
		variable = v
		break
	}
	if variable == nil {
		t.Fatal("fixture has no variable")
	}
	variable.InitAbstractVarBase(variable, "changed", variable.nameNode, body, int(variable.index), variable.input, nil)
	end = d.begin(PassNames_INLINE_VARIABLES)
	scopeOpportunityTestConstruction(c, d, fn)
	for _, policy := range []string{"function_epoch", "exact_declarations"} {
		if scopeOpportunityTestCount(d, policy+"/inline_variables/outer/cached_scope_or_var_mutated") != 1 {
			t.Fatal("Var reinitialization escaped snapshot validation")
		}
	}
	end()
}

type scopeOpportunityPanicPass struct {
	p          *PhaseOptimizer
	diagnostic *scopeOpportunityDiagnostic
}

func (p *scopeOpportunityPanicPass) Process(externs, root *rhino.Node) {
	p.diagnostic = p.p.scopeOpportunity
	panic("diagnostic lifetime test")
}
func TestScopeOpportunityOptimizerPanicReleasesObserver(t *testing.T) {
	t.Setenv("JSGO_SCOPE_OPPORTUNITY_JSONL", filepath.Join(t.TempDir(), "panic.jsonl"))
	c := newFunctionFSIVTestCompiler(t, 1, `function f(a){return a;}`)
	p := NewPhaseOptimizer(c, nil)
	c.phaseOptimizer = p
	defer func() { c.phaseOptimizer = nil }()
	pass := &scopeOpportunityPanicPass{p: p}
	p.passes = []CompilerPass{pass}
	func() {
		defer func() {
			if recover() == nil {
				t.Error("fixture did not panic")
			}
		}()
		p.Process(c.GetExternsRoot(), c.GetJsRoot())
	}()
	if pass.diagnostic == nil || !pass.diagnostic.finished || pass.diagnostic.owner != nil || p.scopeOpportunity != nil {
		t.Fatal("optimizer panic retained diagnostic owner")
	}
}
