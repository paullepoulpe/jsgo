package jscomp

// Diagnostic overlay only. Every original constructor and declaration scanner
// still executes. The two policies below assign shadow generations, never reuse
// or mutate an actual Scope/Var and never affect a production dispatch guard.
import (
	"encoding/json"
	"fmt"
	"os"
	"slices"
	"sync"
	"unsafe"

	"github.com/paullepoulpe/jsgo/internal/jutil"
	"github.com/paullepoulpe/jsgo/internal/rhino"
)

type scopeOpportunityWeight struct {
	Scopes     uint64 `json:"scopes"`
	Vars       uint64 `json:"live_explicit_vars"`
	Events     uint64 `json:"declaration_events"`
	ScopeBytes uint64 `json:"scope_payload_bytes"`
	VarBytes   uint64 `json:"live_var_payload_bytes"`
	MapBytes   uint64 `json:"ordered_map_payload_model_bytes"`
}

func (w *scopeOpportunityWeight) add(v scopeOpportunityWeight) {
	w.Scopes += v.Scopes
	w.Vars += v.Vars
	w.Events += v.Events
	w.ScopeBytes += v.ScopeBytes
	w.VarBytes += v.VarBytes
	w.MapBytes += v.MapBytes
}

type scopeOpportunityPass struct {
	ID        int                               `json:"invocation"`
	Name      string                            `json:"pass"`
	Buckets   map[string]scopeOpportunityWeight `json:"buckets"`
	Retention []map[string]any                  `json:"shadow_retention_after_pass"`
}
type scopeOpportunityDiagnostic struct {
	mu       sync.Mutex
	finished bool
	owner    *Compiler
	path     string
	active   *scopeOpportunityPass
	passes   []*scopeOpportunityPass
	policies [2]scopeOpportunityPolicy
}
type scopeOpportunityPolicy struct {
	name                                                          string
	epoch                                                         bool
	entries                                                       map[*rhino.Node]*scopeOpportunityEntry
	physical                                                      map[*Scope]uint64 // Reset at each NamedPass; not a compiler cache.
	next                                                          uint64
	peakEntries, peakVars, peakEvents, currentVars, currentEvents uint64
	currentVarCapacity, currentEventCapacity                      uint64
}
type scopeOpportunityContext struct {
	parent                                                  *rhino.Node
	input                                                   *rhino.InputId
	token                                                   rhino.Token
	arrow, functionExpression, classExpression, staticBlock bool
}
type scopeOpportunityEvent struct {
	node  *rhino.Node
	name  string
	input *CompilerInput
}
type scopeOpportunityVar struct {
	key   string
	value *Var
	node  *rhino.Node
	input *CompilerInput
}
type scopeOpportunityEntry struct {
	scope                        *Scope
	scopeRoot                    *rhino.Node
	scopeParent                  *Scope
	scopeDepth                   int
	context                      scopeOpportunityContext
	events                       []scopeOpportunityEvent
	vars                         []scopeOpportunityVar
	generation, parentGeneration uint64
	epochRoot                    *rhino.Node
	epochTime                    int32
	lastPass                     int
	lastName                     string
}
type scopeOpportunityObservation struct {
	diagnostic      *scopeOpportunityDiagnostic
	consumer, phase string
	events          []scopeOpportunityEvent
	unsafe          bool
}

func scopeOpportunityStart(p *PhaseOptimizer) *scopeOpportunityDiagnostic {
	path := os.Getenv("JSGO_SCOPE_OPPORTUNITY_JSONL")
	owner, ok := p.compiler.(*Compiler)
	if path == "" || !ok || owner == nil || owner.GetJsRoot() != p.jsRoot {
		return nil
	}
	d := &scopeOpportunityDiagnostic{owner: owner, path: path}
	d.policies[0] = scopeOpportunityPolicy{name: "function_epoch", epoch: true, entries: make(map[*rhino.Node]*scopeOpportunityEntry)}
	d.policies[1] = scopeOpportunityPolicy{name: "exact_declarations", entries: make(map[*rhino.Node]*scopeOpportunityEntry)}
	return d
}
func (d *scopeOpportunityDiagnostic) begin(name string) func() {
	if d == nil {
		return func() {}
	}
	previous := d.active
	d.active = &scopeOpportunityPass{ID: len(d.passes) + 1, Name: name, Buckets: make(map[string]scopeOpportunityWeight)}
	d.passes = append(d.passes, d.active)
	for i := range d.policies {
		d.policies[i].physical = make(map[*Scope]uint64)
	}
	return func() {
		for i := range d.policies {
			d.active.Retention = append(d.active.Retention, d.policies[i].retention())
			d.policies[i].physical = nil
		}
		d.active = previous
	}
}
func (d *scopeOpportunityDiagnostic) bucket(key string, w scopeOpportunityWeight) {
	if d.active == nil {
		return
	}
	v := d.active.Buckets[key]
	v.add(w)
	d.active.Buckets[key] = v
}
func (d *scopeOpportunityDiagnostic) finish() {
	if d == nil {
		return
	}
	d.mu.Lock()
	defer d.mu.Unlock()
	if d.finished {
		return
	}
	d.finished = true
	summaries := make([]map[string]any, 0, 2)
	for i := range d.policies {
		p := &d.policies[i]
		summaries = append(summaries, map[string]any{"policy": p.name, "peak_entries": p.peakEntries, "peak_live_vars": p.peakVars, "peak_event_length": p.peakEvents, "estimated_var_snapshot_payload_bytes": uint64(unsafe.Sizeof(scopeOpportunityVar{})) * p.peakVars, "event_snapshot_payload_bytes": uint64(unsafe.Sizeof(scopeOpportunityEvent{})) * p.peakEvents})
		p.entries = nil
		p.physical = nil // Release all diagnostic-retained AST/Scope/Var graphs even on panic.
	}
	report := map[string]any{"diagnostic": "scope-reconstruction-opportunities-v1", "passes": d.passes, "shadow_policy_retention": summaries, "not_a_performance_measurement": true, "byte_definition": "Scope/live-Var payloads use exact sizeof; ordered-map payload is a frozen-source allocation model; excludes runtime hash-index buckets, allocator rounding, transient/superseded declarations, and diagnostic allocations", "layout": map[string]uint64{"Scope": uint64(unsafe.Sizeof(Scope{})), "Var": uint64(unsafe.Sizeof(Var{})), "diagnosticVarSnapshot": uint64(unsafe.Sizeof(scopeOpportunityVar{})), "diagnosticEvent": uint64(unsafe.Sizeof(scopeOpportunityEvent{})), "diagnosticEntry": uint64(unsafe.Sizeof(scopeOpportunityEntry{}))}}
	f, err := os.OpenFile(d.path, os.O_CREATE|os.O_WRONLY|os.O_APPEND, 0600)
	if err == nil {
		err = json.NewEncoder(f).Encode(report)
		closeErr := f.Close()
		if err == nil {
			err = closeErr
		}
	}
	if err != nil {
		fmt.Fprintf(os.Stderr, "scope opportunity diagnostic: %v\n", err)
	}
	d.owner = nil
	d.active = nil
	d.passes = nil
}

// Private pass callsites mark only their own creator. No public constructor,
// custom compiler, callback or production eligibility guard changes behavior.
func scopeOpportunitySelectedCreator(compiler AbstractCompiler, consumer string) *SyntacticScopeCreator {
	c := NewSyntacticScopeCreator(compiler)
	c.scopeOpportunityConsumer = consumer
	return c
}
func scopeOpportunityForCreator(c *SyntacticScopeCreator) *scopeOpportunityDiagnostic {
	owner, ok := c.compiler.(*Compiler)
	if !ok || owner == nil || owner.phaseOptimizer == nil {
		return nil
	}
	d := owner.phaseOptimizer.scopeOpportunity
	if d == nil || d.owner != owner || d.active == nil {
		return nil
	}
	return d
}
func scopeOpportunityEligible(d *scopeOpportunityDiagnostic, c *SyntacticScopeCreator) bool {
	o := d.owner.GetOptions()
	if c.scopeOpportunityConsumer == "" || o == nil || o.customPasses != nil || !d.owner.GetLifeCycleStage().IsNormalizedUnobfuscated() || d.owner.IsDebugLoggingEnabled() {
		return false
	}
	switch d.active.Name {
	case PassNames_INLINE_VARIABLES, PassNames_FLOW_SENSITIVE_INLINE_VARIABLES, "inlineConstants", "earlyInlineVariables":
	default:
		return false
	}
	h, ok := c.redeclarationHandler.(*SyntacticScopeCreator_DefaultRedeclarationHandler)
	return ok && h != nil && !c.treatProvidesAsRedeclarations && parallelFSIVObserversSafe(d.owner)
}
func scopeOpportunityPrepare(c *SyntacticScopeCreator) *scopeOpportunityObservation {
	d := scopeOpportunityForCreator(c)
	if d == nil || !scopeOpportunityEligible(d, c) {
		return nil
	}
	phase := c.scopeOpportunityPhase
	if phase == "" {
		phase = "outer"
	}
	return &scopeOpportunityObservation{diagnostic: d, consumer: c.scopeOpportunityConsumer, phase: phase}
}
func (o *scopeOpportunityObservation) declaration(s *SyntacticScopeCreator_ScopeScanner, n *rhino.Node) {
	if o == nil {
		return
	}
	// compiler is the exact stock owner; GetInput is a read-only map lookup.
	o.events = append(o.events, scopeOpportunityEvent{node: n, name: n.GetString(), input: o.diagnostic.owner.GetInput(s.inputId)})
}
func scopeOpportunityContextOf(n *rhino.Node) scopeOpportunityContext {
	return scopeOpportunityContext{parent: n.GetParent(), input: NodeUtil_GetInputId(n), token: n.GetToken(), arrow: n.IsArrowFunction(), functionExpression: n.IsFunction() && NodeUtil_IsFunctionExpression(n), classExpression: n.IsClass() && NodeUtil_IsClassExpression(n), staticBlock: n.IsBlock() && NodeUtil_IsClassStaticBlock(n)}
}
func scopeOpportunityEpoch(n *rhino.Node) (*rhino.Node, int32) {
	for n != nil && !n.IsFunction() && !n.IsScript() {
		n = n.GetParent()
	}
	if n == nil {
		return nil, 0
	}
	return n, n.GetChangeTime()
}

// This is payload accounting, not runtime allocation accounting. A fresh scan
// without implicit namespace replacement allocates the first nine map entries
// individually, then 16/32/64/128-entry slabs. Runtime index buckets are opaque.
func scopeOpportunityWeightOf(scope *Scope, events int) scopeOpportunityWeight {
	n := scope.GetVarCount()
	w := scopeOpportunityWeight{Scopes: 1, Vars: uint64(n), Events: uint64(events), ScopeBytes: uint64(unsafe.Sizeof(*scope)), VarBytes: uint64(n) * uint64(unsafe.Sizeof(Var{}))}
	if scope.vars == nil {
		return w
	}
	w.MapBytes = uint64(unsafe.Sizeof(*scope.vars))
	type entry struct {
		key        string
		value      *Var
		prev, next *entry
	}
	entryBytes := uint64(unsafe.Sizeof(entry{}))
	if n <= 8 {
		w.MapBytes += uint64(n) * entryBytes
		return w
	}
	w.MapBytes += 9 * entryBytes
	type large struct {
		index   map[string]*entry
		entries jutil.Slab[entry]
	}
	w.MapBytes += uint64(unsafe.Sizeof(large{}))
	left, chunk := n-9, 16
	for left > 0 {
		w.MapBytes += uint64(chunk) * entryBytes
		left -= chunk
		if chunk < 128 {
			chunk *= 2
		}
	}
	return w
}
func scopeOpportunityVars(scope *Scope) []scopeOpportunityVar {
	if scope.GetVarCount() == 0 {
		return nil
	}
	vars := make([]scopeOpportunityVar, 0, scope.GetVarCount())
	for key, v := range scope.vars.All() {
		vars = append(vars, scopeOpportunityVar{key: key, value: v, node: v.nameNode, input: v.input})
	}
	return vars
}
func scopeOpportunitySnapshotValid(e *scopeOpportunityEntry) bool {
	s := e.scope
	if s.self != s || s.rootNode == nil || s.rootNode.IsDeleted() || s.rootNode != e.scopeRoot || s.parent != e.scopeParent || s.depth != e.scopeDepth || len(e.vars) != s.GetVarCount() {
		return false
	}
	i := 0
	for key, v := range s.vars.All() {
		if i >= len(e.vars) {
			return false
		}
		expected := e.vars[i]
		if v == nil || key != expected.key || v != expected.value || v.self != v || v.name != key || v.nameNode != expected.node || v.input != expected.input || v.scope != s || v.index != int32(i) || v.implicitGoogNamespaceStrength != nil {
			return false
		}
		i++
	}
	if s.parent == nil {
		if s.depth != 0 {
			return false
		}
	} else if s.depth != s.parent.depth+1 {
		return false
	}
	// Ordinary reads may lazily materialize implicit Vars. Validate their
	// canonical metadata without rejecting that legitimate lazy population.
	if s.implicitVars != nil {
		for index, v := range s.implicitVars {
			if v == nil {
				continue
			}
			implicit := AbstractScope_ImplicitVar(index)
			if !s.HasOwnImplicitSlot(&implicit) || v.self != v || v.scope != s || v.name != implicit.name() || v.nameNode != nil || v.input != nil || v.index != -1 || v.implicitGoogNamespaceStrength != nil {
				return false
			}
		}
	}
	return true
}

func scopeOpportunityRecord(c *SyntacticScopeCreator, scope *Scope, o *scopeOpportunityObservation) {
	d := scopeOpportunityForCreator(c)
	if d == nil {
		return
	}
	d.mu.Lock()
	defer d.mu.Unlock()
	events := 0
	if o != nil {
		events = len(o.events)
	}
	w := scopeOpportunityWeightOf(scope, events)
	d.bucket("all_creators/"+scope.rootNode.GetToken().String(), w)
	d.bucket(fmt.Sprintf("all_creator_decl_count/%d", scope.GetVarCount()), w)
	if c.scopeOpportunityConsumer == "" {
		d.bucket("unselected_creator", w)
		return
	}
	if o == nil {
		d.bucket(c.scopeOpportunityConsumer+"/ineligible_context", w)
		return
	}
	d.bucket(fmt.Sprintf("selected_decl_count/%s/%d", o.consumer, scope.GetVarCount()), w)
	for i := range d.policies {
		d.policies[i].record(o, scope, w)
	}
}
func (p *scopeOpportunityPolicy) record(o *scopeOpportunityObservation, s *Scope, w scopeOpportunityWeight) {
	d := o.diagnostic
	prefix := p.name + "/" + o.consumer + "/" + o.phase + "/"
	parentGeneration := uint64(0)
	if s.parent != nil {
		var ok bool
		parentGeneration, ok = p.physical[s.parent]
		if !ok || parentGeneration == 0 {
			d.bucket(prefix+"parent_not_selected", w)
			return
		}
	}
	if o.unsafe || s.rootNode.IsModuleBody() {
		d.bucket(prefix+"module_or_provide", w)
		return
	}
	root := s.rootNode
	context := scopeOpportunityContextOf(root)
	epochRoot, epochTime := scopeOpportunityEpoch(root)
	e := p.entries[root]
	reason := "first_construction"
	if e != nil {
		switch {
		case e.parentGeneration != parentGeneration:
			reason = "parent_generation_changed"
		case e.context != context:
			reason = "root_context_changed"
		case e.scope.rootNode != root || !scopeOpportunitySnapshotValid(e):
			reason = "cached_scope_or_var_mutated"
		case !slices.Equal(e.events, o.events):
			if e.epochRoot == epochRoot && e.epochTime == epochTime {
				reason = "declarations_changed_epoch_same"
			} else {
				reason = "declarations_changed"
			}
		case p.epoch && s.parent != nil && (e.epochRoot != epochRoot || e.epochTime != epochTime):
			reason = "function_epoch_changed"
		default:
			kind := "same_pass_opportunity"
			if e.lastPass != d.active.ID {
				kind = "cross_pass_opportunity"
			}
			d.bucket(prefix+kind, w)
			if kind == "cross_pass_opportunity" {
				d.bucket(prefix+"from_pass/"+e.lastName, w)
			}
			p.physical[s] = e.generation
			e.lastPass = d.active.ID
			e.lastName = d.active.Name
			return
		}
	}
	d.bucket(prefix+reason, w)
	p.next++
	entry := &scopeOpportunityEntry{scope: s, scopeRoot: root, scopeParent: s.parent, scopeDepth: s.depth, context: context, events: slices.Clone(o.events), vars: scopeOpportunityVars(s), generation: p.next, parentGeneration: parentGeneration, epochRoot: epochRoot, epochTime: epochTime, lastPass: d.active.ID, lastName: d.active.Name}
	if e != nil {
		p.currentVars -= uint64(len(e.vars))
		p.currentEvents -= uint64(len(e.events))
		p.currentVarCapacity -= uint64(cap(e.vars))
		p.currentEventCapacity -= uint64(cap(e.events))
	}
	p.entries[root] = entry
	p.physical[s] = entry.generation
	p.currentVars += uint64(len(entry.vars))
	p.currentEvents += uint64(len(entry.events))
	p.currentVarCapacity += uint64(cap(entry.vars))
	p.currentEventCapacity += uint64(cap(entry.events))
	p.peakEntries = max(p.peakEntries, uint64(len(p.entries)))
	p.peakVars = max(p.peakVars, p.currentVars)
	p.peakEvents = max(p.peakEvents, p.currentEvents)
}

func (p *scopeOpportunityPolicy) retention() map[string]any {
	seen := make(map[*Scope]bool)
	var graph scopeOpportunityWeight
	deleted, changedEpoch, staleParent := uint64(0), uint64(0), uint64(0)
	for root, e := range p.entries {
		if root.IsDeleted() || root.GetParent() == nil && e.scopeParent != nil {
			deleted++
		}
		ep, tm := scopeOpportunityEpoch(root)
		if ep != e.epochRoot || tm != e.epochTime {
			changedEpoch++
		}
		if e.scopeParent != nil {
			parent := p.entries[e.scopeParent.rootNode]
			if parent == nil || parent.generation != e.parentGeneration {
				staleParent++
			}
		}
		for s := e.scope; s != nil && !seen[s]; s = s.parent {
			seen[s] = true
			graph.add(scopeOpportunityWeightOf(s, 0))
		}
	}
	return map[string]any{"policy": p.name, "entries": len(p.entries), "snapshot_live_vars": p.currentVars, "snapshot_event_lengths": p.currentEvents, "deleted_or_detached_entries": deleted, "epoch_changed_entries": changedEpoch, "stale_parent_generation_entries": staleParent, "unique_retained_diagnostic_actual_graph_payload": graph, "diagnostic_snapshot_var_capacity_bytes": uint64(unsafe.Sizeof(scopeOpportunityVar{})) * p.currentVarCapacity, "diagnostic_event_capacity_bytes": uint64(unsafe.Sizeof(scopeOpportunityEvent{})) * p.currentEventCapacity, "diagnostic_entry_payload_bytes": uint64(unsafe.Sizeof(scopeOpportunityEntry{})) * uint64(len(p.entries))}
}
