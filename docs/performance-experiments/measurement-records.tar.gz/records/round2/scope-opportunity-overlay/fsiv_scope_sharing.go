package jscomp

import (
	"os"

	"github.com/paullepoulpe/jsgo/internal/jutil"
	"github.com/paullepoulpe/jsgo/internal/rhino"
)

// Only stock serial FSIV may change these internal scope identities. Public
// helpers and custom compilers/conventions/observers keep their original path.
func fsivScopeSharingEnabled(compiler AbstractCompiler) bool {
	if os.Getenv("JSGO_EXPERIMENT_FSIV_SCOPE_SHARING") != "1" {
		return false
	}
	owner, ok := compiler.(*Compiler)
	return ok && owner != nil && owner.GetOptions() != nil && owner.changeTracker != nil &&
		owner.GetLifeCycleStage().IsNormalizedUnobfuscated() && !owner.IsDebugLoggingEnabled() &&
		fsivScopeSharingConventionSafe(owner.GetCodingConvention()) &&
		parallelFSIVObserversSafe(owner)
}

func fsivScopeSharingConventionSafe(convention CodingConvention) bool {
	switch c := convention.(type) {
	case *CodingConventions_DefaultCodingConvention:
		return c != nil
	case *ClosureCodingConvention:
		return c != nil && c.self == c && fsivScopeSharingConventionSafe(c.nextConvention)
	case *GoogleCodingConvention:
		return c != nil && c.self == c && fsivScopeSharingConventionSafe(c.nextConvention)
	default:
		return false
	}
}

type fsivScopeSharingStats struct {
	CollectRequests, CollectHits, EscapeRequests, EscapeHits int
	SeedHits, RecordedScopes, UncachedScopes                 int
	Completed, Released                                      bool
}

type fsivScopeSharingKey struct {
	root   *rhino.Node
	parent *Scope
}

// A window exists for exactly the all-vars and escaped-variable traversals.
// The first reads declarations into fresh output collections. The second reads
// names and stock IsExported answers into its escaped output set. Neither edits
// the AST or scope declarations. Candidate gathering and all rewrites happen
// after collect returns and its deferred release has removed every retained key.
type fsivScopeSharingWindow struct {
	delegate  *SyntacticScopeCreator
	seed      *Scope
	entries   map[fsivScopeSharingKey]*Scope
	recording bool
	stats     *fsivScopeSharingStats
}

func newFSIVScopeSharingWindow(delegate *SyntacticScopeCreator, body *Scope, observe bool) *fsivScopeSharingWindow {
	window := &fsivScopeSharingWindow{delegate: delegate, seed: body, recording: true}
	if observe {
		window.stats = &fsivScopeSharingStats{}
	}
	return window
}

func (w *fsivScopeSharingWindow) CreateScope(root *rhino.Node, parent AbstractScope) AbstractScope {
	jutil.CheckStateMsg(w.delegate != nil, "FSIV scope sharing window is closed")
	var typedParent *Scope
	if parent != nil {
		typedParent = parent.(*Scope) // Same checked cast as SyntacticScopeCreator.
	}
	if w.stats != nil {
		if w.recording {
			w.stats.CollectRequests++
		} else {
			w.stats.EscapeRequests++
		}
	}
	if w.seed != nil && root == w.seed.GetRootNode() && typedParent == w.seed.GetParent() {
		w.hit()
		if w.stats != nil {
			w.stats.SeedHits++
		}
		return w.seed
	}
	key := fsivScopeSharingKey{root: root, parent: typedParent}
	if scope := w.entries[key]; scope != nil {
		w.hit()
		return scope
	}
	scope := w.delegate.CreateScopeOfScope(root, typedParent)
	if w.recording {
		if w.entries == nil {
			w.entries = make(map[fsivScopeSharingKey]*Scope)
		}
		w.entries[key] = scope
		if w.stats != nil {
			w.stats.RecordedScopes++
		}
	} else {
		// Nested/default-parameter functions are first visited by the escaped
		// analysis. They cannot benefit from recording and keep fresh scopes.
		if w.stats != nil {
			w.stats.UncachedScopes++
		}
	}
	return scope
}

func (w *fsivScopeSharingWindow) hit() {
	if w.stats != nil {
		if w.recording {
			w.stats.CollectHits++
		} else {
			w.stats.EscapeHits++
		}
	}
}

func (w *fsivScopeSharingWindow) release() {
	w.delegate, w.seed, w.entries = nil, nil, nil
	w.recording = false
	if w.stats != nil {
		w.stats.Released = true
	}
}

func (w *fsivScopeSharingWindow) collect(compiler AbstractCompiler, functionScope *Scope, escaped *jutil.ObjectLinkedHashSet[*Var]) *NodeUtil_AllVarsDeclaredInFunction {
	defer w.release()
	previousScopeOpportunityPhase := w.delegate.scopeOpportunityPhase
	defer func() {
		if w.delegate != nil {
			w.delegate.scopeOpportunityPhase = previousScopeOpportunityPhase
		}
	}()
	w.delegate.scopeOpportunityPhase = "all_vars"
	vars := NodeUtil_GetAllVarsDeclaredInFunction(compiler, w, functionScope)
	w.recording = false
	w.delegate.scopeOpportunityPhase = "escaped"
	DataFlowAnalysis_ComputeEscaped(functionScope, escaped, compiler, w, vars.GetAllVariables())
	if w.stats != nil {
		w.stats.Completed = true
	}
	return vars
}

func (f *FlowSensitiveInlineVariables) collectReadOnlyScopeFacts(creator *SyntacticScopeCreator, body *Scope, escaped *jutil.ObjectLinkedHashSet[*Var]) *NodeUtil_AllVarsDeclaredInFunction {
	if !f.scopeSharingAllowed {
		return f.collectFreshScopeFacts(creator, body, escaped)
	}
	handler, stockHandler := creator.redeclarationHandler.(*SyntacticScopeCreator_DefaultRedeclarationHandler)
	owner, stockOwner := f.compiler.(*Compiler)
	creatorOwner, stockCreator := creator.compiler.(*Compiler)
	if !stockHandler || handler == nil || !stockOwner || !stockCreator || owner != creatorOwner || creator.treatProvidesAsRedeclarations {
		return f.collectFreshScopeFacts(creator, body, escaped)
	}
	window := newFSIVScopeSharingWindow(creator, body, f.scopeSharingObserver != nil)
	if f.scopeSharingObserver != nil {
		defer func() {
			f.scopeSharingObserver(*window.stats) // collect released before this defer runs.
		}()
	}
	return window.collect(f.compiler, body.GetParent(), escaped)
}

func (f *FlowSensitiveInlineVariables) collectFreshScopeFacts(creator *SyntacticScopeCreator, body *Scope, escaped *jutil.ObjectLinkedHashSet[*Var]) *NodeUtil_AllVarsDeclaredInFunction {
	previousScopeOpportunityPhase := creator.scopeOpportunityPhase
	defer func() { creator.scopeOpportunityPhase = previousScopeOpportunityPhase }()
	creator.scopeOpportunityPhase = "all_vars"
	vars := NodeUtil_GetAllVarsDeclaredInFunction(f.compiler, creator, body.GetParent())
	creator.scopeOpportunityPhase = "escaped"
	DataFlowAnalysis_ComputeEscaped(body.GetParent(), escaped, f.compiler, creator, vars.GetAllVariables())
	return vars
}
