#!/usr/bin/env python3
"""Summarize future untimed counter JSONL; never interpret its timings/memory."""
import argparse
import json
from collections import defaultdict
from pathlib import Path

p=argparse.ArgumentParser()
p.add_argument('jsonl',type=Path)
args=p.parse_args()
totals=defaultdict(lambda:defaultdict(int))
all_creators=defaultdict(int)
transitions=defaultdict(lambda:defaultdict(int))
retention=[]
records=0
for line in args.jsonl.read_text().splitlines():
    record=json.loads(line)
    if record.get('diagnostic')!='scope-reconstruction-opportunities-v1':
        raise SystemExit('unexpected diagnostic schema')
    records+=1
    for run in record['passes']:
        for key,weight in run['buckets'].items():
            parts=key.split('/')
            if parts[0]=='all_creators':
                for field,value in weight.items():all_creators[field]+=value
            if parts[0] not in ['function_epoch','exact_declarations']:continue
            if len(parts)==4:
                target=totals[(run['pass'],*parts)]
            elif len(parts)==5 and parts[3]=='from_pass':
                target=transitions[(run['pass'],*parts)]
            else:continue
            for field,value in weight.items():target[field]+=value
        for r in run['shadow_retention_after_pass']:
            retention.append({'pass':run['pass'],'invocation':run['invocation'],**r})

def rows(source):
    return [{'pass':key[0],'policy':key[1],'consumer':key[2],'phase':key[3],
             'reason':key[4],**({'from_pass':key[5]} if len(key)==6 else {}),**weight}
            for key,weight in sorted(source.items())]
print(json.dumps({'records':records,'all_observed_creator_weight':dict(all_creators),
                  'disjoint_policy_reason_weights':rows(totals),
                  'cross_pass_transitions_overlapping_opportunity_totals':rows(transitions),
                  'retention_by_pass':retention,
                  'not_a_performance_measurement':True},indent=2))
