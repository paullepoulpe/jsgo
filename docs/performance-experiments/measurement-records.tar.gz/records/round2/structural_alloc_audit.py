#!/usr/bin/env python3
"""Read existing post-GC heap profiles; capture no new workload or profile."""
import argparse
import collections
import hashlib
import json
import re
from pathlib import Path

from label_hotspots import symbols
from pprof_data import load_profile

PREFIX = 'github.com/paullepoulpe/jsgo/'
PROCESS = re.compile(r'internal/jscomp\.\(\*([^)]*)\)\.Process(?:$|\.func)')
EXCLUDE = {'Compiler', 'PhaseOptimizer', 'NodeTraversal', 'ReferenceCollector'}


def owner(frames):
    # Report identifiable outer pass roots, not whichever helper first calls
    # Process. Heap profiles retain 512 PCs, unlike the older CPU64 captures.
    roots = []
    for frame in frames:
        match = PROCESS.search(frame)
        if match and match[1] not in EXCLUDE and not match[1].startswith('PhaseOptimizer_'):
            roots.append(match[1])
    return roots[-1] if roots else '(no owning Process root identified)'


def audit(path, limit):
    profile = load_profile(path)
    locations = symbols(profile)
    columns = [profile.sample_types.index((name, unit)) for name, unit in
               [('alloc_objects', 'count'), ('alloc_space', 'bytes')]]
    by_leaf = collections.defaultdict(lambda: [0, 0])
    by_caller = collections.defaultdict(lambda: [0, 0])
    by_owner = collections.defaultdict(lambda: [0, 0])
    by_owner_leaf = collections.defaultdict(lambda: [0, 0])
    by_owner_caller = collections.defaultdict(lambda: [0, 0])
    by_function = collections.defaultdict(lambda: [0, 0])
    totals = [0, 0]
    max_depth = 0
    depth512 = [0, 0]
    for sample in profile.samples:
        values = [sample.values[index] for index in columns]
        frames = [frame.removeprefix(PREFIX) for loc in sample.locations
                  for frame in locations.get(loc, [])]
        max_depth = max(max_depth, len(sample.locations))
        if len(sample.locations) >= 512:
            for i, value in enumerate(values):
                depth512[i] += value
        leaf = frames[0] if frames else '(no function)'
        caller = next((frame for frame in frames if frame.startswith('internal/jscomp.')),
                      '(no jscomp frame)')
        pass_owner = owner(frames)
        keys = [(by_leaf, leaf), (by_caller, caller), (by_owner, pass_owner),
                (by_owner_leaf, (pass_owner, leaf)),
                (by_owner_caller, (pass_owner, caller))]
        keys.extend((by_function, frame) for frame in set(frames))
        for bucket, key in keys:
            for i, value in enumerate(values):
                bucket[key][i] += value
        for i, value in enumerate(values):
            totals[i] += value

    def rows(bucket, sort_column, count=limit):
        return [{'key': key, 'objects': value[0], 'bytes': value[1],
                 'object_fraction': value[0] / totals[0] if totals[0] else 0,
                 'byte_fraction': value[1] / totals[1] if totals[1] else 0}
                for key, value in sorted(bucket.items(),
                                         key=lambda item: item[1][sort_column],
                                         reverse=True)[:count]]

    return {'path': str(path), 'sha256': hashlib.sha256(path.read_bytes()).hexdigest(),
            'sampled_alloc_objects': totals[0], 'sampled_alloc_bytes': totals[1],
            'max_sample_location_depth': max_depth,
            'mass_at_location_depth_ge_512': {'objects': depth512[0], 'bytes': depth512[1]},
            'leaf_by_bytes': rows(by_leaf, 1), 'leaf_by_objects': rows(by_leaf, 0),
            'nearest_jscomp_caller_by_bytes': rows(by_caller, 1),
            'nearest_jscomp_caller_by_objects': rows(by_caller, 0),
            'owning_pass_by_bytes': rows(by_owner, 1),
            'owning_pass_by_objects': rows(by_owner, 0),
            'pass_and_leaf_by_bytes': rows(by_owner_leaf, 1, 3 * limit),
            'pass_and_leaf_by_objects': rows(by_owner_leaf, 0, 3 * limit),
            'pass_and_caller_by_bytes': rows(by_owner_caller, 1, 3 * limit),
            'pass_and_caller_by_objects': rows(by_owner_caller, 0, 3 * limit),
            'inclusive_function_by_bytes': rows(by_function, 1, 3 * limit)}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--root', type=Path, required=True)
    parser.add_argument('--out', type=Path, required=True)
    parser.add_argument('--tasks', nargs='+', default=['bundle', 'typed-app', 'checks-only'])
    parser.add_argument('--limit', type=int, default=50)
    args = parser.parse_args()
    output = {'method': 'Existing post-forcedGC heap profiles; alloc_space/alloc_objects. '
              'Leaf and nearest-caller buckets are exclusive. Function ancestry is inclusive '
              'and overlapping. Owning-pass bucket is the outermost identifiable jscomp '
              'Process root, excluding compiler/traversal/helper wrappers; unrecognized '
              'closures remain explicitly unattributed. Sampled counts are estimates.',
              'tasks': {}}
    for task in args.tasks:
        result = audit(args.root / task / 'profile.live.pprof', args.limit)
        memstats = json.loads((args.root / task / 'profile.memstats.json').read_text())
        result['memstats_alloc_bytes_delta'] = memstats['after']['TotalAlloc'] - memstats['before']['TotalAlloc']
        result['memstats_mallocs_delta'] = memstats['after']['Mallocs'] - memstats['before']['Mallocs']
        output['tasks'][task] = result
        print(task, result['sampled_alloc_bytes'], result['sampled_alloc_objects'],
              'exact', result['memstats_alloc_bytes_delta'], result['memstats_mallocs_delta'])
        for row in result['nearest_jscomp_caller_by_bytes'][:12]:
            print(round(row['bytes'] / 1048576, 2), row['objects'], row['key'])
    args.out.write_text(json.dumps(output, indent=2) + '\n')


if __name__ == '__main__':
    main()
