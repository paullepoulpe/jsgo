#!/usr/bin/env bash
set -euo pipefail
while pgrep -f '^python3 -I -u tools/bench/bench.py run --out /workspace/jsgo-results/baseline' >/dev/null; do sleep 5; done
. /workspace/toolchains/env.sh
cd /workspace/jsgo
echo 'Starting interleaved Go 1.24 / 1.27 comparison'
taskset -c 0,1 python3 -I -u tools/bench/experiments.py --reference /workspace/jsgo-results/baseline --out /workspace/jsgo-results/toolchain --variant go124=/workspace/jsgo/bin/jsgo-go124 --variant go127=/workspace/jsgo/bin/jsgo-go127 --runs 3
printf '\nToolchain comparison complete; building isolated candidates.\n'
cd /workspace/jsgo-collections
GOMAXPROCS=2 go test -p 2 ./internal/jutil > /workspace/jsgo-results/test-collections.log 2>&1
GOMAXPROCS=2 go build -p 2 -o /workspace/jsgo/bin/jsgo-collections ./cmd/jsgo > /workspace/jsgo-results/build-collections.log 2>&1
cd /workspace/jsgo-dataflow
GOMAXPROCS=2 go test -p 2 ./internal/jscomp -run 'TestMustDefDenseStateDifferential|TestMustBeReachingVariableDefTest|TestFlowSensitiveInlineVariables' -count=1 > /workspace/jsgo-results/test-dataflow.log 2>&1
GOMAXPROCS=2 go build -p 2 -o /workspace/jsgo/bin/jsgo-dataflow ./cmd/jsgo > /workspace/jsgo-results/build-dataflow.log 2>&1
cd /workspace/jsgo-node-chunks
GOMAXPROCS=2 go test -p 2 ./internal/rhino > /workspace/jsgo-results/test-node-chunks.log 2>&1
GOMAXPROCS=2 go build -p 2 -o /workspace/jsgo/bin/jsgo-node-chunks ./cmd/jsgo > /workspace/jsgo-results/build-node-chunks.log 2>&1
cd /workspace/jsgo-extern-cache
GOMAXPROCS=2 go test -p 2 ./internal/parsing -run 'TestBuiltinExternCacheIsolation' -count=1 > /workspace/jsgo-results/test-extern-cache.log 2>&1
GOMAXPROCS=2 go build -p 2 -o /workspace/jsgo/bin/gowarm ./tools/bench/gowarm > /workspace/jsgo-results/build-gowarm.log 2>&1
printf '\nAll isolated candidates built.\n'
