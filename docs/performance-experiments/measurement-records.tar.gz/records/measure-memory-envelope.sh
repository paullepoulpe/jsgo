#!/usr/bin/env bash
set -euo pipefail
. /workspace/toolchains/env.sh
cd /workspace/jsgo
taskset -c 0,1 python3 -I -u tools/bench/experiments.py --reference /workspace/jsgo-results/baseline --out /workspace/jsgo-results/memory-envelope --tasks typed-app,bundle,downlevel-whitespace --variant default=/workspace/jsgo/bin/jsgo-combined --variant gc200=/workspace/jsgo-results/jsgo-combined-gogc-200 --variant gc400=/workspace/jsgo-results/jsgo-combined-gogc-400 --variant gc800=/workspace/jsgo-results/jsgo-combined-gogc-800 --variant gcoff=/workspace/jsgo-results/jsgo-combined-gogc-off --runs 3 > /workspace/jsgo-results/memory-envelope.log 2>&1
