#!/usr/bin/env bash
set -euo pipefail
. /workspace/toolchains/env.sh
export PATH=/workspace/toolchains/go1.27.2/bin:$PATH
cd /workspace/jsgo-delivery
GOMAXPROCS=2 GOGC=20 go test -c -p 1 -o /workspace/jsgo-results/jscomp.test ./internal/jscomp > /workspace/jsgo-results/build-jscomp-tests-low-memory.log 2>&1
cd /workspace/jsgo-delivery/internal/jscomp
GOMAXPROCS=2 /workspace/jsgo-results/jscomp.test -test.timeout=45m > /workspace/jsgo-results/test-jscomp-full.log 2>&1
cd /workspace/jsgo-delivery
GOMAXPROCS=2 go test -p 1 ./... > /workspace/jsgo-results/test-delivery-full-retry.log 2>&1
GOMAXPROCS=2 go vet -p 1 ./internal/... > /workspace/jsgo-results/vet-delivery.log 2>&1
go run ./tools/licenses -check > /workspace/jsgo-results/licenses-delivery.log 2>&1
