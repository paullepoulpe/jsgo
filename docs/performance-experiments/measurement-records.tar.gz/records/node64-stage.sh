#!/usr/bin/env bash
set -euo pipefail
. /workspace/toolchains/env.sh
export PATH=/workspace/toolchains/go1.27.2/bin:$PATH
until [ -f /workspace/jsgo-results/refreshed-smoke/summary.json ] && python3 -c 'import json; assert "checks-only" in json.load(open("/workspace/jsgo-results/refreshed-smoke/summary.json"))' >/dev/null 2>&1; do sleep 3; done
cd /workspace/jsgo-node64
GOMAXPROCS=2 go test -p 2 -gcflags=all=-d=checkptr=2 ./internal/rhino ./internal/parsing > /workspace/jsgo-results/test-node64.log 2>&1
GOMAXPROCS=2 go build -buildvcs=false -p 2 -o /workspace/jsgo/bin/jsgo-node64 ./cmd/jsgo > /workspace/jsgo-results/build-node64.log 2>&1
