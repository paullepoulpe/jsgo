#!/usr/bin/env bash
set -euo pipefail
. /workspace/toolchains/env.sh
while kill -0 8968 2>/dev/null; do sleep 3; done
cd /workspace/jsgo-compact-parser
GOMAXPROCS=2 go test -p 2 -gcflags=all=-d=checkptr=2 ./internal/parser ./internal/parsing > /workspace/jsgo-results/test-compact-parser.log 2>&1
GOMAXPROCS=2 go build -buildvcs=false -p 2 -o /workspace/jsgo/bin/jsgo-compact-parser ./cmd/jsgo > /workspace/jsgo-results/build-compact-parser.log 2>&1
cd /workspace/jsgo-combined
GOMAXPROCS=2 go build -buildvcs=false -p 2 -o /workspace/jsgo/bin/jsgo-combined ./cmd/jsgo > /workspace/jsgo-results/build-combined.log 2>&1
GOMAXPROCS=2 go build -buildvcs=false -p 2 -pgo=cmd/jsgo/default.pgo -o /workspace/jsgo/bin/gowarm-combined ./tools/bench/gowarm > /workspace/jsgo-results/build-gowarm-combined.log 2>&1
