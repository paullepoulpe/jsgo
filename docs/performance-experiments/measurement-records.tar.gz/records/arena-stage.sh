#!/usr/bin/env bash
set -euo pipefail
. /workspace/toolchains/env.sh
export PATH=/workspace/toolchains/go1.27.2/bin:$PATH
until [ -f /workspace/jsgo-results/small-worker/summary.json ] && python3 -c 'import json; assert "small-checks" in json.load(open("/workspace/jsgo-results/small-worker/summary.json"))' >/dev/null 2>&1; do sleep 3; done
cd /workspace/jsgo-process-arena
GOMAXPROCS=2 go build -buildvcs=false -p 2 -o /workspace/jsgo/bin/jsgo-arena-heap-control ./cmd/jsgo > /workspace/jsgo-results/build-arena-heap-control.log 2>&1
GOEXPERIMENT=arenas GOMAXPROCS=2 go build -buildvcs=false -p 2 -o /workspace/jsgo/bin/jsgo-process-arena ./cmd/jsgo > /workspace/jsgo-results/build-process-arena.log 2>&1
cd /workspace/jsgo
taskset -c 0,1 python3 -I -u tools/bench/experiments.py --reference /workspace/jsgo-results/baseline --out /workspace/jsgo-results/arena-smoke --tasks typed-app,bundle,downlevel-whitespace,downlevel-simple,checks-only --variant standard=/workspace/jsgo/bin/jsgo-current-old-pgo --variant heap-control=/workspace/jsgo/bin/jsgo-arena-heap-control --variant process-arena=/workspace/jsgo/bin/jsgo-process-arena --runs 1 > /workspace/jsgo-results/arena-smoke.log 2>&1
