#!/usr/bin/env bash
set -euo pipefail
. /workspace/toolchains/env.sh
go run /workspace/jsgo-results/alloc_classes.go > /workspace/jsgo-results/alloc-classes.txt
cd /workspace/jsgo-combined2
export PATH=/workspace/toolchains/go1.27.2/bin:$PATH
GOMAXPROCS=2 go build -buildvcs=false -p 2 -pgo=cmd/jsgo/default.pgo -o /workspace/jsgo/bin/jsgo-current-profile ./tools/bench/profile > /workspace/jsgo-results/build-current-profile.log 2>&1
taskset -c 0,1 python3 -u /workspace/jsgo-results/profile-current.py > /workspace/jsgo-results/profile-current.log 2>&1
go tool pprof -proto -output=/workspace/jsgo-results/current.pgo /workspace/jsgo-results/current-profile/typed-app/cpu.pprof /workspace/jsgo-results/current-profile/bundle/cpu.pprof /workspace/jsgo-results/current-profile/downlevel-whitespace/cpu.pprof /workspace/jsgo-results/current-profile/checks-only/cpu.pprof > /workspace/jsgo-results/merge-pgo.log 2>&1
GOMAXPROCS=2 go build -buildvcs=false -p 2 -pgo=/workspace/jsgo-results/current.pgo -o /workspace/jsgo/bin/jsgo-current-fresh-pgo ./cmd/jsgo > /workspace/jsgo-results/build-current-fresh-pgo.log 2>&1
GOMAXPROCS=2 go build -buildvcs=false -p 2 -pgo=/workspace/jsgo-results/current.pgo -o /workspace/jsgo/bin/gowarm-current-fresh-pgo ./tools/bench/gowarm > /workspace/jsgo-results/build-gowarm-current-fresh-pgo.log 2>&1
GOMAXPROCS=2 go build -buildvcs=false -p 2 -o /workspace/jsgo/bin/jsgo-current-old-pgo ./cmd/jsgo > /workspace/jsgo-results/build-current-old-pgo.log 2>&1
cd /workspace/jsgo-slab-shapes
GOMAXPROCS=2 go build -buildvcs=false -p 2 -o /workspace/jsgo/bin/jsgo-slab-shapes ./cmd/jsgo > /workspace/jsgo-results/build-slab-shapes.log 2>&1
export PATH=/workspace/toolchains/go1.24.7/bin:$PATH
cd /workspace/jsgo-pass-chunks
GOMAXPROCS=2 go build -buildvcs=false -p 2 -o /workspace/jsgo/bin/jsgo-pass-chunks ./cmd/jsgo > /workspace/jsgo-results/build-pass-chunks.log 2>&1
