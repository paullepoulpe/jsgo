#!/usr/bin/env bash
set -euo pipefail
. /workspace/toolchains/env.sh
while kill -0 14840 2>/dev/null; do sleep 3; done
cd /workspace/jsgo-cache-lifetime
GOMAXPROCS=2 go test -p 2 ./internal/rhino ./internal/parsing > /workspace/jsgo-results/test-cache-lifetime.log 2>&1
GOMAXPROCS=2 go build -buildvcs=false -p 2 -pgo=cmd/jsgo/default.pgo -o /workspace/jsgo/bin/gowarm-lifetime ./tools/bench/gowarm > /workspace/jsgo-results/build-gowarm-lifetime.log 2>&1
cd /workspace/jsgo-node80
GOMAXPROCS=2 go test -p 2 -gcflags=all=-d=checkptr=2 ./internal/rhino > /workspace/jsgo-results/test-node80.log 2>&1
GOMAXPROCS=2 go build -buildvcs=false -p 2 -o /workspace/jsgo/bin/jsgo-node80 ./cmd/jsgo > /workspace/jsgo-results/build-node80.log 2>&1
cd /workspace/jsgo-compact-var
GOMAXPROCS=2 go test -p 2 ./internal/jscomp -run 'TestCompactVar|TestVarHashMatchesScopedName|TestVarTest|TestTypedVar|TestScope' -count=1 > /workspace/jsgo-results/test-compact-var.log 2>&1
GOMAXPROCS=2 go build -buildvcs=false -p 2 -o /workspace/jsgo/bin/jsgo-compact-var ./cmd/jsgo > /workspace/jsgo-results/build-compact-var.log 2>&1
