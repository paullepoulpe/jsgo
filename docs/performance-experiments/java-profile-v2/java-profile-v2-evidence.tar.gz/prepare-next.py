"""Serial build/probe preparation; run only after the previous benchmark stops."""
from pathlib import Path
import json,subprocess,time
ROOT=Path(__file__).resolve().parent
COMMANDS=[]
for candidate,package,probe,extra in [
 ('identity-differs','com.google.javascript.rhino.jstype','IdentityDiffersProbe',[]),
 ('traversal-noop','com.google.javascript.jscomp','TraversalNoopProbe',['--candidate-arg=--require-flags'])]:
 COMMANDS.append(['python3',str(ROOT/'build-candidate.py'),candidate,'--source-root',str(ROOT/'candidates'/candidate/'src')])
 COMMANDS.append(['python3',str(ROOT/'run-probes.py'),'--manifest',str(ROOT/'build'/candidate/'manifest.json'),'--probe-source',str(ROOT/'candidates'/candidate/'probe'/package.replace('.','/')/(probe+'.java')),'--probe-class',package+'.'+probe,'--compare-stdout','--out',str(ROOT/'results'/(candidate+'-probes-attempt-1')),*extra])
record=[]
for command in COMMANDS:
 print('RUN',command,flush=True)
 start=time.time();r=subprocess.run(command);record.append({'argv':command,'started_unix':start,'ended_unix':time.time(),'exit':r.returncode})
 (ROOT/'prepare-next-results.json').write_text(json.dumps(record,indent=2)+'\n')
 if r.returncode:raise SystemExit(r.returncode)
