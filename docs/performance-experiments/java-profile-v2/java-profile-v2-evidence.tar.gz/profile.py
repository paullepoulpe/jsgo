"""Warm stock Closure JFR diagnostics; no benchmark comparison or speed claim."""
from pathlib import Path
import argparse, hashlib, json, os, subprocess, sys, time, types, zipfile
sys.dont_write_bytecode = True
ROOT = Path(__file__).resolve().parent
OLD = ROOT.parent/'transfer-v1'
HELP = Path('/workspace/jsgo-round4-bench/tools/bench')
JAR = Path('/workspace/jsgo/.cache/closure-compiler-v20261015-maven.jar')
JDK = '/usr/lib/jvm/java-21-openjdk-amd64'
IMAGE = 'python@sha256:70729b46c69b4f1e97c4822c1af3df53a1476cf5ddc6c087c0c10bc3a5678c2f'
TASKS = {
 'bigquery': ('/workspace/jsgo-results/round4/bigquery-stock-oracle-v1/spec.json', '/workspace/jsgo-results/round4/bigquery-stock-oracle-v1'),
 'bundle': ('/workspace/jsgo-results/round4/main-9c895b43-sync-v1/benchmark-preparation-v2/go-screen-v2/specs/bundle-n1.json', '/workspace/jsgo-results/round4/paired-main5de-bundle-advanced-t1-v1'),
}
def module(path, name):
 m=types.ModuleType(name);m.__file__=str(path);exec(compile(path.read_bytes(),str(path),'exec'),m.__dict__);return m
def main():
 p=argparse.ArgumentParser();p.add_argument('task',choices=TASKS);p.add_argument('--out',required=True,type=Path);a=p.parse_args()
 b=module(OLD/'bench/run-v3.py','frozen_profile_support')
 assert not b.active(), 'runtime active'
 assert b.sha(JAR)==b.JAR
 out=a.out.resolve();assert not out.exists();out.mkdir(parents=True)
 snapshots=out/'helpers';snapshots.mkdir()
 for name,digest in b.PINS.items():
  source=HELP/name;assert b.sha(source)==digest;(snapshots/name).write_bytes(source.read_bytes())
 h=module(snapshots/'paired_cli.py','profile_helpers')
 specpath,oraclepath=TASKS[a.task];spec=b.read(specpath);oracle=b.read(Path(oraclepath)/'stock-java-oracle-digests.json');om=b.read(Path(oraclepath)/'metadata.json')
 identity=h.input_identity(spec);assert identity==om['input_manifest'] and b.work_identity(spec)==b.work_identity(om['spec'])
 assert len(oracle)==6
 args=types.SimpleNamespace(readonly_bind=sorted(set(spec['links'].values())),binary=str(JAR),jar=str(JAR),java_home=JDK,driver=str(ROOT/'profile-driver/classes'),image=IMAGE,request_timeout=300)
 e=h.Engine(args);original_call=e.call
 def bounded_call(*av,**kw):kw.setdefault('timeout',30);return original_call(*av,**kw)
 e.call=bounded_call
 assert not e.call('ps','-q',capture_output=True,text=True).stdout.strip()
 before=b.outer();started=time.monotonic();work=out/'work';recording=work/'profile.jfr';original_create=e.create
 def create(w,command,java=False):
  command=list(command);command[command.index('CliFactors')]='CliProfile';command.insert(command.index('-Xmx3g'),'-XX:FlightRecorderOptions=stackdepth=128');command.append(str(recording))
  b.save(out/'actual-command.json',{'command':command,'diagnostic_only':True})
  return original_create(w,command,java)
 e.create=create
 names=['com.google.javascript.jscomp.GlobalNamespace','com.google.javascript.jscomp.colors.Color','com.google.javascript.rhino.Node','com.google.javascript.rhino.jstype.PropertyMap']
 with zipfile.ZipFile(JAR) as z:expected={n:hashlib.sha256(z.read(n.replace('.','/')+'.class')).hexdigest() for n in names}
 b.save(out/'metadata.json',{'diagnostic_only':True,'performance_claim':False,'task':a.task,'runner_sha256':b.sha(__file__),'helper_pins':b.PINS,'reused_support_sha256':b.sha(OLD/'bench/run-v3.py'),'jar_sha256':b.sha(JAR),'driver_source_sha256':b.sha(ROOT/'profile-driver/CliProfile.java'),'driver_class_sha256':b.sha(ROOT/'profile-driver/classes/CliProfile.class'),'spec':spec,'spec_path':specpath,'spec_sha256':b.sha(specpath),'oracle':oracle,'input_manifest':identity,'JDK_dependencies':h.java_runtime_dependencies(JDK),'outer_before':before,'warmup_policy':'same v1 stability criteria, min12 max90; recording starts only after stable','profile_requests':8,'JFR':'profile config, 10ms Java execution samples, weighted allocation samples, 128-frame stack; diagnostic only; runtime/GC costs not inferred from Java sample shares'})
 def check():
  now=b.outer();b.zero(b.oom_delta(before,now));assert b.memory_headroom(now)>=1<<30;assert time.monotonic()-started<3600
  assert os.statvfs(out).f_bavail*os.statvfs(out).f_frsize>=1<<30
 j=None;cleanup=[];rows=[];profile=[];failed=None
 try:
  j=b.JVM('STOCK',{'overlay':None},work,e,h,args,spec,names,expected);j.ready(check)
  for n in range(1,91):
   row=j.request(n,'warmup',check);assert row['digests']==oracle;rows.append(row);state=b.stability(rows)
   b.save(out/'warmup.json',{'rows':rows,'stability':state});print('warmup',n,state,flush=True)
   if state['stable']:break
  else:raise RuntimeError('stock did not settle by 90 requests')
  def control(command,reply):
   e.call('unpause',j.cid,stdout=subprocess.DEVNULL);j.paused=False
   try:
    j.process.stdin.write((command+'\n').encode());j.process.stdin.flush();line=j.line(time.monotonic()+300,check);assert line==reply+'\t'+str(recording),line
   finally:j.pause()
  control('PROFILE_START','PROFILE_STARTED')
  for i in range(8):
   row=j.request(len(rows)+i+1,'warmup',check);assert row['digests']==oracle;row['phase']='profiled_diagnostic';profile.append(row);b.save(out/'profiled-requests.json',profile);print('profile',i+1,'PASS6',flush=True)
  control('PROFILE_STOP','PROFILE_STOPPED');assert recording.stat().st_size>0
  assert h.input_identity(spec)==identity
 except BaseException as exc:
  failed=repr(exc);b.save(out/'failure.json',{'error':failed,'diagnostic_only':True});raise
 finally:
  if j is not None:cleanup=j.close()
  e.close();after=b.outer();proof={'cleanup':cleanup,'remaining_engine_containers':sorted(e.containers),'active_compilers':b.active(),'outer_OOM_delta':b.oom_delta(before,after),'outer_after':after}
  b.save(out/'stopped-proof.json',proof)
  assert not proof['remaining_engine_containers'] and not proof['active_compilers'];b.zero(proof['outer_OOM_delta'])
 if not failed:
  assert all(x['driver_exit']==0 for x in cleanup)
  b.save(out/'summary.json',{'status':'PASS settled byte-identical stock JFR diagnostic','warm_requests':len(rows),'profiled_requests':len(profile),'JFR_sha256':b.sha(recording),'JFR_bytes':recording.stat().st_size,'all_six_digests_match':True,'performance_claim':False})
  print('PROFILE COMPLETE',recording,flush=True)
if __name__=='__main__':main()
