// Focused JFR sample aggregates, including explicit zero rows for every target.
// Usage: java --add-modules jdk.jfr -cp <classes> JfrTargets recording.jfr
// Samples identify observed Java hotspots, not elapsed time or exact allocations.
import java.io.IOException;
import java.io.PrintWriter;
import java.nio.charset.StandardCharsets;
import java.nio.file.Path;
import java.time.Duration;
import java.time.Instant;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.TreeMap;
import jdk.jfr.consumer.RecordedClass;
import jdk.jfr.consumer.RecordedEvent;
import jdk.jfr.consumer.RecordedFrame;
import jdk.jfr.consumer.RecordedMethod;
import jdk.jfr.consumer.RecordedStackTrace;
import jdk.jfr.consumer.RecordingFile;

public final class JfrTargets {
  private static final String CPU_EVENT = "jdk.ExecutionSample";
  private static final String ALLOCATION_EVENT = "jdk.ObjectAllocationSample";
  private static final String JSCOMP = "com.google.javascript.jscomp.";
  private static final String PROPERTY_MAP = "com.google.javascript.rhino.jstype.PropertyMap";
  private static final String NODE_TRAVERSAL = JSCOMP + "NodeTraversal";

  private record Target(String label, String owner, String methodName) {
    boolean matches(RecordedMethod method) {
      if (method == null) return false;
      String actualOwner = method.getType().getName();
      // A null method selects this class and its nested classes, all methods.
      return methodName == null
          ? actualOwner.equals(owner) || actualOwner.startsWith(owner + "$")
          : actualOwner.equals(owner) && method.getName().equals(methodName);
    }
    String specification() {
      return owner + (methodName == null ? ".* (including nested classes)" : "." + methodName);
    }
  }

  private static final List<Target> TARGETS = List.of(
      new Target("PropertyMap.getAllKeys", PROPERTY_MAP, "getAllKeys"),
      new Target("PropertyMap.collectAllAncestors", PROPERTY_MAP, "collectAllAncestors"),
      new Target("PropertyMap.hashCode", PROPERTY_MAP, "hashCode"),
      new Target("GlobalNamespace$Name.getFullName", JSCOMP + "GlobalNamespace$Name", "getFullName"),
      new Target("$AutoValue_Color.hashCode", JSCOMP + "colors.$AutoValue_Color", "hashCode"),
      new Target("AutoValue_Color.hashCode", JSCOMP + "colors.AutoValue_Color", "hashCode"),
      // Source ownership is the nested printer, not the outer CodePrinter.
      new Target("CodePrinter$MappedCodePrinter.getSourceMappings", JSCOMP + "CodePrinter$MappedCodePrinter", "getSourceMappings"),
      new Target("SourceMapGeneratorV3.addSourcesContentMap", "com.google.debugging.sourcemap.SourceMapGeneratorV3", "addSourcesContentMap"),
      new Target("NodeTraversal.createsBlockScope", NODE_TRAVERSAL, "createsBlockScope"),
      new Target("SyntacticScopeCreator", JSCOMP + "SyntacticScopeCreator", null),
      new Target("FunctionArgumentInjector.findModifiedParameters", JSCOMP + "FunctionArgumentInjector", "findModifiedParameters"),
      new Target("FunctionArgumentInjector", JSCOMP + "FunctionArgumentInjector", null),
      new Target("NodeTraversal.traverseBranch", NODE_TRAVERSAL, "traverseBranch"));

  private static final class Window {
    long count;
    Instant firstStart, lastEnd;
    void add(RecordedEvent event) {
      count = Math.addExact(count, 1);
      Instant start = event.getStartTime(), end = event.getEndTime();
      if (firstStart == null || start.isBefore(firstStart)) firstStart = start;
      if (lastEnd == null || end.isAfter(lastEnd)) lastEnd = end;
    }
  }

  private static final class Counts {
    long cpuLeaf, cpuInclusive, allocationLeafEvents, allocationLeafWeight;
    long allocationInclusiveEvents, allocationInclusiveWeight;
    void add(boolean cpu, boolean leaf, long weight) {
      if (cpu) {
        cpuInclusive = Math.addExact(cpuInclusive, 1);
        if (leaf) cpuLeaf = Math.addExact(cpuLeaf, 1);
      } else {
        allocationInclusiveEvents = Math.addExact(allocationInclusiveEvents, 1);
        allocationInclusiveWeight = Math.addExact(allocationInclusiveWeight, weight);
        if (leaf) {
          allocationLeafEvents = Math.addExact(allocationLeafEvents, 1);
          allocationLeafWeight = Math.addExact(allocationLeafWeight, weight);
        }
      }
    }
  }

  private static final class TargetCounts {
    final Target target;
    final Counts total = new Counts();
    final Map<String, Counts> methods = new TreeMap<>();
    TargetCounts(Target target) { this.target = target; }
  }

  private static final class WeightedCount {
    long events, weight;
    void add(long value) {
      events = Math.addExact(events, 1);
      weight = Math.addExact(weight, value);
    }
  }

  private static final class AllocationGroup {
    final String label;
    final Set<String> classNames;
    final WeightedCount total = new WeightedCount();
    final Map<String, WeightedCount> classes = new TreeMap<>();
    final Map<String, WeightedCount> stacks = new HashMap<>();
    long missingStack, truncatedStack;
    AllocationGroup(String label, String... classNames) {
      this.label = label;
      this.classNames = Set.of(classNames);
    }
    void add(String objectClass, RecordedStackTrace stack, long weight) {
      total.add(weight);
      classes.computeIfAbsent(objectClass, ignored -> new WeightedCount()).add(weight);
      boolean missing = stack == null || stack.getFrames().isEmpty();
      if (missing) missingStack = Math.addExact(missingStack, 1);
      else if (stack.isTruncated()) truncatedStack = Math.addExact(truncatedStack, 1);
      stacks.computeIfAbsent(missing ? "<missing stack>" : stackKey(stack), ignored -> new WeightedCount()).add(weight);
    }
  }

  private record LineCaller(int line, String caller) {}
  private final List<TargetCounts> targets = TARGETS.stream().map(TargetCounts::new).toList();
  private final List<AllocationGroup> allocationGroups = List.of(
      new AllocationGroup("LinkedHashMap", "java.util.LinkedHashMap"),
      new AllocationGroup("LinkedHashMap$Entry", "java.util.LinkedHashMap$Entry"),
      new AllocationGroup("HashMap$Node[]", "[Ljava.util.HashMap$Node;", "java.util.HashMap$Node[]"),
      new AllocationGroup("Scope", JSCOMP + "Scope"),
      new AllocationGroup("TypedScope", JSCOMP + "TypedScope"));
  private final Window allEvents = new Window(), cpuEvents = new Window(), allocationEvents = new Window();
  private final Map<LineCaller, Long> traverseBranchLines = new HashMap<>();
  private long allocationWeight, cpuMissingStack, cpuTruncatedStack;
  private long allocationMissingStack, allocationMissingStackWeight, allocationTruncatedStack;
  private long traverseBranchLeaves, dataLossEvents;

  public static void main(String[] args) throws IOException {
    if (args.length != 1) throw new IllegalArgumentException("usage: JfrTargets recording.jfr");
    Path path = Path.of(args[0]).toAbsolutePath().normalize();
    JfrTargets summary = new JfrTargets();
    try (RecordingFile recording = new RecordingFile(path)) {
      while (recording.hasMoreEvents()) summary.add(recording.readEvent());
    }
    PrintWriter output = new PrintWriter(System.out, false, StandardCharsets.UTF_8);
    summary.write(output, path);
    output.flush();
    if (output.checkError()) throw new IOException("failed to write JFR targets");
  }

  private void add(RecordedEvent event) throws IOException {
    allEvents.add(event);
    String type = event.getEventType().getName();
    if (type.equals("jdk.DataLoss")) dataLossEvents = Math.addExact(dataLossEvents, 1);
    boolean cpu = type.equals(CPU_EVENT);
    if (!cpu && !type.equals(ALLOCATION_EVENT)) return;
    RecordedStackTrace stack = event.getStackTrace();
    boolean missing = stack == null || stack.getFrames().isEmpty();
    long weight = 0;
    if (cpu) {
      cpuEvents.add(event);
      if (missing) cpuMissingStack = Math.addExact(cpuMissingStack, 1);
      else if (stack.isTruncated()) cpuTruncatedStack = Math.addExact(cpuTruncatedStack, 1);
    } else {
      allocationEvents.add(event);
      if (!event.hasField("weight") || !event.hasField("objectClass")) {
        throw new IOException("ObjectAllocationSample lacks weight/objectClass");
      }
      weight = event.getLong("weight");
      if (weight < 0) throw new IOException("negative allocation weight");
      allocationWeight = Math.addExact(allocationWeight, weight);
      if (missing) {
        allocationMissingStack = Math.addExact(allocationMissingStack, 1);
        allocationMissingStackWeight = Math.addExact(allocationMissingStackWeight, weight);
      } else if (stack.isTruncated()) allocationTruncatedStack = Math.addExact(allocationTruncatedStack, 1);
      RecordedClass cls = event.getClass("objectClass");
      String objectClass = cls == null ? "<unknown>" : cls.getName();
      String normalized = objectClass.replace('/', '.');
      for (AllocationGroup group : allocationGroups) {
        if (group.classNames.contains(normalized)) group.add(objectClass, stack, weight);
      }
    }
    if (missing) return;
    List<RecordedFrame> frames = stack.getFrames();
    if (cpu) {
      RecordedMethod leaf = frames.get(0).getMethod();
      if (leaf != null && leaf.getType().getName().equals(NODE_TRAVERSAL) && leaf.getName().equals("traverseBranch")) {
        traverseBranchLeaves = Math.addExact(traverseBranchLeaves, 1);
        LineCaller key = new LineCaller(frames.get(0).getLineNumber(), frames.size() > 1 ? method(frames.get(1)) : "<missing caller>");
        traverseBranchLines.merge(key, 1L, (left, right) -> Math.addExact(left, right));
      }
    }
    boolean[] seenTargets = new boolean[targets.size()];
    Set<String> seenMethods = new HashSet<>();
    for (int frameIndex = 0; frameIndex < frames.size(); frameIndex++) {
      RecordedFrame frame = frames.get(frameIndex);
      for (int targetIndex = 0; targetIndex < targets.size(); targetIndex++) {
        TargetCounts target = targets.get(targetIndex);
        if (!target.target.matches(frame.getMethod())) continue;
        if (!seenTargets[targetIndex]) {
          target.total.add(cpu, frameIndex == 0, weight);
          seenTargets[targetIndex] = true;
        }
        String name = method(frame);
        if (seenMethods.add(targetIndex + "\t" + name)) {
          target.methods.computeIfAbsent(name, ignored -> new Counts()).add(cpu, frameIndex == 0, weight);
        }
      }
    }
  }

  private static String method(RecordedFrame frame) {
    RecordedMethod method = frame.getMethod();
    return method == null ? "<" + frame.getType() + ":unknown method>"
        : method.getType().getName() + "." + method.getName() + method.getDescriptor();
  }

  private static String stackKey(RecordedStackTrace stack) {
    StringBuilder text = new StringBuilder();
    for (RecordedFrame frame : stack.getFrames()) {
      if (text.length() > 0) text.append(" <- ");
      text.append(method(frame)).append(" [line=").append(frame.getLineNumber())
          .append(",bci=").append(frame.getBytecodeIndex()).append(",type=").append(frame.getType()).append(']');
    }
    if (stack.isTruncated()) text.append(" <- <truncated>");
    return text.toString();
  }

  private void write(PrintWriter out, Path path) {
    row(out, "SCHEMA", "JfrTargets/1");
    row(out, "RECORDING", path);
    row(out, "NOTE", "Every requested target has a row, including zeros. Zero means no matching observed sample frames, not proof of no execution.");
    row(out, "NOTE", "CPU sample shares are not wall time or exact CPU time. Allocation weights are sampled estimates, not exact allocated or retained bytes.");
    row(out, "NOTE", "Inclusive counts deduplicate each method and each target per stack. Target and method rows can overlap; percentages need not sum to 100.");
    row(out, "NOTE", "Matching uses declaring owner and method name, across overloads. METHOD rows include descriptors. Class-loader identities are merged.");
    row(out, "NOTE", "Line/caller rows include only samples whose leaf is NodeTraversal.traverseBranch. Caller is the immediately enclosing recorded frame; line -1 remains unknown.");
    row(out, "NOTE", "Windows describe observed event timestamps, including gaps; they are not compile durations. Missing/truncated stacks limit absence claims.");
    row(out, "COLUMNS", "WINDOW", "event", "count", "first_start", "last_end", "observed_span_ns");
    window(out, "all_events", allEvents); window(out, CPU_EVENT, cpuEvents); window(out, ALLOCATION_EVENT, allocationEvents);
    row(out, "DATA_LOSS_EVENTS", dataLossEvents);
    row(out, "COLUMNS", "CPU_TOTAL", "samples", "missing_stack", "truncated_stack", "traverseBranch_leaf_samples");
    row(out, "CPU_TOTAL", cpuEvents.count, cpuMissingStack, cpuTruncatedStack, traverseBranchLeaves);
    row(out, "COLUMNS", "ALLOCATION_TOTAL", "samples", "estimated_weight_bytes", "missing_stack", "missing_stack_estimated_weight_bytes", "truncated_stack");
    row(out, "ALLOCATION_TOTAL", allocationEvents.count, allocationWeight, allocationMissingStack, allocationMissingStackWeight, allocationTruncatedStack);
    row(out, "COLUMNS", "TARGET/METHOD", "target", "match_or_method", "cpu_leaf", "cpu_inclusive", "cpu_leaf_pct_all", "cpu_inclusive_pct_all",
        "allocation_leaf_samples", "allocation_leaf_estimated_bytes", "allocation_leaf_pct_all_weight", "allocation_inclusive_samples", "allocation_inclusive_estimated_bytes", "allocation_inclusive_pct_all_weight");
    for (TargetCounts target : targets) {
      counts(out, "TARGET", target.target.label(), target.target.specification(), target.total);
      target.methods.forEach((name, value) -> counts(out, "METHOD", target.target.label(), name, value));
    }
    row(out, "COLUMNS", "TRAVERSE_BRANCH_LEAF_LINE", "line", "caller", "samples", "pct_all_cpu", "pct_traverseBranch_leaf");
    List<Map.Entry<LineCaller, Long>> lines = new ArrayList<>(traverseBranchLines.entrySet());
    lines.sort(Map.Entry.<LineCaller, Long>comparingByValue(Comparator.reverseOrder())
        .thenComparingInt(entry -> entry.getKey().line()).thenComparing(entry -> entry.getKey().caller()));
    for (Map.Entry<LineCaller, Long> entry : lines) {
      row(out, "TRAVERSE_BRANCH_LEAF_LINE", entry.getKey().line(), entry.getKey().caller(), entry.getValue(),
          percent(entry.getValue(), cpuEvents.count), percent(entry.getValue(), traverseBranchLeaves));
    }
    row(out, "COLUMNS", "ALLOCATION_GROUP", "group", "samples", "estimated_weight_bytes", "pct_all_weight", "missing_stack", "truncated_stack", "distinct_stacks");
    row(out, "COLUMNS", "ALLOCATION_CLASS", "group", "class", "samples", "estimated_weight_bytes");
    row(out, "COLUMNS", "ALLOCATION_STACK", "group", "rank", "samples", "estimated_weight_bytes", "pct_group_weight", "pct_all_weight", "stack_leaf_to_root");
    for (AllocationGroup group : allocationGroups) {
      row(out, "ALLOCATION_GROUP", group.label, group.total.events, group.total.weight,
          percent(group.total.weight, allocationWeight), group.missingStack, group.truncatedStack, group.stacks.size());
      group.classes.forEach((name, value) -> row(out, "ALLOCATION_CLASS", group.label, name, value.events, value.weight));
      List<Map.Entry<String, WeightedCount>> stacks = new ArrayList<>(group.stacks.entrySet());
      stacks.sort(Comparator.<Map.Entry<String, WeightedCount>>comparingLong(entry -> entry.getValue().weight)
          .reversed().thenComparing(Map.Entry.comparingByKey()));
      for (int i = 0; i < Math.min(20, stacks.size()); i++) {
        Map.Entry<String, WeightedCount> entry = stacks.get(i);
        row(out, "ALLOCATION_STACK", group.label, i + 1, entry.getValue().events, entry.getValue().weight,
            percent(entry.getValue().weight, group.total.weight), percent(entry.getValue().weight, allocationWeight), entry.getKey());
      }
    }
  }

  private void counts(PrintWriter out, String tag, String target, String name, Counts value) {
    row(out, tag, target, name, value.cpuLeaf, value.cpuInclusive, percent(value.cpuLeaf, cpuEvents.count), percent(value.cpuInclusive, cpuEvents.count),
        value.allocationLeafEvents, value.allocationLeafWeight, percent(value.allocationLeafWeight, allocationWeight),
        value.allocationInclusiveEvents, value.allocationInclusiveWeight, percent(value.allocationInclusiveWeight, allocationWeight));
  }
  private static void window(PrintWriter out, String label, Window window) {
    row(out, "WINDOW", label, window.count, window.firstStart, window.lastEnd,
        window.firstStart == null ? 0 : Duration.between(window.firstStart, window.lastEnd).toNanos());
  }
  private static String percent(long value, long total) {
    return total == 0 ? "0.0000" : String.format(Locale.ROOT, "%.4f", 100.0 * value / total);
  }
  private static void row(PrintWriter out, Object... cells) {
    for (int i = 0; i < cells.length; i++) {
      if (i != 0) out.print('\t');
      String value = cells[i] == null ? "" : cells[i].toString();
      out.print(value.replace("\\", "\\\\").replace("\t", "\\t").replace("\n", "\\n").replace("\r", "\\r"));
    }
    out.println();
  }
}
