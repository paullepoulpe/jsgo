// Profiling-only derivative of frozen transfer-v1/bench/CliFactors.java.
// Compile requests and RESULT metrics retain the original semantics.
// JFR samples are diagnostics; profiled RESULT timings are not benchmark evidence.
// One fresh CommandLineRunner/Compiler and normal extern parsing per request.
import com.google.javascript.jscomp.CommandLineRunner;
import java.io.*;
import java.lang.management.*;
import java.nio.charset.Charset;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.util.*;
import java.util.logging.*;
import java.lang.reflect.Method;
import java.security.MessageDigest;
import java.text.ParseException;
import java.time.Duration;
import jdk.jfr.Configuration;
import jdk.jfr.Recording;

public final class CliProfile extends CommandLineRunner {
  private CliProfile(String[] args, PrintStream out, PrintStream err) {
    super(args, InputStream.nullInputStream(), out, err);
  }
  private int runAsMain() {
    int[] status = {0};
    if (shouldRunCompiler()) {
      setExitCodeReceiver(code -> { status[0] = code; return null; });
      run();
    } else if (hasErrors()) { status[0] = -1; }
    return status[0] & 255;
  }
  private static String cg(String name) throws IOException {
    return Files.readString(Path.of("/sys/fs/cgroup", name)).trim().replace('\n', ';');
  }
  private static long status(String key) throws IOException {
    for (String line : Files.readAllLines(Path.of("/proc/self/status"))) {
      if (line.startsWith(key + ":")) return Long.parseLong(line.substring(key.length()+1).replace("kB", "").trim());
    }
    throw new IOException("missing process metric: " + key);
  }
  private static long[] gc() {
    long count = 0, ms = 0;
    for (GarbageCollectorMXBean bean : ManagementFactory.getGarbageCollectorMXBeans()) {
      count += Math.max(0, bean.getCollectionCount()); ms += Math.max(0, bean.getCollectionTime());
    }
    return new long[]{count, ms};
  }
  private static long cpu() {
    return ((com.sun.management.OperatingSystemMXBean) ManagementFactory.getOperatingSystemMXBean()).getProcessCpuTime();
  }
  private static long jit() {
    CompilationMXBean bean = ManagementFactory.getCompilationMXBean();
    return bean != null && bean.isCompilationTimeMonitoringSupported() ? bean.getTotalCompilationTime() : -1;
  }
  // VM-wide allocation counter includes allocations by dead and live threads.
  // Reflection keeps unsupported VMs explicit instead of summing live threads
  // and silently losing allocations when compiler worker threads terminate.
  private static final com.sun.management.ThreadMXBean ALLOC =
      (com.sun.management.ThreadMXBean) ManagementFactory.getThreadMXBean();
  private static final Method TOTAL_ALLOCATED = allocationMethod();
  private static Method allocationMethod() {
    try {
      if (!ALLOC.isThreadAllocatedMemorySupported()) return null;
      if (!ALLOC.isThreadAllocatedMemoryEnabled()) ALLOC.setThreadAllocatedMemoryEnabled(true);
      return com.sun.management.ThreadMXBean.class.getMethod("getTotalThreadAllocatedBytes");
    } catch (ReflectiveOperationException | UnsupportedOperationException | SecurityException e) { return null; }
  }
  private static long allocated() {
    if (TOTAL_ALLOCATED == null) return -1;
    try { return ((Long) TOTAL_ALLOCATED.invoke(ALLOC)).longValue(); }
    catch (ReflectiveOperationException | RuntimeException e) { return -1; }
  }
  private static String classHash(Class<?> cls) throws IOException {
    try (InputStream in = cls.getResourceAsStream("/"+cls.getName().replace('.', '/')+".class")) {
      if (in == null) throw new IOException("missing loaded class bytes: "+cls.getName());
      try { return HexFormat.of().formatHex(MessageDigest.getInstance("SHA-256").digest(in.readAllBytes())); }
      catch (java.security.NoSuchAlgorithmException e) { throw new AssertionError(e); }
    }
  }
  public static void main(String[] args) {
    try { serve(args); } catch (IOException error) { throw new UncheckedIOException(error); }
  }
  private static Recording startProfile() throws IOException {
    final Configuration configuration;
    try { configuration = Configuration.getConfiguration("profile"); }
    catch (ParseException e) { throw new IOException("invalid built-in JFR profile configuration", e); }
    Recording recording = new Recording(configuration);
    try {
      recording.setName("Closure Compiler warmed diagnostic profile");
      recording.setToDisk(true);
      recording.setDumpOnExit(false);
      recording.enable("jdk.ExecutionSample").withPeriod(Duration.ofMillis(10)).withStackTrace();
      recording.enable("jdk.ObjectAllocationSample").withStackTrace().with("throttle", "150/s");
      recording.start();
      return recording;
    } catch (RuntimeException | Error error) {
      recording.close();
      throw error;
    }
  }
  private static void serve(String[] args) throws IOException {
    if (args.length != 3) throw new IOException("usage: CliProfile <args-file> <classes-file> <recording.jfr>");
    Path recordingPath = Path.of(args[2]).toAbsolutePath().normalize();
    if (!cg("memory.max").equals("4294967296") || !cg("memory.swap.max").equals("0")) {
      throw new IOException("requires kernel cgroup memory.max=4GiB and memory.swap.max=0");
    }
    Logger.getLogger("com.google.javascript.jscomp.PhaseOptimizer").setLevel(Level.OFF);
    List<String> job = Files.readAllLines(Path.of(args[0]), StandardCharsets.UTF_8);
    // One argument per line; embedded newlines are rejected by the controller.
    String[] compilerArgs = job.toArray(String[]::new);
    Charset stdout = Charset.forName(System.getProperty("stdout.encoding", System.getProperty("native.encoding", "UTF-8")));
    Charset stderr = Charset.forName(System.getProperty("stderr.encoding", System.getProperty("native.encoding", "UTF-8")));
    String collectors = ManagementFactory.getGarbageCollectorMXBeans().stream()
        .map(GarbageCollectorMXBean::getName).reduce((a, b) -> a+","+b).orElse("unknown");
    System.out.println("VM\t"+System.getProperty("java.runtime.version")+"\t"+collectors+"\t"+Runtime.getRuntime().maxMemory());
    for (String name : Files.readAllLines(Path.of(args[1]), StandardCharsets.UTF_8)) {
      try {
        Class<?> cls = Class.forName(name, false, CliProfile.class.getClassLoader());
        System.out.println("CLASS\t"+name+"\t"+cls.getProtectionDomain().getCodeSource().getLocation()+"\t"+classHash(cls));
      } catch (ClassNotFoundException e) { throw new IOException(e); }
    }
    System.out.println("READY\t"+cg("memory.max")+"\t"+cg("memory.swap.max")+"\t"+cg("cpu.max")+"\t"+cg("cpuset.cpus.effective"));
    System.out.flush();
    BufferedReader input = new BufferedReader(new InputStreamReader(System.in, StandardCharsets.UTF_8));
    Recording recording = null;
    boolean profileCompleted = false;
    long completedWarmups = 0;
    try {
    for (String command; (command = input.readLine()) != null;) {
      if (command.equals("PROFILE_START")) {
        if (recording != null || profileCompleted) throw new IOException("only one JFR recording per process is allowed");
        if (completedWarmups == 0) throw new IOException("PROFILE_START requires completed warmup requests");
        // The controller decides when warmup has settled. Configuration, JFR
        // startup, and protocol acknowledgements are outside compile timing.
        recording = startProfile();
        System.out.println("PROFILE_STARTED\t"+recordingPath);
        System.out.flush();
        continue;
      }
      if (command.equals("PROFILE_STOP")) {
        if (recording == null) throw new IOException("PROFILE_STOP requires an active recording");
        recording.stop();
        recording.dump(recordingPath);
        recording.close();
        recording = null;
        profileCompleted = true;
        System.out.println("PROFILE_STOPPED\t"+recordingPath);
        System.out.flush();
        continue;
      }
      if (command.equals("STOP")) {
        if (recording != null) throw new IOException("PROFILE_STOP is required before STOP");
        break;
      }
      String[] parts = command.split("\\t", -1);
      if (parts.length != 2 || !parts[0].matches("[0-9]+") || !parts[1].matches("warmup|measure")) {
        throw new IOException("invalid benchmark request");
      }
      Path directory = Path.of("protocol", parts[0]); Files.createDirectories(directory);
      long[] gcBefore = gc(); long jitBefore = jit(), cpuBefore = cpu(), allocationBefore = allocated(), start = System.nanoTime();
      int code;
      // Both runtimes write compiler stdout/stderr to real files inside their
      // timed interval. The protocol uses separate System.out, never a result
      // cache or a cheaper Java-only in-memory diagnostic sink.
      try (PrintStream output = new PrintStream(Files.newOutputStream(directory.resolve("stdout")), true, stdout);
           PrintStream errors = new PrintStream(Files.newOutputStream(directory.resolve("stderr")), true, stderr)) {
        code = new CliProfile(compilerArgs, output, errors).runAsMain();
      }
      long wall = System.nanoTime()-start, allocationAfter = allocated(), processCpu = cpu()-cpuBefore, jitAfter = jit(); long[] gcAfter = gc();
      Files.writeString(directory.resolve("exit"), code+"\n", StandardCharsets.US_ASCII);
      System.out.println(String.join("\t", "RESULT", parts[0], parts[1], Long.toString(wall), Long.toString(processCpu),
          Long.toString(gcAfter[0]-gcBefore[0]), Long.toString(gcAfter[1]-gcBefore[1]), Long.toString(jitBefore), Long.toString(jitAfter),
          Long.toString(status("VmRSS")), Long.toString(status("VmHWM")), Integer.toString(code), cg("memory.peak"), cg("memory.events"), Long.toString(allocationBefore), Long.toString(allocationAfter), cg("memory.current")));
      System.out.flush();
      if (parts[1].equals("warmup")) completedWarmups++;
    }
    if (recording != null) throw new IOException("input ended before PROFILE_STOP");
    } finally {
      if (recording != null) recording.close();
    }
  }
}
