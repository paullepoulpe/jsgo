// Standalone, bounded TSV summary of JFR samples. Requires JDK 17+; no dependencies.
// Usage: java --add-modules jdk.jfr -cp <classes> JfrSummary recording.jfr [topN]
// CPU counts are sample observations, not elapsed or process CPU time. Allocation
// weights are JFR's sampled estimates, not exact allocations or retained bytes.
import java.io.IOException;
import java.io.PrintWriter;
import java.nio.charset.StandardCharsets;
import java.nio.file.Path;
import java.time.Duration;
import java.time.Instant;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.TreeMap;
import jdk.jfr.consumer.RecordedClass;
import jdk.jfr.consumer.RecordedEvent;
import jdk.jfr.consumer.RecordedFrame;
import jdk.jfr.consumer.RecordedMethod;
import jdk.jfr.consumer.RecordedStackTrace;
import jdk.jfr.consumer.RecordingFile;

public final class JfrSummary {
  private static final String CPU_EVENT = "jdk.ExecutionSample";
  private static final String ALLOCATION_EVENT = "jdk.ObjectAllocationSample";

  private static final class Window {
    long count;
    Instant firstStart;
    Instant lastStart;
    Instant lastEnd;

    void add(RecordedEvent event) {
      count = Math.addExact(count, 1);
      Instant start = event.getStartTime();
      Instant end = event.getEndTime();
      if (firstStart == null || start.isBefore(firstStart)) firstStart = start;
      if (lastStart == null || start.isAfter(lastStart)) lastStart = start;
      if (lastEnd == null || end.isAfter(lastEnd)) lastEnd = end;
    }

    long observedSpanNanos() {
      return firstStart == null ? 0 : Duration.between(firstStart, lastEnd).toNanos();
    }
  }

  private static final class WeightedCount {
    long events;
    long weight;

    void add(long value) {
      events = Math.addExact(events, 1);
      weight = Math.addExact(weight, value);
    }
  }

  private final Window allEvents = new Window();
  private final Map<String, Window> eventTypes = new TreeMap<>();
  private final Map<String, Long> cpuLeaves = new HashMap<>();
  private final Map<String, Long> cpuInclusive = new HashMap<>();
  private final Map<String, WeightedCount> allocationClasses = new HashMap<>();
  private final Map<String, WeightedCount> allocationStacks = new HashMap<>();
  private final Map<String, WeightedCount> allocationInclusive = new HashMap<>();
  private long cpuSamples;
  private long cpuMissingStack;
  private long cpuTruncatedStack;
  private long allocationSamples;
  private long allocationWeight;
  private long allocationMissingStack;
  private long allocationMissingStackWeight;
  private long allocationTruncatedStack;

  public static void main(String[] args) throws IOException {
    if (args.length < 1 || args.length > 2) {
      throw new IllegalArgumentException("usage: JfrSummary recording.jfr [topN:1..200]");
    }
    int topN = args.length == 2 ? Integer.parseInt(args[1]) : 40;
    if (topN < 1 || topN > 200) {
      throw new IllegalArgumentException("topN must be between 1 and 200");
    }
    Path path = Path.of(args[0]).toAbsolutePath().normalize();
    JfrSummary summary = new JfrSummary();
    try (RecordingFile recording = new RecordingFile(path)) {
      while (recording.hasMoreEvents()) summary.add(recording.readEvent());
    }
    PrintWriter output = new PrintWriter(System.out, false, StandardCharsets.UTF_8);
    summary.write(output, path, topN);
    output.flush();
    if (output.checkError()) throw new IOException("failed to write JFR summary");
  }

  private void add(RecordedEvent event) throws IOException {
    String type = event.getEventType().getName();
    allEvents.add(event);
    eventTypes.computeIfAbsent(type, ignored -> new Window()).add(event);
    if (type.equals(CPU_EVENT)) {
      cpuSamples = Math.addExact(cpuSamples, 1);
      RecordedStackTrace stack = event.getStackTrace();
      if (stack == null || stack.getFrames().isEmpty()) {
        cpuMissingStack = Math.addExact(cpuMissingStack, 1);
        return;
      }
      if (stack.isTruncated()) cpuTruncatedStack = Math.addExact(cpuTruncatedStack, 1);
      // JFR orders frames from the sampled leaf towards the root.
      increment(cpuLeaves, method(stack.getFrames().get(0)));
      Set<String> seen = new HashSet<>();
      for (RecordedFrame frame : stack.getFrames()) {
        String name = method(frame);
        if (seen.add(name)) increment(cpuInclusive, name);
      }
    } else if (type.equals(ALLOCATION_EVENT)) {
      if (!event.hasField("weight") || !event.hasField("objectClass")) {
        throw new IOException("ObjectAllocationSample lacks expected weight/objectClass fields");
      }
      long weight = event.getLong("weight");
      if (weight < 0) throw new IOException("negative ObjectAllocationSample weight");
      allocationSamples = Math.addExact(allocationSamples, 1);
      allocationWeight = Math.addExact(allocationWeight, weight);
      RecordedClass objectClass = event.getClass("objectClass");
      addWeight(allocationClasses, objectClass == null ? "<unknown>" : objectClass.getName(), weight);
      RecordedStackTrace stack = event.getStackTrace();
      if (stack == null || stack.getFrames().isEmpty()) {
        allocationMissingStack = Math.addExact(allocationMissingStack, 1);
        allocationMissingStackWeight = Math.addExact(allocationMissingStackWeight, weight);
        addWeight(allocationStacks, "<missing stack>", weight);
        return;
      }
      if (stack.isTruncated()) {
        allocationTruncatedStack = Math.addExact(allocationTruncatedStack, 1);
      }
      addWeight(allocationStacks, stackKey(stack), weight);
      Set<String> seen = new HashSet<>();
      for (RecordedFrame frame : stack.getFrames()) {
        String name = method(frame);
        if (seen.add(name)) addWeight(allocationInclusive, name, weight);
      }
    }
  }

  private static void increment(Map<String, Long> counts, String name) {
    counts.merge(name, 1L, (left, right) -> Math.addExact(left, right));
  }

  private static void addWeight(Map<String, WeightedCount> counts, String name, long weight) {
    counts.computeIfAbsent(name, ignored -> new WeightedCount()).add(weight);
  }

  private static String method(RecordedFrame frame) {
    RecordedMethod method = frame.getMethod();
    if (method == null) return "<" + frame.getType() + ":unknown method>";
    // Descriptors distinguish overloads. Class-loader identities are deliberately
    // excluded so method keys remain comparable between separate recordings.
    return method.getType().getName() + "." + method.getName() + method.getDescriptor();
  }

  private static String stackKey(RecordedStackTrace stack) {
    StringBuilder result = new StringBuilder();
    for (RecordedFrame frame : stack.getFrames()) {
      if (result.length() != 0) result.append(" <- ");
      result.append(method(frame)).append(" [line=").append(frame.getLineNumber())
          .append(",bci=").append(frame.getBytecodeIndex()).append(",type=")
          .append(frame.getType()).append(']');
    }
    if (stack.isTruncated()) result.append(" <- <truncated>");
    return result.toString();
  }

  private void write(PrintWriter output, Path path, int topN) {
    row(output, "SCHEMA", "JfrSummary/1", "topN", topN);
    row(output, "RECORDING", path);
    row(output, "NOTE", "CPU counts describe jdk.ExecutionSample observations, not wall time or exact CPU time.");
    row(output, "NOTE", "Allocation weight bytes are sampled estimates, not exact allocated or retained bytes.");
    row(output, "NOTE", "Inclusive tables count each method once per sampled stack; their percentages need not sum to 100.");
    row(output, "NOTE", "WINDOW/EVENT spans cover observed event timestamps, not the requested recording duration.");
    row(output, "NOTE", "Stack keys retain all recorded frames in leaf-to-root order; truncated stacks remain marked.");
    row(output, "COLUMNS", "WINDOW/EVENT", "name", "events", "first_start", "last_start", "last_end", "observed_span_ns");
    writeWindow(output, "WINDOW", "all_events", allEvents);
    eventTypes.forEach((type, window) -> writeWindow(output, "EVENT", type, window));
    row(output, "DATA_LOSS_EVENTS", eventTypes.containsKey("jdk.DataLoss")
        ? eventTypes.get("jdk.DataLoss").count : 0);
    row(output, "COLUMNS", "CPU_TOTAL", "samples", "with_stack", "missing_stack", "truncated_stack");
    row(output, "CPU_TOTAL", cpuSamples, cpuSamples - cpuMissingStack, cpuMissingStack, cpuTruncatedStack);
    row(output, "COLUMNS", "CPU_LEAF/CPU_INCLUSIVE", "rank", "samples", "percent_all_cpu_samples", "method");
    writeCpu(output, "CPU_LEAF", cpuLeaves, topN);
    writeCpu(output, "CPU_INCLUSIVE", cpuInclusive, topN);
    row(output, "COLUMNS", "ALLOCATION_TOTAL", "samples", "estimated_weight_bytes", "with_stack", "missing_stack",
        "missing_stack_estimated_weight_bytes", "truncated_stack");
    row(output, "ALLOCATION_TOTAL", allocationSamples, allocationWeight, allocationSamples - allocationMissingStack,
        allocationMissingStack, allocationMissingStackWeight, allocationTruncatedStack);
    row(output, "COLUMNS", "ALLOCATION_CLASS/ALLOCATION_STACK/ALLOCATION_INCLUSIVE", "rank", "samples",
        "estimated_weight_bytes", "percent_all_allocation_weight", "class_or_stack_or_method");
    writeWeighted(output, "ALLOCATION_CLASS", allocationClasses, topN);
    writeWeighted(output, "ALLOCATION_STACK", allocationStacks, topN);
    writeWeighted(output, "ALLOCATION_INCLUSIVE", allocationInclusive, topN);
  }

  private static void writeWindow(PrintWriter output, String tag, String name, Window window) {
    row(output, tag, name, window.count, window.firstStart, window.lastStart, window.lastEnd,
        window.observedSpanNanos());
  }

  private void writeCpu(PrintWriter output, String tag, Map<String, Long> counts, int topN) {
    List<Map.Entry<String, Long>> entries = new ArrayList<>(counts.entrySet());
    entries.sort(Map.Entry.<String, Long>comparingByValue(Comparator.reverseOrder())
        .thenComparing(Map.Entry.comparingByKey()));
    row(output, "DISTINCT", tag, entries.size());
    for (int i = 0; i < Math.min(topN, entries.size()); i++) {
      Map.Entry<String, Long> entry = entries.get(i);
      row(output, tag, i + 1, entry.getValue(), percent(entry.getValue(), cpuSamples), entry.getKey());
    }
  }

  private void writeWeighted(PrintWriter output, String tag, Map<String, WeightedCount> counts, int topN) {
    List<Map.Entry<String, WeightedCount>> entries = new ArrayList<>(counts.entrySet());
    entries.sort(Comparator.<Map.Entry<String, WeightedCount>>comparingLong(entry -> entry.getValue().weight)
        .reversed().thenComparing(Map.Entry.comparingByKey()));
    row(output, "DISTINCT", tag, entries.size());
    for (int i = 0; i < Math.min(topN, entries.size()); i++) {
      Map.Entry<String, WeightedCount> entry = entries.get(i);
      row(output, tag, i + 1, entry.getValue().events, entry.getValue().weight,
          percent(entry.getValue().weight, allocationWeight), entry.getKey());
    }
  }

  private static String percent(long value, long total) {
    return total == 0 ? "0.0000" : String.format(Locale.ROOT, "%.4f", 100.0 * value / total);
  }

  private static void row(PrintWriter output, Object... cells) {
    for (int i = 0; i < cells.length; i++) {
      if (i != 0) output.print('\t');
      // Escape before printing so arbitrary JVM names cannot break TSV records.
      String value = cells[i] == null ? "" : cells[i].toString();
      output.print(value.replace("\\", "\\\\").replace("\t", "\\t")
          .replace("\n", "\\n").replace("\r", "\\r"));
    }
    output.println();
  }
}
