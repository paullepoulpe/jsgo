// Standalone caller attribution for selected JFR samples; no external dependencies.
// Usage: java --add-modules jdk.jfr -cp <classes> JfrAllocationCallers recording.jfr
import java.io.IOException;
import java.io.PrintWriter;
import java.nio.charset.StandardCharsets;
import java.nio.file.Path;
import java.time.Duration;
import java.time.Instant;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import jdk.jfr.consumer.RecordedClass;
import jdk.jfr.consumer.RecordedEvent;
import jdk.jfr.consumer.RecordedFrame;
import jdk.jfr.consumer.RecordedMethod;
import jdk.jfr.consumer.RecordedStackTrace;
import jdk.jfr.consumer.RecordingFile;

public final class JfrAllocationCallers {
  private static final String CPU = "jdk.ExecutionSample";
  private static final String ALLOCATION = "jdk.ObjectAllocationSample";
  private static final class Window {
    long count;
    Instant firstStart, lastEnd;
    void add(RecordedEvent event) {
      count = Math.addExact(count, 1);
      if (firstStart == null || event.getStartTime().isBefore(firstStart)) firstStart = event.getStartTime();
      if (lastEnd == null || event.getEndTime().isAfter(lastEnd)) lastEnd = event.getEndTime();
    }
  }
  private static final class CpuTarget {
    final String owner, name;
    long samples, missingCaller, truncatedStack;
    final Map<String, Long> immediate = new HashMap<>(), callers = new HashMap<>();
    CpuTarget(String owner, String name) { this.owner = owner; this.name = name; }
    String label() { return owner + "." + name; }
    boolean matches(RecordedMethod method) {
      return method != null && owner.equals(method.getType().getName()) && name.equals(method.getName());
    }
    void add(RecordedStackTrace stack) {
      samples = Math.addExact(samples, 1);
      List<RecordedFrame> frames = stack.getFrames();
      if (frames.size() < 2) missingCaller = Math.addExact(missingCaller, 1);
      if (stack.isTruncated()) truncatedStack = Math.addExact(truncatedStack, 1);
      increment(immediate, frames.size() < 2 ? "<missing caller>" : frame(frames.get(1)));
      increment(callers, prefix(stack, 1, 4, "<missing caller>"));
    }
  }
  private static final class Weight {
    long events, bytes;
    void add(long weight) {
      events = Math.addExact(events, 1);
      bytes = Math.addExact(bytes, weight);
    }
  }
  private static final class AllocationTarget {
    final String objectClass;
    final Weight total = new Weight();
    final Map<String, Weight> prefixes = new HashMap<>();
    long missingStack, missingWeight, truncatedStack;
    AllocationTarget(String objectClass) { this.objectClass = objectClass; }
    void add(RecordedStackTrace stack, long weight) {
      total.add(weight);
      boolean missing = stack == null || stack.getFrames().isEmpty();
      if (missing) {
        missingStack = Math.addExact(missingStack, 1);
        missingWeight = Math.addExact(missingWeight, weight);
      } else if (stack.isTruncated()) truncatedStack = Math.addExact(truncatedStack, 1);
      String key = missing ? "<missing stack>" : prefix(stack, 0, 5, "<missing stack>");
      prefixes.computeIfAbsent(key, ignored -> new Weight()).add(weight);
    }
  }

  private final List<CpuTarget> cpuTargets = List.of(
      new CpuTarget("com.google.javascript.rhino.Node", "lookupProperty"),
      new CpuTarget("java.util.HashMap", "getNode"),
      new CpuTarget("java.util.HashMap", "resize"));
  private final List<AllocationTarget> allocationTargets = List.of(
      new AllocationTarget("com.google.javascript.rhino.jstype.EqualityChecker"),
      new AllocationTarget("com.google.javascript.jscomp.parsing.parser.util.SourcePosition"),
      new AllocationTarget("[B"),
      new AllocationTarget("[Ljava.lang.Object;"),
      new AllocationTarget("java.lang.String"),
      new AllocationTarget("java.lang.StringBuilder"),
      new AllocationTarget("java.util.LinkedHashMap"),
      new AllocationTarget("java.util.LinkedHashMap$Entry"),
      new AllocationTarget("[Ljava.util.HashMap$Node;"));
  private final Window allEvents = new Window(), cpuEvents = new Window(), allocationEvents = new Window();
  private long cpuMissingStack, cpuUnknownLeaf, cpuTruncatedStack;
  private long allocationWeight, allocationMissingStack, allocationMissingWeight, allocationTruncatedStack;
  private long dataLossEvents;

  public static void main(String[] args) throws IOException {
    if (args.length != 1) throw new IllegalArgumentException("usage: JfrAllocationCallers recording.jfr");
    Path path = Path.of(args[0]).toAbsolutePath().normalize();
    JfrAllocationCallers summary = new JfrAllocationCallers();
    try (RecordingFile file = new RecordingFile(path)) {
      while (file.hasMoreEvents()) summary.add(file.readEvent());
    }
    PrintWriter out = new PrintWriter(System.out, false, StandardCharsets.UTF_8);
    summary.write(out, path);
    out.flush();
    if (out.checkError()) throw new IOException("failed to write JFR caller summary");
  }

  private void add(RecordedEvent event) throws IOException {
    allEvents.add(event);
    String type = event.getEventType().getName();
    if (type.equals("jdk.DataLoss")) dataLossEvents = Math.addExact(dataLossEvents, 1);
    if (!type.equals(CPU) && !type.equals(ALLOCATION)) return;
    RecordedStackTrace stack = event.getStackTrace();
    boolean missing = stack == null || stack.getFrames().isEmpty();
    if (type.equals(CPU)) {
      cpuEvents.add(event);
      if (missing) { cpuMissingStack = Math.addExact(cpuMissingStack, 1); return; }
      if (stack.isTruncated()) cpuTruncatedStack = Math.addExact(cpuTruncatedStack, 1);
      RecordedMethod leaf = stack.getFrames().get(0).getMethod();
      if (leaf == null) cpuUnknownLeaf = Math.addExact(cpuUnknownLeaf, 1);
      for (CpuTarget target : cpuTargets) if (target.matches(leaf)) target.add(stack);
    } else {
      allocationEvents.add(event);
      if (!event.hasField("weight") || !event.hasField("objectClass")) {
        throw new IOException("ObjectAllocationSample lacks weight/objectClass");
      }
      long weight = event.getLong("weight");
      if (weight < 0) throw new IOException("negative allocation weight");
      allocationWeight = Math.addExact(allocationWeight, weight);
      if (missing) {
        allocationMissingStack = Math.addExact(allocationMissingStack, 1);
        allocationMissingWeight = Math.addExact(allocationMissingWeight, weight);
      } else if (stack.isTruncated()) allocationTruncatedStack = Math.addExact(allocationTruncatedStack, 1);
      RecordedClass cls = event.getClass("objectClass");
      if (cls == null) return;
      String name = cls.getName().replace('/', '.');
      for (AllocationTarget target : allocationTargets) {
        if (target.objectClass.equals(name)) target.add(stack, weight);
      }
    }
  }

  private static void increment(Map<String, Long> values, String key) {
    values.merge(key, 1L, (left, right) -> Math.addExact(left, right));
  }
  private static String frame(RecordedFrame frame) {
    RecordedMethod method = frame.getMethod();
    String name = method == null ? "<unknown method>"
        : method.getType().getName() + "." + method.getName() + method.getDescriptor();
    return name + " [line=" + frame.getLineNumber() + ",bci=" + frame.getBytecodeIndex() + ",type=" + frame.getType() + "]";
  }
  private static String prefix(RecordedStackTrace stack, int start, int count, String missing) {
    List<RecordedFrame> frames = stack.getFrames();
    if (frames.size() <= start) return missing;
    int end = Math.min(frames.size(), start + count);
    StringBuilder result = new StringBuilder();
    for (int i = start; i < end; i++) {
      if (i > start) result.append(" <- ");
      result.append(frame(frames.get(i)));
    }
    result.append(frames.size() > end ? " <- <deeper frames omitted>"
        : stack.isTruncated() ? " <- <recording stack truncated>" : " <- <recorded stack ends>");
    return result.toString();
  }

  private void write(PrintWriter out, Path path) {
    row(out, "SCHEMA", "JfrAllocationCallers/1"); row(out, "RECORDING", path);
    row(out, "NOTE", "CPU counts are observed jdk.ExecutionSample leaves, not wall time, exact CPU time, or call counts. Allocation weights are sampled estimates, not exact allocated or retained bytes.");
    row(out, "NOTE", "CPU_IMMEDIATE and CPU_CALLERS4 are alternative partitions of the same matched leaf samples; do not add them. Callers exclude the sampled leaf and run outward from its immediate recorded caller.");
    row(out, "NOTE", "Allocation prefixes retain the first five recorded frames starting at the allocation leaf. Equal prefixes merge deeper contexts intentionally; deeper-frame omission is distinct from recording truncation.");
    row(out, "NOTE", "Methods match exact declaring class/name across overloads; allocation classes match exactly. Keys retain descriptors, line, BCI and frame type; class-loader identities are merged. Negative line/BCI values remain unknown.");
    row(out, "NOTE", "Zero totals mean no matching recorded samples, not no execution. Sampling, missing/truncated stacks, inlining, profiler overhead and pauses constrain inference. Windows span observed event timestamps, not compile durations.");
    row(out, "COLUMNS", "WINDOW", "event", "count", "first_start", "last_end", "observed_span_ns");
    window(out, "all_events", allEvents); window(out, CPU, cpuEvents); window(out, ALLOCATION, allocationEvents);
    row(out, "DATA_LOSS_EVENTS", dataLossEvents);
    row(out, "COLUMNS", "CPU_TOTAL", "samples", "missing_stack", "unknown_leaf_method", "truncated_stack");
    row(out, "CPU_TOTAL", cpuEvents.count, cpuMissingStack, cpuUnknownLeaf, cpuTruncatedStack);
    row(out, "COLUMNS", "ALLOCATION_TOTAL", "samples", "estimated_weight_bytes", "missing_stack", "missing_stack_weight_bytes", "truncated_stack");
    row(out, "ALLOCATION_TOTAL", allocationEvents.count, allocationWeight, allocationMissingStack, allocationMissingWeight, allocationTruncatedStack);
    row(out, "COLUMNS", "CPU_LEAF_TOTAL", "leaf", "matched_samples", "all_cpu_samples", "pct_all_cpu", "missing_caller", "truncated_stack");
    row(out, "COLUMNS", "CPU_IMMEDIATE/CPU_CALLERS4", "leaf", "rank", "samples", "matched_leaf_denominator", "all_cpu_denominator", "pct_leaf", "pct_all_cpu", "caller_frames");
    row(out, "COLUMNS", "CPU_REMAINDER", "partition", "leaf", "unshown_distinct_keys", "unshown_samples");
    for (CpuTarget target : cpuTargets) {
      row(out, "CPU_LEAF_TOTAL", target.label(), target.samples, cpuEvents.count, percent(target.samples, cpuEvents.count), target.missingCaller, target.truncatedStack);
      cpuTable(out, "CPU_IMMEDIATE", target, target.immediate);
      cpuTable(out, "CPU_CALLERS4", target, target.callers);
    }
    row(out, "COLUMNS", "ALLOCATION_CLASS_TOTAL", "class", "samples", "estimated_weight_bytes", "all_allocation_samples", "all_allocation_weight_bytes", "pct_all_weight", "missing_stack", "missing_stack_weight_bytes", "truncated_stack");
    row(out, "COLUMNS", "ALLOCATION_PREFIX5", "class", "rank", "samples", "estimated_weight_bytes", "class_samples_denominator", "class_weight_denominator", "all_weight_denominator", "pct_class_weight", "pct_all_weight", "frames");
    row(out, "COLUMNS", "ALLOCATION_REMAINDER", "class", "unshown_distinct_keys", "unshown_samples", "unshown_weight_bytes");
    for (AllocationTarget target : allocationTargets) {
      row(out, "ALLOCATION_CLASS_TOTAL", target.objectClass, target.total.events, target.total.bytes, allocationEvents.count,
          allocationWeight, percent(target.total.bytes, allocationWeight), target.missingStack, target.missingWeight, target.truncatedStack);
      List<Map.Entry<String, Weight>> entries = new ArrayList<>(target.prefixes.entrySet());
      entries.sort(Comparator.<Map.Entry<String, Weight>>comparingLong(entry -> entry.getValue().bytes).reversed().thenComparing(Map.Entry.comparingByKey()));
      int shown = Math.min(10, entries.size()); long shownEvents = 0, shownWeight = 0;
      for (int i = 0; i < shown; i++) {
        Map.Entry<String, Weight> entry = entries.get(i); Weight value = entry.getValue();
        shownEvents = Math.addExact(shownEvents, value.events); shownWeight = Math.addExact(shownWeight, value.bytes);
        row(out, "ALLOCATION_PREFIX5", target.objectClass, i + 1, value.events, value.bytes, target.total.events, target.total.bytes,
            allocationWeight, percent(value.bytes, target.total.bytes), percent(value.bytes, allocationWeight), entry.getKey());
      }
      row(out, "ALLOCATION_REMAINDER", target.objectClass, entries.size() - shown, target.total.events - shownEvents, target.total.bytes - shownWeight);
    }
  }

  private void cpuTable(PrintWriter out, String tag, CpuTarget target, Map<String, Long> values) {
    List<Map.Entry<String, Long>> entries = new ArrayList<>(values.entrySet());
    entries.sort(Map.Entry.<String, Long>comparingByValue(Comparator.reverseOrder()).thenComparing(Map.Entry.comparingByKey()));
    int shown = Math.min(20, entries.size()); long shownSamples = 0;
    for (int i = 0; i < shown; i++) {
      Map.Entry<String, Long> entry = entries.get(i); shownSamples = Math.addExact(shownSamples, entry.getValue());
      row(out, tag, target.label(), i + 1, entry.getValue(), target.samples, cpuEvents.count,
          percent(entry.getValue(), target.samples), percent(entry.getValue(), cpuEvents.count), entry.getKey());
    }
    row(out, "CPU_REMAINDER", tag, target.label(), entries.size() - shown, target.samples - shownSamples);
  }
  private static void window(PrintWriter out, String label, Window window) {
    row(out, "WINDOW", label, window.count, window.firstStart, window.lastEnd,
        window.firstStart == null ? 0 : Duration.between(window.firstStart, window.lastEnd).toNanos());
  }
  private static String percent(long value, long total) {
    return total == 0 ? "0.0000" : String.format(Locale.ROOT, "%.4f", 100.0 * value / total);
  }
  private static void row(PrintWriter out, Object... cells) {
    for (int i = 0; i < cells.length; i++) {
      if (i != 0) out.print('\t');
      String value = cells[i] == null ? "" : cells[i].toString();
      out.print(value.replace("\\", "\\\\").replace("\t", "\\t").replace("\n", "\\n").replace("\r", "\\r"));
    }
    out.println();
  }
}
