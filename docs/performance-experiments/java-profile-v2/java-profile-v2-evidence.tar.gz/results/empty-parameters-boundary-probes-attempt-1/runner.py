"""Compile source-pinned probes once, then check STOCK, CONTROL, and one candidate.

Each invocation requires a fresh --out directory. Failed attempts remain intact;
correct fixtures in a new source copy and use a new output directory to retry.
"""
from pathlib import Path
from urllib.parse import unquote, urlsplit
import argparse
import hashlib
import json
import os
import re
import subprocess
import sys
import time

DEFAULT_JAR = Path('/workspace/jsgo/.cache/closure-compiler-v20261015-maven.jar')
REMOVED_ENV = ('JAVA_TOOL_OPTIONS', '_JAVA_OPTIONS', 'JDK_JAVA_OPTIONS')
RELOCATION = r'(?<![\w.])com\.google\.(common|auto|errorprone|gson|protobuf|j2objc|thirdparty)(?=\.)'
JAVA_NAME = r'[A-Za-z_$][A-Za-z0-9_$]*(?:\.[A-Za-z_$][A-Za-z0-9_$]*)*'


def digest(data):
    return hashlib.sha256(data).hexdigest()


def sha(path):
    result = hashlib.sha256()
    with Path(path).open('rb') as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b''):
            result.update(chunk)
    return result.hexdigest()


def save(path, value):
    Path(path).write_text(json.dumps(value, indent=2) + '\n')


def require(condition, message):
    if not condition:
        raise ValueError(message)


def runtimes():
    found = []
    for entry in Path('/proc').iterdir():
        if entry.name.isdigit():
            try:
                command = (entry / 'comm').read_text().strip()
                if command in ('java', 'javac'):
                    found.append({'pid': int(entry.name), 'comm': command})
            except (FileNotFoundError, PermissionError, ProcessLookupError):
                pass
    return sorted(found, key=lambda item: item['pid'])


def command(directory, argv, environment, timeout):
    directory.mkdir()
    receipt = {'argv': argv, 'cwd': str(directory), 'started_unix': time.time(),
               'environment_variables_removed': REMOVED_ENV, 'timeout_seconds': timeout,
               'status': 'RUNNING', 'exit': None}
    save(directory / 'command.json', receipt)
    process = None
    with (directory / 'stdout').open('wb') as out, (directory / 'stderr').open('wb') as err:
        try:
            process = subprocess.Popen(argv, cwd=directory, env=environment, stdout=out, stderr=err)
            receipt['pid'] = process.pid
            save(directory / 'command.json', receipt)
            receipt['exit'] = process.wait(timeout=timeout)
            receipt['status'] = 'PASS' if receipt['exit'] == 0 else 'FAIL_EXIT'
        except subprocess.TimeoutExpired:
            receipt['status'] = 'TIMEOUT'
        except (Exception, KeyboardInterrupt) as error:
            receipt.update(status='ERROR', error_type=type(error).__name__, error=str(error))
        finally:
            if process is not None and process.poll() is None:
                process.kill()
                receipt['exit'] = process.wait()
            receipt['ended_unix'] = time.time()
    receipt.update(stdout_sha256=sha(directory / 'stdout'), stderr_sha256=sha(directory / 'stderr'))
    save(directory / 'command.json', receipt)
    return receipt


def check_origins(log, classes, expected):
    lines = log.read_text().splitlines() if log.exists() else []
    results = {}
    for name in classes:
        pattern = re.compile(r'\] ' + re.escape(name) + r' source: (.*)$')
        matches = [match.group(1) for line in lines if (match := pattern.search(line))]
        normalized = []
        for value in matches:
            uri = urlsplit(value)
            normalized.append(str(Path(unquote(uri.path)).resolve())
                              if uri.scheme == 'file' and uri.netloc in ('', 'localhost') else None)
        results[name] = {'logged_origins': matches, 'normalized_origins': normalized,
                         'expected_path': str(expected),
                         'pass': normalized == [str(expected)]}
    return results


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--manifest', required=True, type=Path)
    parser.add_argument('--candidate', help='Defaults to the sole non-STOCK/non-CONTROL variant.')
    parser.add_argument('--probe-source', required=True, action='append', type=Path)
    parser.add_argument('--probe-class', required=True, action='append', help='Fully qualified main class.')
    parser.add_argument('--origin-class', action='append', help='Defaults to all manifest source families.')
    parser.add_argument('--probe-arg', action='append', default=[], help='Argument passed to every run.')
    parser.add_argument('--candidate-arg', action='append', default=[], help='Additional candidate-only argument.')
    parser.add_argument('--compare-stdout', action='store_true', help='Require exact stdout equality with STOCK.')
    parser.add_argument('--jar', type=Path, default=DEFAULT_JAR)
    parser.add_argument('--out', required=True, type=Path)
    parser.add_argument('--timeout', type=float, default=60.0, help='Per compiler/probe process, seconds.')
    args = parser.parse_args()
    destination = args.out.resolve()
    # Refuse to overwrite receipts, classes, or sources from any earlier attempt.
    destination.mkdir(parents=True, exist_ok=False)
    metadata = {'status': 'PREPARING', 'started_unix': time.time(), 'invocation_argv': sys.argv,
                'sources': {}, 'runs': [], 'overlays': {}, 'preflight_runtimes': [],
                'build_manifest': str(args.manifest.resolve())}
    save(destination / 'manifest.json', metadata)
    manifest_bytes = None
    tracked_sources = {}
    try:
        require(args.timeout > 0, '--timeout must be positive')
        metadata['preflight_runtimes'] = runtimes()
        require(not metadata['preflight_runtimes'], 'Java runtime already active; do not overlap benchmarks')
        runner = Path(__file__).read_bytes()
        (destination / 'runner.py').write_bytes(runner)
        metadata['runner_sha256'] = digest(runner)
        manifest_bytes = args.manifest.resolve().read_bytes()
        (destination / 'build-manifest.json').write_bytes(manifest_bytes)
        metadata['build_manifest_sha256'] = digest(manifest_bytes)
        manifest = json.loads(manifest_bytes)
        require(manifest['status'] == 'PASS_BUILD_VALIDATION', 'Build manifest did not pass validation')
        candidates = [name for name in manifest['variants'] if name not in ('STOCK', 'CONTROL')]
        candidate = args.candidate or (candidates[0] if len(candidates) == 1 else None)
        require(candidate in candidates, 'Specify a candidate present in the build manifest')
        require(re.fullmatch(r'[A-Za-z0-9_.-]+', candidate), 'Invalid candidate name')
        for name in ('STOCK', 'CONTROL', candidate):
            require(name in manifest['variants'], 'Missing variant: ' + name)
        require(manifest['variants']['STOCK']['overlay'] is None, 'STOCK must have no overlay')
        jar = args.jar.resolve()
        metadata.update(candidate=candidate, jar=str(jar), jar_sha256=sha(jar))
        require(metadata['jar_sha256'] == manifest['jar_sha256'], 'Pinned jar digest mismatch')
        java = (Path(manifest['java_home']) / 'bin/java').resolve()
        flags = manifest['javac_flags']
        origins = args.origin_class or [name.replace('/', '.') for name in manifest['compiler_source_families']]
        require(origins, 'No class-origin targets')
        require(all(re.fullmatch(JAVA_NAME, name)
                    for name in [*origins, *args.probe_class]), 'Invalid fully qualified class name')
        metadata.update(java=str(java), java_version_from_build_manifest=manifest.get('java_version'),
                        javac_flags=flags, origin_classes=origins,
                        expected_runs=3 * len(args.probe_class), execution_complete=False)
        sourcepath = destination / 'empty-sourcepath'
        classes = destination / 'classes'
        sourcepath.mkdir()
        classes.mkdir()
        relocated_files = []
        for source_arg in args.probe_source:
            source = source_arg.resolve()
            data = source.read_bytes()
            text = data.decode('UTF-8')
            package = re.search(r'(?m)^\s*package\s+(' + JAVA_NAME + r')\s*;', text)
            require(source.suffix == '.java' and package is not None, 'Expected a packaged Java source: ' + str(source))
            relative = Path(package.group(1).replace('.', '/')) / source.name
            original = destination / 'original-sources' / relative
            relocated = destination / 'relocated-sources' / relative
            require(not original.exists(), 'Duplicate source destination: ' + str(relative))
            original.parent.mkdir(parents=True, exist_ok=True)
            relocated.parent.mkdir(parents=True, exist_ok=True)
            original.write_bytes(data)
            changed = re.sub(RELOCATION, r'com.google.javascript.jscomp.jarjar.com.google.\1', text)
            relocated.write_text(changed, encoding='UTF-8')
            metadata['sources'][str(relative)] = {'original_path': str(source),
                'original_sha256': digest(data), 'relocated_sha256': sha(relocated)}
            tracked_sources[source] = digest(data)
            relocated_files.append(str(relocated))
        for name in ('CONTROL', candidate):
            specification = manifest['variants'][name]
            overlay = Path(specification['overlay']).resolve()
            actual = {str(path.relative_to(overlay)): sha(path) for path in sorted(overlay.rglob('*.class'))}
            require(actual == specification['classes'] and actual, 'Overlay classes differ from manifest: ' + name)
            metadata['overlays'][name] = {'directory': str(overlay), 'classes': actual}
        metadata['status'] = 'RUNNING'
        save(destination / 'manifest.json', metadata)
        environment = {key: value for key, value in os.environ.items() if key not in REMOVED_ENV}
        argv = [str(java), '-Xmx1g', '-m', 'jdk.compiler/com.sun.tools.javac.Main', *flags,
                '-cp', str(jar), '-sourcepath', str(sourcepath), '-d', str(classes), *relocated_files]
        metadata['compile'] = command(destination / 'compile', argv, environment, args.timeout)
        metadata['probe_classes'] = {str(path.relative_to(classes)): sha(path) for path in sorted(classes.rglob('*.class'))}
        metadata['status'] = metadata['compile']['status']
        if metadata['status'] == 'PASS':
            metadata['status'] = 'RUNNING'
            for probe in args.probe_class:
                require(probe.replace('.', '/') + '.class' in metadata['probe_classes'],
                        'Requested probe main class was not emitted: ' + probe)
            stock_stdout = {}
            for name in ('STOCK', 'CONTROL', candidate):
                overlay = Path(metadata['overlays'][name]['directory']) if name != 'STOCK' else None
                classpath = [str(classes)] + ([str(overlay)] if overlay else []) + [str(jar)]
                for index, probe in enumerate(args.probe_class):
                    run_dir = destination / (name + '-' + str(index + 1) + '-' + probe.rsplit('.', 1)[-1])
                    log = run_dir / 'class-load.log'
                    argv = [str(java), '-Xmx1g', '-Xlog:class+load=info:file=' + str(log),
                            '-cp', os.pathsep.join(classpath), probe, *args.probe_arg]
                    if name == candidate:
                        argv.extend(args.candidate_arg)
                    result = command(run_dir, argv, environment, args.timeout)
                    result.update(variant=name, probe=probe,
                                  class_origins=check_origins(log, origins, overlay or jar))
                    if log.exists():
                        result['class_load_log_sha256'] = sha(log)
                    if result['status'] == 'PASS' and not all(item['pass'] for item in result['class_origins'].values()):
                        result['status'] = 'FAIL_CLASS_ORIGIN'
                    output = (run_dir / 'stdout').read_bytes()
                    if name == 'STOCK':
                        stock_stdout[index] = output
                    elif args.compare_stdout:
                        result['stdout_equals_stock'] = output == stock_stdout[index]
                        if result['status'] == 'PASS' and not result['stdout_equals_stock']:
                            result['status'] = 'FAIL_STDOUT'
                    save(run_dir / 'result.json', result)
                    metadata['runs'].append(result)
                    if result['status'] != 'PASS':
                        metadata['status'] = result['status']
                    save(destination / 'manifest.json', metadata)
                    print(name, probe, result['status'], result['exit'], flush=True)
                    if result['status'] != 'PASS':
                        break
                if metadata['status'] != 'RUNNING':
                    break
            metadata['execution_complete'] = (
                len(metadata['runs']) == metadata['expected_runs']
                and all(run['status'] == 'PASS' for run in metadata['runs']))
    except (Exception, KeyboardInterrupt) as error:
        metadata.update(status='ERROR', error_type=type(error).__name__, error=str(error))
    finally:
        checks = {}
        for path, expected in tracked_sources.items():
            try:
                checks[str(path)] = sha(path) == expected
            except OSError:
                checks[str(path)] = False
        metadata['source_integrity'] = checks
        overlay_checks = {}
        for name, specification in metadata['overlays'].items():
            try:
                overlay = Path(specification['directory'])
                actual = {str(path.relative_to(overlay)): sha(path) for path in overlay.rglob('*.class')}
                overlay_checks[name] = actual == specification['classes']
            except OSError:
                overlay_checks[name] = False
        metadata['overlay_integrity'] = overlay_checks
        if manifest_bytes is not None:
            try:
                metadata['build_manifest_unchanged'] = args.manifest.resolve().read_bytes() == manifest_bytes
            except OSError:
                metadata['build_manifest_unchanged'] = False
        metadata['postflight_runtimes'] = runtimes()
        if metadata['status'] == 'RUNNING':
            if not metadata.get('execution_complete', False):
                metadata['status'] = 'FAIL_INCOMPLETE'
            elif (not all(checks.values()) or not all(overlay_checks.values())
                    or not metadata.get('build_manifest_unchanged', False) or metadata['postflight_runtimes']):
                metadata['status'] = 'FAIL_POSTFLIGHT'
            else:
                metadata['status'] = 'PASS'
        metadata['ended_unix'] = time.time()
        save(destination / 'manifest.json', metadata)
    print(json.dumps({'status': metadata['status'], 'manifest': str(destination / 'manifest.json'),
                      'postflight_runtimes': metadata['postflight_runtimes']}), flush=True)
    return 0 if metadata['status'] == 'PASS' else 1


if __name__ == '__main__':
    sys.exit(main())
