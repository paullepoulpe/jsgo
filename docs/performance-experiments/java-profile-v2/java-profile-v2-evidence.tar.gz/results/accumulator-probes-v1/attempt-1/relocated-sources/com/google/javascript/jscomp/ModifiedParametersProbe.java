package com.google.javascript.jscomp;

import com.google.javascript.jscomp.jarjar.com.google.common.collect.ImmutableSet;
import com.google.javascript.rhino.Node;
import java.util.ArrayList;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;

/** Semantic probe for stock, rebuilt control, and the shared-accumulator candidate. */
public final class ModifiedParametersProbe {
  public static void main(String[] args) {
    check("function f() { var x=0; x++; }");
    check("function f(a,b) { return a+b; }");
    check("function f(a,b,c) { c=1; a=1; b=2; c=3; }", "c", "a", "b");
    check("function f(a) { a.x=1; a[0]++; }");
    check("function f(a) { var a; }", "a");
    check("function f(a,b) { { let a=1; const b=2; } }");
    check("function f(a,b) { function g(){ return b+a; } return a; }", "b", "a");
    check("function f(a,b) { function g(){ return a; } return b; }", "a");
    check("function f(a,b) { const g=()=>b; return a; }", "b");
    check("function f(a,b) { function g(){ return b; } a=0; b=0; }", "b", "a");
    check("function f(a,b) { class C { x=a; static y=b; } }", "a");
    check("function f(a,b,c,d) { class C { [a]=b; static y=c; x=d; } }", "b", "d");
    check("function f(a) { class C { static x=(a=1); } }", "a");
    check("function f(a,b) { for(a in b) {} }", "a");
    check("function f(a,b) { for(a of b) {} }", "a");
    check("function f(a,b) { ({x:a}=b); }", "a");
    // Preserve the existing synthetic REST_MARKER convention, including its direct-AST behavior.
    check("function f(a,...args) { a=2; args=3; }", "a");

    StringBuilder repeated = new StringBuilder("function f(a,b) { b=0;");
    for (int i = 0; i < 100; i++) {
      repeated.append("if(a) { a=1; b=2; } else { b=3; a; }");
    }
    check(repeated.append('}').toString(), "b", "a");

    checkRejected("function f(a=1) { a=2; }");
    checkRejected("function f({a}) { a=2; }");
    checkRejected("function f([a]) { a=2; }");
    System.out.println("ModifiedParametersProbe OK");
  }

  private static void check(String source, String... expectedOrder) {
    Compiler compiler = new Compiler();
    Node function = parseFunction(compiler, source);
    String originalTree = function.toStringTree();
    FunctionArgumentInjector injector = new FunctionArgumentInjector(compiler.getAstAnalyzer());
    List<String> expected = List.of(expectedOrder);
    List<String> referenceOrder = new ArrayList<>(reference(function));
    require(referenceOrder.equals(expected), "fixture expectation", source);
    for (int i = 0; i < 2; i++) {
      List<String> actual = new ArrayList<>(injector.findModifiedParameters(function));
      require(actual.equals(referenceOrder), "ordered reference result", source);
      require(function.toStringTree().equals(originalTree), "AST mutation", source);
    }
  }

  private static void checkRejected(String source) {
    Compiler compiler = new Compiler();
    Node function = parseFunction(compiler, source);
    String originalTree = function.toStringTree();
    FunctionArgumentInjector injector = new FunctionArgumentInjector(compiler.getAstAnalyzer());
    String expectedMessage;
    try {
      reference(function);
      throw new AssertionError("reference accepted unsupported parameter: " + source);
    } catch (IllegalStateException expected) {
      expectedMessage = expected.getMessage();
    }
    try {
      injector.findModifiedParameters(function);
      throw new AssertionError("accepted unsupported parameter: " + source);
    } catch (IllegalStateException actual) {
      require(actual.getMessage().equals(expectedMessage), "exception message", source);
    }
    require(function.toStringTree().equals(originalTree), "AST mutation on exception", source);
  }

  private static Node parseFunction(Compiler compiler, String source) {
    Node script = compiler.parseTestCode(source);
    require(script != null && compiler.getErrors().isEmpty(), "parse failure", source);
    Node function = script.getFirstChild();
    require(function != null && function.isFunction(), "expected function", source);
    return function;
  }

  // Pinned original parameter extraction and recursive set-merging algorithm.
  private static ImmutableSet<String> reference(Node function) {
    ImmutableSet.Builder<String> names = ImmutableSet.builder();
    for (Node n = NodeUtil.getFunctionParameters(function).getFirstChild();
        n != null; n = n.getNext()) {
      if (n.isRest()) {
        names.add(FunctionArgumentInjector.REST_MARKER);
      } else if (n.isDefaultValue() || n.isObjectPattern() || n.isArrayPattern()) {
        throw new IllegalStateException("Not supported: " + n);
      } else {
        names.add(n.getString());
      }
    }
    return ImmutableSet.copyOf(reference(function.getLastChild(), names.build(), false));
  }

  private static Set<String> reference(Node n, ImmutableSet<String> names, boolean inInnerClosure) {
    LinkedHashSet<String> unsafe = new LinkedHashSet<>();
    if (NodeUtil.isFunctionOrNonStaticClassFieldInitializer(n)) {
      inInnerClosure = true;
    }
    if (n.isName() && names.contains(n.getString()) && (inInnerClosure || canNameValueChange(n))) {
      unsafe.add(n.getString());
    }
    for (Node c = n.getFirstChild(); c != null; c = c.getNext()) {
      unsafe.addAll(reference(c, names, inInnerClosure));
    }
    return unsafe;
  }

  private static boolean canNameValueChange(Node n) {
    if (!NodeUtil.isLValue(n)) {
      return false;
    }
    if (NodeUtil.isDeclarationLValue(n)) {
      Node declaring = NodeUtil.getDeclaringParent(n);
      return !declaring.isConst() && !declaring.isLet();
    }
    return true;
  }

  private static void require(boolean condition, String message, String source) {
    if (!condition) {
      throw new AssertionError(message + ": " + source);
    }
  }
}
