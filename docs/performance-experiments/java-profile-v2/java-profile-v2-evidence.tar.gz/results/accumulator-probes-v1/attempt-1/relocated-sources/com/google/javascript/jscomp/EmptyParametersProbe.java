package com.google.javascript.jscomp;

import com.google.javascript.jscomp.jarjar.com.google.common.collect.ImmutableSet;
import com.google.javascript.rhino.IR;
import com.google.javascript.rhino.Node;
import com.google.javascript.rhino.Token;
import java.util.ArrayList;
import java.util.List;

/** Valid-AST checks plus an explicit malformed-body boundary for the empty-formal shortcut. */
public final class EmptyParametersProbe {
  public static void main(String[] args) {
    boolean expectShortcut = args.length == 1 && args[0].equals("--expect-shortcut");
    require(args.length == 0 || expectShortcut, "unexpected arguments");
    check("function f() {}");
    check("function f() { f=1; return f; }");
    check("function f() { function g(a) { a=1; } return ()=>f; }");
    check("function f() { arguments[0]=1; this.x=2; class C { [f]=f; x=()=>f; static y=f; } }");
    check("function* f() { yield 1; }");
    check("function f(a) { a=1; }", "a");
    check("function f(...args) { args=1; }");

    StringBuilder large = new StringBuilder("function f() {");
    for (int i = 0; i < 100; i++) {
      large.append("if(f) { f=1; } else { f++; }");
    }
    check(large.append('}').toString());

    Compiler compiler = new Compiler();
    compiler.parseTestCode("function f() {}");
    FunctionArgumentInjector injector = new FunctionArgumentInjector(compiler.getAstAnalyzer());
    requireThrows(NullPointerException.class, () -> injector.findModifiedParameters(null));
    requireThrows(IllegalArgumentException.class, () -> injector.findModifiedParameters(IR.block()));
    requireThrows(NullPointerException.class,
        () -> injector.findModifiedParameters(new Node(Token.FUNCTION)));

    // NAME nodes must be StringNodes. This intentionally malformed body marks the contract boundary:
    // stock and accumulator-only throw while the empty-formal variants never inspect the body.
    Node invalidBody = invalidNameFunction(IR.paramList());
    if (expectShortcut) {
      require(injector.findModifiedParameters(invalidBody).isEmpty(), "empty shortcut boundary");
    } else {
      requireThrows(ClassCastException.class, () -> injector.findModifiedParameters(invalidBody));
    }
    // A real formal or REST_MARKER prevents the shortcut; malformed-body errors remain observable.
    requireThrows(ClassCastException.class,
        () -> injector.findModifiedParameters(invalidNameFunction(IR.paramList(IR.name("a")))));
    requireThrows(ClassCastException.class,
        () -> injector.findModifiedParameters(
            invalidNameFunction(IR.paramList(new Node(Token.ITER_REST, IR.name("args"))))));
    System.out.println("EmptyParametersProbe OK");
  }

  private static void check(String source, String... expectedOrder) {
    Compiler compiler = new Compiler();
    Node script = compiler.parseTestCode(source);
    require(script != null && compiler.getErrors().isEmpty(), "parse failure: " + source);
    Node function = script.getFirstChild();
    require(function != null && function.isFunction(), "expected function: " + source);
    String before = function.toStringTree();
    FunctionArgumentInjector injector = new FunctionArgumentInjector(compiler.getAstAnalyzer());
    ImmutableSet<String> result = injector.findModifiedParameters(function);
    require(new ArrayList<>(result).equals(List.of(expectedOrder)), "ordered result: " + source);
    require(function.toStringTree().equals(before), "AST mutation: " + source);
  }

  private static Node invalidNameFunction(Node parameters) {
    return IR.function(IR.name("f"), parameters,
        IR.block(IR.exprResult(new Node(Token.NAME))));
  }

  private static void requireThrows(Class<? extends RuntimeException> type, Runnable operation) {
    try {
      operation.run();
      throw new AssertionError("Expected " + type.getSimpleName());
    } catch (RuntimeException actual) {
      require(type.isInstance(actual), "Expected " + type.getSimpleName() + ", got " + actual);
    }
  }

  private static void require(boolean condition, String message) {
    if (!condition) {
      throw new AssertionError(message);
    }
  }
}
