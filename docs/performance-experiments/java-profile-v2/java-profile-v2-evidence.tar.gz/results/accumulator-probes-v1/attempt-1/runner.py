"""Compile frozen semantic probes once and run stock/control/accumulator sequentially."""
from pathlib import Path
import argparse
import hashlib
import json
import os
import re
import subprocess
import time

ROOT = Path(__file__).resolve().parent
PROFILE = ROOT.parent.parent
CANDIDATE = PROFILE / 'candidates/scope-maps'
MANIFEST_PATH = PROFILE / 'build/accumulator/manifest.json'
JAR = Path('/workspace/jsgo/.cache/closure-compiler-v20261015-maven.jar')
JAVA = Path('/usr/lib/jvm/java-21-openjdk-amd64/bin/java')
FLAGS = ['-source', '21', '-target', '21', '-g', '-proc:none', '-implicit:none',
         '-encoding', 'UTF-8']
SOURCES = {
    'ModifiedParametersProbe.java': CANDIDATE / 'probe/com/google/javascript/jscomp/ModifiedParametersProbe.java',
    'EmptyParametersProbe.java': CANDIDATE / 'empty-parameters-only/probe/com/google/javascript/jscomp/EmptyParametersProbe.java',
}
ENV_REMOVED = ['JAVA_TOOL_OPTIONS', '_JAVA_OPTIONS', 'JDK_JAVA_OPTIONS']


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def save(path, value):
    Path(path).write_text(json.dumps(value, indent=2) + '\n')


def runtimes():
    found = []
    for entry in Path('/proc').iterdir():
        if not entry.name.isdigit():
            continue
        try:
            if (entry / 'comm').read_text().strip() in ('java', 'javac'):
                found.append({'pid': int(entry.name), 'comm': (entry / 'comm').read_text().strip()})
        except (FileNotFoundError, PermissionError):
            pass
    return found


def run(directory, argv, env):
    directory.mkdir()
    receipt = {'argv': argv, 'cwd': str(directory), 'started_unix': time.time(),
               'environment_variables_removed': ENV_REMOVED}
    save(directory / 'command.json', receipt)
    with (directory / 'stdout').open('wb') as out, (directory / 'stderr').open('wb') as err:
        try:
            process = subprocess.run(argv, cwd=directory, env=env, stdout=out, stderr=err, timeout=60)
            receipt.update(exit=process.returncode, status='PASS' if process.returncode == 0 else 'FAIL')
        except subprocess.TimeoutExpired:
            receipt.update(exit=None, status='TIMEOUT')
    receipt.update(ended_unix=time.time(), stdout_sha256=sha(directory / 'stdout'),
                   stderr_sha256=sha(directory / 'stderr'))
    save(directory / 'command.json', receipt)
    return receipt


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('attempt')
    parser.add_argument('--effective-source-dir', type=Path)
    args = parser.parse_args()
    assert re.fullmatch('attempt-[0-9]+', args.attempt)
    destination = ROOT / args.attempt
    destination.mkdir()
    manifest = json.loads(MANIFEST_PATH.read_text())
    assert manifest['status'] == 'PASS_BUILD_VALIDATION'
    assert sha(JAR) == manifest['jar_sha256']
    assert not runtimes(), 'exclusive runtime grant violated before execution'
    original = destination / 'original-sources'
    effective = destination / 'effective-sources'
    relocated = destination / 'relocated-sources/com/google/javascript/jscomp'
    classes = destination / 'classes'
    sourcepath = destination / 'empty-sourcepath'
    for directory in (original, effective, relocated, classes, sourcepath):
        directory.mkdir(parents=True)
    metadata = {'build_manifest': str(MANIFEST_PATH), 'build_manifest_sha256': sha(MANIFEST_PATH),
                'jar': str(JAR), 'jar_sha256': manifest['jar_sha256'], 'java': str(JAVA),
                'java_version_from_build_manifest': manifest['java_version'],
                'runner_sha256': sha(__file__), 'javac_flags': FLAGS, 'sources': {},
                'preflight_runtimes': runtimes(), 'runs': [], 'status': 'RUNNING'}
    for filename, source in SOURCES.items():
        data = source.read_bytes()
        (original / filename).write_bytes(data)
        chosen = args.effective_source_dir / filename if args.effective_source_dir else source
        chosen_data = chosen.read_bytes()
        (effective / filename).write_bytes(chosen_data)
        transformed = re.sub(r'(?<![\w.])com\.google\.(common|auto|errorprone|gson|protobuf|j2objc|thirdparty)(?=\.)',
                             r'com.google.javascript.jscomp.jarjar.com.google.\1', chosen_data.decode())
        (relocated / filename).write_text(transformed)
        metadata['sources'][filename] = {
            'original_path': str(source), 'original_sha256': sha(source),
            'effective_source_path': str(chosen), 'effective_sha256': sha(effective / filename),
            'relocated_sha256': sha(relocated / filename)}
    for variant in ('CONTROL', 'accumulator'):
        specification = manifest['variants'][variant]
        overlay = Path(specification['overlay'])
        assert {str(p.relative_to(overlay)): sha(p) for p in overlay.rglob('*.class')} == specification['classes']
    save(destination / 'manifest.json', metadata)
    env = {key: value for key, value in os.environ.items() if key not in ENV_REMOVED}
    compile_command = [str(JAVA), '-Xmx1g', '-m', 'jdk.compiler/com.sun.tools.javac.Main',
                       *FLAGS, '-cp', str(JAR), '-sourcepath', str(sourcepath), '-d', str(classes),
                       *[str(relocated / filename) for filename in SOURCES]]
    compilation = run(destination / 'compile', compile_command, env)
    metadata['compile'] = compilation
    metadata['classes'] = {str(p.relative_to(classes)): sha(p) for p in classes.rglob('*.class')}
    metadata['status'] = compilation['status']
    if compilation['status'] == 'PASS':
        for variant in ('STOCK', 'CONTROL', 'accumulator'):
            for filename in SOURCES:
                simple = filename.removesuffix('.java')
                name = 'com.google.javascript.jscomp.' + simple
                run_dir = destination / (variant + '-' + simple)
                overlay = manifest['variants'][variant]['overlay']
                classpath = [str(classes)] + ([overlay] if overlay else []) + [str(JAR)]
                argv = [str(JAVA), '-Xmx1g', '-Xlog:class+load=info:file=' + str(run_dir / 'class-load.log'),
                        '-cp', os.pathsep.join(classpath), name]
                result = run(run_dir, argv, env)
                result.update(variant=variant, probe=name)
                class_log = run_dir / 'class-load.log'
                loaded = [line for line in class_log.read_text().splitlines()
                          if '] com.google.javascript.jscomp.FunctionArgumentInjector source: ' in line]
                expected_origin = Path(overlay).as_uri() + '/' if overlay else JAR.as_uri()
                result['function_argument_injector_origin'] = loaded
                result['expected_origin'] = expected_origin
                result['class_load_log_sha256'] = sha(class_log)
                if len(loaded) != 1 or loaded[0].split(' source: ', 1)[1] != expected_origin:
                    result['status'] = 'FAIL_CLASS_ORIGIN'
                save(run_dir / 'result.json', result)
                metadata['runs'].append(result)
                print(variant, simple, result['status'], result['exit'], flush=True)
                if result['status'] != 'PASS':
                    metadata['status'] = result['status']
                    break
            if metadata['status'] != 'PASS':
                break
    metadata['postflight_runtimes'] = runtimes()
    metadata['original_sources_unchanged'] = all(
        sha(SOURCES[name]) == record['original_sha256'] for name, record in metadata['sources'].items())
    metadata['build_manifest_unchanged'] = sha(MANIFEST_PATH) == metadata['build_manifest_sha256']
    assert not metadata['postflight_runtimes']
    assert metadata['original_sources_unchanged'] and metadata['build_manifest_unchanged']
    save(destination / 'manifest.json', metadata)
    print(json.dumps({'status': metadata['status'], 'manifest': str(destination / 'manifest.json'),
                      'postflight_runtimes': metadata['postflight_runtimes']}), flush=True)
    if compilation['status'] != 'PASS':
        print((destination / 'compile/stderr').read_text())
    elif metadata['status'] != 'PASS':
        print((run_dir / 'stderr').read_text())


if __name__ == '__main__':
    main()
