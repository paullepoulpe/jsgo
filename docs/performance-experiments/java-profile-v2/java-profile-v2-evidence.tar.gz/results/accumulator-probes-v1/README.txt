Accumulator semantic probes: PASS

Attempt 2 compiled mechanically relocated copies of the two frozen probe sources
against the pinned Closure v20261015 stock jar, using Java 21 and the recorded
source/target/debug/annotation-processing flags. Both ModifiedParametersProbe and
EmptyParametersProbe passed on STOCK, rebuilt CONTROL, and the accumulator overlay:
six runs, each exit 0. Loaded FunctionArgumentInjector origins matched the intended
stock jar or overlay directory. Probe expectations needed no correction.

attempt-2/manifest.json records original/effective/relocated source hashes, probe
class hashes, exact compile/runtime argv, exits, and source/build immutability
checks. Per-command directories retain stdout, stderr, and class-load logs. Runner
copies are retained inside each attempt. The matching source snapshots and empty
sourcepath directories are also retained. Postflight observed no java/javac
processes; the exclusive runtime grant was released to the parent at completion.

Attempt 1 is preserved. Its STOCK ModifiedParametersProbe passed with exit 0, but
the harness classified class provenance as failing because JDK logs use file:/...
while pathlib.as_uri generated file:///.... The runner's expected URI formatting
was corrected without changing probe fixtures or production sources. Attempt 2
then rebuilt the probes and completed all six cases successfully.

Only the existing accumulator/control build was exercised. Empty-parameter and
combined production variants were not built or run. EmptyParametersProbe ran in
its stock-behavior mode, confirming the accumulator retains malformed-body errors.
These checks establish focused semantic parity; they do not establish an
end-to-end performance improvement or replace the parent's byte-output gates.
