package com.google.javascript.rhino.jstype;

import com.google.javascript.jscomp.jarjar.com.google.common.collect.ImmutableList;
import com.google.javascript.rhino.ErrorReporter;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/** Same-source oracle probe for the exact plain-object equality shortcut. */
public final class PrototypeScalarEqualsProbe {
  private record Case(String label, JSType type) {}
  private record Outcome(boolean value, String failure) {}
  private interface Comparison { boolean run(); }
  private static final Reporter REPORTER = new Reporter();
  private static final JSTypeRegistry REGISTRY = new JSTypeRegistry(REPORTER);

  public static void main(String[] args) {
    check(args.length == 0, "unexpected arguments");
    matrix();
    uncachedPrototypeHooks(false);
    uncachedPrototypeHooks(true);
    subclassFallback();
    templateMaps();
    unresolvedAndProxy();
    System.out.println("PrototypeScalarEqualsProbe OK");
  }

  private static void matrix() {
    List<Case> cases = new ArrayList<>();
    for (JSTypeNative kind : JSTypeNative.values()) {
      JSType type = REGISTRY.getNativeType(kind);
      check(type != null, "native initialized");
      check(type.equals(type), "native self identity");
      check(!type.equals(null) && !type.equals("unrelated"), "non-type operands");
      cases.add(new Case("native-" + kind.name(), type));
    }
    PrototypeObjectType plain = plain("Plain");
    PrototypeObjectType anonymous = plain(null);
    warmKnown(plain);
    warmKnown(anonymous);
    cases.add(new Case("plain", plain));
    cases.add(new Case("anonymous", anonymous));
    cases.add(new Case("same-name-other", plain("Plain")));
    JSType number = REGISTRY.getNativeType(JSTypeNative.NUMBER_TYPE);
    JSType string = REGISTRY.getNativeType(JSTypeNative.STRING_TYPE);
    cases.add(new Case("record-a", REGISTRY.createRecordType(Map.of("x", number))));
    cases.add(new Case("record-b", REGISTRY.createRecordType(Map.of("x", number))));
    cases.add(new Case("function-a", REGISTRY.createFunctionType(number, string)));
    cases.add(new Case("function-b", REGISTRY.createFunctionType(number, string)));
    cases.add(new Case("union", REGISTRY.createUnionType(plain, REGISTRY.getNativeType(JSTypeNative.NULL_TYPE))));
    cases.add(new Case("proxy-to-plain", new ProxyObjectType(REGISTRY, plain)));
    cases.add(new Case("no-resolved", new NoResolvedType(REGISTRY, "Absent", ImmutableList.of())));
    for (Case left : cases) {
      StringBuilder bits = new StringBuilder(left.label()).append(':');
      for (Case right : cases) {
        boolean expected = reference(left.type(), right.type());
        boolean actual = left.type().equals(right.type());
        check(actual == expected, left.label() + "/" + right.label());
        bits.append(actual ? '1' : '0');
      }
      System.out.println(bits);
    }
    for (int kind = 0; kind < 4; kind++) {
      JSType right = freshRight(kind);
      check(eligible(plain, right), "positive guard fixture " + kind);
      check(!reference(plain, right) && !plain.equals(right), "plain/final right " + kind);
      check(plain.hasCachedValues(), "positive guard preserves known cache");
    }
  }

  private static void uncachedPrototypeHooks(boolean unknown) {
    CountingPrototype prototype = new CountingPrototype();
    PrototypeObjectType left = PrototypeObjectType.builder(REGISTRY)
        .setName("WithCountingPrototype").setImplicitPrototype(prototype).build();
    prototype.armed = true;
    prototype.answer = unknown;
    for (int kind = 0; kind < 4; kind++) {
      JSType right = freshRight(kind);
      left.clearCachedValues();
      prototype.calls = 0;
      check(!eligible(left, right), "uncached root must fall back");
      boolean expected = reference(left, right);
      int expectedCalls = prototype.calls;
      boolean expectedCache = left.hasCachedValues();
      left.clearCachedValues();
      prototype.calls = 0;
      boolean actual = left.equals(right);
      check(actual == expected && prototype.calls == expectedCalls,
          "uncached prototype callback parity " + kind);
      check(expectedCalls > 0 && left.hasCachedValues() == expectedCache,
          "uncached cache transition parity " + kind);
      check(left.hasCachedValues() == !unknown, "cache tracks unknown result");
      if (!unknown) {
        prototype.throwOnCall = true;
        prototype.calls = 0;
        check(eligible(left, right), "known cached root is eligible");
        check(!reference(left, right) && !left.equals(right), "cached result");
        check(prototype.calls == 0, "cached comparison must not revisit prototype");
        prototype.throwOnCall = false;
      }
      System.out.println("prototype-hook:" + unknown + ":" + kind + ":" + expectedCalls
          + ":cached=" + expectedCache + ":result=" + actual);
    }
    left.clearCachedValues();
    prototype.throwOnCall = true;
    prototype.calls = 0;
    Outcome expected = outcome(() -> reference(left, freshRight(0)));
    int expectedCalls = prototype.calls;
    left.clearCachedValues();
    prototype.calls = 0;
    Outcome actual = outcome(() -> left.equals(freshRight(0)));
    check(expected.equals(actual) && expected.failure().equals("prototype hook")
        && prototype.calls == expectedCalls, "uncached throwing hook fallback");
  }

  private static void subclassFallback() {
    CountingValue left = new CountingValue();
    warmKnown(left);
    left.armed = true;
    for (int kind = 0; kind < 4; kind++) {
      JSType right = freshRight(kind);
      check(!eligible(left, right), "subclass excluded");
      left.calls = 0;
      Outcome expected = outcome(() -> reference(left, right));
      int expectedCalls = left.calls;
      left.calls = 0;
      Outcome actual = outcome(() -> left.equals(right));
      check(expected.equals(actual) && expected.failure().equals("type predicate")
          && left.calls == expectedCalls && expectedCalls > 0, "armed subclass fallback " + kind);
    }
    left.calls = 0;
    check(left.equals(left), "identity remains first");
    check(!left.equals(null) && !left.equals("unrelated"), "non-types remain cheap false");
    check(left.calls == 0, "identity/non-type must not invoke predicates");
    System.out.println("subclass-and-identity-fallback:OK");
  }

  private static void templateMaps() {
    TemplateType key = REGISTRY.createTemplateType("ProbeTemplate");
    JSType number = REGISTRY.getNativeType(JSTypeNative.NUMBER_TYPE);
    CountingValue value = new CountingValue();
    ObjectType leftDonor = donor(key, value);
    ObjectType rightDonor = donor(key, number);
    for (int kind = 0; kind < 4; kind++) {
      PrototypeObjectType left = plain("TemplatedLeft");
      JSType right = freshRight(kind);
      warmKnown(left);
      check(eligible(left, right), "empty maps initially eligible");
      // Exercise the public mutator instead of replacing protected/final fields.
      left.mergeSupertypeTemplateTypes(leftDonor);
      right.mergeSupertypeTemplateTypes(rightDonor);
      check(!left.getTemplateTypeMap().isEmpty() && !right.getTemplateTypeMap().isEmpty(),
          "both maps populated by public API");
      check(!eligible(left, right), "left map forces fallback");
      value.armed = true;
      value.calls = 0;
      Outcome expected = outcome(() -> reference(left, right));
      int expectedCalls = value.calls;
      value.calls = 0;
      Outcome actual = outcome(() -> left.equals(right));
      check(expected.equals(actual) && expected.failure().equals("type predicate")
          && value.calls == expectedCalls && expectedCalls > 0,
          "populated map preserves recursive predicate " + kind);
      value.armed = false;

      PrototypeObjectType emptyLeft = plain("EmptyLeft");
      warmKnown(emptyLeft);
      JSType rightWithArmedValue = freshRight(kind);
      rightWithArmedValue.mergeSupertypeTemplateTypes(leftDonor);
      value.armed = true;
      value.calls = 0;
      check(eligible(emptyLeft, rightWithArmedValue), "empty left remains eligible");
      check(!reference(emptyLeft, rightWithArmedValue) && !emptyLeft.equals(rightWithArmedValue),
          "empty-left/right-populated result " + kind);
      check(value.calls == 0, "empty left map never compares right values");
      value.armed = false;

      JSType emptyRight = freshRight(kind);
      value.calls = 0;
      check(!reference(left, emptyRight) && !left.equals(emptyRight),
          "left-populated/right-empty result " + kind);
      check(value.calls == 0, "unmatched template key must not compare values");
      System.out.println("template-map-guards:" + kind + ":OK");
    }
  }

  private static void unresolvedAndProxy() {
    try (JSTypeResolver.Closer closer = REGISTRY.getResolver().openForDefinition()) {
      PrototypeObjectType left = plain("UnresolvedPlain");
      check(!left.isResolved(), "fixture starts unresolved");
      warmKnown(left);
      for (int kind = 0; kind < 4; kind++) {
        JSType right = freshRight(kind);
        check(eligible(left, right), "plain guard does not require resolution");
        check(!reference(left, right) && !left.equals(right), "unresolved plain result");
        check(!left.isResolved(), "comparison must not resolve plain object");
      }
      NamedType pending = NamedType.builder(REGISTRY, "PendingEquality")
          .setResolutionKind(NamedType.ResolutionKind.NONE).build();
      check(!pending.isResolved(), "named fixture unresolved");
      check(!eligible(left, pending), "named right excluded");
      check(left.equals(pending) == reference(left, pending), "named right checker fallback");
      check(!pending.isResolved(), "comparison must not resolve named reference");
    }
    PrototypeObjectType plain = plain("ProxyTarget");
    warmKnown(plain);
    ProxyObjectType proxy = new ProxyObjectType(REGISTRY, plain);
    check(!eligible(plain, proxy), "proxy right excluded");
    check(reference(plain, proxy) && plain.equals(proxy), "proxy to left remains equal");
    System.out.println("unresolved-and-proxy-fallback:OK");
  }

  private static PrototypeObjectType plain(String name) {
    return PrototypeObjectType.builder(REGISTRY).setName(name).build();
  }

  private static ObjectType donor(TemplateType key, JSType value) {
    return PrototypeObjectType.builder(REGISTRY).setName("Donor")
        .setTemplateTypeMap(REGISTRY.getEmptyTemplateTypeMap()
            .copyWithExtension(ImmutableList.of(key), ImmutableList.of(value))).build();
  }

  private static JSType freshRight(int kind) {
    return switch (kind) {
      case 0 -> new NullType(REGISTRY);
      case 1 -> new VoidType(REGISTRY);
      case 2 -> new UnknownType(REGISTRY, false);
      case 3 -> new UnknownType(REGISTRY, true);
      default -> throw new AssertionError("invalid right fixture");
    };
  }

  private static boolean eligible(JSType left, Object right) {
    return left.getClass() == PrototypeObjectType.class
        && (right instanceof NullType || right instanceof VoidType || right instanceof UnknownType)
        && ((ObjectType) left).hasCachedValues() && left.getTemplateTypeMap().isEmpty();
  }

  private static void warmKnown(ObjectType type) {
    check(!type.isUnknownType() && type.hasCachedValues(), "known cached fixture");
  }

  private static boolean reference(JSType left, Object right) {
    return left == right || (right instanceof JSType other
        && new EqualityChecker().setEqMethod(EqualityChecker.EqMethod.IDENTITY).check(left, other));
  }

  private static Outcome outcome(Comparison comparison) {
    try { return new Outcome(comparison.run(), ""); }
    catch (IllegalStateException exception) { return new Outcome(false, exception.getMessage()); }
  }

  private static final class CountingPrototype extends PrototypeObjectType {
    boolean armed;
    boolean answer;
    boolean throwOnCall;
    int calls;
    CountingPrototype() { super(PrototypeObjectType.builder(REGISTRY).setName("CountedPrototype")); }
    @Override public boolean isUnknownType() {
      if (!armed) { return super.isUnknownType(); }
      calls++;
      if (throwOnCall) { throw new IllegalStateException("prototype hook"); }
      return answer;
    }
  }

  private static final class CountingValue extends PrototypeObjectType {
    boolean armed;
    int calls;
    CountingValue() { super(PrototypeObjectType.builder(REGISTRY).setName("CountedValue")); }
    @Override public boolean isNoResolvedType() {
      if (armed) { calls++; throw new IllegalStateException("type predicate"); }
      return super.isNoResolvedType();
    }
  }

  private static final class Reporter implements ErrorReporter {
    @Override public void warning(String message, String source, int line, int column) {}
    @Override public void error(String message, String source, int line, int column) {}
  }

  private static void check(boolean condition, String message) {
    if (!condition) { throw new AssertionError(message); }
  }
}
