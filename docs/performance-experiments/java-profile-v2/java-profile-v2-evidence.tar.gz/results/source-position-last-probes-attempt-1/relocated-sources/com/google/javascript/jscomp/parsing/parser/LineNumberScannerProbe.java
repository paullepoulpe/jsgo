package com.google.javascript.jscomp.parsing.parser;

import com.google.javascript.jscomp.jarjar.com.google.common.base.Preconditions;
import com.google.javascript.jscomp.parsing.parser.util.SourcePosition;
import com.google.javascript.jscomp.parsing.parser.util.SourceRange;
import java.lang.reflect.Field;
import java.util.List;
import java.util.Objects;

/** Compares every position, exception, and line-state transition to the pinned scanner. */
public final class LineNumberScannerProbe {
  private static final Field LAST_LINE = field("lastLine");
  private static final Field LAST_START = field("lastLineStart");
  private static final Field NEXT_START = field("nextLineStart");

  public static void main(String[] args) throws Exception {
    boolean requireReuse = args.length == 1 && args[0].equals("--require-reuse");
    require(args.length == 0 || requireReuse, "unexpected arguments");
    for (String contents : List.of("", "abc", "a\nb\n", "a\rb\r", "a\r\nb\r\n",
        "a\u2028b\u2029c", "\r\n\n\r\u2028\u2029", "a\r\nb\nc\rd\u2028e\u2029f")) {
      Fixture fixture = new Fixture(contents);
      fixture.position(-2);
      fixture.position(-1);
      for (int offset = 0; offset <= contents.length() + 2; offset++) {
        fixture.position(offset);
        fixture.position(offset);
        fixture.range(offset, offset);
      }
      fixture.position(0); // Backing up across a line must still fail before a cache hit.
      fixture.rewind(new SourcePosition(fixture.file, 0, 0, 0));
      fixture.range(0, contents.length());
      fixture.rewind(new SourcePosition(fixture.file, 0, 0, 0));
      fixture.position(0);
      fixture.rewind(new SourcePosition(new SourceFile("other.js", contents), 0, 0, 0));
      fixture.rewind(null);
      fixture.position(0);
    }

    Fixture sameLine = new Fixture("abcdef");
    sameLine.position(5);
    sameLine.position(2);
    sameLine.position(2);
    sameLine.range(4, 1); // The original permits reversed ranges within a line.
    sameLine.position(Integer.MAX_VALUE - 1);
    sameLine.position(Integer.MIN_VALUE);
    sameLine.position(3);

    Fixture rejectedCachedOffset = new Fixture("abcdef");
    rejectedCachedOffset.position(4);
    rejectedCachedOffset.rewind(new SourcePosition(rejectedCachedOffset.file, -1, 0, -6));
    rejectedCachedOffset.position(4); // A cached offset cannot bypass the existing precondition.
    rejectedCachedOffset.position(5);

    Fixture changedLine = new Fixture("a\nb\nc");
    changedLine.position(4);
    changedLine.rewind(new SourcePosition(changedLine.file, 0, 100, 0));
    changedLine.position(4);
    SourcePosition line = changedLine.actual.getSourcePosition(4);
    require(line.line == 102 && line.column == 0, "forged rewind must change the line");

    Fixture changedColumn = new Fixture("a\nbcdef");
    changedColumn.position(5);
    changedColumn.rewind(new SourcePosition(changedColumn.file, 1, 1, -2));
    changedColumn.position(5);
    SourcePosition column = changedColumn.actual.getSourcePosition(5);
    require(column.line == 1 && column.column == 2, "forged rewind must change the column");
    changedColumn.rewind(new SourcePosition(changedColumn.file, -1, 0, 0));
    changedColumn.position(5); // Preserve any state left behind by the failed rewind.

    SourceFile file = new SourceFile("reuse.js", "a+b");
    LineNumberScanner scanner = new LineNumberScanner(file);
    SourcePosition first = scanner.getSourcePosition(1);
    SourcePosition second = scanner.getSourcePosition(1);
    if (requireReuse) {
      require(first == second, "candidate did not reuse an equal consecutive position");
    }
    System.out.println("LineNumberScannerProbe OK");
  }

  private static final class Fixture {
    final SourceFile file;
    final LineNumberScanner actual;
    final Original original;

    Fixture(String contents) {
      file = new SourceFile("fixture.js", contents);
      actual = new LineNumberScanner(file);
      original = new Original(file);
      System.out.println("source=" + escape(contents));
    }

    void position(int offset) throws Exception {
      compare("position(" + offset + ")", () -> format(original.getSourcePosition(offset)),
          () -> format(actual.getSourcePosition(offset)));
    }

    void range(int start, int end) throws Exception {
      compare("range(" + start + "," + end + ")", () -> format(original.getSourceRange(start, end)),
          () -> format(actual.getSourceRange(start, end)));
    }

    void rewind(SourcePosition position) throws Exception {
      compare("rewind(" + (position == null ? "null" : position.offset + "," + position.line
              + "," + position.column + ",sameSource=" + (position.source == file)) + ")",
          () -> { original.rewindTo(position); return "OK"; },
          () -> { actual.rewindTo(position); return "OK"; });
    }

    void compare(String label, Operation expectedOperation, Operation actualOperation)
        throws Exception {
      String expected = outcome(expectedOperation);
      String result = outcome(actualOperation);
      require(result.equals(expected), label + ": " + expected + " != " + result);
      require(LAST_LINE.getInt(actual) == original.lastLine
              && LAST_START.getInt(actual) == original.lastLineStart
              && NEXT_START.getInt(actual) == original.nextLineStart,
          label + ": line scanner state changed");
      System.out.println(label + "=" + result + ";state=" + original.lastLine + ","
          + original.lastLineStart + "," + original.nextLineStart);
    }

    String format(SourcePosition position) {
      require(position.source == file, "source object changed");
      return position.offset + "," + position.line + "," + position.column;
    }

    String format(SourceRange range) {
      return format(range.start) + ".." + format(range.end);
    }
  }

  @FunctionalInterface
  private interface Operation {
    String run();
  }

  private static String outcome(Operation operation) {
    try {
      return operation.run();
    } catch (RuntimeException error) {
      if (error instanceof NullPointerException) {
        // Helpful NPE wording depends on class-file debug metadata, not the scanner result.
        return error.getClass().getName();
      }
      return error.getClass().getName() + ":" + escape(String.valueOf(error.getMessage()));
    }
  }

  private static Field field(String name) {
    try {
      Field field = LineNumberScanner.class.getDeclaredField(name);
      field.setAccessible(true);
      return field;
    } catch (ReflectiveOperationException error) {
      throw new ExceptionInInitializerError(error);
    }
  }

  private static String escape(String value) {
    return value.replace("\\", "\\\\").replace("\r", "\\r").replace("\n", "\\n")
        .replace("\u2028", "\\u2028").replace("\u2029", "\\u2029");
  }

  private static void require(boolean condition, String message) {
    if (!condition) {
      throw new AssertionError(message);
    }
  }

  // Pinned LineNumberScanner implementation; no caching or shared mutable state with actual.
  private static final class Original {
    private final SourceFile sourceFile;
    private final String contents;
    private final int sourceLength;
    private int lastLine = -1;
    private int lastLineStart = -1;
    private int nextLineStart = 0;

    Original(SourceFile sourceFile) {
      this.sourceFile = sourceFile;
      this.contents = sourceFile.contents;
      this.sourceLength = contents.length();
    }

    SourcePosition getSourcePosition(int offset) {
      Preconditions.checkArgument(
          offset >= lastLineStart,
          "Must call rewindTo before calling getSourcePosition for an earlier line (%s < %s)",
          offset,
          lastLineStart);
      while (offset >= nextLineStart) {
        advanceLine();
      }
      return new SourcePosition(sourceFile, offset, lastLine, offset - lastLineStart);
    }

    SourceRange getSourceRange(int startOffset, int endOffset) {
      return new SourceRange(getSourcePosition(startOffset), getSourcePosition(endOffset));
    }

    void rewindTo(SourcePosition position) {
      Preconditions.checkArgument(Objects.equals(position.source, sourceFile));
      if (position.offset < lastLineStart) {
        lastLine = position.line - 1;
        nextLineStart = position.offset - position.column;
        advanceLine();
      }
    }

    private void advanceLine() {
      lastLine++;
      lastLineStart = nextLineStart;
      for (int index = lastLineStart; index < sourceLength; index++) {
        char ch = contents.charAt(index);
        if (isLineTerminator(ch)) {
          if (ch == '\r' && index + 1 < sourceLength && contents.charAt(index + 1) == '\n') {
            index++;
          }
          nextLineStart = index + 1;
          return;
        }
      }
      nextLineStart = Integer.MAX_VALUE;
    }

    private static boolean isLineTerminator(char ch) {
      return switch (ch) {
        case '\n', '\r', '\u2028', '\u2029' -> true;
        default -> false;
      };
    }
  }
}
