"""Run one equality-entry diagnostic compilation; never a performance comparison."""
from pathlib import Path
import argparse
import hashlib
import json
import os
import re
import signal
import subprocess
import sys
import time
import traceback
import types

sys.dont_write_bytecode = True
ROOT = Path(__file__).resolve().parent
SUPPORT = ROOT / 'bench/run-v3.py'
SUPPORT_SHA256 = '74ed5966d78afe3621f382e893488e400701ace393f04514274326a107ebab7f'
JAR = Path('/workspace/jsgo/.cache/closure-compiler-v20261015-maven.jar')
JDK = '/usr/lib/jvm/java-21-openjdk-amd64'
IMAGE = 'python@sha256:70729b46c69b4f1e97c4822c1af3df53a1476cf5ddc6c087c0c10bc3a5678c2f'
DIAGNOSTIC = ROOT / 'diagnostics/equality-pairs'
VARIANT = 'equality-pairs'
FAMILY = 'com/google/javascript/rhino/jstype/EqualityChecker'
PREFIX = 'JSGO_EQUALITY_ENTRY_DIAGNOSTIC\t'
TASKS = {
    'bigquery': (
        '/workspace/jsgo-results/round4/bigquery-stock-oracle-v1/spec.json',
        '/workspace/jsgo-results/round4/bigquery-stock-oracle-v1'),
    'bundle': (
        '/workspace/jsgo-results/round4/main-9c895b43-sync-v1/benchmark-preparation-v2/go-screen-v2/specs/bundle-n1.json',
        '/workspace/jsgo-results/round4/paired-main5de-bundle-advanced-t1-v1'),
}


def module(path, name):
    result = types.ModuleType(name)
    result.__file__ = str(path)
    exec(compile(path.read_bytes(), str(path), 'exec'), result.__dict__)
    return result


def parse_report(path):
    assert path.stat().st_size <= 1 << 20, 'unexpectedly large driver stderr'
    raw_lines = path.read_text(encoding='UTF-8').splitlines()
    lines = [line[len(PREFIX):] for line in raw_lines if line.startswith(PREFIX)]
    assert 3 <= len(lines) <= 131 and lines[0] == 'version=1'
    summary = dict(part.split('=', 1) for part in lines[1].split('\t'))
    keys = {'total', 'tracked_keys', 'printed_keys', 'omitted_keys', 'omitted_calls', 'overflow_calls'}
    assert set(summary) == keys and len(lines[1].split('\t')) == len(keys)
    assert all(re.fullmatch(r'[0-9]+', value) for value in summary.values())
    summary = {key: int(value) for key, value in summary.items()}
    assert lines[2] == 'method\tleft_class\tright_class\tidentical\tcalls'
    rows = []
    class_name = r'(?:[A-Za-z_$][A-Za-z0-9_$]*\.)*[A-Za-z_$][A-Za-z0-9_$]*|<null>'
    for line in lines[3:]:
        fields = line.split('\t')
        assert len(fields) == 5
        method, left, right, identical, calls = fields
        assert method in ('IDENTITY', 'DATA_FLOW', '<unset>')
        assert re.fullmatch(class_name, left) and re.fullmatch(class_name, right)
        assert identical in ('true', 'false') and re.fullmatch(r'[1-9][0-9]*', calls)
        assert identical != 'true' or left == right
        rows.append({'method': method, 'left_class': left, 'right_class': right,
                     'identical': identical == 'true', 'calls': int(calls)})
    order = lambda row: (-row['calls'], row['method'], row['left_class'], row['right_class'], row['identical'])
    assert rows == sorted(rows, key=order)
    assert len({(r['method'], r['left_class'], r['right_class'], r['identical']) for r in rows}) == len(rows)
    assert summary['total'] > 0 and 0 < summary['tracked_keys'] <= 4096
    assert len(rows) == summary['printed_keys'] == min(128, summary['tracked_keys'])
    assert summary['omitted_keys'] == summary['tracked_keys'] - len(rows)
    assert summary['omitted_calls'] >= summary['omitted_keys']
    assert summary['omitted_keys'] != 0 or summary['omitted_calls'] == 0
    assert summary['total'] == sum(row['calls'] for row in rows) + summary['omitted_calls'] + summary['overflow_calls']
    assert summary['overflow_calls'] == 0, 'counter capacity exceeded; do not infer complete distribution'
    for row in rows:
        row['fraction_of_check_entries'] = row['calls'] / summary['total']
    return {'status': 'PASS bounded coherent entry counts', 'summary': summary, 'rows': rows,
            'non_diagnostic_stderr_lines': len(raw_lines) - len(lines),
            'scope': 'EqualityChecker.check entries only; excludes recursive checks and checkParameters',
            'performance_claim': False}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('task', choices=TASKS)
    parser.add_argument('--manifest', required=True, type=Path)
    parser.add_argument('--out', required=True, type=Path)
    args = parser.parse_args()
    manifest_path = args.manifest.resolve()
    out = args.out.resolve()
    assert not out.exists(), 'output path must be new'
    # Loading support only defines functions; main is not invoked.
    assert hashlib.sha256(SUPPORT.read_bytes()).hexdigest() == SUPPORT_SHA256
    b = module(SUPPORT, 'equality_diagnostic_support')
    assert not b.active(), 'compiler runtime already active'
    manifest = b.read(manifest_path)
    assert manifest['java_home'] == JDK and manifest['compiler_source_families'] == [FAMILY]
    assert manifest['source_jar_sha256'] == '4d38166975b61466aa3b02b0d2d38160b855dd7f7e1f6171069fc84974bac45a'
    assert b.sha(JAR) == b.JAR
    b.validate_classes(manifest, JAR)
    variant = manifest['variants'][VARIANT]
    assert variant['overlay'] and FAMILY + '$EntryDiagnostic.class' in variant['classes']
    out.mkdir(parents=True)
    snapshots = out / 'helper-snapshots'
    snapshots.mkdir()
    for name, digest in b.PINS.items():
        source = b.HELP / name
        assert b.sha(source) == digest
        (snapshots / name).write_bytes(source.read_bytes())
    (out / 'run-equality-diagnostic.py').write_bytes(Path(__file__).read_bytes())
    (out / 'run-v3-support.py').write_bytes(SUPPORT.read_bytes())
    (out / 'build-manifest.json').write_bytes(manifest_path.read_bytes())
    h = module(snapshots / 'paired_cli.py', 'equality_diagnostic_helpers')
    spec_path, oracle_directory = TASKS[args.task]
    oracle_directory = Path(oracle_directory)
    oracle_path = oracle_directory / 'stock-java-oracle-digests.json'
    oracle_metadata_path = oracle_directory / 'metadata.json'
    spec, oracle, oracle_metadata = b.read(spec_path), b.read(oracle_path), b.read(oracle_metadata_path)
    assert all('\n' not in value and '\r' not in value and '\x00' not in value for value in spec['argv'])
    identity = h.input_identity(spec)
    assert oracle_metadata.get('jar_sha256', oracle_metadata.get('java_jar_sha256')) == b.JAR
    assert identity == oracle_metadata['input_manifest'] and b.work_identity(spec) == b.work_identity(oracle_metadata['spec'])
    assert set(oracle) == {'stdout', 'stderr', 'exit', *spec['artifacts'], *spec.get('absent_artifacts', [])}
    assert len(oracle) == 6 and oracle['exit'] == hashlib.sha256(b'0\n').hexdigest()
    pins = {str(path): b.sha(path) for path in (Path(__file__), SUPPORT, manifest_path, Path(spec_path), oracle_path, oracle_metadata_path, JAR)}
    for name in ('CONTROL', VARIANT):
        v = manifest['variants'][name]
        receipt_path = Path(v['build_proof'])
        assert b.sha(receipt_path) == v['build_proof_sha256'] == manifest['compiler_build_receipt_sha256'][name]
        receipt = b.read(receipt_path)
        assert receipt['status'] == 'PASS' and receipt['exit'] == 0 and receipt['classes'] == v['classes']
        assert receipt['javac_flags'] == manifest['javac_flags']
        pins[str(receipt_path)] = b.sha(receipt_path)
        source_root = DIAGNOSTIC / ('control-src' if name == 'CONTROL' else 'src')
        for rel, digest in receipt['effective_sources'].items():
            source = source_root / rel
            assert b.sha(source) == digest
            pins[str(source)] = digest
        for rel, digest in receipt['relocated_sources'].items():
            source = Path(v['overlay']).parent / 'src' / rel
            assert b.sha(source) == digest
            pins[str(source)] = digest
    settings = types.SimpleNamespace(
        readonly_bind=sorted(set(spec['links'].values()) | {v['overlay'] for v in manifest['variants'].values() if v['overlay']}),
        binary=str(JAR), jar=str(JAR), java_home=JDK, driver=manifest['driver']['directory'],
        image=IMAGE, request_timeout=300)
    engine = h.Engine(settings)
    original_call = engine.call
    def bounded_call(*argv, **kwargs):
        kwargs.setdefault('timeout', 15)
        return original_call(*argv, **kwargs)
    engine.call = bounded_call
    assert not engine.call('ps', '-q', capture_output=True, text=True).stdout.strip(), 'another container is running'
    before = b.outer()
    started = time.monotonic()
    def check():
        now = b.outer()
        b.zero(b.oom_delta(before, now))
        assert b.memory_headroom(now) >= 1 << 30
        assert time.monotonic() - started < 600
        disk = os.statvfs(out)
        assert disk.f_bavail * disk.f_frsize >= 1 << 30
    def unchanged():
        assert all(b.sha(path) == digest for path, digest in pins.items()), 'source/input pin changed'
        assert all(b.sha(snapshots / name) == digest for name, digest in b.PINS.items())
        b.validate_classes(manifest, JAR)
        assert h.input_identity(spec) == identity
    b.save(out / 'metadata.json', {
        'diagnostic_only': True, 'performance_claim': False, 'task': args.task, 'variant': VARIANT,
        'manifest': manifest, 'manifest_path': str(manifest_path), 'spec': spec, 'spec_path': spec_path,
        'oracle': oracle, 'input_manifest': identity, 'pins': pins, 'helper_pins': b.PINS,
        'java_runtime_dependencies': h.java_runtime_dependencies(JDK), 'java_flags': ['-Xmx3g'],
        'driver': manifest['driver'], 'outer_before': before,
        'requests': 1, 'warmup_requests': 0,
        'protocol_kind': 'warmup is the accepted driver label; this request is diagnostic, not settling',
        'policy': 'one fresh compiler/extern parse; 4GiB/no swap/two CPUs; same six output digests; no timing conclusion'})
    b.save(out / 'oracle.json', oracle)
    j = None
    cleanup, cleanup_errors = [], []
    try:
        check()
        origins = sorted(rel[:-6].replace('/', '.') for rel in variant['classes'])
        expected = {name: variant['classes'][name.replace('.', '/') + '.class'] for name in origins}
        # Retain the object even if __init__ fails after container/process creation.
        j = b.JVM.__new__(b.JVM)
        b.JVM.__init__(j, VARIANT, variant, out / 'work', engine, h, settings, spec, origins, expected)
        j.ready(check)
        row = j.request(1, 'warmup', check)
        assert row['digests'] == oracle, 'strict six-artifact mismatch'
        b.save(out / 'diagnostic-request.json', dict(row, diagnostic_only=True, performance_claim=False))
        unchanged()
    except BaseException as error:
        b.save(out / 'failure.json', {'status': 'FAILED diagnostic; no performance claim',
            'type': type(error).__name__, 'message': str(error), 'traceback': traceback.format_exc()})
        raise
    finally:
        if j is not None:
            try:
                cleanup += j.close()
            except BaseException as error:
                cleanup_errors.append(repr(error))
        for cid in list(engine.containers):
            try:
                engine.call('rm', '-f', cid, stdout=subprocess.DEVNULL)
                engine.containers.discard(cid)
                cleanup.append({'container': cid, 'fallback_removed': True})
            except BaseException as error:
                cleanup_errors.append(repr(error))
        process = getattr(j, 'process', None)
        if process is not None and process.poll() is None:
            for sig in (signal.SIGTERM, signal.SIGKILL):
                if process.poll() is not None:
                    break
                try:
                    os.killpg(process.pid, sig)
                except ProcessLookupError:
                    pass
                try:
                    process.wait(timeout=5)
                except subprocess.TimeoutExpired:
                    pass
        after = b.outer()
        proof = {'owned_cleanup': cleanup, 'cleanup_errors': cleanup_errors,
            'remaining_owned_containers': sorted(engine.containers), 'active_compilers': b.active(),
            'remaining_owned_driver_processes': [process.pid] if process is not None and process.poll() is None else [],
            'outer_before': before, 'outer_after': after, 'outer_OOM_delta': b.oom_delta(before, after)}
        b.save(out / 'stopped-proof.json', proof)
        try:
            assert not cleanup_errors and not proof['remaining_owned_containers'] and not proof['active_compilers'] and not proof['remaining_owned_driver_processes']
            b.zero(proof['outer_OOM_delta'])
        except BaseException as error:
            # Keep any original request failure intact as well as this cleanup failure.
            b.save(out / 'cleanup-failure.json', {'status': 'FAILED diagnostic cleanup',
                'type': type(error).__name__, 'message': str(error), 'traceback': traceback.format_exc()})
            raise
    try:
        assert len(cleanup) == 1 and cleanup[0]['removed'] is True and cleanup[0]['driver_exit'] == 0
        unchanged()
        report = parse_report(out / 'work/driver.stderr')
        b.save(out / 'entry-counts.json', report)
        summary = {'status': 'PASS single byte-identical diagnostic request', 'requests': 1,
            'all_six_digests_match': True, 'class_source_and_input_identity': 'PASS before/after',
            'graceful_driver_exit': 0, 'entry_counts': report['summary'],
            'driver_stderr_sha256': b.sha(out / 'work/driver.stderr'), 'performance_claim': False}
        b.save(out / 'summary.json', summary)
        print(json.dumps(summary, indent=2), flush=True)
    except BaseException as error:
        b.save(out / 'failure.json', {'status': 'FAILED diagnostic postflight; no performance claim',
            'type': type(error).__name__, 'message': str(error), 'traceback': traceback.format_exc()})
        raise


if __name__ == '__main__':
    main()
