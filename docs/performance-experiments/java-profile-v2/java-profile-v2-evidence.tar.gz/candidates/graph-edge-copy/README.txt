LinkedDirectedGraph.getEdges copy loop: source-only candidate

Status and evidence
  Prepared from untouched pinned Closure v20261015. No JVM, compiler, build,
  benchmark or probe execution performed here. Root owns runtime selection.
  analysis-driver-v1/allocation-callers.stdout attributes 8 Object[] samples,
  0.6369% of all weighted allocation, to Arrays.copyOf -> ArrayList.toArray ->
  ArrayList.addAll -> LinkedDirectedGraph.getEdges -> DataFlowAnalysis.initialize.
  This is sampled allocation evidence, not elapsed time or a guaranteed gain.

Files
  graph-edge-copy.patch: unshaded diff against the pinned source root.
  src/com/google/javascript/jscomp/graph/LinkedDirectedGraph.java: candidate.
  control-src/com/google/javascript/jscomp/graph/LinkedDirectedGraph.java: stock copy.
  probe/com/google/javascript/jscomp/graph/GraphEdgeCopyProbe.java: same-source
    standalone probe for stock, rebuilt control and candidate jars, no arguments.
  frozen-source-manifest.json: narrow file sizes and SHA256 hashes.

Exact change
  Only the zero-argument getEdges implementation changes. The private result is
  declared ArrayList instead of List. For each node, getOutEdges is still invoked
  exactly once; cache that list and its size, reserve result.size()+count capacity,
  then copy references with indexed get/add. The nodes.values() loop and final
  Collections.unmodifiableList wrapper remain unchanged. No direct private-list
  access, new imports, global edge count, or data-flow initialization change.

Ownership and semantics
  LinkedDiGraphNode is public/nonfinal but has a private constructor. The only
  constructible subclass in the source is final AnnotatedLinkedDiGraphNode; it
  does not override getOutEdges. The getter returns the private final outEdgeList,
  always a concrete ArrayList. Ordinary external graph subclasses cannot inject
  custom node/list subclasses through normal constructors. Protected nodes is
  the same final LinkedHashMap; subclasses may change membership or alias existing
  nodes, and the unchanged values traversal preserves that order/multiplicity.

  size/get/add perform no node-value or edge-value methods. There are no user
  callbacks between reading count and copying a node's edges. Indexed copying
  retains node insertion order, outgoing-edge insertion order, exact edge object
  identity, parallel edges, self-loops, duplicate references and null entries.
  The snapshot's container remains fresh, independent of later graph/list changes,
  and unmodifiable. Edge and node annotation objects remain shared as before.
  Independent source review found no ordinary single-threaded semantic defect.

Capacity behavior
  Reserving capacity avoids a plain add loop's possible repeated growth for a
  high-degree node. For ordinary non-overflow JDK 21 sizes, ensureCapacity(required)
  uses the same grow(required) policy as addAll's bulk insertion. On the default
  empty backing array, count 1..10 leaves reservation lazy; the first add allocates
  capacity 10, matching addAll. Counts above 10 reserve directly; zero allocates
  no storage. Existing allocated arrays use the same required-size growth before
  insertion. Internal modCount differs, but no iterator sees the private result
  during construction and the returned wrapper forbids later list mutation.

Limits
  The graph and exposed node adjacency lists have no synchronization contract.
  Concurrent list mutation can produce different partial observations or
  exceptions: stock copies with toArray, while this version performs indexed
  reads. No equivalence under an unsynchronized concurrent mutation is claimed.

  Integer overflow in result.size()+count and memory-exhaustion behavior are not
  equivalent. Stock first allocates a temporary input array and bulk-copies;
  candidate reserves then copies incrementally. For an overflowing sum,
  ensureCapacity may do nothing where stock's grow would fail earlier. These
  allocation/failure boundaries are outside the successful representable-size
  snapshot proof. No extra hot-path overflow machinery was introduced.

  Reservation, size arithmetic and indexed reads add work; HotSpot may already
  optimize some copies, and the allocation saving need not improve wall time.
  No timing or memory improvement is established by this source candidate.

Probe coverage
  Normal factories with annotations enabled and disabled; empty/isolated graphs;
  node insertion order differing from connection order; parallel edge identity;
  self-loops/cycles; high outgoing degree; fresh wrapper identity; mutation through
  connect/disconnect after capture; annotation identity; all common unmodifiable
  list operations; exposed adjacency containing a repeated edge and null; direct
  adjacency clearing; and a graph subclass with aliased protected membership and
  armed unrelated API hooks. Armed node/edge values throw on equals/hashCode/
  toString to detect unintended callbacks during snapshot construction.

  Assertions compare exact edge references and expected order, then emit compact
  deterministic fixture results. Compile/run the same probe against all three
  jars and compare stdout and successful exit status. End-to-end compiler output,
  diagnostic, source-map and memory/timing checks remain root's separate work.
  No concurrency or forced-OOM probe is included. Frozen files must not change
  after root builds them.
