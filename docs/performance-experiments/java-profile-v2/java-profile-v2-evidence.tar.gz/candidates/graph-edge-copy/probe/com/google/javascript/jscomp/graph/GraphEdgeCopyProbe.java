package com.google.javascript.jscomp.graph;

import com.google.javascript.jscomp.graph.LinkedDirectedGraph.LinkedDiGraphEdge;
import com.google.javascript.jscomp.graph.LinkedDirectedGraph.LinkedDiGraphNode;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;

/** Same-source snapshot probe for stock, rebuilt control, and candidate jars. */
public final class GraphEdgeCopyProbe {
  public static void main(String[] args) {
    check(args.length == 0, "unexpected arguments");
    for (boolean annotated : new boolean[] {false, true}) {
      ordinary(annotated);
      highDegree(annotated);
    }
    exposedAdjacency();
    inheritedGraph();
    noValueCallbacks();
    System.out.println("GraphEdgeCopyProbe OK");
  }

  private static LinkedDirectedGraph<String, String> graph(boolean annotated) {
    return annotated ? LinkedDirectedGraph.create() : LinkedDirectedGraph.createWithoutAnnotations();
  }

  private static void ordinary(boolean annotated) {
    String label = "ordinary-" + annotated;
    LinkedDirectedGraph<String, String> graph = graph(annotated);
    List<LinkedDiGraphEdge<String, String>> empty = graph.getEdges();
    snapshot(label + "-empty", empty);
    unmodifiable(empty);
    graph.createNode("B");
    graph.createNode("A");
    graph.createNode("C");
    graph.createNode("isolated");
    snapshot(label + "-isolated", graph.getEdges());

    // Node insertion order differs from connection order. Parallel edges share a value,
    // but remain distinct objects; a self-loop appears exactly once in all-edge snapshots.
    LinkedDiGraphEdge<String, String> ac = connect(graph, "A", "a-c", "C");
    LinkedDiGraphEdge<String, String> ba1 = connect(graph, "B", "parallel", "A");
    LinkedDiGraphEdge<String, String> cb = connect(graph, "C", "cycle", "B");
    LinkedDiGraphEdge<String, String> ba2 = connect(graph, "B", "parallel", "A");
    LinkedDiGraphEdge<String, String> bb = connect(graph, "B", "self", "B");
    List<LinkedDiGraphEdge<String, String>> saved = graph.getEdges();
    snapshot(label + "-ordered", saved, ba1, ba2, bb, ac, cb);
    check(ba1 != ba2, "parallel edge identity");
    check(saved != graph.getEdges(), "each call must return a fresh snapshot wrapper");
    unmodifiable(saved);

    if (annotated) {
      Annotation tag = new Annotation() {};
      ba1.setAnnotation(tag);
      check(saved.get(0).getAnnotation() == tag, "snapshot must share edge annotation identity");
      graph.getNode("B").setAnnotation(tag);
      check(saved.get(0).getSource().getAnnotation() == tag, "snapshot must share node identity");
    } else {
      expectUnsupported(() -> ba1.setAnnotation(new Annotation() {}));
      expectUnsupported(() -> ba1.getAnnotation());
    }

    LinkedDiGraphEdge<String, String> bc = connect(graph, "B", "later", "C");
    snapshot(label + "-after-connect", graph.getEdges(), ba1, ba2, bb, bc, ac, cb);
    graph.disconnectInDirection("B", "A");
    snapshot(label + "-after-disconnect", graph.getEdges(), bb, bc, ac, cb);
    snapshot(label + "-saved-stable", saved, ba1, ba2, bb, ac, cb);
    snapshot(label + "-original-empty-stable", empty);
  }

  private static void highDegree(boolean annotated) {
    LinkedDirectedGraph<String, String> graph = graph(annotated);
    graph.createNode("hub");
    graph.createNode("leaf");
    ArrayList<LinkedDiGraphEdge<String, String>> hubEdges = new ArrayList<>();
    ArrayList<LinkedDiGraphEdge<String, String>> leafEdges = new ArrayList<>();
    for (int i = 0; i < 129; i++) {
      hubEdges.add(connect(graph, "hub", "h" + i, "leaf"));
      if (i % 8 == 0) { leafEdges.add(connect(graph, "leaf", "l" + i, "hub")); }
    }
    ArrayList<LinkedDiGraphEdge<String, String>> expected = new ArrayList<>(hubEdges);
    expected.addAll(leafEdges);
    List<LinkedDiGraphEdge<String, String>> saved = graph.getEdges();
    snapshot("high-degree-" + annotated, saved, expected.toArray());
    graph.disconnect("hub", "leaf");
    snapshot("high-degree-cleared-" + annotated, graph.getEdges());
    snapshot("high-degree-saved-" + annotated, saved, expected.toArray());
    unmodifiable(saved);
  }

  private static void exposedAdjacency() {
    LinkedDirectedGraph<String, String> graph = graph(false);
    LinkedDiGraphNode<String, String> a = graph.createNode("A");
    graph.createNode("B");
    LinkedDiGraphEdge<String, String> edge = connect(graph, "A", "edge", "B");
    // Public node adjacency lists admit duplicate references and null entries. getEdges
    // copies them without dereferencing or deduplicating, even for this irregular graph.
    a.getOutEdges().add(edge);
    a.getOutEdges().add(null);
    List<LinkedDiGraphEdge<String, String>> saved = graph.getEdges();
    snapshot("exposed-adjacency", saved, edge, edge, null);
    a.getOutEdges().clear();
    snapshot("exposed-adjacency-cleared", graph.getEdges());
    snapshot("exposed-adjacency-saved", saved, edge, edge, null);
    unmodifiable(saved);
  }

  private static void inheritedGraph() {
    HookGraph graph = new HookGraph();
    LinkedDiGraphNode<String, String> a = graph.createNode("A");
    graph.createNode("B");
    LinkedDiGraphEdge<String, String> edge = connect(graph, "A", "edge", "B");
    graph.alias("again", a);
    snapshot("inherited-protected-membership", graph.getEdges(), edge, edge);
  }

  private static void noValueCallbacks() {
    LinkedDirectedGraph<Bomb, Bomb> graph = LinkedDirectedGraph.create();
    Bomb a = new Bomb("A");
    Bomb b = new Bomb("B");
    Bomb value = new Bomb("edge");
    graph.createNode(a);
    graph.createNode(b);
    LinkedDiGraphEdge<Bomb, Bomb> edge = connect(graph, a, value, b);
    a.armed = b.armed = value.armed = true;
    List<LinkedDiGraphEdge<Bomb, Bomb>> saved = graph.getEdges();
    snapshot("no-value-callbacks", saved, edge);
    unmodifiable(saved);
  }

  private static <N, E> LinkedDiGraphEdge<N, E> connect(
      LinkedDirectedGraph<N, E> graph, N source, E value, N destination) {
    List<LinkedDiGraphEdge<N, E>> outgoing = graph.getNode(source).getOutEdges();
    int previousSize = outgoing.size();
    graph.connect(source, value, destination);
    check(outgoing.size() == previousSize + 1, "connect must append one edge");
    return outgoing.get(previousSize);
  }

  private static void snapshot(String label, List<?> actual, Object... expected) {
    check(actual.size() == expected.length, label + ": snapshot size");
    for (int i = 0; i < expected.length; i++) {
      check(actual.get(i) == expected[i], label + ": edge identity/order at " + i);
    }
    System.out.println(label + "\tedges=" + actual.size());
  }

  private static void unmodifiable(List<?> snapshot) {
    expectUnsupported(() -> snapshot.add(null));
    expectUnsupported(snapshot::clear);
    if (!snapshot.isEmpty()) {
      expectUnsupported(() -> snapshot.set(0, null));
      expectUnsupported(() -> snapshot.remove(0));
      Iterator<?> iterator = snapshot.iterator();
      iterator.next();
      expectUnsupported(iterator::remove);
    }
  }

  private static void expectUnsupported(Runnable operation) {
    try {
      operation.run();
      throw new AssertionError("expected UnsupportedOperationException");
    } catch (UnsupportedOperationException expected) {
      // Expected from the existing unmodifiable snapshot and annotation APIs.
    }
  }

  private static final class HookGraph extends LinkedDirectedGraph<String, String> {
    HookGraph() { super(false, false); }
    void alias(String key, LinkedDiGraphNode<String, String> node) { nodes.put(key, node); }
    @Override public Collection<LinkedDiGraphNode<String, String>> getNodes() {
      throw new AssertionError("getNodes hook must not run");
    }
    @Override public List<LinkedDiGraphEdge<String, String>> getOutEdges(String node) {
      throw new AssertionError("graph-level getOutEdges hook must not run");
    }
    @Override public List<LinkedDiGraphEdge<String, String>> getEdgesInDirection(String a, String b) {
      throw new AssertionError("getEdgesInDirection hook must not run");
    }
  }

  private static final class Bomb {
    final String label;
    boolean armed;
    Bomb(String label) { this.label = label; }
    @Override public int hashCode() {
      check(!armed, "value hashCode during snapshot");
      return label.hashCode();
    }
    @Override public boolean equals(Object other) {
      check(!armed, "value equals during snapshot");
      return this == other;
    }
    @Override public String toString() {
      check(!armed, "value toString during snapshot");
      return label;
    }
  }

  private static void check(boolean condition, String message) {
    if (!condition) { throw new AssertionError(message); }
  }
}
