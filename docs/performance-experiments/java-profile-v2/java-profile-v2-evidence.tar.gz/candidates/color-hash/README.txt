Color hash memoization candidate — source review only, not promoted

Pinned inputs: /workspace/jsgo/.cache/closure-src and the Closure v20261015 Maven jar.
No compiler, JVM, benchmark, archive mutation, or network command was run here.
The frozen transfer-v1 directory and pinned sources were not modified.

One proposed optimization

Memoize the existing structural hash of each immutable AutoValue_Color. The
upstream source change is four added lines in upstream.patch: @Memoized @Override
public abstract int hashCode(). Color already imports and uses @Memoized.

For a practical isolated experiment, src/.../AutoValue_Color.java adds a lazy
hash override to the pinned generated leaf class. The result still comes from
the unchanged $AutoValue_Color.hashCode(), so no recurrence or hash value changes.
Constructors, builders, equality, subtractNullOrVoid, and public method signatures
remain unchanged in this overlay. control-src contains the exact original leaf
source for a matched rebuilding control. overlay.patch documents the entire
generated-class experiment delta.

The cache uses a transient volatile int and a separate transient volatile boolean.
It computes under the same per-object monitor pattern already used by
subtractNullOrVoid. A completed hash is written before the initialized flag. The
flag supports zero, negative, and positive results; a zero hash is not a sentinel.
A failed computation leaves the flag false. The monitor is released before return.

Source evidence and limits

The generated superclass holds final fields. ColorId and strings are immutable;
sets are ImmutableSet and production Color instances are generated values. The
source contains no other subclass of this Color. ColorPool rejects cyclic Color
structures (ColorPool.java:237–251), and builders construct parents from already
constructed children. Hash recursion therefore follows the ordinary acyclic
graph; the existing subtractNullOrVoid monitor is reentrant. Same-package custom
mutable subclasses or reflection-created cycles are outside this immutability
assumption and could invalidate caching or introduce recursive lock cycles.

An int, a boolean, and first-call synchronization are added per instance; the hot
path reads two volatile fields. Actual shallow-size growth depends on VM layout
and alignment and is unmeasured. A roughly eight-byte increase is plausible, not
a measured result. Existing ImmutableSet hashes may already be cached, so a large
CPU contribution must be established by the parent profile before selection.

The upstream annotation patch is provisional: AutoValue may also generate an
equals hash precheck. Regenerate with the project's pinned annotation processor
and inspect that result before claiming this hash-only overlay is the upstream
patch's exact machine-code equivalent. Preserve collision behavior and the pinned
equals contract for other Color implementations. If generated output differs,
review and measure the actual generated result before an upstream recommendation.

Adding an abstract Color.hashCode declaration is compatible with the pinned
AutoValue hierarchy, whose superclass already implements it. A separately
compiled same-package Color subclass that relied on Object.hashCode may become
incompatible; Color's package-private constructor limits, but does not eliminate,
that possibility. The generated-leaf overlay itself does not change Color's API.

Deferred build and verification plan

1. Only after a favorable stock profile, compile the single generated leaf source
   against the pinned stock jar, using the same JDK/release/options for control and
   candidate, with annotation processing and implicit source compilation disabled
   (-proc:none -implicit:none, empty -sourcepath). Compile into fresh directories.
   No source regeneration is needed for this isolated hash-only experiment.
2. Compile probe/.../ColorHashProbe.java once against stock. Run with classes first
   in the classpath, before the stock jar. Run stock, rebuilt control, and candidate;
   pass --require-cache only for candidate. Its anonymous reference class derives
   directly from the pinned $AutoValue_Color, exercising the exact old recurrence.
   Confirm the overlay contains only AutoValue_Color.class and runtime resolution
   selects the intended class. For the later upstream build, inspect actual
   generated classes before repeating the semantic and performance checks.
3. The probe covers all 16 boolean combinations, null/non-null box IDs, empty and
   nested prototype/instance/property sets, all axiomatic colors, unions, flattening,
   hash collection lookup, and subtractNullOrVoid before/after hashing. It tests
   the exact zero-hash singleton ID 0x7eaa1ea7 and initialized zero cache state. IDs
   1L and 0x1_0000_0001L deliberately collide while remaining unequal. Six threads
   start together on fresh zero, ordinary, and nested colors. Race stress is a
   regression check; the publication argument comes from the volatile flag and
   monitor, not a claim that a stress test proves the Java memory model.
4. Run the project's existing Color tests on the eventual upstream build. Verify
   byte-identical compiler output and equivalent diagnostics on the parent's
   existing workloads/options. Compare stock, rebuilt control, and candidate so
   rebuilding effects are visible. Use independent JVM cohorts for confirmation,
   and inspect allocation/GC impact if the time result is credible. Do not promote
   merely because the path activates or a small initial sample looks favorable.

All source and probe files are currently uncompiled and unexecuted.
