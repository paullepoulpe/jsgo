package com.google.javascript.jscomp.colors;

import com.google.common.collect.ImmutableSet;
import com.google.errorprone.annotations.concurrent.LazyInit;
import java.lang.Override;
import java.lang.String;
import java.lang.SuppressWarnings;
import javax.annotation.processing.Generated;
import org.jspecify.annotations.Nullable;

@Generated("com.google.auto.value.extension.memoized.processor.MemoizeExtension")
final class AutoValue_Color extends $AutoValue_Color {
  @LazyInit
  @SuppressWarnings("Immutable")
  private transient volatile Color subtractNullOrVoid;

  AutoValue_Color(ColorId id, ImmutableSet<Color> prototypes, ImmutableSet<Color> instanceColors,
      boolean invalidating, boolean propertiesKeepOriginalName, boolean constructor,
      ImmutableSet<String> ownProperties, @Nullable ColorId boxId, boolean closureAssert,
      ImmutableSet<Color> unionElements) {
    super(id, prototypes, instanceColors, invalidating, propertiesKeepOriginalName, constructor, ownProperties, boxId, closureAssert, unionElements);
  }

  @Override
  public Color subtractNullOrVoid() {
    if (subtractNullOrVoid == null) {
      synchronized (this) {
        if (subtractNullOrVoid == null) {
          subtractNullOrVoid = super.subtractNullOrVoid();
          if (subtractNullOrVoid == null) {
            throw new NullPointerException("subtractNullOrVoid() cannot return null");
          }
        }
      }
    }
    return subtractNullOrVoid;
  }
}
