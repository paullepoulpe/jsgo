package com.google.javascript.jscomp.colors;

import com.google.common.collect.ImmutableSet;
import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;

/** Standalone semantic probe; run against stock, rebuilt control, and candidate. */
public final class ColorHashProbe {
  private static boolean requireCache;

  public static void main(String[] args) throws Exception {
    requireCache = args.length == 1 && args[0].equals("--require-cache");
    check(args.length == 0 || requireCache, "unexpected arguments");

    for (Color color : StandardColors.AXIOMATIC_COLORS.values()) {
      checkEquivalent(color);
    }
    for (int flags = 0; flags < 16; flags++) {
      for (int boxed = 0; boxed < 2; boxed++) {
        for (int nested = 0; nested < 2; nested++) {
          Color color = new AutoValue_Color(
              ColorId.fromUnsigned(0x12345678),
              nested == 0 ? ImmutableSet.of() : ImmutableSet.of(StandardColors.TOP_OBJECT),
              nested == 0 ? ImmutableSet.of() : ImmutableSet.of(StandardColors.NUMBER),
              (flags & 1) != 0,
              (flags & 2) != 0,
              (flags & 4) != 0,
              nested == 0 ? ImmutableSet.of() : ImmutableSet.of("Aa", "BB", "property"),
              boxed == 0 ? null : StandardColors.NUMBER_OBJECT_ID,
              (flags & 8) != 0,
              ImmutableSet.of());
          checkEquivalent(color);
        }
      }
    }

    Color left = singleton(1L);
    Color collision = singleton(0x1_0000_0001L);
    check(left.hashCode() == collision.hashCode(), "collision fixture");
    check(!left.equals(collision) && !collision.equals(left), "collision equals");
    HashSet<Color> colliding = new HashSet<>();
    colliding.add(left);
    colliding.add(collision);
    check(colliding.size() == 2, "collision set size");

    Color zero = singleton(0x7eaa1ea7L);
    check(reference(zero).hashCode() == 0, "zero fixture");
    checkEquivalent(zero);
    checkCache(zero, 0);

    Color union = Color.createUnion(ImmutableSet.of(left, StandardColors.NULL_OR_VOID));
    check(union.subtractNullOrVoid() == left, "subtract before hashing");
    checkEquivalent(union);
    check(union.subtractNullOrVoid() == left, "subtract after hashing");
    Color nestedUnion = Color.createUnion(ImmutableSet.of(union, collision));
    check(nestedUnion.getUnionElements().size() == 3, "union flattening");
    checkEquivalent(nestedUnion);
    Color subtracted = nestedUnion.subtractNullOrVoid();
    check(subtracted.getUnionElements().equals(ImmutableSet.of(left, collision)), "subtract union");
    check(nestedUnion.subtractNullOrVoid() == subtracted, "existing memoization");
    checkEquivalent(subtracted);

    checkConcurrent(singleton(0x7eaa1ea7L));
    checkConcurrent(singleton(7L));
    checkConcurrent(Color.singleBuilder().setId(ColorId.fromUnsigned(8L))
        .setPrototype(union).setInstanceColor(subtracted).build());
    System.out.println("ColorHashProbe OK");
  }

  private static Color singleton(long id) {
    return Color.singleBuilder().setId(ColorId.fromUnsigned(id)).build();
  }

  // The pinned generated superclass supplies the exact original recurrence and equality.
  private static Color reference(Color value) {
    return new $AutoValue_Color(
        value.getId(), value.getPrototypes(), value.getInstanceColors(), value.isInvalidating(),
        value.getPropertiesKeepOriginalName(), value.isConstructor(), value.getOwnProperties(),
        value.getBoxId(), value.isClosureAssert(), value.getUnionElements()) {};
  }

  private static void checkEquivalent(Color value) throws Exception {
    Color expected = reference(value);
    int expectedHash = expected.hashCode();
    check(value.equals(expected) && expected.equals(value), "reference equals");
    for (int i = 0; i < 5; i++) {
      check(value.hashCode() == expectedHash, "reference hash");
    }
    HashSet<Color> lookup = new HashSet<>();
    lookup.add(value);
    check(lookup.contains(expected), "reference lookup");
    checkCache(value, expectedHash);
  }

  private static void checkConcurrent(Color value) throws Exception {
    if (requireCache) {
      check(!cacheInitialized(value), "fresh value must be cold");
    }
    int expected = reference(value).hashCode();
    int workers = 6;
    ExecutorService pool = Executors.newFixedThreadPool(workers);
    CountDownLatch ready = new CountDownLatch(workers);
    CountDownLatch start = new CountDownLatch(1);
    List<Future<?>> futures = new ArrayList<>();
    try {
      for (int i = 0; i < workers; i++) {
        futures.add(pool.submit(() -> {
          ready.countDown();
          start.await();
          for (int j = 0; j < 1000; j++) {
            check(value.hashCode() == expected, "concurrent hash");
          }
          return null;
        }));
      }
      ready.await();
      start.countDown();
      for (Future<?> future : futures) {
        future.get();
      }
    } finally {
      start.countDown();
      pool.shutdownNow();
    }
    checkCache(value, expected);
  }

  private static boolean cacheInitialized(Color value) throws Exception {
    Field initialized = AutoValue_Color.class.getDeclaredField("hashCode$Memoized");
    initialized.setAccessible(true);
    return initialized.getBoolean(value);
  }

  private static void checkCache(Color value, int expected) throws Exception {
    if (!requireCache) {
      return;
    }
    check(cacheInitialized(value), "hash cache initialized, including zero");
    Field cached = AutoValue_Color.class.getDeclaredField("hashCode");
    cached.setAccessible(true);
    check(cached.getInt(value) == expected, "cached hash value");
  }

  private static void check(boolean condition, String message) {
    if (!condition) {
      throw new AssertionError(message);
    }
  }
}
