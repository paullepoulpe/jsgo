package com.google.javascript.jscomp;

import com.google.javascript.rhino.IR;
import com.google.javascript.rhino.Node;
import com.google.javascript.rhino.Token;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.EnumSet;
import java.util.List;
import java.util.Set;

/** Same-source declaration probe for stock, rebuilt control, and the function-name shortcut. */
public final class ReferenceFunctionFirstChildProbe {
  private static final Set<Token> DECLARATION_PARENTS = EnumSet.of(
      Token.VAR, Token.LET, Token.CONST, Token.PARAM_LIST, Token.FUNCTION, Token.CLASS, Token.CATCH);
  private static final Method ACTUAL;
  private static int checks;

  static {
    try {
      ACTUAL = Reference.class.getDeclaredMethod("isDeclarationHelper", Node.class);
      ACTUAL.setAccessible(true);
    } catch (ReflectiveOperationException error) {
      throw new ExceptionInInitializerError(error);
    }
  }

  public static void main(String[] args) throws Exception {
    require(args.length == 0, "unexpected arguments");
    checkParsed("function f(a) { var b=a; return b; } const g=function h(p){return p;};");
    checkParsed("const f=(a)=>a; const g=()=>{let b=0; return b;};");
    checkParsed("function f({a:x=1},[y],...rest){let {b:z}=x; [z]=rest; return y;}");
    checkParsed("const key='x'; let {[key]:value,...rest}=source; const [first,...tail]=list;");
    checkParsed("class B extends A { method(p){return p;} static x=B; }");
    checkParsed("try { throw 1; } catch(e) { let x=e; } for(let x of xs) { x; }");
    checkParsed("import main,{item as renamed} from 'module'; export {renamed};");

    // All parent tokens, all three child positions, and stale arrow flags on nonfunctions.
    // Raw nodes intentionally include malformed structural layouts; the helper must keep its
    // existing results even when the parent is not a valid parse tree for that token.
    List<Token> tokens = new ArrayList<>(List.of(Token.values()));
    tokens.add(null);
    for (Token token : tokens) {
      for (boolean arrow : new boolean[] {false, true}) {
        Node parent = new Node(Token.FUNCTION);
        parent.setIsArrowFunction(arrow);
        parent.setToken(token);
        Node first = IR.name("first");
        Node second = IR.name("second");
        Node third = IR.name("third");
        parent.addChildToBack(first);
        parent.addChildToBack(second);
        parent.addChildToBack(third);
        Node root = new Node(Token.ROOT, parent);
        for (Node child : List.of(first, second, third)) {
          check("parent=" + token + ",arrow=" + arrow + ",child=" + child.getString(), child);
          if (token == Token.FUNCTION) {
            require(actual(child).equals(Boolean.toString(!arrow || child == first)),
                "explicit function truth table");
          }
        }
        require(parent.getParent() == root && parent.getToken() == token,
            "parent identity/token changed");
        require(parent.getFirstChild() == first && first.getNext() == second
                && second.getNext() == third && third.getNext() == null
                && parent.getLastChild() == third,
            "child order changed");
        require(first.getParent() == parent && second.getParent() == parent
                && third.getParent() == parent,
            "child parents changed");
        if (token == Token.FUNCTION) {
          require(parent.isArrowFunction() == arrow, "arrow flag changed");
        }
      }
    }

    Node topFunction = IR.function(IR.name("top"), IR.paramList(), IR.block());
    check("parent-has-no-parent", topFunction.getFirstChild());
    check("detached-name", IR.name("detached"));
    check("null-node", null);
    System.out.println("ReferenceFunctionFirstChildProbe OK checks=" + checks);
  }

  private static void checkParsed(String source) throws Exception {
    Compiler compiler = new Compiler();
    Node script = compiler.parseTestCode(source);
    require(script != null && compiler.getErrors().isEmpty(), "parse failure: " + source);
    String before = script.toStringTree();
    visit(script, "parsed");
    require(before.equals(script.toStringTree()), "parsed AST changed");
  }

  private static void visit(Node node, String path) throws Exception {
    if (node.isName()) {
      check(path + ":" + node.getString(), node);
    }
    int index = 0;
    for (Node child = node.getFirstChild(); child != null; child = child.getNext()) {
      visit(child, path + "/" + index++);
    }
  }

  private static void check(String label, Node node) throws Exception {
    String expected;
    try {
      expected = Boolean.toString(original(node));
    } catch (RuntimeException error) {
      expected = "throws:" + error.getClass().getName();
    }
    String actual = actual(node);
    require(actual.equals(expected), label + ": expected " + expected + ", got " + actual);
    require(actual(node).equals(actual), label + ": repeat result changed");
    checks++;
    System.out.println(label + "=" + actual);
  }

  private static String actual(Node node) throws Exception {
    try {
      return ACTUAL.invoke(null, node).toString();
    } catch (InvocationTargetException error) {
      Throwable cause = error.getCause();
      if (cause instanceof RuntimeException) {
        return "throws:" + cause.getClass().getName();
      }
      throw error;
    }
  }

  // Exact pinned helper control flow, with the same enum membership represented by EnumSet.
  private static boolean original(Node node) {
    Node parent = node.getParent();
    if (parent.isClass() && !node.isFirstChildOf(parent)) {
      return false;
    }
    if (parent.getParent() == null) {
      return false;
    }
    if (NodeUtil.isNameDeclaration(parent.getParent()) && node == parent.getSecondChild()) {
      return false;
    }
    if (parent.isDestructuringLhs()
        || parent.isDestructuringPattern()
        || parent.isRest()
        || (parent.isStringKey() && parent.getParent().isObjectPattern())
        || (parent.isComputedProp()
            && parent.getParent().isObjectPattern()
            && node == parent.getLastChild())
        || (parent.isDefaultValue() && node == parent.getFirstChild())) {
      return original(parent);
    }
    if (parent.isImport()) {
      return true;
    }
    if (parent.isImportSpec() && node == parent.getLastChild()) {
      return true;
    }
    if (parent.isArrowFunction()) {
      return node == parent.getFirstChild();
    }
    return DECLARATION_PARENTS.contains(parent.getToken());
  }

  private static void require(boolean condition, String message) {
    if (!condition) {
      throw new AssertionError(message);
    }
  }
}
