Reference function-first-child declaration shortcut

Status: source-only candidate prepared against Closure v20261015. No Java,
compiler, benchmark, or archive operation was run. No runtime gain is claimed.

The three changed lines replace the final arrow-function branch in
Reference.isDeclarationHelper with a FUNCTION branch whose result is
  node == parent.getFirstChild() || !parent.isArrowFunction()
The corresponding comment is updated. Earlier guards, recursion, and the final
declaration-parent membership test remain unchanged.

Correctness
  DECLARATION_PARENTS contains FUNCTION. When the original helper reaches the
  final arrow branch and the parent is FUNCTION, its result is therefore
  !arrowFlag || isFirstChild. Reordering these operands gives the same result
  while avoiding the property lookup for every first child. This includes a
  normal function name and the empty name node in an arrow function.

  For a nonfunction parent, isArrowFunction already returns false before any
  property lookup. The new parent.isFunction check likewise falls through to
  the unchanged membership test. A stale ARROW_FN flag on a nonfunction does
  not affect either version. For a FUNCTION parent with a nonfirst child, the
  flag remains necessary: ordinary functions return true, arrows return false.

  getParent, getToken, isFunction, getFirstChild, isArrowFunction, and the boolean
  property getter are final and read-only. There is no user callback or scope
  construction to skip. Null parents, detached nodes, null parent tokens, and
  invalid child layouts encounter the same earlier checks and boolean results.

  As with a shortcut over any property read, deliberately corrupting private
  property storage is outside this proof. In particular, an object-valued
  ARROW_FN entry manufactured through same-package misuse or reflection can
  make the original integer getter throw; the first-child shortcut would avoid
  that error. The ordinary arrow setter/deserializer stores the boolean as an
  integer entry. No public AST construction operation requires malformed
  property-storage exceptions to identify a declaration.

Profile grounding
  Corrected profile results/profile-stock-bigquery-steady-v2/hot-callers.tsv,
  CPU_CALLERS4 Node.lookupProperty rank 2: 14/2221 total CPU samples (0.6303%)
  are attributed through getIntProp -> getBooleanProp -> isArrowFunction ->
  Reference.isDeclarationHelper. This identifies the exact lookup site, but
  does not count how many calls have first-child arguments or measure speedup.
  End-to-end performance may be below the measurement floor.

Artifacts
  control-src/.../Reference.java: untouched pinned original.
  src/.../Reference.java: isolated candidate.
  reference-function-first-child.patch: normalized a/src and b/src patch.
  probe/.../ReferenceFunctionFirstChildProbe.java: same-source probe intended
    for stock, rebuilt control, and candidate; no special arguments.
  frozen-source-manifest.json: hashes and source-only application evidence.

Probe
  Uses reflection only to invoke the production private static helper. An
  independent copy of the pinned helper supplies the original result. Explicit
  function truth tables additionally check all three child positions with the
  arrow flag both false and true. Every Token (plus a null parent token) is
  tested in all three child positions, with both ordinary and stale arrow flags.
  Parsed examples cover declarations, function expressions, arrows, rest and
  destructuring/defaults, computed keys, classes, imports, catch, and loops.
  Detached/null inputs compare exception classes. Successful runs print stable
  full result transcripts for comparison across variants. Parsed trees and
  synthetic parent/child linkage are checked for mutation.

  Compile/run and exact stdout comparison remain pending under root control.
  Runtime probes do not replace compiler-output/diagnostic byte gates or an
  independent timing confirmation. Existing frozen candidates were not changed.
