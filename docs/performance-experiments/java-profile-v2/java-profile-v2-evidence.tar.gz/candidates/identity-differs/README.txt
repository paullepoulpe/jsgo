JSType.differsFrom identity: source-only candidate

Status
  Three-line patch prepared from pinned Closure v20261015. No Java process,
  build, compiler, or benchmark was run by this task. Root controls execution
  after the current quiet screen. No runtime benefit is asserted.

Files
  identity-differs.patch: unshaded diff against the pinned source root.
  src/com/google/javascript/rhino/jstype/JSType.java: candidate.
  control-src/com/google/javascript/rhino/jstype/JSType.java: exact pinned copy.
  probe/com/google/javascript/rhino/jstype/IdentityDiffersProbe.java:
    same-source standalone probe for stock, rebuilt control, and candidate.

Change
  At the start of differsFrom(JSType that), return false when this == that.
  The EqualityChecker DATA_FLOW fallback is byte-for-byte unchanged.
  JSType.equals immediately above already has the corresponding identity guard.
  areSimilar inherits the result through its existing differsFrom call.

Correctness reasoning
  EqualityChecker.areEqualInternal begins with identical(left, right) => true,
  before null checks, type predicates, unknown handling, proxy unwrapping,
  resolution, or recursion. JSCompObjects.identical is exactly a == b.

  On the fresh checker constructed by differsFrom, the preceding constructor,
  setEqMethod, check, and areEqualCaching steps touch only checker-local state.
  The recursion depth starts at zero; no recursion cache is constructed for the
  identity case. Thus the original path already returns false without inspecting
  or changing the type, including unresolved and recursive types. The new guard
  skips no required type operation. A null argument cannot equal this, so it
  retains the existing fallback and differsFrom(null) returns true.

  Source callers include LinkedFlowScope.equalSlots, which already checks slot
  identity but can receive distinct slots holding the same JSType, and
  TypeInference's assertion-narrowing comparison. Aggregate EqualityChecker
  allocation samples include other equality calls and nonidentity comparisons;
  they do not measure the avoidable share of this guard. HotSpot may already
  eliminate some checker construction, so this remains a measurement candidate.

Probe
  For every native type, check self differsFrom/areSimilar, null arguments, and
  unchanged resolution state. A small matrix of primitive/unknown, record,
  function, union, template, templatized-array, and known-symbol values compares
  differsFrom to a direct new EqualityChecker(DATA_FLOW).check call, which is
  the exact pinned fallback. Distinct values and unknown equivalence are included.

  Within resolver.openForDefinition(), check a named type remains unresolved
  after self comparison, retains its referenced type, and emits no diagnostic.
  A record using a forward NamedType proxy tests self comparison before and
  after cyclic type resolution. An armed PrototypeObjectType subclass throws
  from its type predicates, confirming those methods are not called on self
  comparison. These checks are intentionally expected to pass on stock too.

  The probe prints stable native/self state rows and the full matrix of boolean
  results. Successful complete stdout should match across all three jars.
  No timings or identity hashes are printed. Main class:
    com.google.javascript.rhino.jstype.IdentityDiffersProbe

Validation boundary
  Source review and patch dry-run only. Runtime probe results, compiler-output
  byte/diagnostic checks, allocation measurements, and wall-time confirmation
  remain outstanding. Do not infer a speedup from the size or apparent simplicity
  of the source change.
