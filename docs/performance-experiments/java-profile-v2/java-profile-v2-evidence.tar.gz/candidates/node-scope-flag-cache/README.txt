Deferred source draft: lazy Node flag cache

This draft is retained for provenance, not selected for a build or benchmark.
It adds one byte to Node, caches only arrow/synthetic getter results after a
successful original property read, and invalidates through the existing property
head setter after routing every direct head replacement through that setter.
Independent source review found no ordinary single-threaded semantic blocker,
but it requires maintaining complete invalidation and may enlarge common Node
subclasses. No memory layout, compilation, probe or runtime measurement exists.

Root selected the cleaner immutable PropListItem suffix-summary design for
further source/probe preparation, under ../node-hot-prop-summary. That alternative
adds no Node field and requires no invalidation writes. This directory's draft
sources were not overwritten or combined with that alternative.
