Exact plain-object / scalar equality guard

Status: source and focused oracle probe prepared; no candidate build or runtime yet.
This is an isolated JSType.java change against pinned Closure v20261015. It does
not include the equality-entry instrumentation or any other candidate.

Change
After the existing this==other check, return false when the left runtime class is
exactly PrototypeObjectType, the right is final NullType/VoidType/UnknownType, the
left's unknown cache already says known, and its template map is empty. All other
operands use the original EqualityChecker expression unchanged. No cache or worker
reuse is introduced; this avoids constructing and entering a checker for a narrow
case whose result is already fixed.

Observed opportunity, not a performance result
The single BigQuery equality-entry diagnostic counted 1,863,747 check() entries.
IDENTITY nonidentity PrototypeObjectType/NullType, /VoidType, and /UnknownType had
152,263 + 152,251 + 134,828 = 439,342 entries (23.573049%). This is an UPPER BOUND
on qualifying entries: that diagnostic did not inspect cached-unknown state or
template-map emptiness. Entry frequencies are not sampled allocation weights and
are not elapsed-time savings. The diagnostic is instrumented/cold, not a settled
performance baseline. Its independent receipt review is under
reviews/diagnostic-bigquery-equality-pairs-v1/review.json.

Semantic proof
1. The original identity shortcut remains first. The added right-side instanceof
   conditions are false for null and non-JSType objects, so those results and lack
   of type callbacks are unchanged.
2. Exact left runtime class excludes all subclasses and their custom predicates.
   The three right classes are final. No added guard invokes an overridable method
   on an object whose concrete implementation is not known.
3. PrototypeObjectType inherits ObjectType.hasCachedValues(), which returns
   !unknown. A true result means the existing ObjectType.isUnknownType() call is
   only a false field read: it will not walk prototypes, initialize FunctionType
   prototypes, inspect interfaces, or change the unknown cache. Without that guard,
   skipping the call would change public hasCachedValues() and possible hooks.
4. Left isNoResolvedType is pure false. Right predicates are fixed. For final
   UnknownType the right unknown predicate is pure true. IDENTITY mode with the
   left known false cannot enter the both-unknown/nominal mismatch branch.
5. Neither side is a union, function, ArrowType or proxy. Exact PrototypeObjectType
   inherits isRecordType/isNominalType=false. In particular, it does NOT call a
   constructor name or ownerFunction hook during this equality path.
6. Both template getters are plain field reads. TemplateTypeMap is final; isEmpty
   reads its immutable key list. An empty left list makes areTypeMapEqual perform
   no recursive value comparisons and return true, regardless of right contents.
   Public mergeSupertypeTemplateTypes can change even these types' maps; a populated
   left map therefore deliberately falls back. Skipping right map/list field reads
   has no observable effect on valid constructed types.
7. The original checker reaches its final false. Its allocation, local hasRun flag
   and recursionDepth increments are private per-call state and need not be retained.

The proof assumes ordinary valid objects, no reflection/Unsafe corruption, and the
compiler's existing single-threaded type mutation contract. It does not claim to
preserve resource-exhaustion or Java stack-trace frame identities. It preserves
reachable custom type/prototype/template callbacks through the fallback guards.
Independent source review by review_entry_diagnostic agreed with this proof.

Focused probe
PrototypeScalarEqualsProbe uses an unmodified direct EqualityChecker IDENTITY call
as the oracle. It checks all native pairs plus plain/anonymous, records/functions,
union, proxy and NoResolved fixtures. Targeted checks cover all three right classes,
checked and unchecked unknowns, positive eligibility, public template-map mutation
on either/both sides, armed recursive template predicates, uncached prototype
callbacks and exceptions, cache transitions/repeated cached calls, custom left
subclasses, identity/null/non-type operands, unresolved objects and proxy equality.
No final/private production field is replaced to create template-map cases.

Build and probe plan (root executes only when the benchmark machine is idle)

python3 /workspace/jsgo-java-experiments/profile-v2/build-candidate.py equality-prototype-scalar \
  --source-root /workspace/jsgo-java-experiments/profile-v2/candidates/equality-prototype-scalar/src

python3 /workspace/jsgo-java-experiments/profile-v2/run-probes.py \
  --manifest /workspace/jsgo-java-experiments/profile-v2/build/equality-prototype-scalar/manifest.json \
  --probe-source /workspace/jsgo-java-experiments/profile-v2/candidates/equality-prototype-scalar/probe/com/google/javascript/rhino/jstype/PrototypeScalarEqualsProbe.java \
  --probe-class com.google.javascript.rhino.jstype.PrototypeScalarEqualsProbe \
  --compare-stdout \
  --out /workspace/jsgo-java-experiments/profile-v2/results/equality-prototype-scalar-probes-attempt-1

Only a successful build/probe should proceed to the existing isolated CONTROL
screen and, if promising, independent direct-STOCK confirmation. Compare all six
workload artifacts and report time/CPU/allocation/current RSS/lifetime peak RSS.
The checks added to every equals call may offset the removed work; measure the net
rather than inferring a win from the diagnostic count.
