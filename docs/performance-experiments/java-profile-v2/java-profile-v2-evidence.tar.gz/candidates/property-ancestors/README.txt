PropertyMap ancestor membership: source-only candidate

Status
  Prepared from the pinned Closure v20261015 source. No javac, java, JVM,
  compiler, Docker, or benchmark was run. Patch dry-run against pinned source
  succeeds. Semantic probe execution and stock/control/candidate comparison
  are deliberately deferred until the profiling run ends.

Files
  property-ancestors.patch: unshaded diff against com/google/... source root.
  src/com/google/javascript/rhino/jstype/PropertyMap.java: candidate source.
  control-src/com/google/javascript/rhino/jstype/PropertyMap.java: exact pinned
    source copy for an isolated rebuilt control overlay.
  probe/com/google/javascript/rhino/jstype/PropertyAncestorsProbe.java:
    one standalone package-level probe, intended to run unchanged against
    stock, rebuilt control, and candidate. Successful stdout should match
    byte-for-byte across those runs. It prints named snapshots and a check
    count; it prints no identity hashes or timing data.

Patch boundary
  Replace LinkedHashSet<PropertyMap> traversal storage with an ArrayList for
  ordered processing plus IdentityHashMap<PropertyMap, Boolean> membership.
  Each first visit inserts membership and appends the map before fetching the
  primary parent. Primary traversal still precedes secondary traversal.
  Duplicate visits still return before any parent getter is called.

  The cache-validation/rebuild loops, counters, invalidation, sorted string
  keys, known-symbol collection, mutation methods, and PropertyMap.hashCode
  are unchanged. No public method was added or modified; the private recursive
  helper takes the two traversal containers.

Equality and getter side effects
  PropertyMap is final, directly extends Object, and does not override equals.
  Its existing equality is object identity even though hashCode depends on
  its own property names. IdentityHashMap uses the same membership relation.
  Do not change PropertyMap.hashCode: JSType hashing uses its current meaning.

  Parent access is not assumed pure. In particular, InstanceObjectType's
  getImplicitPrototype calls FunctionType.getPrototype, which may lazily
  allocate a prototype. The candidate leaves parent-getter positions and
  frequency unchanged, and does not cache or hoist them. Inspected standard
  getter implementations do not mutate existing PropertyMap property-name
  sets during this traversal; lazy prototype setup stores the prototype in
  FunctionType.prototypeSlot, separately from PropertyMap.properties.

  A custom PrototypeObjectType subclass could mutate its property names in a
  getter, invalidating the old LinkedHashSet's hashed-key assumptions. This
  work does not establish behavioral equivalence for arbitrary such mutation.
  The probe's custom getter fixture is read-only during traversal and checks
  the exact cold/warm DFS event sequence.

Probe coverage and construction
  - Empty mutable map and shared immutable empty map; warm cache references.
  - Primary parent chain; sorted strings and duplicate-symbol insertion order.
  - Existing property replacement: counter and key-cache references preserved.
  - New ancestor property/symbol: counter increments, descendant keys refresh,
    ancestor counters converge; symbol replacement preserves caches.
  - Interface diamond: standard FunctionType builder + setExtendedInterfaces;
    first-visit order, shared ancestor, symbol deduplication, later mutation.
  - Distinct PropertyMaps with equal own-name hashes: both caches must be
    invalidated by the aggregate rebuild, proving both identities were visited.
  - Mutual interfaces: synthetic cycle termination and root-dependent symbol
    order. The Java setter accepts these references; this is not valid JS
    inheritance and the probe makes no compiler-acceptance assertion.
  - Abstract constructor implementing an interface: alternate secondary-parent
    branch is included.
  - Read-only PrototypeObjectType getter-trace fixture: primary before secondary,
    one getter sequence per distinct map on both cold and warm calls.

  Factory details were checked in source: JSTypeRegistry(ErrorReporter),
  createObjectType(name, parent), resetImplicitPrototype, FunctionType.builder
  with forInterface/forConstructor/withIsAbstract, setExtendedInterfaces,
  setImplementedInterfaces, and KnownSymbolType(registry, name).
  A null createObjectType parent defaults to native Object. Fixtures explicitly
  reset that prototype to null before defining properties/warming caches to
  exclude unrelated native ancestry. Interface edges are set before warming:
  setExtendedInterfaces alone does not explicitly invalidate PropertyMap's
  cache, and this candidate does not alter that existing behavior.
  PropertyMap.putProperty is used directly inside the package-level fixture
  to focus replacement and mutation checks on PropertyMap bookkeeping.

Follow-up execution (not performed here)
  Build isolated control and candidate overlays with the existing v2 build
  workflow and published-jar dependency shading. Compile the same probe against
  each intended jar/classpath and run its fully qualified main class:
    com.google.javascript.rhino.jstype.PropertyAncestorsProbe
  Compare successful complete stdout and exit statuses for stock/control/
  candidate. Do not treat these focused checks as end-to-end byte validation.
  Candidate selection still depends on the warmed profile and subsequent
  independent byte/diagnostic checks and wall-time confirmation.
