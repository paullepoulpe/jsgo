package com.google.javascript.rhino.jstype;

import com.google.javascript.rhino.ErrorReporter;
import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.List;

/** Run this same package-level semantic probe against stock, control, and candidate. */
public final class PropertyAncestorsProbe {
  private static final JSTypeRegistry REGISTRY =
      new JSTypeRegistry(ErrorReporter.ALWAYS_THROWS_INSTANCE);
  private static final JSType NUMBER = REGISTRY.getNativeType(JSTypeNative.NUMBER_TYPE);
  private static final JSType BOOLEAN = REGISTRY.getNativeType(JSTypeNative.BOOLEAN_TYPE);
  private static final Field COUNTER = field("cachedKeySetCounter");
  private static final Field STRING_CACHE = field("cachedKeySet");
  private static final List<String> TRACE = new ArrayList<>();
  private static boolean tracing;
  private static int checks;

  public static void main(String[] args) throws Exception {
    check(args.length == 0, "unexpected arguments");
    emptyMaps();
    primaryChainAndMutations();
    interfaceDiamond();
    equalPropertiesDistinctMaps();
    syntheticInterfaceCycle();
    abstractImplementedInterfaces();
    getterSequence();
    System.out.println("PropertyAncestorsProbe OK checks=" + checks);
  }

  private static void emptyMaps() throws Exception {
    PropertyMap empty = new PropertyMap();
    expect("empty", empty, List.of(), List.of());
    checkWarm(empty, "empty warm");
    expect("immutable-empty", PropertyMap.immutableEmptyMap(), List.of(), List.of());
    checkWarm(PropertyMap.immutableEmptyMap(), "immutable empty warm");
  }

  private static void primaryChainAndMutations() throws Exception {
    ObjectType parent = object("ProbeParent", null);
    ObjectType child = object("ProbeChild", parent);
    put(parent, "z", NUMBER);
    put(child, "a", NUMBER);
    KnownSymbolType parentSymbol = symbol("parent-symbol");
    KnownSymbolType shared = symbol("shared-symbol");
    KnownSymbolType childSymbol = symbol("child-symbol");
    put(parent, parentSymbol);
    put(parent, shared);
    put(child, childSymbol);
    put(child, shared);
    List<KnownSymbolType> symbols = List.of(childSymbol, shared, parentSymbol);
    PropertyMap map = child.getPropertyMap();
    expect("primary", map, List.of("a", "z"), symbols);
    checkWarm(map, "primary warm");
    checkCounters(child, parent);

    PropertyMap.AllKeys beforeReplacement = map.getAllKeys();
    int parentCounter = counter(parent.getPropertyMap());
    put(parent, "z", BOOLEAN);
    check(counter(parent.getPropertyMap()) == parentCounter, "replacement counter");
    PropertyMap.AllKeys afterReplacement = map.getAllKeys();
    checkSameCaches(beforeReplacement, afterReplacement, "replacement caches");
    check(parent.getPropertyMap().getOwnProperty("z").getType() == BOOLEAN,
        "replacement type visible");

    put(parent, "b", NUMBER);
    check(counter(parent.getPropertyMap()) == parentCounter + 1, "new name counter");
    PropertyMap.AllKeys afterAddition = expect("primary-added", map, List.of("a", "b", "z"), symbols);
    check(afterAddition.stringKeys() != afterReplacement.stringKeys(), "new name invalidates cache");
    checkCounters(child, parent);
    checkWarm(map, "after string addition warm");

    KnownSymbolType later = symbol("later-symbol");
    int beforeSymbolCounter = counter(parent.getPropertyMap());
    put(parent, later);
    check(counter(parent.getPropertyMap()) == beforeSymbolCounter + 1, "new symbol counter");
    expect("primary-symbol-added", map, List.of("a", "b", "z"),
        List.of(childSymbol, shared, parentSymbol, later));
    checkCounters(child, parent);
    checkWarm(map, "after symbol addition warm");

    PropertyMap.AllKeys beforeSymbolReplacement = map.getAllKeys();
    int beforeSymbolReplacementCounter = counter(parent.getPropertyMap());
    Property.Key key = new Property.SymbolKey(later);
    parent.getPropertyMap().putProperty(key, new Property(key, BOOLEAN, false, null));
    check(counter(parent.getPropertyMap()) == beforeSymbolReplacementCounter,
        "symbol replacement counter");
    checkSameCaches(beforeSymbolReplacement, map.getAllKeys(), "symbol replacement caches");
  }

  private static void interfaceDiamond() throws Exception {
    FunctionType top = iface("ProbeTop");
    FunctionType left = iface("ProbeLeft");
    FunctionType right = iface("ProbeRight");
    FunctionType root = iface("ProbeRoot");
    left.setExtendedInterfaces(List.of(top.getInstanceType()));
    right.setExtendedInterfaces(List.of(top.getInstanceType()));
    root.setExtendedInterfaces(List.of(left.getInstanceType(), right.getInstanceType()));
    ObjectType t = top.getInstanceType();
    ObjectType l = left.getInstanceType();
    ObjectType r = right.getInstanceType();
    ObjectType d = root.getInstanceType();
    put(t, "top", NUMBER);
    put(l, "left", NUMBER);
    put(r, "right", NUMBER);
    put(d, "root", NUMBER);
    KnownSymbolType st = symbol("top-symbol");
    KnownSymbolType sl = symbol("left-symbol");
    KnownSymbolType sr = symbol("right-symbol");
    KnownSymbolType sd = symbol("root-symbol");
    KnownSymbolType shared = symbol("diamond-shared");
    put(t, st);
    put(t, shared);
    put(l, sl);
    put(l, shared);
    put(r, sr);
    put(r, shared);
    put(d, sd);
    List<KnownSymbolType> symbols = List.of(sd, sl, shared, st, sr);
    PropertyMap map = d.getPropertyMap();
    expect("diamond", map, List.of("left", "right", "root", "top"), symbols);
    checkWarm(map, "diamond warm");
    checkCounters(d, l, r, t, root.getPrototype(), left.getPrototype(),
        right.getPrototype(), top.getPrototype());

    put(t, "added", NUMBER);
    expect("diamond-added", map, List.of("added", "left", "right", "root", "top"), symbols);
    checkWarm(map, "diamond addition warm");
    checkCounters(d, l, r, t);
  }

  private static void equalPropertiesDistinctMaps() throws Exception {
    TraceObject left = new TraceObject("EqualLeft");
    TraceObject right = new TraceObject("EqualRight");
    TraceObject root = new TraceObject("EqualRoot");
    put(left, "same", NUMBER);
    put(right, "same", BOOLEAN);
    PropertyMap lm = left.getPropertyMap();
    PropertyMap rm = right.getPropertyMap();
    check(lm != rm && !lm.equals(rm) && !rm.equals(lm), "map equality is identity");
    check(lm.hashCode() == rm.hashCode(), "equal-property hash collision fixture");
    lm.getAllKeys();
    rm.getAllKeys();
    check(STRING_CACHE.get(lm) != null && STRING_CACHE.get(rm) != null, "both caches primed");
    root.secondaries = List.of(left, right);
    expect("equal-properties", root.getPropertyMap(), List.of("same"), List.of());
    check(STRING_CACHE.get(lm) == null && STRING_CACHE.get(rm) == null,
        "both distinct ancestors visited and invalidated");
    put(right, "right-added", NUMBER);
    expect("equal-properties-added", root.getPropertyMap(),
        List.of("right-added", "same"), List.of());
  }

  // The Java setters permit this graph; cyclic interface inheritance is invalid JavaScript.
  // This checks only PropertyMap's finite-graph traversal, not compiler acceptance of a cycle.
  private static void syntheticInterfaceCycle() throws Exception {
    FunctionType a = iface("CycleA");
    FunctionType b = iface("CycleB");
    a.setExtendedInterfaces(List.of(b.getInstanceType()));
    b.setExtendedInterfaces(List.of(a.getInstanceType()));
    ObjectType at = a.getInstanceType();
    ObjectType bt = b.getInstanceType();
    put(at, "cycle-a", NUMBER);
    put(bt, "cycle-b", NUMBER);
    KnownSymbolType sa = symbol("cycle-a-symbol");
    KnownSymbolType sb = symbol("cycle-b-symbol");
    put(at, sa);
    put(bt, sb);
    expect("cycle-a", at.getPropertyMap(), List.of("cycle-a", "cycle-b"), List.of(sa, sb));
    checkWarm(at.getPropertyMap(), "cycle a warm");
    expect("cycle-b", bt.getPropertyMap(), List.of("cycle-a", "cycle-b"), List.of(sb, sa));
    checkWarm(bt.getPropertyMap(), "cycle b warm");
    put(bt, "cycle-added", NUMBER);
    expect("cycle-added", at.getPropertyMap(), List.of("cycle-a", "cycle-added", "cycle-b"),
        List.of(sa, sb));
    checkCounters(at, bt);
  }

  private static void abstractImplementedInterfaces() throws Exception {
    FunctionType iface = iface("ImplementedInterface");
    ObjectType it = iface.getInstanceType();
    put(it, "interface-property", NUMBER);
    FunctionType abstractCtor = FunctionType.builder(REGISTRY).forConstructor()
        .withName("ProbeAbstract").withIsAbstract(true).build();
    REGISTRY.resetImplicitPrototype(abstractCtor.getPrototype(), null);
    abstractCtor.setImplementedInterfaces(List.of(it));
    ObjectType instance = abstractCtor.getInstanceType();
    put(instance, "instance-property", NUMBER);
    expect("abstract-implemented", instance.getPropertyMap(),
        List.of("instance-property", "interface-property"), List.of());
    checkWarm(instance.getPropertyMap(), "abstract warm");
  }

  private static void getterSequence() throws Exception {
    TraceObject d = new TraceObject("D");
    TraceObject b = new TraceObject("B");
    TraceObject c = new TraceObject("C");
    TraceObject a = new TraceObject("A");
    a.primary = b;
    b.primary = d;
    c.primary = d;
    a.secondaries = List.of(c, b);
    for (TraceObject object : List.of(a, b, c, d)) {
      put(object, "same", NUMBER);
    }
    List<String> expected = List.of(
        "A.primary", "B.primary", "D.primary", "D.constructor", "D.secondary",
        "B.constructor", "B.secondary", "A.constructor", "A.secondary",
        "C.primary", "C.constructor", "C.secondary");
    for (int attempt = 0; attempt < 2; attempt++) {
      TRACE.clear();
      tracing = true;
      try {
        a.getPropertyMap().getAllKeys();
      } finally {
        tracing = false;
      }
      check(TRACE.equals(expected), "getter DFS sequence, attempt " + attempt + ": " + TRACE);
    }
    System.out.println("getter-trace=" + TRACE);
  }

  private static ObjectType object(String name, ObjectType parent) {
    ObjectType result = REGISTRY.createObjectType(name, parent);
    // createObjectType(name, null) otherwise defaults to native Object.
    if (parent == null) {
      REGISTRY.resetImplicitPrototype(result, null);
    }
    return result;
  }

  private static FunctionType iface(String name) {
    FunctionType result = FunctionType.builder(REGISTRY).forInterface().withName(name).build();
    // Remove unrelated native ancestors before adding fixture properties or warming caches.
    REGISTRY.resetImplicitPrototype(result.getPrototype(), null);
    return result;
  }

  private static KnownSymbolType symbol(String name) {
    return new KnownSymbolType(REGISTRY, name);
  }

  private static void put(ObjectType owner, String name, JSType type) {
    owner.getPropertyMap().putProperty(name, new Property(name, type, false, null));
  }

  private static void put(ObjectType owner, KnownSymbolType symbol) {
    Property.Key key = new Property.SymbolKey(symbol);
    owner.getPropertyMap().putProperty(key, new Property(key, NUMBER, false, null));
  }

  private static PropertyMap.AllKeys expect(String label, PropertyMap map,
      List<String> strings, List<KnownSymbolType> symbols) {
    PropertyMap.AllKeys actual = map.getAllKeys();
    check(new ArrayList<>(actual.stringKeys()).equals(strings), label + " strings");
    check(new ArrayList<>(actual.knownSymbolKeys()).equals(symbols), label + " symbol order");
    List<String> names = new ArrayList<>();
    for (KnownSymbolType symbol : actual.knownSymbolKeys()) {
      names.add(symbol.getDisplayName());
    }
    System.out.println(label + " strings=" + actual.stringKeys() + " symbols=" + names);
    return actual;
  }

  private static void checkWarm(PropertyMap map, String label) {
    PropertyMap.AllKeys a = map.getAllKeys();
    PropertyMap.AllKeys b = map.getAllKeys();
    checkSameCaches(a, b, label);
  }

  private static void checkSameCaches(PropertyMap.AllKeys a, PropertyMap.AllKeys b, String label) {
    check(a.stringKeys() == b.stringKeys(), label + " strings");
    check(a.knownSymbolKeys() == b.knownSymbolKeys(), label + " symbols");
  }

  private static void checkCounters(ObjectType first, ObjectType... rest) throws Exception {
    int expected = counter(first.getPropertyMap());
    for (ObjectType object : rest) {
      check(counter(object.getPropertyMap()) == expected, "ancestor counters converge");
    }
  }

  private static int counter(PropertyMap map) throws Exception {
    return COUNTER.getInt(map);
  }

  private static Field field(String name) {
    try {
      Field result = PropertyMap.class.getDeclaredField(name);
      result.setAccessible(true);
      return result;
    } catch (ReflectiveOperationException e) {
      throw new AssertionError(e);
    }
  }

  private static void check(boolean condition, String label) {
    checks++;
    if (!condition) {
      throw new AssertionError(label);
    }
  }

  /** Read-only getter overrides expose exact call order without mutating the graph during lookup. */
  private static final class TraceObject extends PrototypeObjectType {
    private final String label;
    private ObjectType primary;
    private List<ObjectType> secondaries = List.of();

    TraceObject(String label) {
      super(PrototypeObjectType.builder(REGISTRY).setName(label).setNative(true));
      this.label = label;
    }

    @Override
    public ObjectType getImplicitPrototype() {
      record("primary");
      return primary;
    }

    @Override
    public FunctionType getConstructor() {
      record("constructor");
      return null;
    }

    @Override
    public Iterable<ObjectType> getCtorExtendedInterfaces() {
      record("secondary");
      return secondaries == null ? List.of() : secondaries;
    }

    private void record(String getter) {
      if (tracing) {
        TRACE.add(label + "." + getter);
      }
    }
  }
}
