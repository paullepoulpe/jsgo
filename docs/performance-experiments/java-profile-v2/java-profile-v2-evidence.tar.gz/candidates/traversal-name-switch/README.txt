NodeTraversal NAME dispatch: source-only candidate

Status
  Isolated candidate based on pinned STOCK NodeTraversal, with no callback flags
  or other candidate changes. No runtime, Java, compiler, or build was run.
  No JIT or speedup claim is made.

Change
  Read `Token token = n.getToken()` once at the original dispatch point, then
  wrap `switch (token)` in `if (token != Token.NAME)`. Import Token explicitly.
  Apart from indentation, the switch body is byte-for-byte unchanged. Every
  subsequent operation remains in its original position: currentNode assignment,
  shouldTraverse, post-callback scope detection, child iteration, scope cleanup,
  currentNode restoration, and visit. Special handlers are unchanged.

Source proof
  Node.getToken (614) is final and returns the token field. Comparing the local
  token with Token.NAME invokes no callback, resolves no state, and changes no
  node. NAME has no special case in the switch;
  it currently takes the empty default arm. The guard therefore bypasses only
  that empty dispatch for NAME nodes. All other tokens use the original switch
  cases. The token is read once, in the original place before callbacks.

  A callback may change a NAME's token later in shouldTraverse. The guard does
  not reuse the local token after dispatch, so the original post-callback
  createsBlockScope(n) still observes that mutation. The original switch was
  likewise executed before shouldTraverse.

Null behavior boundary
  A null Node still fails on the same initial getToken() invocation before
  currentNode assignment or callback invocation. A nonnull Node with a null
  token compares unequal to Token.NAME and still fails during enum dispatch,
  before traversal state or callbacks change. For that malformed null-token
  case, JVM helpful-NPE wording can refer to the local token instead of the
  getter's return value; exact wording is not claimed identical. No null input
  is silently accepted. No extra null comparison was added to the hot path.

Artifacts and probe
  traversal-name-switch.patch: unshaded diff.
  src/com/google/javascript/jscomp/NodeTraversal.java: candidate source.
  control-src/com/google/javascript/jscomp/NodeTraversal.java: exact pinned copy.
  probe/com/google/javascript/jscomp/TraversalNoopProbe.java: exact copy of the
    already source-reviewed traversal-noop probe. Run in normal no-argument mode;
    this variant has no callback classification fields, so --require-flags is
    inapplicable. Generic/specialized traces, all ordinary/special syntax paths,
    callbacks, scope state, mutations, pruning, removal, and exceptions remain
    covered. Successful complete stdout is intended to match stock/control.

  Probe main: com.google.javascript.jscomp.TraversalNoopProbe
  Use the existing v2 overlay build/probe process after the root grants runtime.
  Patch dry-run and source checks pass; compilation, runtime probe execution,
  end-to-end byte/diagnostic checks, and independent timing remain outstanding.
