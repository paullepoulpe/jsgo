package com.google.javascript.jscomp;

import com.google.javascript.rhino.Node;
import com.google.javascript.rhino.Token;
import java.lang.reflect.Field;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Base64;
import java.util.List;

/** Same-source callback transcript probe for stock, rebuilt control, and candidate. */
public final class TraversalNoopProbe {
  private enum Mode { POST, SCOPED, PRE, CFG, LAMBDA }
  private enum Action { NONE, SKIP, EMPTY_TO_BLOCK, BLOCK_TO_EMPTY, REMOVE, THROW_PRE, THROW_POST }
  private static boolean requireFlags;

  private static final String SYNTAX =
      "let seed=0; const {p:alias=1}=source;"
      + "function f(arg=2){for(let i=0;i<2;i++){seed+=i;}return arg;}"
      + "class C extends Base {static field=seed;static {seed++;}"
      + "[key](x=3){return x;} method(){return seed;}}"
      + "try {f();} catch (e) {seed=e;}";
  private static final String MODULE =
      "export const value=1; export function f(x=2){return x+value;}";

  public static void main(String[] args) throws Exception {
    requireFlags = args.length == 1 && args[0].equals("--require-flags");
    check(args.length == 0 || requireFlags, "unexpected arguments");
    for (Mode mode : Mode.values()) {
      compare("syntax-" + mode, SYNTAX, mode, Action.NONE, false);
      compare("execution-order-" + mode, SYNTAX, mode, Action.NONE, true);
      compare("module-" + mode, MODULE, mode, Action.NONE, false);
    }
    for (Mode mode : List.of(Mode.PRE, Mode.CFG)) {
      compare("filter-" + mode, "keep();skip(hidden());last();", mode, Action.SKIP, false);
      compare("throw-pre-" + mode, "first();explode();last();", mode, Action.THROW_PRE, false);
    }
    compare("empty-to-block", ";keep();", Mode.PRE, Action.EMPTY_TO_BLOCK, false);
    compare("block-to-empty", "{}keep();", Mode.PRE, Action.BLOCK_TO_EMPTY, false);
    for (Mode mode : List.of(Mode.POST, Mode.SCOPED, Mode.LAMBDA)) {
      compare("remove-" + mode, "first();drop();last();", mode, Action.REMOVE, false);
    }
    for (Mode mode : List.of(Mode.POST, Mode.SCOPED, Mode.CFG, Mode.LAMBDA)) {
      compare("throw-post-" + mode, "first();explode();last();", mode, Action.THROW_POST, false);
    }
    System.out.println("TraversalNoopProbe OK");
  }

  private static void compare(String label, String source, Mode mode, Action action,
      boolean executionOrder) throws Exception {
    String generic = run(source, mode, action, executionOrder, false);
    String specialized = run(source, mode, action, executionOrder, true);
    check(generic.equals(specialized), label + ": generic/specialized transcript mismatch\n"
        + generic + "\n--- specialized ---\n" + specialized);
    // Complete event sequence, exception context, and output are retained for cross-jar comparison.
    System.out.println(label + "\t" + Base64.getEncoder().encodeToString(
        specialized.getBytes(StandardCharsets.UTF_8)));
  }

  private static String run(String source, Mode mode, Action action, boolean executionOrder,
      boolean specialized) throws Exception {
    CompilerOptions options = new CompilerOptions();
    options.setLanguageIn(CompilerOptions.LanguageMode.ECMASCRIPT_NEXT);
    options.setLanguageOut(CompilerOptions.LanguageMode.ECMASCRIPT_NEXT);
    Compiler compiler = new Compiler();
    compiler.init(List.of(), List.of(SourceFile.fromCode("probe.js", source)), options);
    compiler.parseForCompilation();
    check(compiler.getErrors().isEmpty(), "fixture parse: " + compiler.getErrors());
    Node root = compiler.getRoot().getLastChild();
    Trace trace = new Trace(action);
    NodeTraversal.Builder builder = NodeTraversal.builder().setCompiler(compiler)
        .setObeyDestructuringAndDefaultValueExecutionOrder(executionOrder);
    if (specialized && mode == Mode.LAMBDA) {
      builder.setCallback((NodeTraversal.AbstractPostOrderCallbackInterface) trace::visit);
    } else {
      builder.setCallback(callback(mode, trace, specialized));
    }
    checkFlags(builder.build(), specialized &&
        (mode == Mode.POST || mode == Mode.SCOPED || mode == Mode.LAMBDA),
        !(specialized && mode == Mode.PRE));

    RuntimeException caught = null;
    try {
      builder.traverse(root);
    } catch (RuntimeException failure) {
      if (!containsMarker(failure, trace.marker)) {
        throw failure;
      }
      caught = failure;
    }
    boolean throwing = action == Action.THROW_PRE || action == Action.THROW_POST;
    check((caught != null) == throwing, "callback exception propagation");
    if (action == Action.SKIP) {
      check(trace.skipped, "filter branch must run");
      check(trace.events.stream().noneMatch(s -> s.contains("NAME(hidden)")),
          "filtered child must not be visited");
    }
    if (action == Action.EMPTY_TO_BLOCK) {
      check(trace.changed != null && trace.enteredChangedScope == 1,
          "scope detection must observe EMPTY changed to BLOCK in shouldTraverse");
    }
    if (action == Action.BLOCK_TO_EMPTY) {
      check(trace.changed != null && trace.enteredChangedScope == 0,
          "scope detection must observe BLOCK changed to EMPTY in shouldTraverse");
    }
    if (action == Action.REMOVE) {
      check(trace.removed, "postorder removal must run");
    }
    trace.events.add("exception=" + (caught == null ? "none"
        : caught.getClass().getName() + ":" + caught.getMessage()));
    trace.events.add("output=" + compiler.toSource(root));
    return String.join("\n", trace.events);
  }

  private static NodeTraversal.Callback callback(Mode mode, Trace trace, boolean specialized) {
    if (specialized) {
      switch (mode) {
        case POST -> {
          // A further subclass still inherits the guaranteed final predicate.
          return new PostRecorder(trace) {};
        }
        case SCOPED -> {
          return new NodeTraversal.AbstractScopedCallback() {
            @Override public void visit(NodeTraversal t, Node n, Node p) { trace.visit(t, n, p); }
            @Override public void enterScope(NodeTraversal t) { trace.enter(t); }
            @Override public void exitScope(NodeTraversal t) { trace.exit(t); }
          };
        }
        case PRE -> { return new PreRecorder(trace); }
        case CFG -> {
          // Both methods are deliberately overridden: this base must remain unclassified.
          return new NodeTraversal.AbstractCfgCallback() {
            @Override public boolean shouldTraverse(NodeTraversal t, Node n, Node p) {
              return trace.should(t, n, p);
            }
            @Override public void visit(NodeTraversal t, Node n, Node p) { trace.visit(t, n, p); }
            @Override public void enterScopeWithCfg(NodeTraversal t) { trace.enter(t); }
            @Override public void exitScopeWithCfg(NodeTraversal t) { trace.exit(t); }
          };
        }
        case LAMBDA -> throw new AssertionError("lambda must use builder overload");
      }
    }
    if (mode == Mode.POST || mode == Mode.LAMBDA) {
      return new NodeTraversal.Callback() {
        @Override public boolean shouldTraverse(NodeTraversal t, Node n, Node p) { return true; }
        @Override public void visit(NodeTraversal t, Node n, Node p) { trace.visit(t, n, p); }
      };
    }
    return new NodeTraversal.ScopedCallback() {
      @Override public boolean shouldTraverse(NodeTraversal t, Node n, Node p) {
        return mode == Mode.SCOPED || trace.should(t, n, p);
      }
      @Override public void visit(NodeTraversal t, Node n, Node p) {
        if (mode != Mode.PRE) { trace.visit(t, n, p); }
      }
      @Override public void enterScope(NodeTraversal t) { trace.enter(t); }
      @Override public void exitScope(NodeTraversal t) { trace.exit(t); }
    };
  }

  private static class PostRecorder extends NodeTraversal.AbstractPostOrderCallback {
    private final Trace trace;
    PostRecorder(Trace trace) { this.trace = trace; }
    @Override public void visit(NodeTraversal t, Node n, Node p) { trace.visit(t, n, p); }
  }

  private static final class PreRecorder extends NodeTraversal.AbstractPreOrderCallback
      implements NodeTraversal.ScopedCallback {
    private final Trace trace;
    PreRecorder(Trace trace) { this.trace = trace; }
    @Override public boolean shouldTraverse(NodeTraversal t, Node n, Node p) {
      return trace.should(t, n, p);
    }
    @Override public void enterScope(NodeTraversal t) { trace.enter(t); }
    @Override public void exitScope(NodeTraversal t) { trace.exit(t); }
  }

  private static final class Trace {
    final Action action;
    final List<String> events = new ArrayList<>();
    final MarkerException marker = new MarkerException();
    Node changed;
    int enteredChangedScope;
    boolean skipped;
    boolean removed;

    Trace(Action action) { this.action = action; }

    boolean should(NodeTraversal t, Node n, Node parent) {
      event("pre", t, n, parent);
      if (action == Action.THROW_PRE && n.matchesName("explode")) { throw marker; }
      if (action == Action.SKIP && n.isCall() && n.getFirstChild().matchesName("skip")) {
        skipped = true;
        return false;
      }
      if (changed == null && action == Action.EMPTY_TO_BLOCK && n.isEmpty()) {
        changed = n;
        n.setToken(Token.BLOCK);
        events.add("changed=BLOCK");
      } else if (changed == null && action == Action.BLOCK_TO_EMPTY
          && n.isBlock() && !n.hasChildren() && parent.isScript()) {
        changed = n;
        n.setToken(Token.EMPTY);
        events.add("changed=EMPTY");
      }
      return true;
    }

    void visit(NodeTraversal t, Node n, Node parent) {
      event("post", t, n, parent);
      if (action == Action.THROW_POST && n.matchesName("explode")) { throw marker; }
      if (action == Action.REMOVE && n.isExprResult() && n.getFirstChild().isCall()
          && n.getFirstChild().getFirstChild().matchesName("drop")) {
        n.detach();
        removed = true;
        events.add("removed=drop");
      }
    }

    void enter(NodeTraversal t) {
      if (changed != null && t.getScopeRoot() == changed) { enteredChangedScope++; }
      events.add("enter:" + context(t));
    }

    void exit(NodeTraversal t) { events.add("exit:" + context(t)); }

    void event(String kind, NodeTraversal t, Node n, Node parent) {
      // Some special class-member handlers expose CLASS_MEMBERS as currentNode.
      // Record existing context rather than asserting currentNode always equals n.
      events.add(kind + ":" + key(n) + ":parent=" + key(parent) + ":" + context(t));
    }
  }

  private static String context(NodeTraversal t) {
    return "current=" + key(t.getCurrentNode()) + ":scope=" + key(t.getScopeRoot())
        + ":depth=" + t.getScopeDepth() + ":hoist=" + key(t.getClosestHoistScopeRoot());
  }

  private static String key(Node n) {
    return n == null ? "null" : n.getToken() + (n.isName() ? "(" + n.getString() + ")" : "")
        + "@" + n.getLineno() + ":" + n.getCharno();
  }

  private static void checkFlags(NodeTraversal traversal, boolean always, boolean visit)
      throws Exception {
    try {
      Field alwaysField = NodeTraversal.class.getDeclaredField("alwaysTraverse");
      Field visitField = NodeTraversal.class.getDeclaredField("needsVisit");
      alwaysField.setAccessible(true);
      visitField.setAccessible(true);
      check(alwaysField.getBoolean(traversal) == always, "alwaysTraverse classification");
      check(visitField.getBoolean(traversal) == visit, "needsVisit classification");
    } catch (NoSuchFieldException absent) {
      check(!requireFlags, "candidate fields are required");
    }
  }

  private static boolean containsMarker(Throwable failure, MarkerException marker) {
    for (Throwable current = failure; current != null; current = current.getCause()) {
      if (current == marker) { return true; }
    }
    return false;
  }

  private static final class MarkerException extends RuntimeException {
    MarkerException() { super("expected callback marker"); }
  }

  private static void check(boolean condition, String message) {
    if (!condition) { throw new AssertionError(message); }
  }
}
