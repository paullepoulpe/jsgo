Scope/map allocation source investigation — one candidate, not promoted

Status: source and probe only. No compiler, JVM, benchmark, network, or archive
command was run. Frozen transfer-v1 and pinned source inputs were not modified.

Scope maps are already small and lazy

AbstractScope.java:66–67 initializes vars and implicitVars to shared ImmutableMap
empty sentinels. First explicit declaration allocates a LinkedHashMap with expected
size 1 (:151–155); implicit variables lazily allocate an EnumMap (:190–196).
Scope and TypedScope inherit this behavior. There is no default-capacity 16 table
allocated eagerly for every scope. A capacity trial 1 -> 2 would trade one-variable
space for fewer resizes in larger scopes, but the observed data does not establish
scope-size distribution. No such tuning patch is proposed.

Map identity also matters: getVarIterable (:273) and getAllSymbols (:302) expose
views of the current map. Converting populated maps to immutable singletons, or
resetting to an empty sentinel on clear, changes retained-view behavior. The
existing implementation preserves map identity across clear and undeclaration.

TypedScope's two-argument constructor (:70) allocates an empty LinkedHashSet then
discards it when the four-argument constructor normalizes empty reservedNames.
ImmutableSet.of() would be a safe cleanup, but the production TypedScopeCreator
calls the four-argument constructor (:420); there is no demonstrated hot-path gain.
ReferenceCollection.references (:35) uses a default ArrayList. Smaller initial
capacity could save short-list space and cause extra growth elsewhere. The profile
contains both initial-growth and Arrays.copyOf stacks, and no size distribution;
the default-capacity hypothesis is unproven. No such tuning patch is proposed.

Grounded adjacent candidate: one modified-parameter accumulator

FunctionArgumentInjector.findModifiedParameters creates a new LinkedHashSet for
every visited AST node (:242–264), then addAll-merges each child's result. Move the
one result set to the package method and pass it into a void recursive helper.
accumulator.patch and src/.../FunctionArgumentInjector.java contain the change;
control-src holds the exact pinned original for a matched rebuilding control.

The old algorithm yields stableUnique(local qualifying name, then each child's
ordered result). One LinkedHashSet filled in the identical preorder traversal
produces the same first-occurrence order and retains the same String instances.
The primitive closure flag remains local to each recursive call. Parameter
extraction/validation stays before traversal; the predicates, child traversal,
and ImmutableSet.copyOf result are unchanged. The accumulator never escapes.
The package method signature stays unchanged; only the private helper changes.
No AST mutation, shared compiler cache, new early exit, or capacity assumption is
introduced. It removes intermediate sets, duplicate intermediate map entries,
and addAll iterators at the source level; retained result membership is identical.

Profile evidence is diagnostic, not a stable measurement

results/profile-stock-bigquery-v1/summary.tsv shows the recursive method at
575,328,616 estimated allocation-weight bytes (3.3043%); its package wrapper is
584,760,536 (3.3585%). Displayed stacks directly show LinkedHashSet construction
and LinkedHashMap iterators under recursive addAll. These are overlapping inclusive
weights, not additive costs or exact allocated bytes. Class-wide map percentages
cannot be attributed entirely to scopes.

The parent subsequently found that JFR_START triggered substantial JIT activity
in this v1 recording. Treat these rows only as disturbed diagnostic leads. The
parent is preparing an always-recording primed profile; candidate selection and
performance claims must wait for corrected profiling and independent measurement.

Deferred validation

Compile the source with the parent's established pinned-JAR import relocation and
JDK/options, using fresh candidate/control directories and -proc:none -implicit:none
with an empty sourcepath. Overlay the emitted top-level and nested classes; the
source contains two records and an inner visitor, so this is not a one-class-file
overlay. Preserve matched build inputs for control. Inspect resulting class paths.

Compile ModifiedParametersProbe once against stock, then run stock, rebuilt control,
and candidate. It compares explicit ordered expected results with a pinned original
recursive reference and checks repeated calls and unchanged ASTs. Cases cover empty
results, duplicates and order, sibling closure isolation, arrow functions, instance
and computed fields, static fields, assignments, var versus let/const declarations,
property mutations, loop/destructuring writes, rest-marker behavior, and matching
exceptions for unsupported default/object/array-pattern parameters. This probe is
uncompiled and unexecuted; fixture expectations must pass on stock first.

Then run existing FunctionArgumentInjector tests and byte-identical compiler
output/diagnostics checks on the parent's workloads. Only after semantic checks
and corrected profiling should stock/control/candidate timings be compared across
independent JVM cohorts. A source-level allocation reduction is not a speed claim.
