package com.google.javascript.jscomp;

import com.google.javascript.rhino.IR;
import com.google.javascript.rhino.Node;
import com.google.javascript.rhino.Token;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;

/** Exercises the pinned concrete scopes against the original declaration predicates. */
public final class ScopeDeclareOnceProbe {
  public static void main(String[] args) {
    require(args.length == 0, "unexpected arguments");
    for (boolean typed : new boolean[] {false, true}) {
      Fixture global = global(typed, "global");
      declare(global, "a", declaration("a"), false);
      Iterable<? extends AbstractVar<?, ?>> live = global.scope.getVarIterable();
      declare(global, "b", declaration("b"), false);
      declare(global, "c", declaration("c"), false);
      declare(global, "a", declaration("a"), false); // Untyped rejects; typed overwrites.
      declare(global, "a", declaration("a"), true); // Internal replacement is allowed in both.
      AbstractVar<?, ?> b = global.scope.getOwnSlot("b");
      global.undeclare(b);
      declare(global, "b", declaration("b"), false);
      require(names(live).equals(List.of("a", "c", "b")), "live declaration order changed");
      predicates(global, "a", "b", "missing", "arguments", "exports");
      declare(global, "", declaration(""), false);
      global.scope.clearVarsInternal();
      require(names(live).isEmpty(), "retained view did not observe clear");
      declare(global, "z", declaration("z"), false);
      require(names(live).equals(List.of("z")), "retained view did not observe reuse");

      Node function = function(global, "bleed", false);
      Fixture fn = child(global, "function", function, Set.of());
      Fixture body = child(fn, "body", function.getLastChild(), Set.of());
      Node parameter = function.getSecondChild().getFirstChild();
      Node lateParameter = parameter.getNext();
      declare(fn, "bleed", function.getFirstChild(), false);
      declare(fn, "p", parameter, false);
      declare(fn, "nameless", null, false);
      predicates(fn, "p", "bleed", "arguments", "this", "super", "exports");
      predicates(body, "p", "bleed", "arguments", "this", "super", "nameless", "fresh");
      declare(body, "p", declaration("p"), false);
      declare(body, "nameless", declaration("nameless"), false);
      declare(body, "arguments", declaration("arguments"), false);
      declare(body, "bleed", declaration("bleed"), false);
      declare(body, "fresh", declaration("fresh"), false);

      Node nestedNode = IR.block();
      function.getLastChild().addChildToBack(nestedNode);
      Fixture nested = child(body, "nested", nestedNode, Set.of());
      declare(nested, "p", declaration("p"), false);
      declare(nested, "arguments", declaration("arguments"), false);

      // An own entry bypasses the parent-shadow check even after the parent gains that name.
      declare(body, "late", declaration("late"), false);
      declare(fn, "late", lateParameter, false);
      declare(body, "late", declaration("late"), true);
      predicates(body, "late", "p", "bleed");
      declare(fn, "arguments", declaration("arguments"), false);
      declare(fn, "arguments", declaration("arguments"), true);

      Node arrow = function(global, "", true);
      Fixture arrowScope = child(global, "arrow", arrow, Set.of());
      Fixture arrowBody = child(arrowScope, "arrow-body", arrow.getLastChild(), Set.of());
      predicates(arrowScope, "arguments", "this", "super");
      declare(arrowBody, "arguments", declaration("arguments"), false);

      Node moduleBody = new Node(Token.MODULE_BODY);
      Node moduleScript = new Node(Token.SCRIPT, moduleBody);
      moduleScript.putBooleanProp(Node.GOOG_MODULE, true);
      Fixture moduleGlobal = new Fixture(typed, "module-global", rootScope(typed, IR.root(moduleScript)));
      Fixture module = child(moduleGlobal, "module", moduleBody, Set.of());
      require(module.scope.hasOwnSlot("exports") == !typed, "typed/untyped exports distinction");
      predicates(module, "exports", "arguments");
      declare(module, "exports", declaration("exports"), false);
      declare(module, "exports", declaration("exports"), true);
    }
    reservedFailure();
    System.out.println("ScopeDeclareOnceProbe OK");
  }

  private static void reservedFailure() {
    Fixture global = global(true, "reserved-global");
    Node function = function(global, "reserved", false);
    Fixture fn = child(global, "reserved-function", function, Set.of());
    declare(fn, "p", function.getSecondChild().getFirstChild(), false);
    Fixture body = child(fn, "reserved-body", function.getLastChild(), Set.of("p", "future"));
    TypedScope scope = (TypedScope) body.scope;
    require(scope.getTopmostScopeOfEventualDeclaration("p") == scope, "missing reservation");
    declare(body, "p", declaration("p"), false);
    // TypedScope removes a reservation before declareInternal rejects the shadow; preserve that.
    require(scope.getTopmostScopeOfEventualDeclaration("p") == fn.scope,
        "failed declaration changed reserved-name behavior");
    require(scope.getTopmostScopeOfEventualDeclaration("future") == scope, "unrelated reservation lost");
    declare(body, "future", declaration("future"), false);
    scope.validateCompletelyBuilt();
    System.out.println("reserved-failure=removed-p,retained-future,then-complete");
  }

  private static void predicates(Fixture fixture, String... names) {
    for (String name : names) {
      boolean expected = originalCanDeclare(fixture.scope, name);
      require(fixture.scope.canDeclare(name) == expected, fixture.label + ": canDeclare " + name);
      System.out.println(fixture.label + "/predicate/" + name + " own="
          + fixture.scope.hasOwnSlot(name) + " can=" + expected + " internal="
          + originalInternalPredicate(fixture.scope, name) + " slot="
          + describe(fixture.scope.getOwnSlot(name)));
    }
  }

  private static void declare(Fixture fixture, String name, Node nameNode, boolean internal) {
    List<AbstractVar<?, ?>> before = variables(fixture.scope);
    String expectedError = null;
    if (!internal && name.isEmpty()) {
      expectedError = fixture.typed ? IllegalStateException.class.getName()
          : IllegalArgumentException.class.getName();
    } else if (!internal && !fixture.typed && fixture.scope.getOwnSlot(name) != null) {
      expectedError = IllegalStateException.class.getName();
    } else if (!originalInternalPredicate(fixture.scope, name)) {
      expectedError = IllegalStateException.class.getName();
    }

    AbstractVar<?, ?> result = null;
    String actualError = null;
    try {
      result = fixture.declare(name, nameNode, internal);
    } catch (RuntimeException error) {
      actualError = error.getClass().getName();
    }
    require(java.util.Objects.equals(expectedError, actualError), fixture.label + "/" + name
        + ": expected " + expectedError + ", got " + actualError);
    List<AbstractVar<?, ?>> after = variables(fixture.scope);
    if (actualError != null) {
      require(sameVariables(before, after), fixture.label + ": failed declaration changed variables");
    } else {
      require(result != null && fixture.scope.getOwnSlot(name) == result, "returned slot mismatch");
      require(result.getIndex() == before.size(), fixture.label + ": declaration index changed");
      List<String> expectedOrder = names(before);
      if (!expectedOrder.contains(name)) {
        expectedOrder.add(name);
      }
      require(names(after).equals(expectedOrder), fixture.label + ": insertion order changed");
      require(after.size() == fixture.scope.getVarCount(), "variable count mismatch");
    }
    System.out.println(fixture.label + "/" + (internal ? "internal/" : "declare/") + name + "="
        + (actualError == null ? describe(result) : "throws:" + actualError) + " vars=" + describe(after));
  }

  // Exact original predicate order; this deliberately uses actual Scope/TypedScope lookup methods.
  private static boolean originalInternalPredicate(AbstractScope<?, ?> scope, String name) {
    return scope.hasOwnSlot(name) || originalCanDeclare(scope, name);
  }

  private static boolean originalCanDeclare(AbstractScope<?, ?> scope, String name) {
    return !scope.hasOwnSlot(name)
        && (!scope.isFunctionBlockScope()
            || !scope.getParent().hasOwnSlot(name)
            || originalBleedingName(scope, name));
  }

  private static boolean originalBleedingName(AbstractScope<?, ?> scope, String name) {
    AbstractVar<?, ?> var = scope.getVar(name);
    return var != null && var.getNode() != null && var.getNode().getParent().isFunction();
  }

  private static Fixture global(boolean typed, String label) {
    return new Fixture(typed, label, rootScope(typed, IR.root(IR.script())));
  }

  private static AbstractScope<?, ?> rootScope(boolean typed, Node root) {
    return typed ? TypedScope.createGlobalScope(root) : Scope.createGlobalScope(root);
  }

  private static Fixture child(Fixture parent, String label, Node root, Set<String> reserved) {
    return new Fixture(parent.typed, label, parent.typed
        ? new TypedScope((TypedScope) parent.scope, root, reserved, null)
        : Scope.createChildScope((Scope) parent.scope, root));
  }

  private static Node function(Fixture global, String name, boolean arrow) {
    Node function = IR.function(IR.name(name), IR.paramList(IR.name("p"), IR.name("late")), IR.block());
    function.setIsArrowFunction(arrow);
    global.scope.getRootNode().getFirstChild().addChildToBack(IR.exprResult(function));
    return function;
  }

  private static Node declaration(String name) {
    Node node = IR.name(name);
    IR.var(node); // Give NAME a declaration parent; bleeding names use the FUNCTION child instead.
    return node;
  }

  private static List<AbstractVar<?, ?>> variables(AbstractScope<?, ?> scope) {
    List<AbstractVar<?, ?>> result = new ArrayList<>();
    for (AbstractVar<?, ?> var : scope.getVarIterable()) {
      result.add(var);
    }
    return result;
  }

  private static List<String> names(Iterable<? extends AbstractVar<?, ?>> variables) {
    List<String> result = new ArrayList<>();
    for (AbstractVar<?, ?> var : variables) {
      result.add(var.getName());
    }
    return result;
  }

  private static boolean sameVariables(List<AbstractVar<?, ?>> left, List<AbstractVar<?, ?>> right) {
    if (left.size() != right.size()) {
      return false;
    }
    for (int i = 0; i < left.size(); i++) {
      if (left.get(i) != right.get(i)) {
        return false;
      }
    }
    return true;
  }

  private static String describe(List<AbstractVar<?, ?>> variables) {
    List<String> result = new ArrayList<>();
    for (AbstractVar<?, ?> var : variables) {
      result.add(describe(var));
    }
    return result.toString();
  }

  private static String describe(AbstractVar<?, ?> var) {
    if (var == null) {
      return "null";
    }
    Node node = var.getNode();
    return var.getName() + "@" + var.getIndex() + ":depth=" + var.getScope().getDepth()
        + ":node=" + (node == null ? "null" : node.getToken().name())
        + (var instanceof TypedVar typed ? ":inferred=" + typed.isTypeInferred() : "");
  }

  private static final class Fixture {
    final boolean typed;
    final String label;
    final AbstractScope<?, ?> scope;

    Fixture(boolean typed, String label, AbstractScope<?, ?> scope) {
      this.typed = typed;
      this.label = (typed ? "typed/" : "untyped/") + label;
      this.scope = scope;
    }

    AbstractVar<?, ?> declare(String name, Node node, boolean internal) {
      if (typed) {
        TypedScope actual = (TypedScope) scope;
        if (!internal) {
          return actual.declare(name, node, null, null, false);
        }
        TypedVar var = new TypedVar(true, name, node, null, actual, actual.getVarCount(), null);
        actual.declareInternal(name, var);
        return var;
      }
      Scope actual = (Scope) scope;
      if (!internal) {
        return actual.declare(name, node, null);
      }
      Var var = new Var(name, node, actual, actual.getVarCount(), null, null);
      actual.declareInternal(name, var);
      return var;
    }

    void undeclare(AbstractVar<?, ?> var) {
      if (typed) {
        ((TypedScope) scope).undeclare((TypedVar) var);
      } else {
        ((Scope) scope).undeclare((Var) var);
      }
    }
  }

  private static void require(boolean condition, String message) {
    if (!condition) {
      throw new AssertionError(message);
    }
  }
}
