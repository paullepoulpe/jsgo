Avoid the duplicate own-scope query when declaring a variable

Status: source-only candidate against Closure v20261015. Compilation, probes,
compiler-output/diagnostic byte checks, and timing remain pending. No JVM,
compiler, benchmark, or archive operation was run in preparing this candidate.
Existing candidate snapshots remain untouched.

Change
  AbstractScope.declareInternal currently checks
    hasOwnSlot(name) || canDeclare(name)
  and canDeclare starts with another !hasOwnSlot(name). For a name absent from
  the scope, declaring it therefore repeats the same map and implicit-name query.
  The candidate extracts the existing parent-shadow predicate into a private
  canShadowParentName helper. declareInternal and canDeclare each query the
  current scope exactly once before applying that shared predicate.

  This keeps canDeclare's existing meaning: an already-present name cannot be
  newly declared. declareInternal retains its different behavior: an existing
  own slot permits the internal replacement path. The helper preserves the
  function-block restriction, parent lookup, and bleeding-function-name exception
  in their original order. Map allocation, insertion order, variable indices,
  diagnostics, and every call to getVar/isBleedingFunctionName remain unchanged.
  No declaration validation is removed and no compiler pass is skipped.

Proof and extension boundary
  Let own be hasOwnSlot(name) and parentAllowed be the existing parent predicate.
  The old declareInternal condition is own || (!own && parentAllowed), equivalent
  to own || parentAllowed for the actual compiler's pure own-slot query. Its only
  removed operation is the repeated own query after the first returned false.

  AbstractScope.hasOwnSlot is final and reads its private map, then a protected
  hasOwnImplicitSlot predicate. Scope is final and uses the base predicate;
  TypedScope's override only excludes implicit exports before the same scope
  checks. Both implementations are read-only. These are the two concrete
  AbstractScope implementations in the pinned source; no TypedScope subclasses
  are present. AbstractScope's constructor and abstract makeImplicitVar method,
  and TypedScope's constructors, are package-private, so ordinary external
  subclass construction is not a supported extension route. A future same-package
  subclass with a stateful own-slot predicate would need a renewed purity review.
  The candidate adds no class guards or assumptions about arbitrary user callbacks.

  canDeclare still has the same own-query count and boolean expression. A true
  own result still skips parent work in declareInternal. A false own result still
  evaluates the same parent predicate, including any implicit-var lookup in the
  unchanged bleeding-name check. The error's var.getNode argument is evaluated
  once at the same point. Null/error behavior of the initial own query remains.

Profile grounding and limits
  Corrected profile-stock-bigquery-steady-v2 attributes 8.9149% inclusive CPU
  samples to SyntacticScopeCreator.createScope, 8.3746% to populate, and 2.9716%
  to declareVar. These overlapping totals do not measure this candidate's savings.
  AbstractScope.declareInternal has one reported leaf sample (0.0450%); inlining
  and downstream map/implicit-variable work prevent using that leaf as a total.
  The saved duplicate-query share has not been separately measured. This is a
  source-proven removal of redundant work, with no claimed percentage or speedup.

  Other investigated options were deferred: scopes are already created lazily
  within a traversal; MemoizedScopeCreator explicitly permits stale results after
  AST changes; scanVars already restricts recursion to statement containers and
  skips nested block scopes when hoisted declarations are irrelevant. A Node
  flag cache would require coordinating property mutations or adding a head-key
  reference, with unmeasured Node-subclass footprint/retention costs.

Artifacts
  src/.../AbstractScope.java: candidate.
  control-src/.../AbstractScope.java: exact pinned original.
  scope-declare-once.patch: normalized a/src and b/src patch.
  probe/.../ScopeDeclareOnceProbe.java: same-source semantic probe, no arguments.
  patch-check.json and frozen-source-manifest.json: source-only proofs and hashes.

Execution remains under root control. Run the probe unchanged against STOCK,
rebuilt CONTROL, and candidate; compare complete successful stdout. Semantic
probes do not substitute for compiler-output byte checks or independent timing.
