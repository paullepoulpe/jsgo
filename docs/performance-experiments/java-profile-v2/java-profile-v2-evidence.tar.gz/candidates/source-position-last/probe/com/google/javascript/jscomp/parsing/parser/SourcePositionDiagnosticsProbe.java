package com.google.javascript.jscomp.parsing.parser;

import com.google.javascript.jscomp.parsing.parser.trees.Comment;
import com.google.javascript.jscomp.parsing.parser.trees.ParseTree;
import com.google.javascript.jscomp.parsing.parser.trees.ProgramTree;
import com.google.javascript.jscomp.parsing.parser.util.ErrorReporter;
import com.google.javascript.jscomp.parsing.parser.util.SourcePosition;
import com.google.javascript.jscomp.parsing.parser.util.SourceRange;
import java.util.ArrayList;
import java.util.List;

/** Field-only scanner/parser transcript, suitable for exact comparison across variants. */
public final class SourcePositionDiagnosticsProbe {
  public static void main(String[] args) {
    require(args.length == 0, "unexpected arguments");
    String ls = Character.toString((char) 0x2028);
    String ps = Character.toString((char) 0x2029);
    String mixed = "let a=1;\r\nlet b=2;\rlet c=3;\nlet d=4;" + ls
        + "let e=5;" + ps + "let f=6;";
    String strings = "const a='first\\\r\nsecond';const b=\"x" + ls + "y\";";

    scanAndReplay("adjacent", "let x=1;x++;f(x);");
    scanAndReplay("spaced-comments", " /* lead */ let x = 1;\r\n// next\n x += 2; ");
    scanAndReplay("mixed-lines", mixed);
    scanAndReplay("multiline-strings", strings);
    scanTemplate();
    scanRegExp();

    parse("empty", "", false, false);
    parse("minified", "function f(x){return x+1}const y=f(2);", false, false);
    parse("spaced", "function f ( x ) {\n return x + 1;\n}\nconst y = f ( 2 );", false, false);
    parse("mixed-lines", mixed, false, false);
    parse("multiline-strings", strings, false, false);
    parse("templates", "const t=`head\r\n${1+2}mid" + ls + "${3}tail`;", false, false);
    parse("tagged-invalid-escape", "tag`\\xZ`;", false, false);
    parse("regexp", "const r=/a[bc]+/gi;", false, false);
    parse("comments", "/** doc */\nconst x=1; // last\n//# sourceMappingURL=x.map", false, false);
    parse("invalid-expression", "const x = ;", true, false);
    parse("unterminated-string", "let s='oops", true, false);
    parse("unterminated-template", "const t=`oops\r\n", true, false);
    parse("template-invalid-escape", "const t=`\\xZ`;", true, false);
    parse("string-invalid-escape", "const s='\\xZ';", true, false);
    parse("es3-trailing-comma", "var x={a:1,};",
        new Parser.Config(Parser.Config.Mode.ES3, false), false, true);
    System.out.println("SourcePositionDiagnosticsProbe OK");
  }

  private static void scanAndReplay(String label, String source) {
    System.out.println("scan " + label + " source=" + quote(source));
    Reporter reporter = new Reporter("scan/" + label);
    Scanner scanner = scanner(label, source, reporter);
    System.out.println("initial=" + position(scanner.getPosition()));
    System.out.println("initial-again=" + position(scanner.getPosition()));
    SourcePosition start = scanner.getPosition();
    System.out.println("lookahead2=" + token(scanner.peekToken(2)));
    System.out.println("lookahead-position=" + position(scanner.getPosition())
        + " offset=" + scanner.getOffset());
    System.out.println("consume0=" + token(scanner.nextToken()));
    System.out.println("consume1=" + token(scanner.nextToken()));
    scanner.setPosition(start);
    List<String> first = scanAll(label + "/first", scanner, source.length() + 2);
    // Use a separately constructed position as well as the scanner-returned bookmark.
    scanner.setPosition(new SourcePosition(start.source, start.offset, start.line, start.column));
    List<String> second = scanAll(label + "/replay", scanner, source.length() + 2);
    require(first.equals(second), label + ": token fields changed on replay");
    require(!reporter.hadError(), label + ": unexpected scanner error");
    System.out.println("final=" + position(scanner.getPosition()));
    System.out.println("eof-again=" + token(scanner.nextToken()));
  }

  private static List<String> scanAll(String label, Scanner scanner, int limit) {
    List<String> result = new ArrayList<>();
    for (int i = 0; i < limit; i++) {
      Token next = scanner.nextToken();
      String value = token(next);
      result.add(value);
      System.out.println(label + "/" + i + "=" + value);
      if (next.type == TokenType.END_OF_FILE) {
        return result;
      }
    }
    throw new AssertionError(label + ": token limit exceeded");
  }

  private static void scanTemplate() {
    String source = "`a\r\n${x}b${y}c`";
    Reporter reporter = new Reporter("scan/template");
    Scanner scanner = scanner("template", source, reporter);
    System.out.println("scan template source=" + quote(source));
    SourcePosition start = scanner.getPosition();
    List<String> first = templateTokens(scanner, "template/first");
    scanner.setPosition(start);
    require(first.equals(templateTokens(scanner, "template/replay")),
        "template token fields changed on replay");
    require(!reporter.hadError(), "unexpected template scanner error");
  }

  private static List<String> templateTokens(Scanner scanner, String label) {
    List<String> result = new ArrayList<>();
    addToken(result, label, scanner.nextToken(), TokenType.TEMPLATE_HEAD);
    addToken(result, label, scanner.nextToken(), TokenType.IDENTIFIER);
    require(scanner.peekToken().type == TokenType.CLOSE_CURLY, "missing first template close");
    addToken(result, label, scanner.nextTemplateLiteralToken(), TokenType.TEMPLATE_MIDDLE);
    addToken(result, label, scanner.nextToken(), TokenType.IDENTIFIER);
    require(scanner.peekToken().type == TokenType.CLOSE_CURLY, "missing second template close");
    addToken(result, label, scanner.nextTemplateLiteralToken(), TokenType.TEMPLATE_TAIL);
    addToken(result, label, scanner.nextToken(), TokenType.END_OF_FILE);
    return result;
  }

  private static void scanRegExp() {
    Reporter reporter = new Reporter("scan/regexp");
    Scanner scanner = scanner("regexp", "/a[bc]+/gi;", reporter);
    System.out.println("regexp/lookahead=" + token(scanner.peekToken()));
    System.out.println("regexp/literal=" + token(scanner.nextRegularExpressionLiteralToken()));
    System.out.println("regexp/semicolon=" + token(scanner.nextToken()));
    System.out.println("regexp/eof=" + token(scanner.nextToken()));
    require(!reporter.hadError(), "unexpected regexp scanner error");
  }

  private static void addToken(List<String> result, String label, Token value, TokenType expected) {
    require(value.type == expected, label + ": expected " + expected + ", got " + value.type);
    String description = token(value);
    System.out.println(label + "/" + result.size() + "=" + description);
    result.add(description);
  }

  private static Scanner scanner(String label, String source, Reporter reporter) {
    return new Scanner(reporter,
        (type, location, value) -> System.out.println("scan-comment " + label + " "
            + type.name() + " " + range(location) + " " + quote(value)),
        new SourceFile(label + ".js", source), 0);
  }

  private static void parse(String label, String source, boolean errors, boolean warnings) {
    parse(label, source, new Parser.Config(), errors, warnings);
  }

  private static void parse(
      String label, String source, Parser.Config config, boolean errors, boolean warnings) {
    System.out.println("parse " + label + " source=" + quote(source));
    Reporter reporter = new Reporter("parse/" + label);
    Parser parser = new Parser(config, reporter, new SourceFile(label + ".js", source));
    ProgramTree program = parser.parseProgram();
    require(program != null, label + ": missing program");
    System.out.println("program=" + range(program.location));
    // The scanner cases print every token; these parser cases print program/top-level ranges,
    // comments, and all diagnostics without reflecting over the full parse-tree implementation.
    for (int i = 0; i < program.sourceElements.size(); i++) {
      ParseTree element = program.sourceElements.get(i);
      System.out.println("element/" + i + "=" + element.type.name() + " " + range(element.location));
    }
    List<Comment> comments = parser.getComments();
    for (int i = 0; i < comments.size(); i++) {
      Comment comment = comments.get(i);
      System.out.println("comment/" + i + "=" + comment.type.name() + " "
          + range(comment.location) + " " + quote(comment.value));
    }
    System.out.println("diagnostic-counts=" + reporter.errors + "," + reporter.warnings
        + " hadError=" + reporter.hadError() + " sourceMap=" + quote(parser.getSourceMapURL()));
    require(reporter.hadError() == errors && (reporter.errors > 0) == errors,
        label + ": unexpected error presence");
    require((reporter.warnings > 0) == warnings, label + ": unexpected warning presence");
  }

  private static String token(Token token) {
    String result = token.type.name() + " " + range(token.location) + " " + quote(token.toString());
    if (token instanceof StringLiteralToken string) {
      result += " unicodeSeparator=" + string.hasUnescapedUnicodeLineOrParagraphSeparator();
    }
    if (token instanceof TemplateLiteralToken template) {
      result += " templateError=" + template.errorLevel + ":" + quote(template.errorMessage)
          + "@" + position(template.errorPosition);
    }
    return result;
  }

  private static String range(SourceRange range) {
    return range == null ? "null" : position(range.start) + ".." + position(range.end);
  }

  private static String position(SourcePosition position) {
    return position == null ? "null" : "(" + quote(position.source == null ? null : position.source.name)
        + "," + position.offset + "," + position.line + "," + position.column + ")";
  }

  private static String quote(String value) {
    if (value == null) {
      return "null";
    }
    StringBuilder result = new StringBuilder("\"");
    for (int i = 0; i < value.length(); i++) {
      char c = value.charAt(i);
      if (c == '\\' || c == '"') {
        result.append('\\').append(c);
      } else if (c < 32 || c > 126) {
        String hex = Integer.toHexString(c);
        result.append("\\u").append("0".repeat(4 - hex.length())).append(hex);
      } else {
        result.append(c);
      }
    }
    return result.append('"').toString();
  }

  private static final class Reporter extends ErrorReporter {
    private final String label;
    private int errors;
    private int warnings;

    Reporter(String label) {
      this.label = label;
    }

    @Override
    protected void reportError(SourcePosition location, String message) {
      errors++;
      System.out.println("diagnostic " + label + " error " + position(location) + " " + quote(message));
    }

    @Override
    protected void reportWarning(SourcePosition location, String message) {
      warnings++;
      System.out.println("diagnostic " + label + " warning " + position(location) + " " + quote(message));
    }
  }

  private static void require(boolean condition, String message) {
    if (!condition) {
      throw new AssertionError(message);
    }
  }
}
