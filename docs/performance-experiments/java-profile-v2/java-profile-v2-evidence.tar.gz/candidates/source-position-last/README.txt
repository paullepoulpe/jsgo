LineNumberScanner last-position reuse

Status: source-only candidate against Closure v20261015, pending compilation,
focused runtime probes, compiler-output/diagnostic byte checks, and timing.
No compiler, JVM, benchmark, or archive operation was run during preparation.
No runtime benefit is assumed. Existing frozen candidates remain unchanged.

Change
  Keep one nullable SourcePosition in each LineNumberScanner. After the existing
  precondition and entire advanceLine loop, reuse that position only when its
  offset, line, and column equal the fields the original would return. Otherwise
  construct the original plain SourcePosition and replace the entry. All other
  methods, including getSourceRange and rewindTo, remain unchanged.

  Consecutive adjacent token ranges can ask for the same endpoint twice. The
  entry covers the normal integer-offset range path, unlike a narrower change
  reusing an already-held string/template start. Repeated position queries and
  zero-width ranges can also reuse an entry. The cache has one-entry capacity
  and does not retain a file-wide table or skip any scan, parse, or compiler pass.

Value/state proof
  The checkArgument call and line-advancing loop run before any cache decision,
  so invalid backward queries, line transitions, and errors occur in the same
  order. The cache uses the post-loop lastLine and offset-lastLineStart values.
  The cached object's source is necessarily the same final SourceFile used by
  the scanner; SourceFile is final and immutable. Cached objects are always plain
  locally constructed SourcePosition instances, whose four data fields are final.
  No user override or supplied SourcePosition object is cached.

  rewindTo can accept positions with caller-chosen line/column fields. An
  offset-only hit check is therefore insufficient, even though ordinary parsed
  positions have canonical values. Two successful original behaviors illustrate
  why all three fields are checked:
    source "a\nb\nc": get(4) -> (4,2,0); rewind(0,100,0);
      get(4) -> (4,102,0).
    source "a\nbcdef": get(5) -> (5,1,3); rewind(1,1,-2);
      get(5) -> (5,1,2).
  A full tuple comparison preserves these results without clearing the cache
  on rewind. A failing rewind can leave partial scanner state; subsequent calls
  still run all original logic before testing the cache. The scanner was already
  mutable and unsynchronized; this candidate makes no concurrent-use guarantee.

Public identity boundary
  SourcePosition inherits Object.equals/hashCode. Repeated equal queries and
  adjacent ranges may now expose the same object through public Scanner, Token,
  parse-tree, source-range, or ErrorReporter APIs. In particular a zero-width
  range may have start == end. This intentionally changes observable identity
  and aliasing for third-party consumers that retain/compare those objects; it
  is not universal API-equivalence or a change to SourcePosition.equals.

  Source review found stock Parser, IRFactory, and ParserRunner.Es6ErrorReporter
  using position fields rather than identity/equality-keyed collections. The
  stock reporter reduces positions to source name, line, and column. The target
  requirement is unchanged compiler output, diagnostics, and source maps; those
  byte gates remain mandatory. Allocation/OOME behavior necessarily differs.

Profile grounding
  Corrected profile-stock-bigquery-steady-v2 reports SourcePosition as 60 sampled
  allocation events with 860672096 weighted bytes, 5.3498% of sampled allocation
  weight. All ten displayed allocation prefixes use getTokenRange(int), together
  accounting for about 5.1675% of total allocation weight. This candidate reaches
  that path, but the profile does not establish repeated-offset frequency or
  avoidable bytes. Added field reads/branches can outweigh allocation savings.
  No percentage of allocation reduction or runtime improvement is predicted.

Artifacts
  src/.../LineNumberScanner.java: candidate.
  control-src/.../LineNumberScanner.java: exact pinned original.
  source-position-last.patch: normalized repository-root diff.
  probe/.../LineNumberScannerProbe.java: exact value/state/original-algorithm probe.
  probe/.../SourcePositionDiagnosticsProbe.java: scanner/parser field transcripts.
  patch-check.json and frozen-source-manifest.json: source-only checks and hashes.

Probe execution, pending root control
  Run each same-source probe on STOCK, rebuilt CONTROL, and candidate; successful
  complete stdout must match. Main classes:
    com.google.javascript.jscomp.parsing.parser.LineNumberScannerProbe
    com.google.javascript.jscomp.parsing.parser.SourcePositionDiagnosticsProbe

  LineNumberScannerProbe can additionally receive --require-reuse on the
  candidate only. This asserts that an equal consecutive position is reused;
  the successful transcript remains identical. Use that option only for this
  probe, not the diagnostics probe. It checks empty input, LF/CR/CRLF/Unicode
  separators, adjacent/repeated/zero-width/reversed ranges, same-line backwards
  movement, earlier-line rejection, valid and forged rewinds, source mismatch,
  null rewinds, negative/out-of-range offsets, and unchanged private scalar state
  after successful and failing operations. Exception classes and non-NPE messages
  are compared with a copied original implementation; JVM-generated helpful NPE
  wording depends on class-file debug metadata and is excluded. A rewind also
  makes a cached offset invalid, checking that hits cannot bypass validation.
  Integer.MAX_VALUE is deliberately not
  queried because the original sentinel loop would not terminate there.

  Diagnostic/range transcripts exercise stock field consumers and errors; they
  make no assertion that object identity remains the same. The runtime and
  end-to-end gates are still outstanding when this source package is prepared.
