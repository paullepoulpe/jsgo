NodeTraversal no-op callbacks: source-only candidate

Status
  Prepared from pinned Closure v20261015 source. No Java process, compilation,
  benchmark, or build was run. The root task controls candidate selection and
  runtime execution. This source review makes no JIT or wall-time claim.

Files
  traversal-noop.patch: unshaded diff against the pinned source root.
  src/com/google/javascript/jscomp/NodeTraversal.java: candidate source.
  control-src/com/google/javascript/jscomp/NodeTraversal.java: exact pinned copy.
  probe/com/google/javascript/jscomp/TraversalNoopProbe.java: standalone probe
    intended to run unchanged against stock, rebuilt control, and candidate.

Exact patch boundary
  Add two final booleans, classified once after the callback's existing null
  check. alwaysTraverse is true only for AbstractPostOrderCallback and
  AbstractScopedCallback. needsVisit is false only for AbstractPreOrderCallback.
  In the ordinary traverseBranch path, guard its shouldTraverse and visit calls.
  The initial token switch and every special handler remain unchanged.

  Both currentNode=n assignments stay outside the guards. createsBlockScope(n)
  remains after shouldTraverse. This matters because custom/preorder callbacks
  may change a node token during shouldTraverse, and the original scope logic
  observes the changed token. Child iteration, saved-next handling, scope
  push/pop, and hoist-scope restoration are unchanged.

Source assessment
  AbstractPostOrderCallback.shouldTraverse (146) and
  AbstractScopedCallback.shouldTraverse (177) are final and return true with no
  other work. AbstractPreOrderCallback.visit (171) is final and empty. Further
  subclasses inherit those implementations. The callback field itself is final.
  No reflection-based inference about arbitrary callback implementations is used.

  Builder.setCallback(AbstractPostOrderCallbackInterface) (434) wraps its lambda
  in an AbstractPostOrderCallback subclass, so that adapter is covered.
  AbstractCfgCallback is deliberately excluded: both callback methods can be
  overridden. ExternsSkippingCallback, shallow callbacks, module callbacks, and
  ordinary custom implementations are also excluded.

  Meaningful callback exceptions and their ordering are retained: only final
  methods with no user body are bypassed. ScopedCallback enter/exit hooks are
  untouched, including when a preorder subclass also implements ScopedCallback.
  Special class-member handlers sometimes expose CLASS_MEMBERS as currentNode
  while passing a child to a callback; the probe records that existing behavior
  instead of asserting currentNode always equals the callback argument.

Probe design
  Each fixture runs once with an ordinary callback implementing equivalent
  behavior and once with the relevant base class or lambda adapter. Complete
  transcripts must match within each run. Successful output also contains the
  full transcript encoded as Base64 for byte comparison across stock/control/
  candidate jars. Transcripts include callback order, node/parent identity by
  stable syntax location, current node, scope root/depth, hoist scope, scope hooks,
  output JS, and exception type/message/context. No timings are printed.

  Cases cover ordinary syntax, function/default/destructuring paths in both
  execution-order modes, class/computed member/static-block paths, ES modules,
  an inherited postorder subclass, a scoped preorder subclass, the Builder's
  lambda adapter, overridden CFG methods, subtree pruning, removal in postorder,
  and exceptions from meaningful pre/post callbacks. The mutation fixtures turn
  an empty statement into an empty BLOCK and an empty BLOCK into EMPTY during
  shouldTraverse and check whether the resulting scope is entered.

  Where candidate fields exist, the probe checks classification via reflection,
  including false/true for the generic callbacks and overridden CFG callbacks.
  An optional --require-flags argument fails if candidate fields are absent; it
  otherwise leaves successful output identical. The normal no-argument mode is
  suitable for comparison across all three jars.

Follow-up execution (not performed here)
  Build isolated control/candidate overlays using the existing v2 workflow and
  published-jar dependency shading. Compile the same probe for each intended
  jar/classpath, run com.google.javascript.jscomp.TraversalNoopProbe, and compare
  complete stdout plus successful exit statuses. Candidate-only --require-flags
  checks the new classifications. Focused traces do not replace end-to-end
  byte/diagnostic validation or independent timing confirmation.
