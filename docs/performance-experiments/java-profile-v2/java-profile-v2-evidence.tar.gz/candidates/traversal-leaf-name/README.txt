NodeTraversal inline leaf NAME visit: source-only candidate

Status
  Prepared from untouched pinned Closure v20261015 source. No JVM, compiler,
  build, benchmark, or probe execution was performed by this agent. Root owns
  runtime selection and execution. Source review establishes no timing benefit.

Files
  traversal-leaf-name.patch: unshaded diff against the pinned source root.
  src/com/google/javascript/jscomp/NodeTraversal.java: candidate source.
  control-src/com/google/javascript/jscomp/NodeTraversal.java: exact pinned copy.
  probe/com/google/javascript/jscomp/TraversalLeafNameProbe.java: standalone
    same-source probe intended for stock, rebuilt control, and candidate jars.
  frozen-source-manifest.json: narrow file sizes and SHA256 hashes.

Exact change
  One final alwaysTraverse field, classified immediately after the callback's
  existing null check. It recognizes only AbstractPostOrderCallback and
  AbstractScopedCallback, whose shouldTraverse methods are final true with no
  other work. The Builder's postorder functional-interface adapter extends the
  first base. AbstractCfgCallback and arbitrary callbacks remain unclassified.

  Only the ordinary traverseBranch child loop changes. After saving child.next
  exactly as stock does, inline currentNode=child and callback.visit(this,child,n)
  when alwaysTraverse && child.isName() && !child.hasChildren(). All other nodes
  retain traverseBranch(child,n), then child=next remains unchanged. No wrapper,
  helper, extra recursive frame, token-switch guard, or other candidate is mixed
  in. Special handlers and the separate traverseChildren method remain stock.

Source proof
  For an eligible NAME child, stock's initial switch has no special handler.
  It sets currentNode to the child, invokes the final pure true predicate, computes
  createsBlockScope(NAME)==false, reads an unused hoist-root local, skips the empty
  child loop and false scope-pop branch, sets currentNode to the child again, then
  invokes the same visit with the same parent. The inline path has exactly the
  same meaningful callback and traversal state. Node.getToken/isName/hasChildren,
  getFirstChild and getNext are final direct field reads. There is no callback
  between the eligibility reads and visit that could mutate token or children.

  scopes, currentHoistScopeRoot, currentFunction, currentScript, change scope,
  input/source fields and scope callback ordering therefore remain equivalent.
  Lazy getScope/getAbstractScope sees the same scope stack and currentNode. A
  NAME does not push/pop a scope or perform cleanup after visit. A nested traversal
  started by the callback therefore does not lose any stock restoration step.

  Saving next before eligibility and visit retains existing detach, replacement,
  sibling insertion/removal, and later-sibling mutation behavior. In particular,
  a callback may detach the saved next node: stock still visits that detached
  object using the original parent argument and then follows its now-cleared
  next pointer. The candidate does the same. A child added to the current NAME
  during postorder remains unvisited; a NAME with an existing/new initializer
  before its turn goes through the full path and visits that initializer.

  Callback exceptions retain the same thrown cause, current node, source context,
  and meaningful callback order. Null-token children remain on the stock path.
  traverseScopeRoots wraps callbacks in a custom ScopedCallback, so its pruning
  behavior remains on the fallback path. Other traversal entrypoints and special
  dispatch sites are unchanged. Independent source review found no state defect.

Java stack caveat
  Eligible visits have one fewer traverseBranch frame. Raw Java stack traces,
  StackWalker/introspection and stack-overflow boundaries can observe this. The
  probe compares exception cause identity/type/message/source context, not raw
  stack frames. This candidate is not a claim of identical Java stack shape.

Probe design
  Each fixture runs once with an ordinary equivalent callback and once with its
  specialized base/lambda form. Complete event/exception/output transcripts must
  match within a run, and Base64 stdout retains those transcripts for cross-jar
  byte comparison. Normal invocation has no arguments; candidate-only optional
  --require-flag requires and checks alwaysTraverse through reflection without
  changing successful output. The probe no longer expects a needsVisit field.

  Existing syntax/module/default/destructuring/class/static-block fixtures,
  pruning, pre/post exceptions, token changes in shouldTraverse, and removal are
  retained. Added fixtures cover an AbstractPostOrderCallback subclass that also
  implements ScopedCallback; leaf NAME rename/replacement/removal/token changes;
  sibling insert/remove/replace; an initializer added during visit; an initializer
  added to the next sibling before its turn; meaningful PRE/CFG shouldTraverse
  adding an initializer; and existing declaration/default initializers.

  A lazy-scope fixture asserts no scope creation before the target NAME visit,
  logs each actual creator call with its currentNode and scope parent, and checks
  memoization/root consistency. Reentry starts a separate traversal from a leaf
  callback, reusing the same callback object (lambda adapters share the same trace)
  and verifies outer current node, scope/depth, hoist/function/source context and
  materialized Scope identity afterward. Transcripts also distinguish the callback
  parent argument from the node's actual parent after sibling detachment.

Performance limits and later execution
  Every ordinary child iteration gains an alwaysTraverse test. Eligible callbacks
  gain NAME/child checks; nonleaf NAMEs and other nodes still traverse normally.
  The eligible fraction and HotSpot code generation are unmeasured, and the extra
  checks/code size can outweigh avoided work. Aggregate traverseBranch samples do
  not establish the removable fraction. Root must run the probe and end-to-end
  byte/diagnostic checks before treating this as executable, then independently
  assess elapsed time and memory. Frozen files must not change after root builds.
