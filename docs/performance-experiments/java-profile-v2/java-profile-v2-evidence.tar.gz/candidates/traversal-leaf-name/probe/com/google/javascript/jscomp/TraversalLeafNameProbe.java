package com.google.javascript.jscomp;

import com.google.javascript.rhino.IR;
import com.google.javascript.rhino.Node;
import com.google.javascript.rhino.Token;
import java.lang.reflect.Field;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Base64;
import java.util.List;

/** Same-source callback transcript probe for stock, rebuilt control, and candidate. */
public final class TraversalLeafNameProbe {
  private enum Mode { POST, POST_SCOPED, SCOPED, PRE, CFG, LAMBDA }
  private enum Action {
    NONE, SKIP, EMPTY_TO_BLOCK, BLOCK_TO_EMPTY, REMOVE, THROW_PRE, THROW_POST,
    LEAF_RENAME, LEAF_REPLACE, LEAF_REMOVE, LEAF_INSERT, LEAF_REMOVE_NEXT,
    LEAF_REPLACE_NEXT, LEAF_ADD_CHILD, LEAF_MUTATE_NEXT, LEAF_CHANGE_TOKEN,
    LAZY_SCOPE, REENTER, PRE_ADD_CHILD
  }
  private static boolean requireFlag;

  private static final String SYNTAX =
      "let seed=0; const {p:alias=1}=source;"
      + "function f(arg=2){for(let i=0;i<2;i++){seed+=i;}return arg;}"
      + "class C extends Base {static field=seed;static {seed++;}"
      + "[key](x=3){return x;} method(){return seed;}}"
      + "try {f();} catch (e) {seed=e;}";
  private static final String MODULE =
      "export const value=1; export function f(x=2){return x+value;}";

  public static void main(String[] args) throws Exception {
    requireFlag = args.length == 1 && args[0].equals("--require-flag");
    check(args.length == 0 || requireFlag, "unexpected arguments");
    for (Mode mode : Mode.values()) {
      compare("syntax-" + mode, SYNTAX, mode, Action.NONE, false);
      compare("execution-order-" + mode, SYNTAX, mode, Action.NONE, true);
      compare("module-" + mode, MODULE, mode, Action.NONE, false);
    }
    for (Mode mode : List.of(Mode.PRE, Mode.CFG)) {
      compare("filter-" + mode, "keep();skip(hidden());last();", mode, Action.SKIP, false);
      compare("throw-pre-" + mode, "first();explode();last();", mode, Action.THROW_PRE, false);
    }
    compare("empty-to-block", ";keep();", Mode.PRE, Action.EMPTY_TO_BLOCK, false);
    compare("block-to-empty", "{}keep();", Mode.PRE, Action.BLOCK_TO_EMPTY, false);
    for (Mode mode : List.of(Mode.POST, Mode.SCOPED, Mode.LAMBDA)) {
      compare("remove-" + mode, "first();drop();last();", mode, Action.REMOVE, false);
    }
    for (Mode mode : List.of(Mode.POST, Mode.SCOPED, Mode.CFG, Mode.LAMBDA)) {
      compare("throw-post-" + mode, "first();explode();last();", mode, Action.THROW_POST, false);
    }
    for (Mode mode : List.of(Mode.POST, Mode.POST_SCOPED, Mode.SCOPED, Mode.LAMBDA, Mode.CFG)) {
      for (Action action : List.of(Action.LEAF_RENAME, Action.LEAF_REPLACE, Action.LEAF_REMOVE,
          Action.LEAF_INSERT, Action.LEAF_REMOVE_NEXT, Action.LEAF_REPLACE_NEXT,
          Action.LEAF_CHANGE_TOKEN)) {
        compare("leaf-" + action + "-" + mode,
            "invoke(target,pending,after);last();", mode, action, false);
      }
      compare("leaf-add-child-" + mode, "let target;last();", mode, Action.LEAF_ADD_CHILD, false);
      compare("leaf-mutate-next-" + mode, "let target,pending,after;last();",
          mode, Action.LEAF_MUTATE_NEXT, false);
      compare("lazy-scope-" + mode, "function outer(){ {invoke(target);} }",
          mode, Action.LAZY_SCOPE, false);
      compare("reenter-" + mode, "function outer(){let local=1;invoke(target,local);}",
          mode, Action.REENTER, false);
      compare("initializers-" + mode,
          "let first=init(),target=next(first),last;"
              + "function f(arg=seed){var local=target;return local;}",
          mode, Action.NONE, false);
    }
    for (Mode mode : List.of(Mode.PRE, Mode.CFG)) {
      compare("pre-add-child-" + mode, "let target;last();", mode, Action.PRE_ADD_CHILD, false);
    }
    System.out.println("TraversalLeafNameProbe OK");
  }

  private static void compare(String label, String source, Mode mode, Action action,
      boolean executionOrder) throws Exception {
    String generic = run(source, mode, action, executionOrder, false);
    String specialized = run(source, mode, action, executionOrder, true);
    check(generic.equals(specialized), label + ": generic/specialized transcript mismatch\n"
        + generic + "\n--- specialized ---\n" + specialized);
    // Complete event sequence, exception context, and output are retained for cross-jar comparison.
    System.out.println(label + "\t" + Base64.getEncoder().encodeToString(
        specialized.getBytes(StandardCharsets.UTF_8)));
  }

  private static String run(String source, Mode mode, Action action, boolean executionOrder,
      boolean specialized) throws Exception {
    CompilerOptions options = new CompilerOptions();
    options.setLanguageIn(CompilerOptions.LanguageMode.ECMASCRIPT_NEXT);
    options.setLanguageOut(CompilerOptions.LanguageMode.ECMASCRIPT_NEXT);
    Compiler compiler = new Compiler();
    compiler.init(List.of(), List.of(SourceFile.fromCode("probe.js", source)), options);
    compiler.parseForCompilation();
    check(compiler.getErrors().isEmpty(), "fixture parse: " + compiler.getErrors());
    Node root = compiler.getRoot().getLastChild();
    Trace trace = new Trace(action, compiler, mode, specialized, executionOrder);
    NodeTraversal.Builder builder = trace.builder();
    checkAlwaysTraverse(builder.build(), specialized &&
        (mode == Mode.POST || mode == Mode.POST_SCOPED || mode == Mode.SCOPED
            || mode == Mode.LAMBDA));

    RuntimeException caught = null;
    try {
      builder.traverse(root);
    } catch (RuntimeException failure) {
      if (!containsMarker(failure, trace.marker)) {
        throw failure;
      }
      caught = failure;
    }
    boolean throwing = action == Action.THROW_PRE || action == Action.THROW_POST;
    check((caught != null) == throwing, "callback exception propagation");
    if (action == Action.SKIP) {
      check(trace.skipped, "filter branch must run");
      check(trace.events.stream().noneMatch(s -> s.contains("NAME(hidden)")),
          "filtered child must not be visited");
    }
    if (action == Action.EMPTY_TO_BLOCK) {
      check(trace.changed != null && trace.enteredChangedScope == 1,
          "scope detection must observe EMPTY changed to BLOCK in shouldTraverse");
    }
    if (action == Action.BLOCK_TO_EMPTY) {
      check(trace.changed != null && trace.enteredChangedScope == 0,
          "scope detection must observe BLOCK changed to EMPTY in shouldTraverse");
    }
    if (action == Action.REMOVE) {
      check(trace.removed, "postorder removal must run");
    }
    if (action.name().startsWith("LEAF_") || action == Action.PRE_ADD_CHILD) {
      check(trace.mutated, "leaf mutation must run: " + action);
    }
    if (action == Action.LEAF_ADD_CHILD) {
      check(!trace.sawName("lateInit"), "child added during postorder must remain unvisited");
    }
    if (action == Action.LEAF_MUTATE_NEXT || action == Action.PRE_ADD_CHILD) {
      check(trace.sawName("lateInit"), "nonleaf NAME initializer must be traversed");
    }
    if (action == Action.LEAF_INSERT) {
      check(!trace.sawName("inserted"), "new sibling before saved-next must remain unvisited");
    }
    if (action == Action.LEAF_REPLACE) {
      check(!trace.sawName("replacementCallee") && !trace.sawName("replacementArg"),
          "replacement subtree must remain unvisited");
    }
    if (action == Action.LEAF_REMOVE_NEXT || action == Action.LEAF_REPLACE_NEXT) {
      check(trace.sawName("pending") && !trace.sawName("after"),
          "saved detached next node must retain stock continuation behavior");
    }
    if (action == Action.LAZY_SCOPE) { check(trace.lazyScopeChecked, "lazy scope fixture"); }
    if (action == Action.REENTER) { check(trace.reentered && trace.sawName("nestedLeaf"), "reentry fixture"); }
    trace.events.add("exception=" + (caught == null ? "none"
        : caught.getClass().getName() + ":" + caught.getMessage()));
    trace.events.add("output=" + compiler.toSource(root));
    return String.join("\n", trace.events);
  }

  private static NodeTraversal.Callback callback(Mode mode, Trace trace, boolean specialized) {
    if (specialized) {
      switch (mode) {
        case POST -> {
          // A further subclass still inherits the guaranteed final predicate.
          return new PostRecorder(trace) {};
        }
        case POST_SCOPED -> { return new ScopedPostRecorder(trace); }
        case SCOPED -> {
          return new NodeTraversal.AbstractScopedCallback() {
            @Override public void visit(NodeTraversal t, Node n, Node p) { trace.visit(t, n, p); }
            @Override public void enterScope(NodeTraversal t) { trace.enter(t); }
            @Override public void exitScope(NodeTraversal t) { trace.exit(t); }
          };
        }
        case PRE -> { return new PreRecorder(trace); }
        case CFG -> {
          // Both methods are deliberately overridden: this base must remain unclassified.
          return new NodeTraversal.AbstractCfgCallback() {
            @Override public boolean shouldTraverse(NodeTraversal t, Node n, Node p) {
              return trace.should(t, n, p);
            }
            @Override public void visit(NodeTraversal t, Node n, Node p) { trace.visit(t, n, p); }
            @Override public void enterScopeWithCfg(NodeTraversal t) { trace.enter(t); }
            @Override public void exitScopeWithCfg(NodeTraversal t) { trace.exit(t); }
          };
        }
        case LAMBDA -> throw new AssertionError("lambda must use builder overload");
      }
    }
    if (mode == Mode.POST || mode == Mode.LAMBDA) {
      return new NodeTraversal.Callback() {
        @Override public boolean shouldTraverse(NodeTraversal t, Node n, Node p) { return true; }
        @Override public void visit(NodeTraversal t, Node n, Node p) { trace.visit(t, n, p); }
      };
    }
    return new NodeTraversal.ScopedCallback() {
      @Override public boolean shouldTraverse(NodeTraversal t, Node n, Node p) {
        return mode == Mode.SCOPED || mode == Mode.POST_SCOPED || trace.should(t, n, p);
      }
      @Override public void visit(NodeTraversal t, Node n, Node p) {
        if (mode != Mode.PRE) { trace.visit(t, n, p); }
      }
      @Override public void enterScope(NodeTraversal t) { trace.enter(t); }
      @Override public void exitScope(NodeTraversal t) { trace.exit(t); }
    };
  }

  private static class PostRecorder extends NodeTraversal.AbstractPostOrderCallback {
    final Trace trace;
    PostRecorder(Trace trace) { this.trace = trace; }
    @Override public void visit(NodeTraversal t, Node n, Node p) { trace.visit(t, n, p); }
  }

  private static final class ScopedPostRecorder extends PostRecorder
      implements NodeTraversal.ScopedCallback {
    ScopedPostRecorder(Trace trace) { super(trace); }
    @Override public void enterScope(NodeTraversal t) { trace.enter(t); }
    @Override public void exitScope(NodeTraversal t) { trace.exit(t); }
  }

  private static final class PreRecorder extends NodeTraversal.AbstractPreOrderCallback
      implements NodeTraversal.ScopedCallback {
    private final Trace trace;
    PreRecorder(Trace trace) { this.trace = trace; }
    @Override public boolean shouldTraverse(NodeTraversal t, Node n, Node p) {
      return trace.should(t, n, p);
    }
    @Override public void enterScope(NodeTraversal t) { trace.enter(t); }
    @Override public void exitScope(NodeTraversal t) { trace.exit(t); }
  }

  private static final class Trace {
    final Action action;
    final List<String> events = new ArrayList<>();
    final MarkerException marker = new MarkerException();
    Node changed;
    int enteredChangedScope;
    boolean skipped;
    boolean removed;
    boolean mutated;
    boolean lazyScopeChecked;
    boolean reentered;
    final Compiler compiler;
    final Mode mode;
    final boolean specialized;
    final boolean executionOrder;
    final SyntacticScopeCreator scopeCreator;
    NodeTraversal.Callback traversalCallback;
    NodeTraversal materializingTraversal;
    int scopeCreations;

    Trace(Action action, Compiler compiler, Mode mode, boolean specialized, boolean executionOrder) {
      this.action = action;
      this.compiler = compiler;
      this.mode = mode;
      this.specialized = specialized;
      this.executionOrder = executionOrder;
      this.scopeCreator = new SyntacticScopeCreator(compiler);
    }

    NodeTraversal.Builder builder() {
      NodeTraversal.Builder result = NodeTraversal.builder().setCompiler(compiler)
          .setObeyDestructuringAndDefaultValueExecutionOrder(executionOrder)
          .setScopeCreator((scopeRoot, parentScope) -> {
            scopeCreations++;
            events.add("create-scope:" + key(scopeRoot) + ":parent="
                + key(parentScope == null ? null : parentScope.getRootNode())
                + ":current=" + key(materializingTraversal == null
                    ? null : materializingTraversal.getCurrentNode()));
            return scopeCreator.createScope(scopeRoot, parentScope);
          });
      if (specialized && mode == Mode.LAMBDA) {
        result.setCallback((NodeTraversal.AbstractPostOrderCallbackInterface) this::visit);
      } else {
        if (traversalCallback == null) { traversalCallback = callback(mode, this, specialized); }
        result.setCallback(traversalCallback);
      }
      return result;
    }

    boolean sawName(String name) {
      return events.stream().anyMatch(s -> s.startsWith("post:NAME(" + name + ")")
          || s.startsWith("pre:NAME(" + name + ")"));
    }

    boolean should(NodeTraversal t, Node n, Node parent) {
      event("pre", t, n, parent);
      if (action == Action.THROW_PRE && n.matchesName("explode")) { throw marker; }
      if (action == Action.SKIP && n.isCall() && n.getFirstChild().matchesName("skip")) {
        skipped = true;
        return false;
      }
      if (changed == null && action == Action.EMPTY_TO_BLOCK && n.isEmpty()) {
        changed = n;
        n.setToken(Token.BLOCK);
        events.add("changed=BLOCK");
      } else if (changed == null && action == Action.BLOCK_TO_EMPTY
          && n.isBlock() && !n.hasChildren() && parent.isScript()) {
        changed = n;
        n.setToken(Token.EMPTY);
        events.add("changed=EMPTY");
      }
      if (!mutated && action == Action.PRE_ADD_CHILD && n.matchesName("target")) {
        n.addChildToBack(IR.name("lateInit").srcref(n));
        mutated = true;
        events.add("pre-added-initializer");
      }
      return true;
    }

    void visit(NodeTraversal t, Node n, Node parent) {
      event("post", t, n, parent);
      if (action == Action.THROW_POST && n.matchesName("explode")) { throw marker; }
      if (n.matchesName("target")) {
        if (action == Action.LAZY_SCOPE || action == Action.REENTER) {
          if (action == Action.LAZY_SCOPE) {
            check(scopeCreations == 0, "scopes must remain lazy until target visit");
          }
          materializingTraversal = t;
          Scope scope = t.getScope();
          materializingTraversal = null;
          check(scopeCreations > 0, "target visit must materialize scopes");
          check(scope == t.getScope(), "scope must remain memoized within traversal");
          check(scope.getRootNode() == t.getScopeRoot(), "lazy scope root");
          check(t.getCurrentNode() == n, "leaf currentNode before lazy scope/reentry");
          events.add("lazy-scope:" + key(scope.getRootNode()) + ":vars=" + scope.getVarCount()
              + ":enclosing=" + key(t.getEnclosingFunction()) + ":source=" + t.getSourceName());
          lazyScopeChecked = true;
          if (action == Action.REENTER && !reentered) {
            reentered = true;
            String before = context(t);
            Node nestedRoot = IR.script(IR.exprResult(IR.name("nestedLeaf"))).srcrefTree(n);
            events.add("reenter-begin");
            builder().traverse(nestedRoot);
            events.add("reenter-end:" + context(t));
            check(before.equals(context(t)) && t.getScope() == scope,
                "nested traversal must preserve outer context and scope");
          }
        }
        if (!mutated && action.name().startsWith("LEAF_")) {
          check(!n.hasChildren(), "leaf mutation target must initially have no initializer");
          switch (action) {
            case LEAF_RENAME -> n.setString("renamed");
            case LEAF_REPLACE -> n.replaceWith(
                IR.call(IR.name("replacementCallee"), IR.name("replacementArg")).srcrefTree(n));
            case LEAF_REMOVE -> n.detach();
            case LEAF_INSERT -> IR.name("inserted").srcref(n).insertAfter(n);
            case LEAF_REMOVE_NEXT -> n.getNext().detach();
            case LEAF_REPLACE_NEXT -> n.getNext().replaceWith(IR.name("replacementNext").srcref(n));
            case LEAF_ADD_CHILD -> n.addChildToBack(IR.name("lateInit").srcref(n));
            case LEAF_MUTATE_NEXT -> n.getNext().addChildToBack(IR.name("lateInit").srcref(n));
            case LEAF_CHANGE_TOKEN -> n.setToken(Token.STRINGLIT);
            default -> throw new AssertionError("unexpected leaf action " + action);
          }
          mutated = true;
          events.add("mutated=" + action + ":current=" + key(t.getCurrentNode())
              + ":attached=" + key(n.getParent()));
        }
      }
      if (action == Action.REMOVE && n.isExprResult() && n.getFirstChild().isCall()
          && n.getFirstChild().getFirstChild().matchesName("drop")) {
        n.detach();
        removed = true;
        events.add("removed=drop");
      }
    }

    void enter(NodeTraversal t) {
      if (changed != null && t.getScopeRoot() == changed) { enteredChangedScope++; }
      events.add("enter:" + context(t));
    }

    void exit(NodeTraversal t) { events.add("exit:" + context(t)); }

    void event(String kind, NodeTraversal t, Node n, Node parent) {
      // Some special class-member handlers expose CLASS_MEMBERS as currentNode.
      // Record existing context rather than asserting currentNode always equals n.
      events.add(kind + ":" + key(n) + ":parent=" + key(parent)
          + ":attached=" + key(n.getParent()) + ":" + context(t));
    }
  }

  private static String context(NodeTraversal t) {
    return "current=" + key(t.getCurrentNode()) + ":scope=" + key(t.getScopeRoot())
        + ":depth=" + t.getScopeDepth() + ":hoist=" + key(t.getClosestHoistScopeRoot())
        + ":function=" + key(t.getEnclosingFunction()) + ":source=" + t.getSourceName();
  }

  private static String key(Node n) {
    return n == null ? "null" : n.getToken() + (n.isName() ? "(" + n.getString() + ")" : "")
        + "@" + n.getLineno() + ":" + n.getCharno();
  }

  private static void checkAlwaysTraverse(NodeTraversal traversal, boolean always)
      throws Exception {
    try {
      Field alwaysField = NodeTraversal.class.getDeclaredField("alwaysTraverse");
      alwaysField.setAccessible(true);
      check(alwaysField.getBoolean(traversal) == always, "alwaysTraverse classification");
    } catch (NoSuchFieldException absent) {
      check(!requireFlag, "candidate flag is required");
    }
  }

  private static boolean containsMarker(Throwable failure, MarkerException marker) {
    for (Throwable current = failure; current != null; current = current.getCause()) {
      if (current == marker) { return true; }
    }
    return false;
  }

  private static final class MarkerException extends RuntimeException {
    MarkerException() { super("expected callback marker"); }
  }

  private static void check(boolean condition, String message) {
    if (!condition) { throw new AssertionError(message); }
  }
}
