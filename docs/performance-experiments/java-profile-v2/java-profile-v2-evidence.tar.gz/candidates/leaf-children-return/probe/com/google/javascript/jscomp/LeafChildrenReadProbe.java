package com.google.javascript.jscomp;

import com.google.javascript.rhino.IR;
import com.google.javascript.rhino.Node;
import java.lang.reflect.Constructor;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Deque;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

/** Same-source private-graph semantic probe for stock, rebuilt control, and leaf guard. */
public final class LeafChildrenReadProbe {
  private static final Class<?> PROPERTY;
  private static final Constructor<?> NEW_PROPERTY;
  private static final Field CHILDREN;
  private static final Field WRITES;
  private static final Field IS_READ;
  private static final Method ADD_WRITE;
  private static final Method MARK_CHILDREN_READ;

  static {
    try {
      String outer = DeadPropertyAssignmentElimination.class.getName();
      PROPERTY = Class.forName(outer + "$Property");
      Class<?> write = Class.forName(outer + "$PropertyWrite");
      NEW_PROPERTY = PROPERTY.getDeclaredConstructor(String.class);
      CHILDREN = PROPERTY.getDeclaredField("children");
      WRITES = PROPERTY.getDeclaredField("writes");
      IS_READ = write.getDeclaredField("isRead");
      ADD_WRITE = PROPERTY.getDeclaredMethod("addWrite", Node.class);
      MARK_CHILDREN_READ = PROPERTY.getDeclaredMethod("markChildrenRead");
      NEW_PROPERTY.setAccessible(true);
      CHILDREN.setAccessible(true);
      WRITES.setAccessible(true);
      IS_READ.setAccessible(true);
      ADD_WRITE.setAccessible(true);
      MARK_CHILDREN_READ.setAccessible(true);
    } catch (ReflectiveOperationException error) {
      throw new ExceptionInInitializerError(error);
    }
  }

  public static void main(String[] args) throws Exception {
    check(args.length == 0, "unexpected arguments");
    Fixture empty = new Fixture().property("root", 0);
    empty.mark("empty-no-writes", "root");
    Fixture leaf = new Fixture().property("root", 2);
    leaf.mark("empty-two-writes", "root");
    IS_READ.setBoolean(leaf.writes("root").get(0), true);
    leaf.mark("empty-preserves-existing-read", "root");

    // No persistent empty-state caching: later edges must be processed.
    leaf.property("child", 2).edges("root", "child");
    leaf.mark("leaf-gains-child", "root", "child");
    leaf.addWrite("child");
    leaf.mark("child-gains-new-write", "root", "child");
    leaf.children("root").clear();
    leaf.mark("parent-becomes-leaf", "root");

    Fixture bridge = new Fixture().property("root", 2).property("bridge", 0).property("last", 2);
    bridge.edges("root", "bridge").edges("bridge", "last");
    bridge.mark("empty-write-bridge", "root", "last");

    Fixture diamond = new Fixture().property("root", 2).property("a", 2)
        .property("b", 2).property("shared", 2).property("unreachable", 2);
    diamond.edges("root", "a", "b").edges("a", "shared").edges("b", "shared");
    diamond.mark("diamond-a-b", "root", "a", "b", "shared");
    diamond.children("root").clear();
    diamond.edges("root", "b", "a", "b");
    diamond.mark("diamond-b-a", "root", "b", "a", "shared");

    Fixture cycle = new Fixture().property("root", 2).property("a", 2).property("b", 2);
    cycle.edges("root", "a").edges("a", "b").edges("b", "root", "a");
    cycle.mark("indirect-cycle", "root", "a", "b");
    cycle.mark("indirect-cycle-repeat", "root", "a", "b");

    // Stock seeds its queue before adding this to the seen set: direct self-edges mark this.
    Fixture self = new Fixture().property("root", 2);
    self.edges("root", "root");
    self.mark("direct-self-loop", "root", "root");
    Fixture childSelf = new Fixture().property("root", 2).property("child", 2);
    childSelf.edges("root", "child").edges("child", "child");
    childSelf.mark("child-self-loop", "root", "child");
    System.out.println("LeafChildrenReadProbe OK");
  }

  private static final class Fixture {
    private final Map<String, Object> properties = new LinkedHashMap<>();

    Fixture property(String name, int writes) throws Exception {
      check(!properties.containsKey(name), "duplicate property");
      properties.put(name, NEW_PROPERTY.newInstance(name));
      for (int i = 0; i < writes; i++) {
        addWrite(name);
      }
      return this;
    }

    void addWrite(String name) throws Exception {
      ADD_WRITE.invoke(properties.get(name), IR.getprop(IR.name("object"), name));
    }

    Fixture edges(String parent, String... children) throws Exception {
      for (String child : children) {
        check(properties.containsKey(child), "missing child");
        children(parent).add(properties.get(child));
      }
      return this;
    }

    @SuppressWarnings("unchecked")
    Set<Object> children(String name) throws Exception {
      return (Set<Object>) CHILDREN.get(properties.get(name));
    }

    @SuppressWarnings("unchecked")
    List<Object> writes(String name) throws Exception {
      return new ArrayList<>((Deque<Object>) WRITES.get(properties.get(name)));
    }

    void mark(String label, String root, String... markedNames) throws Exception {
      Set<String> marked = Set.of(markedNames);
      Map<String, List<Object>> childrenBefore = new LinkedHashMap<>();
      Map<String, List<Object>> writesBefore = new LinkedHashMap<>();
      Map<String, List<Boolean>> flagsBefore = new LinkedHashMap<>();
      for (String name : properties.keySet()) {
        childrenBefore.put(name, new ArrayList<>(children(name)));
        writesBefore.put(name, writes(name));
        List<Boolean> flags = new ArrayList<>();
        for (Object write : writesBefore.get(name)) {
          flags.add(IS_READ.getBoolean(write));
        }
        flagsBefore.put(name, flags);
      }
      MARK_CHILDREN_READ.invoke(properties.get(root));
      StringBuilder result = new StringBuilder(label);
      for (String name : properties.keySet()) {
        check(new ArrayList<>(children(name)).equals(childrenBefore.get(name)), "child order: " + label);
        List<Object> writes = writes(name);
        check(writes.equals(writesBefore.get(name)), "write order: " + label);
        result.append(' ').append(name).append('=');
        for (int i = 0; i < writes.size(); i++) {
          boolean expected = flagsBefore.get(name).get(i) || (marked.contains(name) && i == writes.size() - 1);
          boolean actual = IS_READ.getBoolean(writes.get(i));
          check(actual == expected, "last-write flags: " + label + "/" + name + "/" + i);
          result.append(actual ? '1' : '0');
        }
      }
      System.out.println(result);
    }
  }

  private static void check(boolean condition, String message) {
    if (!condition) {
      throw new AssertionError(message);
    }
  }
}
