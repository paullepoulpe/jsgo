Leaf property read guard — source/probe only, not promoted

Change: add `if (children.isEmpty()) { return; }` at the start of the private
Property.markChildrenRead method. This is three added lines. Empty children make
the existing queue empty, so the original method performs no graph/write mutation;
it only allocates a copied LinkedHashSet, an ArrayDeque, and adds this to the set.
The child set is a private final LinkedHashSet with no extension hooks. The guard
adds no state, changes no API, and preserves lazy behavior after later graph edits.
The entire nonempty traversal remains byte-for-byte unchanged in source.

Corrected profile attribution:
profile-v2/results/profile-stock-bigquery-steady-v2/targets.tsv, HashMap$Node[]
allocation stack rank 2, reports one sample carrying 67,070,688 estimated bytes,
10.2959% of the array group and 0.4169% of total sampled allocation weight. The
Property.markChildrenRead frame is line 170, bci 23: propertiesSet.add(this).
This supports inspecting the empty case, but one weighted sample does not quantify
its frequency, prove how much is removable, or establish an end-to-end gain.

Files: src/ is the candidate; control-src/ is the exact pinned original;
leaf-children-return.patch is the complete upstream diff. frozen-source-manifest.json
records local source/probe hashes without reading or hashing the full compiler jar.
No compilation, JVM, benchmark, or archive work was performed for this candidate.

Focused probe: LeafChildrenReadProbe uses reflection to construct the actual private
Property objects, invoke addWrite/markChildrenRead, and inspect actual write flags.
It uses the original collection instances and changes neither final fields nor
production methods. Cases cover no-write leaves, two-write leaves, preexisting read
flags, adding/removing child edges after a leaf call, new writes, empty-write bridges,
diamonds, reversed child insertion order, unreachable properties, indirect cycles,
direct self-loops, and child self-loops. Every call verifies child insertion order
and write deque order are preserved and only expected latest-write flags change.
The deterministic output can be compared byte-for-byte across all three artifacts.

Subtle existing behavior is preserved: A->B->A leaves A unread, but A->A marks A's
last write because the initial queue is seeded before this is added to the seen set.
The source comment 'don't process ourselves' does not override that implementation.
The probe checks final flags/collection order, not internal visit counts or precise
queue visitation order; idempotent private flag writes do not expose that order.

Deferred execution after an exclusive runtime slot is available:
build the isolated candidate and matched control with the parent's existing
build-candidate.py, then use run-probes.py with the resulting manifest,
--probe-source pointing to probe/.../LeafChildrenReadProbe.java,
--probe-class com.google.javascript.jscomp.LeafChildrenReadProbe, --compare-stdout,
and a fresh --out directory. Also set
--origin-class com.google.javascript.jscomp.DeadPropertyAssignmentElimination
--origin-class 'com.google.javascript.jscomp.DeadPropertyAssignmentElimination$Property'
to verify both the enclosing class and the changed nested class load as intended.
Run the stock probe first, then control/candidate, existing pass tests, and strict
compiler output/diagnostic byte gates before any performance conclusion.
