ReferenceCollection initial capacity two: measurement candidate only

Status
  SOURCE_ONLY_UNCOMPILED, NONE_PROMOTED. Prepared against untouched Closure
  v20261015. No JVM, compiler, benchmark, probe execution or archive access was
  performed here. Root owns deferred matched build, probes and timing selection.

Change and motivation
  One source line changes `new ArrayList<>()` to `new ArrayList<>(2)` for the
  package-visible references field. No other code, API or class field changes.
  Corrected BigQuery allocation-callers.stdout reports 41 Object[] samples,
  193,554,640 estimated bytes / 1.2031% of total weighted allocation, at the
  stock first-growth site: ArrayList.grow line 239 bci 52 -> grow -> add ->
  add -> ReferenceCollection.add. This identifies allocated storage, not a list
  length distribution or expected speedup. No completed bundle profile exists.

Source proof and construction ownership
  ReferenceCollection is final, despite its stale class comment about subclasses.
  Its field remains the same mutable List<Reference>, containing a fresh ordinary
  ArrayList. Only the initial spare capacity changes. The class does not expose a
  capacity query, and no compiler use of ArrayList.ensureCapacity or trimToSize
  was found in the pinned jscomp sources. No compiler assignment replaces this
  ReferenceCollection field. Existing indexed reads, append order, null/duplicate
  admission, reference identity, iteration and iterator removal remain unchanged.
  Constructor capacity allocation invokes no Reference or user callback.

  Both production construction sites use map.computeIfAbsent followed immediately
  by add: ReferenceCollector.java:326-329 and
  CrossChunkReferenceCollector.java:311-314. Thus a successful ordinary collection
  creation supplies at least one reference. This does not prove lists end at two,
  nor exclude direct public construction of an empty collection or later clearing.
  No declaration-plus-one-use frequency is assumed.

  ReferenceCollection and Reference are Serializable. No declared field/method/
  constructor signature changes, and this edit adds no class initializer. The
  intended logical serialization is identical; the focused probe compares exact
  serialized-byte digests and serialVersionUID across stock/control/candidate for
  empty and null-only lists at several lengths. Node itself is not Serializable,
  so ordinary Reference objects with nodes retain the existing serialization
  failure; the probe checks that failure too. Runtime verification is pending.

Allocation and growth tradeoff
  Stock starts with a shared empty backing array, then normally first grows to
  ten slots. Candidate eagerly allocates two slots when the collection is created.
  Empty collections therefore cost an extra array; short populated lists can
  retain fewer spare slots. Lists exceeding two references grow earlier and can
  incur additional arrays/copies. Their eventual capacity sequence also differs.
  The source edit trades these costs; it does not eliminate all allocation at the
  observed stock growth site, and allocating at construction moves attribution.
  End-to-end allocated bytes, CPU, wall time and memory must decide whether this
  is useful. Source/profile evidence justifies a measurement candidate only.

  Resource-exhaustion timing and capacity introspection by reflection are outside
  logical compiler equivalence. Same-package code can access and downcast the
  field; capacity-changing operations such as ensureCapacity may then cause
  different fail-fast iterator behavior. No such compiler caller was found, and
  no universal equivalence for arbitrary reflective/same-package programs is
  claimed. ArrayList remains unsynchronized; no concurrent-mutation guarantee is
  added or inferred.

Probe
  probe/com/google/javascript/jscomp/ReferenceListTwoProbe.java uses the actual
  collection constructor/add/iterator and the existing Reference test factory.
  It checks empty query results and existing empty-list exceptions; append sizes
  0,1,2,3,10,11,64 crossing both initial capacities; exact element identity/order;
  duplicate and null preservation; iterator removal and fail-fast after append;
  clear/reuse; null-only serialization bytes and roundtrip content; and the
  existing serialization failure for references containing nonserializable nodes.
  It contains no copied implementation or capacity reflection. Its synthetic
  references are used for list operations, not nonempty scope/dataflow queries.

  Build the single ReferenceCollection source family and run the same probe on
  STOCK/CONTROL/candidate with --compare-stdout and
  --origin-class com.google.javascript.jscomp.ReferenceCollection. The normal
  compiler-output, diagnostic and source-map byte gates remain separate. Focused
  probes do not replace the full upstream Java test suite.

Artifacts
  control-src/.../ReferenceCollection.java: exact pinned original.
  src/.../ReferenceCollection.java: isolated one-line candidate.
  reference-list-two.patch: a/src and b/src patch against a Closure checkout.
  frozen-source-manifest.json: narrow source/probe/document hashes and exact
    forward/reverse source application proof. Freeze after root builds.
