package com.google.javascript.jscomp;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.NotSerializableException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.ObjectStreamClass;
import java.security.MessageDigest;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.ConcurrentModificationException;
import java.util.HexFormat;
import java.util.Iterator;
import java.util.List;
import java.util.NoSuchElementException;

/** Same-source operations probe for STOCK, rebuilt CONTROL, and capacity-two candidate. */
public final class ReferenceListTwoProbe {
  private static final CompilerInput INPUT =
      new CompilerInput(SourceFile.fromCode("reference-list-probe.js", ""));

  public static void main(String[] args) throws Exception {
    require(args.length == 0, "unexpected arguments");
    emptyQueries();
    for (int size : new int[] {0, 1, 2, 3, 10, 11, 64}) {
      appendAndSerialize(size);
    }
    mutationAndDuplicates();
    System.out.println("ReferenceListTwoProbe OK serialUID="
        + ObjectStreamClass.lookup(ReferenceCollection.class).getSerialVersionUID());
  }

  private static void emptyQueries() {
    ReferenceCollection refs = new ReferenceCollection();
    require(refs.references instanceof ArrayList, "backing implementation changed");
    require(refs.references != new ReferenceCollection().references, "shared list object");
    require(!refs.isWellDefined(), "empty well-defined");
    require(!refs.isEscaped(), "empty escaped");
    require(!refs.isThisRebound(), "empty this rebound");
    require(!refs.isAssignedOnceInLifetime(), "empty assignment count");
    require(!refs.isReferencedWeakly(), "empty weak usage");
    require(refs.getInitializingReferenceForConstants() == null, "empty constant init");
    require(refs.getOneAndOnlyAssignment() == null, "empty single assignment");
    require(refs.isNeverAssigned(), "empty never-assigned");
    require(!refs.firstReferenceIsAssigningDeclaration(), "empty assigning declaration");
    expect(IndexOutOfBoundsException.class, () -> refs.getInitializingReference());
    Iterator<Reference> iterator = refs.iterator();
    require(!iterator.hasNext(), "empty iterator");
    expect(NoSuchElementException.class, () -> iterator.next());
    System.out.println("empty-queries OK");
  }

  private static void appendAndSerialize(int size) throws Exception {
    ReferenceCollection refs = new ReferenceCollection();
    List<Reference> expected = new ArrayList<>();
    for (int i = 0; i < size; i++) {
      Reference ref = Reference.createRefForTest(INPUT);
      refs.add(ref);
      expected.add(ref);
      ordered(refs, expected);
    }
    ordered(refs, expected);

    // Reference declares Serializable, but its Node field is not Serializable.
    // Preserve that existing failure for real references, without assuming a new capability.
    if (size > 0) {
      expectNodeNotSerializable(refs);
    }

    // Empty/null-only collections can serialize. These exercise backing-list serialization
    // at the relevant lengths without introducing unsupported serializable AST fixtures.
    ReferenceCollection nullable = new ReferenceCollection();
    for (int i = 0; i < size; i++) {
      nullable.add(null);
    }
    byte[] bytes = serialize(nullable);
    require(Arrays.equals(bytes, serialize(nullable)), "serialization not repeatable");
    ReferenceCollection restored = deserialize(bytes);
    require(restored != nullable && restored.references != nullable.references, "roundtrip alias");
    require(restored.references.size() == size, "roundtrip size");
    for (int i = 0; i < size; i++) {
      require(restored.references.get(i) == null, "roundtrip null entry");
    }
    restored.add(Reference.createRefForTest(INPUT));
    require(restored.references.size() == size + 1 && nullable.references.size() == size,
        "roundtrip append affected original");
    System.out.println("size=" + size + " nullSerializedBytes=" + bytes.length + " sha256="
        + HexFormat.of().formatHex(MessageDigest.getInstance("SHA-256").digest(bytes)));
  }

  private static void mutationAndDuplicates() throws Exception {
    ReferenceCollection refs = new ReferenceCollection();
    Reference a = Reference.createRefForTest(INPUT);
    Reference b = Reference.createRefForTest(INPUT);
    refs.add(a);
    refs.add(b);
    refs.add(a);
    refs.add(null);
    ordered(refs, Arrays.asList(a, b, a, null));
    expectNodeNotSerializable(refs);
    ordered(refs, Arrays.asList(a, b, a, null));

    Iterator<Reference> iterator = refs.iterator();
    require(iterator.next() == a, "iterator first");
    iterator.remove();
    require(iterator.next() == b, "iterator after removal");
    ordered(refs, Arrays.asList(b, a, null));
    Iterator<Reference> stale = refs.iterator();
    refs.add(b);
    expect(ConcurrentModificationException.class, () -> stale.next());
    ordered(refs, Arrays.asList(b, a, null, b));
    refs.references.clear();
    refs.add(a);
    ordered(refs, List.of(a));
    System.out.println("duplicates-null-iterator-remove-failfast-clear-reuse OK");
  }

  private static void ordered(ReferenceCollection refs, List<Reference> expected) {
    require(refs.references.size() == expected.size(), "size");
    Iterator<Reference> iterator = refs.iterator();
    for (int i = 0; i < expected.size(); i++) {
      require(iterator.hasNext(), "short iterator");
      require(iterator.next() == expected.get(i), "iteration identity/order");
      require(refs.references.get(i) == expected.get(i), "indexed identity/order");
    }
    require(!iterator.hasNext(), "long iterator");
  }

  private static byte[] serialize(ReferenceCollection refs) throws Exception {
    ByteArrayOutputStream bytes = new ByteArrayOutputStream();
    try (ObjectOutputStream output = new ObjectOutputStream(bytes)) {
      output.writeObject(refs);
    }
    return bytes.toByteArray();
  }

  private static ReferenceCollection deserialize(byte[] bytes) throws Exception {
    try (ObjectInputStream input = new ObjectInputStream(new ByteArrayInputStream(bytes))) {
      return (ReferenceCollection) input.readObject();
    }
  }

  private static void expectNodeNotSerializable(ReferenceCollection refs) throws Exception {
    try {
      serialize(refs);
      throw new AssertionError("expected existing nonserializable Node failure");
    } catch (NotSerializableException expected) {
      require("com.google.javascript.rhino.Node".equals(expected.getMessage()),
          "unexpected serialization failure target");
    }
  }

  private static void expect(Class<? extends RuntimeException> type, Runnable action) {
    try {
      action.run();
      throw new AssertionError("expected " + type.getSimpleName());
    } catch (RuntimeException actual) {
      require(type.isInstance(actual), "wrong exception type: " + actual.getClass());
    }
  }

  private static void require(boolean ok, String message) {
    if (!ok) {
      throw new AssertionError(message);
    }
  }
}
