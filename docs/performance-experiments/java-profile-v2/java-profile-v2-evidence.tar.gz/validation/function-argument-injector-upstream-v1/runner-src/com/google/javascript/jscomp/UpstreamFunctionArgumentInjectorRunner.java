package com.google.javascript.jscomp;

import java.nio.file.Files;
import java.nio.file.Path;
import java.security.MessageDigest;
import java.util.HexFormat;
import java.util.Set;
import java.util.TreeSet;
import org.junit.Test;
import org.junit.runner.Description;
import org.junit.runner.JUnitCore;
import org.junit.runner.Result;
import org.junit.runner.notification.Failure;
import org.junit.runner.notification.RunListener;

/** Runs the actual upstream JUnit class, with case inventory and compiler-origin checks. */
public final class UpstreamFunctionArgumentInjectorRunner {
  public static void main(String[] args) throws Exception {
    require(args.length == 3, "expected compiler origin, case-list path, target class hash or '-'");
    Path expectedOrigin = Path.of(args[0]).toRealPath();
    Class<?> target = FunctionArgumentInjector.class;
    Path actualOrigin = Path.of(target.getProtectionDomain().getCodeSource().getLocation().toURI())
        .toRealPath();
    require(actualOrigin.equals(expectedOrigin), "wrong FunctionArgumentInjector origin");
    String resource = "/" + target.getName().replace('.', '/') + ".class";
    String classHash;
    try (var input = target.getResourceAsStream(resource)) {
      require(input != null, "missing target class resource");
      classHash = HexFormat.of().formatHex(MessageDigest.getInstance("SHA-256")
          .digest(input.readAllBytes()));
    }
    require(args[2].equals("-") || args[2].equals(classHash), "wrong target class bytes");
    System.out.println("ORIGIN " + actualOrigin);
    System.out.println("TARGET_SHA256 " + classHash);
    System.out.println("TRUTH_ORIGIN " + com.google.common.truth.Truth.class
        .getProtectionDomain().getCodeSource().getLocation());
    System.out.println("TEST_GUAVA_ORIGIN " + com.google.common.collect.ImmutableMap.class
        .getProtectionDomain().getCodeSource().getLocation());
    System.out.println("COMPILER_GUAVA_ORIGIN "
        + com.google.javascript.jscomp.jarjar.com.google.common.collect.ImmutableMap.class
            .getProtectionDomain().getCodeSource().getLocation());

    Set<String> expected = new TreeSet<>(Files.readAllLines(Path.of(args[1])));
    require(!expected.isEmpty() && !expected.contains(""), "empty expected case inventory");
    Set<String> declared = new TreeSet<>();
    for (var method : FunctionArgumentInjectorTest.class.getDeclaredMethods()) {
      if (method.isAnnotationPresent(Test.class)) {
        require(method.getParameterCount() == 0, "test method takes parameters");
        require(declared.add(method.getName()), "duplicate annotated method");
      }
    }
    require(expected.equals(declared), "annotated tests differ from pinned source inventory");

    Set<String> started = new TreeSet<>();
    Set<String> finished = new TreeSet<>();
    int[] assumptions = {0};
    JUnitCore junit = new JUnitCore();
    junit.addListener(new RunListener() {
      @Override public void testStarted(Description test) {
        require(started.add(test.getMethodName()), "test started twice");
      }
      @Override public void testFinished(Description test) {
        require(finished.add(test.getMethodName()), "test finished twice");
      }
      @Override public void testAssumptionFailure(Failure failure) {
        assumptions[0]++;
        System.err.println(failure.getTrace());
      }
      @Override public void testFailure(Failure failure) {
        System.err.println(failure.getDescription());
        System.err.println(failure.getTrace());
      }
    });
    Result result = junit.run(FunctionArgumentInjectorTest.class);
    System.out.println("JUNIT run=" + result.getRunCount() + " failed=" + result.getFailureCount()
        + " ignored=" + result.getIgnoreCount() + " assumptions=" + assumptions[0]);
    require(expected.equals(started) && expected.equals(finished), "not every test completed");
    require(result.wasSuccessful() && result.getRunCount() == expected.size()
        && result.getIgnoreCount() == 0 && assumptions[0] == 0, "upstream JUnit suite did not pass");
    for (String method : finished) {
      System.out.println("PASS " + method);
    }
    System.out.println("UpstreamFunctionArgumentInjectorRunner OK");
  }

  private static void require(boolean ok, String message) {
    if (!ok) {
      throw new AssertionError(message);
    }
  }
}
