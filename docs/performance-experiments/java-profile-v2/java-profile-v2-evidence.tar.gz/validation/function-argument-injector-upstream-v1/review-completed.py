#!/usr/bin/env python3
"""Review already completed JUnit receipts and sources; no Java or archive reads."""
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import re

HERE = Path(__file__).resolve().parent
OUT = HERE/'results-attempt-1'
INPUTS = {}


def require(condition, message):
    if not condition:
        raise ValueError(message)


def sha(value):
    return hashlib.sha256(value).hexdigest()


def read(path):
    path = Path(path)
    require(path.suffix not in ('.jar', '.zip', '.jfr'), 'No archive reads')
    value = path.read_bytes()
    require(len(value) < 1_000_000, 'Small source/receipt/class only')
    require(INPUTS.setdefault(str(path), sha(value)) == sha(value), 'Changed input')
    return value


def obj(path):
    return json.loads(read(path))


def main():
    target = HERE/'completed-review.json'
    require(not target.exists(), 'Preserve prior review')
    prepared = obj(HERE/'prepared-manifest.json')
    result = obj(OUT/'result.json')
    build = obj(OUT/'build-manifest.json')
    require(result['status'] == 'PASS_ALL_UPSTREAM_CASES_STOCK_CONTROL_CANDIDATE', 'Result success')
    require(result['prepared_manifest_sha256'] == sha(read(HERE/'prepared-manifest.json')), 'Frozen prep identity')
    require(result['build_manifest_sha256'] == sha(read(OUT/'build-manifest.json')), 'Build identity')
    require(read(OUT/'build-manifest.json') == read(HERE.parent.parent/'build/accumulator/manifest.json'), 'Current/captured build match')
    for relative, entry in prepared['files'].items():
        if relative.endswith('.jar'):
            continue
        value = read(HERE/relative)
        require(sha(value) == entry['sha256'] and len(value) == entry['bytes'], 'Frozen input '+relative)
    upstream = read(HERE/'fetched/FunctionArgumentInjectorTest.java')
    require(upstream == read(HERE/'fetched/FunctionArgumentInjectorTest.commit.java'), 'Tag/commit exact test')
    require(sha(upstream) == prepared['upstream_test_sha256'], 'Pinned test digest')
    expected_effective = upstream
    imports = ['com.google.common.base.Preconditions', 'com.google.common.base.Supplier', 'com.google.common.collect.ImmutableMap', 'com.google.common.collect.ImmutableSet']
    for qualified in imports:
        require(expected_effective.count(qualified.encode()) == 1, 'One import occurrence '+qualified)
        expected_effective = expected_effective.replace(qualified.encode(), ('com.google.javascript.jscomp.jarjar.'+qualified).encode())
    require(expected_effective == read(HERE/'effective-src/com/google/javascript/jscomp/FunctionArgumentInjectorTest.java'), 'Exactly four import substitutions')
    helper_paths = ['com/google/javascript/jscomp/testing/ColorSubject.java', 'com/google/javascript/rhino/testing/NodeSubject.java', 'com/google/javascript/rhino/testing/TextDiffFactsBuilder.java', 'com/google/javascript/rhino/testing/TypeSubject.java']
    for relative in helper_paths:
        require(read(HERE/'effective-src'/relative) == read(HERE/'fetched'/Path(relative).name), 'Unchanged helper '+relative)
    require(read(HERE/'fetched/NodeSubject.java') == read(HERE/'fetched/NodeSubject.commit.java'), 'NodeSubject tag/commit')
    require(read(HERE/'fetched/FunctionArgumentInjector.java') == read(Path('/workspace/jsgo/.cache/closure-src/com/google/javascript/jscomp/FunctionArgumentInjector.java')), 'Production pinned source')
    methods = sorted(re.findall(r'@Test\s+public void ([A-Za-z_$][A-Za-z0-9_$]*)\s*\(', upstream.decode()))
    expected = read(HERE/'expected-tests.txt').decode().splitlines()
    require(len(methods) == len(set(methods)) == 91 and methods == expected and 'nullishCoalesce' in expected, 'Exact 91 test methods')
    require(upstream.count(b'@Before') == 1 and b'@Ignore' not in upstream, 'Setup/no ignore')
    tag_ref, tag_obj = obj(HERE/'fetched/tag-ref.json'), obj(HERE/'fetched/tag-object.json')
    require(tag_ref['object']['sha'] == tag_obj['sha'] and tag_obj['object']['sha'] == prepared['upstream_commit'], 'Tag commit chain')
    commands = obj(OUT/'commands.json')
    frozen_java = sorted(str(HERE/p) for p in prepared['files'] if p.endswith('.java') and p.startswith(('effective-src/', 'runner-src/')))
    require(sorted(arg for arg in commands['compile'] if arg.endswith('.java')) == frozen_java and len(frozen_java) == 6, 'Exact compiled source set')
    require(result['compile']['exit'] == 0 and not read(OUT/'compile.stdout'), 'Compile success')
    require(b'error:' not in read(OUT/'compile.stderr'), 'No compiler errors')
    require(set(result['runs']) == set(commands['runs']) == {'STOCK','CONTROL','accumulator'}, 'Three variants')
    identities = {}
    family = 'com/google/javascript/jscomp/FunctionArgumentInjector.class'
    for variant in ['STOCK', 'CONTROL', 'accumulator']:
        run = result['runs'][variant]
        stdout, stderr = read(OUT/(variant+'.stdout')), read(OUT/(variant+'.stderr'))
        lines = stdout.decode().splitlines()
        actual_cases = [line[5:] for line in lines if line.startswith('PASS ')]
        require(run['exit'] == 0 and run['passed_cases'] == actual_cases == expected, 'All exact cases '+variant)
        require(sha(stdout) == run['stdout_sha256'] and sha(stderr) == run['stderr_sha256'] and not stderr, 'Log hashes '+variant)
        require(lines.count('JUNIT run=91 failed=0 ignored=0 assumptions=0') == 1 and lines[-1] == 'UpstreamFunctionArgumentInjectorRunner OK', 'JUnit counters '+variant)
        actual_origin = next(line[7:] for line in lines if line.startswith('ORIGIN '))
        actual_digest = next(line[14:] for line in lines if line.startswith('TARGET_SHA256 '))
        if variant == 'STOCK':
            require(actual_origin == '/workspace/jsgo/.cache/closure-compiler-v20261015-maven.jar', 'Stock origin')
        else:
            entry = build['variants'][variant]
            require(actual_origin == entry['overlay'] and actual_digest == entry['classes'][family], 'Overlay origin/digest '+variant)
            overlay = Path(entry['overlay'])
            classes = {str(p.relative_to(overlay)):sha(read(p)) for p in overlay.rglob('*.class')}
            require(classes == entry['classes'] == result['overlay_classes_verified_before'][variant] == result['overlay_classes_verified_after'][variant], 'Full nested overlay '+variant)
        for prefix, expected_path in [('TRUTH_ORIGIN ', HERE/'dependencies/truth-1.4.4.jar'), ('TEST_GUAVA_ORIGIN ', HERE/'dependencies/guava-33.4.8-jre.jar'), ('COMPILER_GUAVA_ORIGIN ', Path('/workspace/jsgo/.cache/closure-compiler-v20261015-maven.jar'))]:
            require(prefix+'file:'+str(expected_path) in lines, 'Library class boundary '+variant)
        identities[variant] = {'cases':len(actual_cases), 'failures':0, 'ignored':0, 'assumptions':0, 'origin':actual_origin, 'target_sha256':actual_digest, 'stdout_sha256':sha(stdout)}
    for path, expected_hash in list(INPUTS.items()):
        require(sha(read(path)) == expected_hash, 'Input changed during review')
    review = {'status':'PASS_INDEPENDENT_SOURCE_AND_COMPLETED_RECEIPT_REVIEW', 'reviewed_at_utc':datetime.now(timezone.utc).isoformat(),
        'scope':'Complete pinned FunctionArgumentInjectorTest class only; full upstream Java suite not run.',
        'new_runtime_started':False, 'upstream_commit':prepared['upstream_commit'], 'test_count':91,
        'exact_upstream_test_body_retained':True, 'mechanical_import_substitutions':4, 'unchanged_upstream_helpers':4,
        'compiled_source_count':6, 'all_case_names_exact':True, 'variants':identities,
        'result_sha256':sha(read(OUT/'result.json')), 'prepared_manifest_sha256':result['prepared_manifest_sha256'],
        'build_manifest_sha256':result['build_manifest_sha256'], 'compiler_diagnostic':'NodeSubject deprecation note only; no errors.',
        'stock_jar_current_bytes_revalidated':False, 'dependency_jar_bytes_rehashed_by_this_review':False,
        'limits':['Stock class origin/digest observed; whole current stock jar not rehashed.', 'Dependency jars rely on frozen download hashes and runner preflight verification; no archive inspected.', 'JUnit success is semantic test evidence, not a speed or allocation claim.'], 'inputs_sha256':INPUTS}
    target.write_text(json.dumps(review,indent=2)+'\n')
    print('PASS: 91 exact upstream cases on each of STOCK, CONTROL, accumulator; source and receipt identities verified. No Java started.')


if __name__ == '__main__':
    main()
