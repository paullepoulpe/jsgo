"""Deferred actual JUnit4 validation. No Java runs without explicit --execute.

Use only in a runtime slot granted by the parent. Produces a fresh results tree;
never modifies candidate/build sources or downloads dependencies.
"""
from pathlib import Path
import argparse
import hashlib
import json
import os
import subprocess
import time

ROOT = Path(__file__).resolve().parent
JAVA = Path('/usr/lib/jvm/java-21-openjdk-amd64/bin/java')
JAR = Path('/workspace/jsgo/.cache/closure-compiler-v20261015-maven.jar')
MAIN = 'com.google.javascript.jscomp.UpstreamFunctionArgumentInjectorRunner'
TARGET = 'com/google/javascript/jscomp/FunctionArgumentInjector.class'


def read(path):
    return json.loads(Path(path).read_text())


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def save(path, value):
    path.write_text(json.dumps(value, indent=2) + '\n')


def require(condition, message):
    if not condition:
        raise ValueError(message)


def verify_overlay(variant):
    root = Path(variant['overlay'])
    actual = {str(p.relative_to(root)): sha(p) for p in root.rglob('*.class')}
    require(actual == variant['classes'], 'overlay class inventory or bytes differ: ' + str(root))
    return actual


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--manifest', required=True, type=Path)
    parser.add_argument('--candidate', default='accumulator')
    parser.add_argument('--out', required=True, type=Path)
    parser.add_argument('--execute', action='store_true')
    args = parser.parse_args()
    require(args.candidate not in ('STOCK', 'CONTROL'), 'candidate must be distinct from STOCK/CONTROL')
    manifest = read(args.manifest)
    prepared = read(ROOT / 'prepared-manifest.json')
    require(manifest['status'] == 'PASS_BUILD_VALIDATION', 'build manifest has not passed')
    require(manifest['jar_sha256'] == prepared['stock_jar_sha256_recorded'], 'wrong stock jar receipt')
    require(manifest['compiler_source_families'] == ['com/google/javascript/jscomp/FunctionArgumentInjector'],
            'wrong compiler source family')
    require(not args.out.exists(), 'result directory already exists')
    require(bool(manifest['variants'][args.candidate]['overlay']), 'candidate overlay required')
    for relative, record in prepared['files'].items():
        require(sha(ROOT / relative) == record['sha256'], 'prepared input differs: ' + relative)
    deps = [str(ROOT / a['path']) for a in prepared['dependency_artifacts']]
    source_names = sorted(p for p in prepared['files']
                          if p.endswith('.java') and p.startswith(('effective-src/', 'runner-src/')))
    actual_sources = {str(p.relative_to(ROOT)) for folder in ('effective-src', 'runner-src')
                      for p in (ROOT / folder).rglob('*.java')}
    require(set(source_names) == actual_sources, 'extra or missing prepared Java sources')
    sources = [ROOT / p for p in source_names]
    classes = args.out.resolve() / 'classes'
    empty_sourcepath = args.out.resolve() / 'empty-sourcepath'
    compile_argv = [str(JAVA), '-Xmx1g', '-m', 'jdk.compiler/com.sun.tools.javac.Main',
                    *manifest['javac_flags'], '-cp', os.pathsep.join([str(JAR), *deps]),
                    '-sourcepath', str(empty_sourcepath), '-d', str(classes), *map(str, sources)]
    commands = {'compile': compile_argv, 'runs': {}}
    for name in ['STOCK', 'CONTROL', args.candidate]:
        variant = manifest['variants'][name]
        overlay = variant['overlay']
        cp = ([overlay] if overlay else []) + [str(classes), str(JAR), *deps]
        origin = overlay or str(JAR)
        digest = variant['classes'][TARGET] if overlay else '-'
        commands['runs'][name] = [str(JAVA), '-Xmx1g', '-cp', os.pathsep.join(cp), MAIN,
                                  origin, str(ROOT / 'expected-tests.txt'), digest]
    require(len(commands['runs']) == 3, 'three distinct variants required')
    if not args.execute:
        print(json.dumps({'status': 'PLAN_ONLY_NO_JAVA', 'commands': commands}, indent=2))
        return

    overlay_inventory = {name: verify_overlay(manifest['variants'][name])
                         for name in ('CONTROL', args.candidate)}
    args.out.mkdir(parents=True)
    classes.mkdir()
    empty_sourcepath.mkdir()
    save(args.out / 'commands.json', commands)
    original_manifest_hash = sha(args.manifest)
    save(args.out / 'build-manifest.json', manifest)
    env = {k: v for k, v in os.environ.items()
           if k not in ('JAVA_TOOL_OPTIONS', '_JAVA_OPTIONS', 'JDK_JAVA_OPTIONS')}
    report = {'status': 'RUNNING', 'build_manifest_sha256': original_manifest_hash,
              'prepared_manifest_sha256': sha(ROOT / 'prepared-manifest.json'), 'runs': {},
              'overlay_classes_verified_before': overlay_inventory,
              'stock_jar_current_bytes_revalidated': False}
    try:
        started = time.time()
        with (args.out / 'compile.stdout').open('wb') as stdout, (args.out / 'compile.stderr').open('wb') as stderr:
            result = subprocess.run(compile_argv, stdout=stdout, stderr=stderr, env=env, timeout=180)
        report['compile'] = {'exit': result.returncode, 'elapsed_seconds': time.time() - started}
        require(result.returncode == 0, 'compile failed; inspect retained stderr')
        require(not (classes / TARGET).exists(), 'test output shadows compiler implementation')
        for name, argv in commands['runs'].items():
            started = time.time()
            with (args.out / (name + '.stdout')).open('wb') as stdout, (args.out / (name + '.stderr')).open('wb') as stderr:
                result = subprocess.run(argv, stdout=stdout, stderr=stderr, env=env, timeout=180)
            output = (args.out / (name + '.stdout')).read_text()
            cases = [line.removeprefix('PASS ') for line in output.splitlines() if line.startswith('PASS ')]
            expected = (ROOT / 'expected-tests.txt').read_text().splitlines()
            report['runs'][name] = {'exit': result.returncode, 'elapsed_seconds': time.time() - started,
                                    'passed_cases': cases, 'stdout_sha256': sha(args.out / (name + '.stdout')),
                                    'stderr_sha256': sha(args.out / (name + '.stderr'))}
            require(result.returncode == 0 and cases == expected, name + ' upstream cases failed')
        require(sha(args.manifest) == original_manifest_hash, 'build manifest changed')
        for relative, record in prepared['files'].items():
            require(sha(ROOT / relative) == record['sha256'], 'prepared input changed: ' + relative)
        require(len(report['runs']) == 3, 'not all three variants ran')
        report['overlay_classes_verified_after'] = {
            name: verify_overlay(manifest['variants'][name]) for name in ('CONTROL', args.candidate)}
        report['status'] = 'PASS_ALL_UPSTREAM_CASES_STOCK_CONTROL_CANDIDATE'
    except BaseException as error:
        report['status'] = 'FAIL'
        report['error'] = repr(error)
        raise
    finally:
        save(args.out / 'result.json', report)
    print(json.dumps({'status': report['status'], 'out': str(args.out)}, indent=2))


if __name__ == '__main__':
    main()
