Pinned FunctionArgumentInjector upstream JUnit4 validation preparation

Status: PREPARED_NOT_COMPILED_OR_RUN. No Java, javac, Bazel, Maven build or benchmark
was started. This directory is self-contained preparation for a later exclusive
runtime slot. Prior source-audit notes about unavailable tests describe the state
before the parent explicitly authorized these small source/dependency downloads.

Exact sources
  Closure tag v20261015 resolves through annotated tag object
  8598e07a0eb8a7295d58c42d9ccc6661bd33ffea to commit
  3aeb67d9ac328013d2ee6bf9552f13fd1a7de529. Retained GitHub API records show that
  chain. The test and NodeSubject fetched by tag exactly match their commit-pinned
  copies. FunctionArgumentInjector.java fetched at that commit exactly matches
  the local pinned Maven source bytes (SHA256 c34dabc4283dc8dd17f45d6ca51a12c98edb14bc8f88a3fd31452f8b4c56d5c4).

  FunctionArgumentInjectorTest.java is the actual standalone upstream JUnit4
  class, with 91 @Test methods and one @Before setup. It does not extend
  CompilerTestCase. The complete supporting source closure is NodeSubject,
  TypeSubject, ColorSubject and TextDiffFactsBuilder. All four helper sources
  retain their complete original bodies and notices. No fixtures or assertions
  were translated, weakened, removed or rewritten.

Shaded compiler boundary
  The published compiler jar uses shaded Guava. Exactly four imports in the test
  source are mechanically redirected to com.google.javascript.jscomp.jarjar:
  Preconditions, Supplier, ImmutableMap and ImmutableSet. The explicit immutable
  collection and Supplier types then agree with compiler method signatures.
  compiler-guava-imports.patch records the entire change.

  Truth remains com.google.common.truth. The helper sources remain byte-identical
  and use ordinary test-library Guava. Compiler collections reach Truth through
  Java Iterable/Map/Object interfaces; helper-created collections remain ordinary
  Guava. No fake Truth/JUnit classes or alternate NodeSubject implementation are
  used. Compilation is still pending, so source review is not claimed as binary
  compatibility validation.

Dependencies
  Twelve jars total 3,981,849 bytes. fetched/dependency-receipt.json records each
  Maven URL, coordinate, size, SHA256 and fetch time. Original POMs and Closure's
  MODULE.bazel plus its pinned google/bazel-common MODULE.bazel are retained.
  JUnit 4.13.2, Truth 1.4.4, Hamcrest 1.3 and Guava 33.4.8-jre follow the pinned
  bazel-common module. Failureaccess 1.0.3, the empty listenablefuture compatibility
  jar, JSpecify 1.0.0, Error Prone annotations 2.36.0 and J2ObjC annotations 3.0.0
  follow Guava's published POM/parent. AutoValue annotations 1.11.0 and ASM 9.7
  follow Truth's POM/parent. java-diff-utils 4.12 follows Closure's own module.
  These explicit test-library versions are a standalone classpath, not a claim to
  have reproduced Bazel's entire dependency resolver or its whole test environment.
  Dependencies were downloaded as opaque jar files; no archive inspection ran.

Deferred commands
  run.py without --execute verifies the preparation hashes and prints the exact
  compile/run plan without starting Java or creating the requested results tree:

    python3 run.py --manifest ../../build/accumulator/manifest.json \
      --candidate accumulator --out ./results-attempt-1

  The parent may add --execute only after its exclusive runtime slot is available.
  The script builds only six Java sources (test, four helpers, runner) once against
  STOCK, then runs those same test classes on STOCK, CONTROL and accumulator in
  sequence. It uses the existing manifest's Java 21 compile flags and a fresh
  empty sourcepath; no compiler implementation is copied into test output. All
  commands, compile diagnostics, per-variant stdout/stderr and results are retained
  in the newly created output directory. Failure stops further runs and preserves
  result.json. There is no benchmark or performance interpretation in this runner.
  The exact frozen Java source set is enforced; extra sources are rejected. Full
  CONTROL/candidate overlay class inventories and hashes, including nested classes,
  are checked before and after execution. Python verification uses explicit raises
  and remains enabled under Python -O; reserved candidate names are rejected.

  The Java wrapper invokes the actual JUnitCore/JUnit4 class runner, retaining
  upstream @Before behavior. It reconciles runtime @Test discovery and completed
  names with expected-tests.txt generated directly from pinned source, requires
  91 completed tests, zero failures/ignored/assumption failures, and prints every
  passing name. This includes nullishCoalesce; discovery is not name-prefix based.
  JUnit failure traces are retained. It verifies FunctionArgumentInjector's actual
  origin and CONTROL/candidate class digest against their build manifest, prints
  the observed STOCK digest, and reports Truth/test-Guava/compiler-Guava origins.

Limits
  Runtime preflight/exclusivity remains the parent's responsibility. This script
  does not start containers or establish its own cgroup caps. Its 1GiB Java heap
  is for short unit validation, not a compiler performance measurement. It does
  not rehash the large stock jar; it consumes the previously validated build
  manifest's pinned jar identity and verifies class origins. Download hashes are
  recorded provenance, not an independent artifact signature verification.

  Successful execution will validate this complete upstream test class against
  each variant. It will not mean the full upstream Java suite passed. Existing
  compiler-output, diagnostic and source-map byte gates remain separate. Prepared
  source hashes and exact-command plans must not be mistaken for completed tests.
