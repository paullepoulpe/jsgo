"""Launch the prospective v4 confirmation after root selects a candidate.

Source prepared separately from execution. This starts five direct-STOCK cohorts
with twenty fixed measured pairs. BigQuery is the default; bundle is explicit.
"""
from pathlib import Path
import argparse
import hashlib
import json
import os
import sys

ROOT = Path(__file__).resolve().parent
RUNNER = ROOT / 'bench/run-v4.py'
RUNNER_SHA256 = '9adb1c481ea19998d45a7e75a87e7670c1d5efafb381f2138c4d8f64bc18730d'
PROTOCOL = {'version': 'confirmation-v4', 'baseline': 'STOCK', 'cohorts': 5, 'pairs': 20,
            'min_warmup': 60, 'max_warmup': 150, 'warm_window': 8, 'max_median_drift': .03,
            'max_JIT_fraction': .01, 'max_spread': 1.15,
            'measured_JIT_annotations': [.01, .02], 'measured_JIT_block_size': 5}
JAR = '/workspace/jsgo/.cache/closure-compiler-v20261015-maven.jar'
JDK = '/usr/lib/jvm/java-21-openjdk-amd64'
IMAGE = 'python@sha256:70729b46c69b4f1e97c4822c1af3df53a1476cf5ddc6c087c0c10bc3a5678c2f'
TASKS = {
    'bigquery': ('/workspace/jsgo-results/round4/bigquery-stock-oracle-v1/spec.json',
                 '/workspace/jsgo-results/round4/bigquery-stock-oracle-v1'),
    'bundle': ('/workspace/jsgo-results/round4/main-9c895b43-sync-v1/benchmark-preparation-v2/go-screen-v2/specs/bundle-n1.json',
               '/workspace/jsgo-results/round4/paired-main5de-bundle-advanced-t1-v1'),
}


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('task', choices=TASKS, nargs='?', default='bigquery')
    parser.add_argument('--manifest', required=True, type=Path)
    parser.add_argument('--candidate', required=True)
    parser.add_argument('--out', required=True, type=Path)
    parser.add_argument('--total-timeout', type=int, default=14400,
                        help='Bound recorded before execution; does not change fixed sample counts')
    args = parser.parse_args()
    manifest_path, out = args.manifest.resolve(), args.out.resolve()
    if out.exists() or args.total_timeout <= 0:
        raise ValueError('use a fresh output directory and positive declared total timeout')
    if sha(RUNNER) != RUNNER_SHA256:
        raise ValueError('v4 runner source differs from its reviewed pin')
    manifest = json.loads(manifest_path.read_text())
    if manifest['status'] != 'PASS_BUILD_VALIDATION' or manifest['java_home'] != JDK:
        raise ValueError('manifest must have a successful build for the pinned JDK')
    if manifest['driver']['source_sha256'] != sha(ROOT / 'bench/CliFactors.java'):
        raise ValueError('manifest driver differs from the unchanged CliFactors source')
    if args.candidate == 'STOCK' or not {'STOCK', args.candidate} <= set(manifest['variants']):
        raise ValueError('candidate must be distinct from published STOCK and present in the manifest')
    spec, oracle_directory = TASKS[args.task]
    oracle_directory = Path(oracle_directory)
    grant = {
        'runner_sha256': RUNNER_SHA256, 'manifest_sha256': sha(manifest_path),
        'spec_sha256': sha(spec), 'out': str(out), 'baseline': 'STOCK',
        'candidate': args.candidate, 'cohorts': 5, 'pairs': 20,
        'min_warmup': 60, 'max_warmup': 150, 'seed': 20261020,
        'request_timeout': 300, 'total_timeout': args.total_timeout,
        'benchmark_protocol': PROTOCOL, 'allowed_stages': ['benchmark'],
        'inference_plan': {
            'confirmation': 'Five fresh independent direct-STOCK cohorts; log-cohort t95(df4) primary; twenty fixed pairs per cohort.',
            'JIT': 'All20 and four fixed5 blocks; >1% and >2% annotations only; no adaptive exclusion, replacement or retry.',
            'pooling': 'No screen/v3/workload pooling; n5 does not promise 2% detectability.',
            'workload': args.task,
            'generalization': 'Bundle starts only when explicitly selected; no automatic follow-up workload.',
        },
    }
    grant_directory = ROOT / 'launches'
    grant_directory.mkdir(parents=True, exist_ok=True)
    grant_path = grant_directory / (out.name + '.grant.json')
    with grant_path.open('x') as output:
        json.dump(grant, output, indent=2, allow_nan=False)
        output.write('\n')
    command = [
        sys.executable, str(RUNNER), '--manifest', str(manifest_path),
        '--baseline', 'STOCK', '--candidate', args.candidate, '--cohorts', '5', '--pairs', '20',
        '--spec', spec, '--oracle', str(oracle_directory / 'stock-java-oracle-digests.json'),
        '--oracle-metadata', str(oracle_directory / 'metadata.json'),
        '--jar', JAR, '--java-home', JDK, '--image', IMAGE,
        '--out', str(out), '--runtime-grant', str(grant_path),
        '--min-warmup', '60', '--max-warmup', '150', '--seed', '20261020',
        '--request-timeout', '300', '--total-timeout', str(args.total_timeout),
    ]
    print(json.dumps({'task': args.task, 'command': command, 'grant': str(grant_path)}), flush=True)
    os.execv(sys.executable, command)


if __name__ == '__main__':
    main()
