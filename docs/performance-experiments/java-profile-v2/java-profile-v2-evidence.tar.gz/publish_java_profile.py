#!/usr/bin/env python3
"""Prepare-only by default; --execute makes a CLOSED local publication snapshot.

No benchmark, JVM, build, git or network publication. The final config names reviewed
jobs; other attempts/proposals remain evidence, without a completion claim.
"""
import argparse
import contextlib
import gzip
import hashlib
import json
import os
from pathlib import Path, PurePosixPath
import shutil
import stat
import subprocess
import sys
import tarfile

sys.dont_write_bytecode = True
ROOT = Path('/workspace/jsgo-java-experiments/profile-v2')
OLD = Path('/workspace/jsgo-java-experiments/transfer-v1')
DEST = Path('/workspace/jsgo-publish-records/docs/performance-experiments/java-profile-v2')
ARCHIVE = 'java-profile-v2-evidence.tar.gz'
DOCKER_DROP = {'DOCKER_HOST', 'DOCKER_CONTEXT', 'DOCKER_TLS', 'DOCKER_TLS_VERIFY', 'DOCKER_CERT_PATH'}
PROTOCOL_V4 = {'version': 'confirmation-v4', 'baseline': 'STOCK', 'cohorts': 5, 'pairs': 20,
               'min_warmup': 60, 'max_warmup': 150, 'warm_window': 8, 'max_median_drift': .03,
               'max_JIT_fraction': .01, 'max_spread': 1.15,
               'measured_JIT_annotations': [.01, .02], 'measured_JIT_block_size': 5}
REPRODUCE = '''This snapshot preserves Java-versus-Java experiment evidence; it makes no new speed claim.

Read README.md and publication-jobs.json for the final reviewed jobs and retained
incomplete/diagnostic attempts. All ordinary experiment records are archived,
including rejected/unexecuted proposals, failed probes/builds, interrupted runs,
profiles' aggregate summaries and JIT annotations. evidence-members.json lists
every included file and every exclusion. Raw JFR files without an explicit passing
audit clearance are omitted from the public archive and retained locally, because
the profile configuration captured environment/system-property strings. Python
caches, symlinks and nonregular files are excluded; links are never followed.

reproduction-inputs/ contains exact per-job spec/oracle/oracle-metadata/helper
snapshots and the shared CliFactors source, externally referenced v1 driver classes
and build receipt. Its manifest identifies original paths and verified hashes.
Optional reference-only metadata supplies workload inputs without a v2 result.
Candidate/control source, overlays, class inventories, probes, build records,
controllers, reviewers and selection notes remain in the main evidence tree.

The published Closure jar, source jar, JDK/dependencies, immutable container image
and workload payloads are external dependencies identified by the recorded pins;
they are not copied into this archive. Remap original absolute paths in a new
workspace, preserve original versions, and record hashes for adapted helpers.
Old runtime coordination receipts are historical evidence, not portable grants.

Use the original method: fresh compiler and normal extern parsing each request,
same flags/default collector, actual 4 GiB/no swap/two CPUs per JVM, matched settled
warmups, sequential alternating requests, six output digests, independent cohorts,
zero new OOM and stopped cleanup. Performance tests use no JFR. Screens remain
separate from confirmation. JFR samples are diagnostic, allocated bytes are not
retained heap, RSS windows differ, and unavailable PSI is not zero. Full upstream
unit suites were not implied by the focused probes or workload parity checks.
'''


def require(ok, message):
    if not ok:
        raise RuntimeError(message)


def relative(value):
    require(isinstance(value, str) and value and '\\' not in value, 'invalid relative path')
    p = PurePosixPath(value)
    require(not p.is_absolute() and all(x not in ('', '.', '..') for x in value.split('/')), 'unsafe relative path')
    return p.as_posix()


def no_links(path):
    path = Path(path).absolute()
    require('..' not in path.parts, 'parent traversal')
    for item in [*reversed(path.parents), path]:
        require(not item.is_symlink(), 'symlink path component: ' + str(item))
    return path


@contextlib.contextmanager
def opened(path):
    path = no_links(path)
    fd = os.open(path, os.O_RDONLY | getattr(os, 'O_NOFOLLOW', 0))
    with os.fdopen(fd, 'rb') as stream:
        before = os.fstat(fd)
        require(stat.S_ISREG(before.st_mode), 'not a regular file: ' + str(path))
        yield stream, before
        after = os.fstat(fd)
        require((before.st_dev, before.st_ino, before.st_size, before.st_mtime_ns, before.st_ctime_ns) ==
                (after.st_dev, after.st_ino, after.st_size, after.st_mtime_ns, after.st_ctime_ns),
                'file changed during read: ' + str(path))


def sha(path):
    digest = hashlib.sha256()
    with opened(path) as (stream, _):
        for block in iter(lambda: stream.read(1 << 20), b''):
            digest.update(block)
    return digest.hexdigest()


def read(path):
    with opened(path) as (stream, info):
        require(info.st_size <= 64 << 20, 'oversized JSON')
        return json.load(stream)


def save(path, value):
    with Path(path).open('x', encoding='utf-8') as stream:
        json.dump(value, stream, indent=2, sort_keys=True, allow_nan=False)
        stream.write('\n')


def copy_exact(source, target, expected):
    target.parent.mkdir(parents=True, exist_ok=True)
    with opened(source) as (stream, _), target.open('xb') as output:
        shutil.copyfileobj(stream, output, 1 << 20)
    require(sha(target) == expected, 'copy hash mismatch: ' + str(target))


def logs():
    checked = {}
    for fd, label in ((1, 'stdout'), (2, 'stderr')):
        info = os.fstat(fd)
        require(stat.S_ISREG(info.st_mode), 'redirect publication logs to external regular files')
        target = no_links(Path(os.readlink('/proc/self/fd/' + str(fd))))
        require(not target.is_relative_to(ROOT) and not target.is_relative_to(DEST), 'log inside captured/published tree')
        current = target.stat()
        require((current.st_dev, current.st_ino) == (info.st_dev, info.st_ino), 'log descriptor mismatch')
        checked[label] = {'path': str(target), 'dev': info.st_dev, 'ino': info.st_ino}
    return checked


def idle():
    active = []
    for path in Path('/proc').iterdir():
        if not path.name.isdigit() or int(path.name) == os.getpid():
            continue
        try:
            if (path / 'stat').read_text().split()[2] == 'Z':
                continue
            comm = (path / 'comm').read_text().strip()
            argv = [os.fsdecode(x) for x in (path / 'cmdline').read_bytes().split(b'\0') if x]
            executable = Path(argv[0]).name if argv else ''
            controller = any(arg.startswith(str(ROOT) + '/') and arg.endswith('.py')
                             and Path(arg) != Path(__file__).absolute() for arg in argv)
            if comm in ('go', 'compile', 'link', 'java', 'javac') or comm.startswith('jsgo') or executable.endswith('.test') or controller:
                active.append({'pid': int(path.name), 'comm': comm})
        except (FileNotFoundError, ProcessLookupError):
            continue
    require(not active, 'active compiler/controller processes: ' + repr(active))
    env = {k: v for k, v in os.environ.items() if k not in DOCKER_DROP}
    result = subprocess.run(['docker', '--host=unix:///var/run/docker.sock', 'ps', '--format', '{{.ID}}'],
                            env=env, capture_output=True, text=True, timeout=30)
    require(result.returncode == 0 and not result.stdout.strip(), 'cannot establish empty running-container set')
    return {'active_compilers_controllers': [], 'running_containers': [], 'docker_ps_exit': 0}


def protocol_for_metadata(metadata):
    if 'benchmark_protocol' not in metadata:
        require(metadata['cohorts'] in (1, 3) and metadata['pairs'] == 5
                and metadata['min_warmup'] == 12 and 12 <= metadata['max_warmup'] <= 90,
                'legacy v3 protocol counts')
        return {'version': 'v3', 'runner': 'bench/run-v3.py', 'pairs': 5,
                'summary_status': 'PASS settled byteidentical Java-vs-Java'}
    require(metadata['benchmark_protocol'] == PROTOCOL_V4, 'unknown or altered benchmark protocol')
    require(metadata['cohorts'] == 5 and metadata['pairs'] == 20 and metadata['baseline'] == 'STOCK'
            and metadata['min_warmup'] == 60 and metadata['max_warmup'] == 150,
            'v4 fixed protocol counts/direct-STOCK')
    return {'version': 'confirmation-v4', 'runner': 'bench/run-v4.py', 'pairs': 20,
            'summary_status': 'PASS warm-gated byteidentical Java-vs-Java v4'}


def final_jobs(config):
    require(config['snapshot_state'] == 'CLOSED', 'config is not CLOSED; do not capture an active experiment')
    jobs = config['completed_benchmark_jobs']
    require(jobs and len({j['result'] for j in jobs}) == len(jobs), 'empty or duplicate final job set')
    finished, records = set(), []
    for job in jobs:
        rel = relative(job['result'])
        require(len(PurePosixPath(rel).parts) == 2 and rel.startswith('results/'), 'job must be results/<name>')
        root = ROOT / rel
        m, s = read(root / 'metadata.json'), read(root / 'summary.json')
        protocol = protocol_for_metadata(m)
        r, stopped = read(ROOT / relative(job['review'])), read(root / 'stopped-proof.json')
        require(s['status'] == protocol['summary_status'] and s['complete'] is True, 'job summary incomplete/protocol mismatch')
        if protocol['version'] == 'confirmation-v4':
            require(s['benchmark_protocol'] == r['benchmark_protocol'] == PROTOCOL_V4, 'v4 summary/review protocol mismatch')
        require(r['status'] == 'PASS independent Java-factor review', 'independent review missing/failed')
        require(r['results'] == str(root) and r['baseline'] == m['baseline'] and r['candidate'] == m['candidate'], 'review identity')
        require(s['baseline'] == m['baseline'] and s['candidate'] == m['candidate'], 'summary identity')
        require(r['cohorts'] == m['cohorts'] == len(s['cohorts'])
                and m['pairs'] == r['pairs_per_cohort'] == protocol['pairs'], 'cohort/request count')
        require(r['measured_requests'] == 2 * protocol['pairs'] * m['cohorts'], 'measured request count')
        require(r['strict_digests_every_request'] == 6 and r['all_graceful_driver_exit_codes_zero'] is True, 'review parity/exit')
        require(r['Java_vs_Go_claim'] is False and s['Java_vs_Go_claim'] is False, 'unexpected Go claim')
        require(m['runner_sha256'] == sha(ROOT / protocol['runner']) == r['runner_sha256'], 'runner identity')
        manifest_path = ROOT / relative(job['manifest'])
        require(sha(manifest_path) == m['manifest_sha256'] == r['manifest_sha256'] and read(manifest_path) == m['manifest'], 'manifest identity')
        require(s['source_manifest_sha256'] == m['manifest_sha256'], 'summary manifest identity')
        require(sha(root / 'stopped-proof.json') == r['stopped_proof_sha256'], 'reviewed stopped-proof identity')
        for key in ('cleanup_errors', 'remaining_owned_containers', 'active_compilers', 'remaining_owned_driver_processes'):
            require(stopped[key] == [], 'job not stopped: ' + key)
        require(all(stopped['outer_OOM_delta'].get(k) == 0 for k in ('oom', 'oom_kill', 'oom_group_kill')), 'job OOM delta')
        finished.add(rel)
        records.append({'result': rel, 'review': job['review'], 'manifest': job['manifest'],
                        'baseline': m['baseline'], 'candidate': m['candidate'], 'cohorts': m['cohorts'],
                        'pairs': protocol['pairs'], 'protocol': protocol['version'],
                        'status': r['status'], 'summary_sha256': sha(root / 'summary.json'),
                        'review_sha256': sha(ROOT / job['review']), 'stopped_sha256': sha(root / 'stopped-proof.json')})
    discovered = set()
    for path in sorted((ROOT / 'results').iterdir()):
        if path.is_symlink() or not path.is_dir() or not (path / 'summary.json').is_file():
            continue
        summary = read(path / 'summary.json')
        if summary.get('complete') is True and 'source_manifest_sha256' in summary:
            protocol = protocol_for_metadata(read(path / 'metadata.json'))
            require(summary.get('status') == protocol['summary_status'], 'completed summary protocol mismatch')
            discovered.add(path.relative_to(ROOT).as_posix())
    require(discovered == finished, 'final job set must name every completed benchmark summary; other attempts remain raw evidence')
    return records


def jfr_clearances(config):
    cleared = {}
    for row in config.get('raw_jfr_clearances', []):
        rel, audit = relative(row['path']), relative(row['audit_receipt'])
        require(rel.lower().endswith('.jfr') and rel not in cleared, 'invalid/duplicate JFR clearance')
        require(sha(ROOT / audit) == row['audit_sha256'], 'audit receipt identity')
        with opened(ROOT / audit) as (stream, info):
            require(info.st_size < 16 << 20, 'oversized JFR audit receipt')
            lines = stream.read().splitlines()
            require(lines and lines[0] == b'STATUS\tPASS_STANDARD_CONSUMER_STRING_AUDIT', 'JFR audit not clear')
        require(sha(ROOT / rel) == row['recording_sha256'], 'cleared recording identity')
        cleared[rel] = row
    return cleared


def reproduction(stage, config):
    target = stage / 'reproduction-inputs'
    target.mkdir()
    entries, inputs = [], []
    sources = [(Path(j['result']).name, ROOT / j['result'] / 'metadata.json', 'COMPLETED_V2_BENCHMARK')
               for j in config['completed_benchmark_jobs']]
    for reference in config.get('extra_reproduction_metadata', []):
        name = relative(reference['name'])
        require('/' not in name, 'reference name must be one component')
        source = Path(reference['metadata'])
        sources.append((name, source if source.is_absolute() else ROOT / relative(str(source)), 'REFERENCE_INPUTS_ONLY_NOT_V2_RESULT'))
    require(len({name for name, _, _ in sources}) == len(sources), 'duplicate reproduction names')
    shared_driver = None

    def snapshot(source, rel, expected):
        source = no_links(source)
        require(sha(source) == expected, 'reproduction source identity: ' + str(source))
        copy_exact(source, target / relative(rel), expected)
        entries.append({'original': str(source), 'copy': rel, 'sha256': expected})

    for name, source, role in sources:
        m = read(source)
        prefix = 'jobs/' + name + '/'
        snapshot(source, prefix + 'metadata.json', sha(source))
        for label in ('spec', 'oracle', 'oracle_metadata'):
            snapshot(Path(m[label]), prefix + label + '.json', m[label + '_sha256'])
        require(set(m['helpers']) == {'paired_cli.py', 'cgroup_exec.py'}, 'helper snapshot set differs')
        for helper, expected in m['helpers'].items():
            require(helper in ('paired_cli.py', 'cgroup_exec.py'), 'unexpected helper')
            snapshot(source.parent / 'helper-snapshots' / helper, prefix + 'helpers/' + helper, expected)
        driver = m['manifest']['driver']
        if shared_driver is None:
            shared_driver = driver
            require(Path(driver['directory']) == OLD / 'bench/driver', 'unexpected shared driver location')
            require(sha(ROOT / 'bench/CliFactors.java') == driver['source_sha256'], 'v2 driver source identity')
            snapshot(OLD / 'bench/CliFactors.java', 'shared-driver/CliFactors.java', driver['source_sha256'])
            for class_name, expected in driver['classes'].items():
                snapshot(Path(driver['directory']) / relative(class_name), 'shared-driver/classes/' + relative(class_name), expected)
            snapshot(Path(driver['build_proof']), 'shared-driver/build.json', driver['build_proof_sha256'])
        else:
            require(driver == shared_driver, 'shared driver differs across reproduction inputs')
        inputs.append({'name': name, 'role': role, 'original_metadata': str(source),
                       'input_manifest': m['input_manifest'], 'jar': m['jar'], 'jar_sha256': m['jar_sha256'],
                       'java_home': m['java_home'], 'java_runtime_dependencies': m['java_runtime_dependencies'],
                       'image': m['image'], 'driver': driver})
    save(target / 'manifest.json', {'status': 'EXACT_PIN_CHECKED_REPRODUCTION_COPIES', 'copies': entries,
                                  'inputs': inputs, 'external_workload_jar_JDK_image_payloads_copied': False})
    return target


def member(path):
    with opened(path) as (stream, info):
        digest = hashlib.sha256()
        for block in iter(lambda: stream.read(1 << 20), b''):
            digest.update(block)
    return {'sha256': digest.hexdigest(), 'bytes': info.st_size, 'mode': stat.S_IMODE(info.st_mode),
            'mtime_ns': info.st_mtime_ns, 'uid': info.st_uid, 'gid': info.st_gid}


def inventory(root, cleared, log_inodes):
    files, excluded = {}, []
    def walk(path):
        for entry in sorted(os.scandir(path), key=lambda e: e.name):
            p = Path(entry.path)
            rel = relative(p.relative_to(root).as_posix())
            info = entry.stat(follow_symlinks=False)
            if stat.S_ISLNK(info.st_mode):
                excluded.append({'path': rel, 'reason': 'symlink_never_followed', 'target': os.readlink(p)})
            elif entry.name == '__pycache__' or entry.name.endswith('.pyc'):
                excluded.append({'path': rel, 'reason': 'python_cache'})
            elif stat.S_ISDIR(info.st_mode):
                walk(p)
            elif stat.S_ISREG(info.st_mode):
                require((info.st_dev, info.st_ino) not in log_inodes, 'live log hardlink inside evidence')
                if rel.lower().endswith('.jfr') and rel not in cleared:
                    excluded.append({'path': rel, 'reason': 'raw_JFR_not_cleared_for_publication_retained_locally',
                                     'bytes': info.st_size, 'mtime_ns': info.st_mtime_ns})
                else:
                    files[rel] = member(p)
            else:
                excluded.append({'path': rel, 'reason': 'nonregular_never_opened', 'mode': info.st_mode})
    walk(root)
    return dict(sorted(files.items())), excluded


def verify_archive(path, files):
    seen = set()
    with tarfile.open(path, 'r|gz') as archive:
        for item in archive:
            name = relative(item.name)
            require(item.isfile() and name in files and name not in seen, 'unexpected archive member')
            expected = files[name]
            require(item.size == expected['bytes'] and item.mode == expected['mode'], 'archive member metadata')
            stream = archive.extractfile(item)
            require(stream is not None, 'archive member stream missing')
            digest = hashlib.sha256()
            for block in iter(lambda: stream.read(1 << 20), b''):
                digest.update(block)
            require(digest.hexdigest() == expected['sha256'], 'archive member hash mismatch: ' + name)
            seen.add(name)
    require(seen == set(files), 'archive missing members')


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--execute', action='store_true')
    parser.add_argument('--config', type=Path)
    args = parser.parse_args()
    if not args.execute:
        print('PREPARED ONLY. No files, runtime, hashes, copies or archive inspected/created.')
        return
    require(args.config is not None, '--execute needs the final explicit job config')
    require(Path(__file__).absolute() == ROOT / 'publish_java_profile.py', 'publisher location changed')
    before_logs = logs()
    before_idle = idle()
    config_path = no_links(args.config)
    config_hash = sha(config_path)
    config = read(config_path)
    jobs = final_jobs(config)
    cleared = jfr_clearances(config)
    require(no_links(DEST.parent).is_dir() and not DEST.exists() and not DEST.is_symlink(), 'new destination required')
    stage = DEST.with_name('.java-profile-v2-staging-' + str(os.getpid()))
    require(not stage.exists() and not stage.is_symlink(), 'staging destination already exists')
    stage.mkdir(mode=0o755)
    reproduction(stage, config)
    save(stage / 'snapshot-config.json', config)
    save(stage / 'publication-jobs.json', {'reviewed_completed_benchmarks': jobs,
                                         'other_records': 'Retained as diagnostic/failed/incomplete/prepared evidence; no successful-job claim.',
                                         'raw_jfr_clearances': list(cleared.values())})
    (stage / 'REPRODUCE.md').write_text(REPRODUCE)
    log_inodes = {(x['dev'], x['ino']) for x in before_logs.values()}
    before_files, before_excluded = inventory(ROOT, cleared, log_inodes)
    extra_files, extra_excluded = inventory(stage, {}, log_inodes)
    require(not extra_excluded and not set(before_files).intersection(extra_files), 'generated-member collision or exclusion')
    files = dict(sorted((before_files | extra_files).items()))
    roots = {name: ROOT for name in before_files} | {name: stage for name in extra_files}
    report_members = set()
    for prefix in config.get('report_paths', ['README.md', 'PROFILE-NOTES.md', 'MEASURED-JIT-REVIEW-NOTE.md', 'reviews', 'source-audit', 'upstream-patches']):
        prefix = relative(prefix)
        selected = [name for name in before_files if name == prefix or name.startswith(prefix + '/')]
        require(selected, 'report path has no included files: ' + prefix)
        report_members.update(selected)
    for name in sorted(report_members):
        copy_exact(ROOT / name, stage / name, before_files[name]['sha256'])
    archive_path = stage / ARCHIVE
    with archive_path.open('xb') as raw:
        with gzip.GzipFile(filename='', mode='wb', fileobj=raw, mtime=0, compresslevel=6) as compressed:
            with tarfile.open(fileobj=compressed, mode='w|', format=tarfile.PAX_FORMAT) as archive:
                for name, expected in files.items():
                    item = tarfile.TarInfo(name)
                    item.size, item.mode = expected['bytes'], expected['mode']
                    item.mtime = item.uid = item.gid = 0
                    item.uname = item.gname = ''
                    with opened(roots[name] / name) as (stream, _):
                        archive.addfile(item, stream)
    verify_archive(archive_path, files)
    after_files, after_excluded = inventory(ROOT, cleared, log_inodes)
    require((before_files, before_excluded) == (after_files, after_excluded), 'experiment changed during capture')
    require(all(member(stage / name) == expected for name, expected in extra_files.items()), 'generated snapshot changed')
    require(sha(config_path) == config_hash and logs() == before_logs, 'config/log descriptors changed')
    after_idle = idle()
    archive_hash = sha(archive_path)
    save(stage / 'evidence-members.json', {'schema': 'jsgo-java-profile-evidence-v2', 'archive': ARCHIVE,
         'archive_sha256': archive_hash, 'archive_bytes': archive_path.stat().st_size, 'files': files,
         'excluded': before_excluded, 'source_root': str(ROOT), 'tar_policy': 'Sorted regular files; no links; normalized ownership/times; member hashes verified without extraction'})
    save(stage / 'publication-receipt.json', {'status': 'LOCAL_SNAPSHOT_VERIFIED', 'config_sha256': config_hash,
         'publisher_sha256': sha(Path(__file__)), 'archive_sha256': archive_hash, 'included_files': len(files),
         'excluded_records': len(before_excluded), 'before_idle': before_idle, 'after_idle': after_idle,
         'external_logs': before_logs, 'experiment_and_frozen_v1_modified': False,
         'compiler_benchmark_build_git_network_actions': False})
    require(not DEST.exists() and not DEST.is_symlink(), 'destination appeared during capture')
    stage.rename(DEST)
    print(json.dumps({'status': 'LOCAL_SNAPSHOT_VERIFIED', 'destination': str(DEST), 'archive_sha256': archive_hash}))


if __name__ == '__main__':
    main()
