#!/usr/bin/env python3
"""Request eviction of clean task-file cache only; never change file contents."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import stat
import time

ROOTS = [
    Path('/workspace/jsgo-legacy-binary-archives-v1'),
    Path('/workspace/.cache'),
    Path('/workspace/jsgo/.cache'),
    Path('/workspace/jsgo-results'),
    Path('/workspace/jsgo-java-experiments'),
]

def memory():
    root = Path('/sys/fs/cgroup')
    return {name: (root / name).read_text() for name in
            ('memory.current', 'memory.max', 'memory.stat', 'memory.events.local')}

def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--out', type=Path, required=True)
    parser.add_argument('--min-bytes', type=int, default=1 << 20)
    args = parser.parse_args()
    if args.out.exists():
        raise SystemExit('New receipt path required')
    if args.min_bytes < 0:
        raise SystemExit('Nonnegative minimum required')
    result = {'started_unix': time.time(), 'before': memory(),
              'script_sha256': hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
              'min_bytes': args.min_bytes,
              'policy': 'POSIX_FADV_DONTNEED, read-only no-follow descriptors, regular files at least min_bytes, owned task roots only; no unlink, truncation, global drop_caches or runtime-setting changes',
              'roots': list(map(str, ROOTS)), 'advised': [], 'errors': []}
    for root in ROOTS:
        if not root.is_dir():
            continue
        for directory, dirs, files in os.walk(root, followlinks=False):
            dirs[:] = [d for d in dirs if d != '.git' and not Path(directory, d).is_symlink()]
            for name in files:
                path = Path(directory, name)
                try:
                    info = path.lstat()
                    if not stat.S_ISREG(info.st_mode) or info.st_size < args.min_bytes:
                        continue
                    fd = os.open(path, os.O_RDONLY | os.O_NOFOLLOW)
                    try:
                        before = os.fstat(fd)
                        if not stat.S_ISREG(before.st_mode):
                            raise RuntimeError('Not a regular opened file')
                        os.posix_fadvise(fd, 0, 0, os.POSIX_FADV_DONTNEED)
                        after = os.fstat(fd)
                        if (before.st_ino, before.st_dev, before.st_size, before.st_mtime_ns) != (after.st_ino, after.st_dev, after.st_size, after.st_mtime_ns):
                            raise RuntimeError('Concurrent file modification observed')
                        result['advised'].append({'path': str(path), 'bytes': before.st_size})
                    finally:
                        os.close(fd)
                except Exception as error:
                    result['errors'].append({'path': str(path), 'error': repr(error)})
    result['after'] = memory()
    result['finished_unix'] = time.time()
    result['status'] = 'CACHE_ADVICE_ONLY_NOT_A_BENCHMARK'
    args.out.write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps({'status': result['status'], 'files_advised': len(result['advised']),
                     'errors': len(result['errors']),
                     'memory_before': int(result['before']['memory.current']),
                     'memory_after': int(result['after']['memory.current'])}))

if __name__ == '__main__':
    main()
