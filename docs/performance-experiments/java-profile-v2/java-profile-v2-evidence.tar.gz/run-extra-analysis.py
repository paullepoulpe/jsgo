"""Root-owned, sequential diagnostic analysis; run only with no benchmark active."""
from pathlib import Path
import hashlib, json, os, subprocess, time

ROOT = Path(__file__).resolve().parent
JAVA = '/usr/lib/jvm/java-21-openjdk-amd64/bin/java'
OUT = ROOT / 'analysis-driver-v1'

def main():
    OUT.mkdir()
    classes = OUT / 'classes'
    classes.mkdir()
    sources = [ROOT / 'profile-driver/JfrAllocationCallers.java',
               ROOT / 'publication-preparation/JfrPublicationAudit.java']
    env = {k:v for k,v in os.environ.items()
           if k not in ('JAVA_TOOL_OPTIONS', '_JAVA_OPTIONS', 'JDK_JAVA_OPTIONS')}
    records = []
    def run(name, argv, allowed=(0,)):
        start = time.time()
        with (OUT / (name + '.stdout')).open('wb') as so, (OUT / (name + '.stderr')).open('wb') as se:
            result = subprocess.run(argv, stdout=so, stderr=se, env=env, timeout=150)
        records.append({'name': name, 'argv': argv, 'started_unix': start,
                        'ended_unix': time.time(), 'exit': result.returncode})
        (OUT / 'receipts.json').write_text(json.dumps(records, indent=2) + '\n')
        assert result.returncode in allowed, (name, result.returncode)
    run('compile', [JAVA, '-Xmx512m', '-m', 'jdk.compiler/com.sun.tools.javac.Main',
                    '--add-modules', 'jdk.jfr', '-source', '21', '-target', '21',
                    '-d', str(classes), *map(str, sources)])
    base = [JAVA, '-Xmx256m', '--add-modules', 'jdk.jfr', '-cp', str(classes)]
    capture = ROOT / 'results/profile-stock-bigquery-steady-v2/work/profile.jfr'
    run('allocation-callers', base + ['JfrAllocationCallers', str(capture)])
    for name in ('profile-stock-bigquery-v1', 'profile-stock-bigquery-steady-v2'):
        run('publication-audit-' + name, base + ['JfrPublicationAudit', str(ROOT / 'results' / name / 'work/profile.jfr')], (0, 2))
    (OUT / 'source-hashes.json').write_text(json.dumps(
        {str(p.relative_to(ROOT)): hashlib.sha256(p.read_bytes()).hexdigest()
         for p in [Path(__file__), *sources]}, indent=2) + '\n')
    print(json.dumps({'status': 'ANALYSIS_COMPLETE', 'receipts': str(OUT / 'receipts.json')}))

if __name__ == '__main__':
    main()
