"""Build one small Java candidate and a matched unmodified-source control."""
from pathlib import Path
import argparse, hashlib, json, os, re, subprocess, time, zipfile
ROOT=Path(__file__).resolve().parent
OLD=ROOT.parent/'transfer-v1'
SOURCE=Path('/workspace/jsgo/.cache/closure-src')
SOURCE_JAR=Path('/workspace/jsgo/.cache/closure-src.jar')
JAR=Path('/workspace/jsgo/.cache/closure-compiler-v20261015-maven.jar')
JDK=Path('/usr/lib/jvm/java-21-openjdk-amd64')
FLAGS=['-source','21','-target','21','-g','-proc:none','-implicit:none','-encoding','UTF-8']
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def save(p,v):Path(p).write_text(json.dumps(v,indent=2)+'\n')
def main():
 p=argparse.ArgumentParser();p.add_argument('candidate');p.add_argument('--source-root',required=True,type=Path);a=p.parse_args()
 assert re.fullmatch('[A-Za-z0-9_.-]+',a.candidate)
 sources={str(p.relative_to(a.source_root)):p for p in sorted(a.source_root.rglob('*.java'))}
 assert sources and all(x.startswith('com/google/') for x in sources)
 assert sha(JAR)=='d6864ebf70bca5ba6e237898de6611a389aaf8b933c2549036ced4a684b664b6'
 assert sha(SOURCE_JAR)=='4d38166975b61466aa3b02b0d2d38160b855dd7f7e1f6171069fc84974bac45a'
 dest=ROOT/'build'/a.candidate;dest.mkdir(parents=True)
 variants={'STOCK':{'overlay':None,'classes':{}}};proofs={}
 families=[s.removesuffix('.java') for s in sources]
 for name in ['CONTROL',a.candidate]:
  out=dest/name;out.mkdir();(out/'classes').mkdir();(out/'src').mkdir();paths=[];originals={};effective={};relocated={}
  with zipfile.ZipFile(SOURCE_JAR) as z:
   for rel,candidate in sources.items():
    original=z.read(rel);assert (SOURCE/rel).read_bytes()==original
    content=original if name=='CONTROL' else candidate.read_bytes()
    transformed=re.sub(r'(?<![\w.])com\.google\.(common|auto|errorprone|gson|protobuf|j2objc|thirdparty)(?=\.)',r'com.google.javascript.jscomp.jarjar.com.google.\1',content.decode())
    target=out/'src'/rel;target.parent.mkdir(parents=True,exist_ok=True);target.write_text(transformed);paths.append(str(target))
    originals[rel]=hashlib.sha256(original).hexdigest();effective[rel]=hashlib.sha256(content).hexdigest();relocated[rel]=sha(target)
  command=[str(JDK/'bin/java'),'-Xmx1g','-m','jdk.compiler/com.sun.tools.javac.Main',*FLAGS,'-cp',str(JAR),'-sourcepath',str(out/'src'),'-d',str(out/'classes'),*paths]
  meta={'variant':name,'argv':command,'javac_flags':FLAGS,'original_sources':originals,'effective_sources':effective,'relocated_sources':relocated,'started_unix':time.time(),'jar_sha256':sha(JAR),'source_jar_sha256':sha(SOURCE_JAR)}
  env={k:v for k,v in os.environ.items() if k not in ['JAVA_TOOL_OPTIONS','_JAVA_OPTIONS','JDK_JAVA_OPTIONS']}
  with (out/'stdout').open('wb') as so,(out/'stderr').open('wb') as se:result=subprocess.run(command,env=env,stdout=so,stderr=se,timeout=180)
  classes={str(p.relative_to(out/'classes')):sha(p) for p in sorted((out/'classes').rglob('*.class'))}
  meta.update(status='PASS' if result.returncode==0 else 'FAILED',exit=result.returncode,classes=classes,ended_unix=time.time());save(out/'build.json',meta)
  assert result.returncode==0,(name,(out/'stderr').read_text())
  proofs[name]=sha(out/'build.json')
  variants[name]={'overlay':str(out/'classes'),'javac_flags':FLAGS,'compiled_source_families':families,'classes':classes,'build_proof':str(out/'build.json'),'build_proof_sha256':proofs[name]}
 old=json.loads((OLD/'bench/build-manifest.json').read_text())
 manifest={'status':'PASS_BUILD_VALIDATION','semantic_parity_status':'Not inferred from successful compilation; probes and strict byte gates required','jar_sha256':sha(JAR),'source_jar_sha256':sha(SOURCE_JAR),'unmodified_compiler_classes_outside_overlays':True,'java_version':old['java_version'],'java_home':str(JDK),'compiler_source_families':families,'family_naming':'Full relative class stems from archive root, excluding .java/.class','javac_flags':FLAGS,'driver_javac_flags':old['driver_javac_flags'],'driver':old['driver'],'variants':variants,'compiler_build_receipt_sha256':proofs}
 save(dest/'manifest.json',manifest);print(json.dumps({'status':manifest['status'],'candidate':a.candidate,'families':families,'manifest':str(dest/'manifest.json')}))
if __name__=='__main__':main()
