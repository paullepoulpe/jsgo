"""Small source/math checks only. Never import a runner or execute JVM/Docker work."""
import ast
import hashlib
import json
import math
from pathlib import Path
import statistics

ROOT = Path(__file__).resolve().parent


def selected(filename, names):
    tree = ast.parse((ROOT / filename).read_text())
    nodes = [node for node in tree.body if isinstance(node, ast.FunctionDef) and node.name in names]
    assert {node.name for node in nodes} == set(names)
    scope = {'math': math, 'statistics': statistics, 'json': json}
    # Only explicitly selected pure functions are evaluated; no module imports,
    # top-level code, main, filesystem functions or benchmark helpers execute.
    exec(compile(ast.Module(body=nodes, type_ignores=[]), filename + ':pure-functions-only', 'exec'), scope)
    return scope


runner = selected('run-v4.py', ['stability'])
reviewer = selected('review-results-v4.py', ['require', 'settling', 't_interval', 'invert', 'measured_jit', 'measured_jit_csv'])


def rows(n=60, wall=1.0, jit=10):
    return [{'request': i + 1, 'wall_s': wall, 'jit_before_ms': 1000, 'jit_after_ms': 1000 + jit} for i in range(n)]


def gate(case, expected):
    assert runner['stability'](case)['stable'] is expected
    try:
        result = reviewer['settling'](case)
    except ValueError:
        assert not expected
    else:
        assert expected and result['stable']


gate(rows(59), False)
gate(rows(), True)  # Exactly 1% last-eight JIT is admitted.
gate(rows(jit=11), False)
case = rows()
for row in case[-8:]:
    row['wall_s'] = 1.029
gate(case, True)
case = rows()
for row in case[-8:]:
    row['wall_s'] = 1.031
gate(case, False)
case = rows()
case[-8]['wall_s'] = 1.151
gate(case, False)
case = rows()
case[-5]['jit_before_ms'] = -1
gate(case, False)  # Last eight, not merely the old last-four window.
case = rows()
case[-5]['jit_after_ms'] = 999
gate(case, False)
case = rows()
case[-17]['wall_s'] = 1000
gate(case, True)  # Requests older than both prescribed windows do not intervene.

measured = rows(20, jit=0)
for row in measured[:5]:
    row['jit_after_ms'] += 30
jit = reviewer['measured_jit'](measured)
assert jit['JIT_deltas_ms'] == [30] * 5 + [0] * 15
assert jit['JIT_sum_ms'] == 150 and jit['wall_sum_s'] == 20
assert not jit['above_1_percent'] and not jit['above_2_percent']
assert jit['fixed_five_request_blocks'][0]['above_1_percent']
assert jit['fixed_five_request_blocks'][0]['above_2_percent']
assert jit['last10_vs_first10_median_wall_drift'] == 0
measured[7]['jit_after_ms'] = 999
jit = reviewer['measured_jit'](measured)
assert jit['JIT_fraction'] is None and jit['above_1_percent'] is None
assert jit['unavailable_or_decreasing_intervals'] == 1
assert jit['JIT_deltas_ms'][7] is None
assert jit['fixed_five_request_blocks'][0]['JIT_fraction'] == .03
report = {'per_cohort': [{'cohort': 1, 'variants': {'candidate': {'measured_JIT': jit}}}]}
assert len(reviewer['measured_jit_csv'](report)) == 5

ci = reviewer['t_interval']([math.exp(x) for x in (-.02, -.01, 0, .01, .02)])
half = 2.7764451051977987 * math.sqrt(.00005)
assert ci['df'] == 4 and math.isclose(ci['geomean'], 1)
assert math.isclose(ci['ci95_low'], math.exp(-half), rel_tol=1e-12)
assert math.isclose(ci['ci95_high'], math.exp(half), rel_tol=1e-12)
inverse = reviewer['invert'](ci)
assert math.isclose(inverse['ci95_low'], 1 / ci['ci95_high'])
assert reviewer['t_interval']([1, 1, 1]) is None

expected = {'run-v3.py': '74ed5966d78afe3621f382e893488e400701ace393f04514274326a107ebab7f',
            'review-results-v2.py': 'a4b9cea4f147089e5b64acc984da4a796fa0ad628776f18388e625324e0e8570'}
for filename, digest in expected.items():
    assert hashlib.sha256((ROOT / filename).read_bytes()).hexdigest() == digest
for old, new, changed in [('run-v3.py', 'run-v4.py', {'stability', 'cohort_ci', 'main'}),
                          ('review-results-v2.py', 'review-results-v4.py', {'bootstrap', 't_interval', 'settling', 'review', 'main'})]:
    definitions = lambda name: {n.name: ast.dump(n, include_attributes=False) for n in ast.parse((ROOT / name).read_text()).body if isinstance(n, (ast.FunctionDef, ast.ClassDef))}
    before, after = definitions(old), definitions(new)
    assert {name for name in before if before[name] != after[name]} == changed

def literal(filename, name):
    tree = ast.parse((ROOT / filename).read_text())
    return ast.literal_eval(next(node.value for node in tree.body if isinstance(node, ast.Assign)
                                 and any(isinstance(target, ast.Name) and target.id == name for target in node.targets)))


protocol = literal('run-v4.py', 'PROTOCOL')
assert protocol == literal('review-results-v4.py', 'PROTOCOL')
assert protocol == literal('../launch-v4.py', 'PROTOCOL')
assert protocol == literal('../publish_java_profile.py', 'PROTOCOL_V4')
assert literal('../launch-v4.py', 'RUNNER_SHA256') == hashlib.sha256((ROOT / 'run-v4.py').read_bytes()).hexdigest()
publisher = selected('../publish_java_profile.py', ['require', 'protocol_for_metadata'])
publisher['PROTOCOL_V4'] = protocol
for count in (1, 3):
    legacy = {'cohorts': count, 'pairs': 5, 'min_warmup': 12, 'max_warmup': 90, 'baseline': 'CONTROL'}
    assert publisher['protocol_for_metadata'](legacy)['version'] == 'v3'
future = {'benchmark_protocol': protocol, 'cohorts': 5, 'pairs': 20,
          'min_warmup': 60, 'max_warmup': 150, 'baseline': 'STOCK'}
assert publisher['protocol_for_metadata'](future)['version'] == 'confirmation-v4'
for key, bad in [('cohorts', 3), ('pairs', 5), ('baseline', 'CONTROL'), ('max_warmup', 90)]:
    try:
        publisher['protocol_for_metadata'](future | {key: bad})
    except RuntimeError:
        pass
    else:
        raise AssertionError('publisher admitted mixed protocol: ' + key)

print('PASS v4 AST/pure-math checks; frozen sources unchanged; no benchmark/JVM/helper modules imported or executed')
