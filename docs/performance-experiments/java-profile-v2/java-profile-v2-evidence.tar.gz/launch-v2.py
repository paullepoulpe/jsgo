"""Launch the pinned v2 Java pair runner with its coordination receipt.

Source prepared separately from execution. Running this file starts a benchmark;
the caller selects a fresh output path, baseline/candidate, and one or three cohorts.
"""
from pathlib import Path
import argparse
import hashlib
import json
import os
import sys

ROOT = Path(__file__).resolve().parent
RUNNER = ROOT / 'bench/run-v3.py'
RUNNER_SHA256 = '74ed5966d78afe3621f382e893488e400701ace393f04514274326a107ebab7f'
JAR = '/workspace/jsgo/.cache/closure-compiler-v20261015-maven.jar'
JDK = '/usr/lib/jvm/java-21-openjdk-amd64'
IMAGE = 'python@sha256:70729b46c69b4f1e97c4822c1af3df53a1476cf5ddc6c087c0c10bc3a5678c2f'
TASKS = {
    'bigquery': (
        '/workspace/jsgo-results/round4/bigquery-stock-oracle-v1/spec.json',
        '/workspace/jsgo-results/round4/bigquery-stock-oracle-v1'),
    'bundle': (
        '/workspace/jsgo-results/round4/main-9c895b43-sync-v1/benchmark-preparation-v2/go-screen-v2/specs/bundle-n1.json',
        '/workspace/jsgo-results/round4/paired-main5de-bundle-advanced-t1-v1'),
}


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('task', choices=TASKS)
    parser.add_argument('--manifest', required=True, type=Path)
    parser.add_argument('--baseline', required=True)
    parser.add_argument('--candidate', required=True)
    parser.add_argument('--cohorts', required=True, type=int, choices=(1, 3))
    parser.add_argument('--out', required=True, type=Path)
    args = parser.parse_args()
    manifest_path = args.manifest.resolve()
    out = args.out.resolve()
    if out.exists():
        raise ValueError('benchmark output must be a fresh path: ' + str(out))
    if sha(RUNNER) != RUNNER_SHA256:
        raise ValueError('runner source differs from the reviewed v2 pin')
    manifest = json.loads(manifest_path.read_text())
    if manifest['status'] != 'PASS_BUILD_VALIDATION' or manifest['java_home'] != JDK:
        raise ValueError('manifest must contain a successful build for the pinned JDK')
    if manifest['driver']['source_sha256'] != sha(ROOT / 'bench/CliFactors.java'):
        raise ValueError('manifest driver differs from the unchanged CliFactors source')
    if args.baseline == args.candidate or not {args.baseline, args.candidate} <= set(manifest['variants']):
        raise ValueError('choose two distinct variants present in the manifest')
    spec, oracle_directory = TASKS[args.task]
    oracle_directory = Path(oracle_directory)
    grant = {
        'runner_sha256': RUNNER_SHA256,
        'manifest_sha256': sha(manifest_path),
        'spec_sha256': sha(spec),
        'out': str(out),
        'baseline': args.baseline,
        'candidate': args.candidate,
        'cohorts': args.cohorts,
        'pairs': 5,
        'allowed_stages': ['benchmark'],
        'inference_plan': {
            'screen': 'One cohort selects candidates only; no significance or confidence-interval claim.',
            'confirmation': 'If promising, compare directly with STOCK in three fresh independent JVM-pair cohorts.',
            'generalization': 'Use a separate bundle workload run; do not pool requests or workloads for confidence intervals.',
        },
    }
    grant_directory = ROOT / 'launches'
    grant_directory.mkdir(parents=True, exist_ok=True)
    grant_path = grant_directory / (out.name + '.grant.json')
    # Refuse to overwrite an earlier run's pin or its retained result directory.
    with grant_path.open('x') as output:
        json.dump(grant, output, indent=2)
        output.write('\n')
    command = [
        sys.executable, str(RUNNER),
        '--manifest', str(manifest_path), '--baseline', args.baseline,
        '--candidate', args.candidate, '--cohorts', str(args.cohorts), '--pairs', '5',
        '--spec', spec, '--oracle', str(oracle_directory / 'stock-java-oracle-digests.json'),
        '--oracle-metadata', str(oracle_directory / 'metadata.json'),
        '--jar', JAR, '--java-home', JDK, '--image', IMAGE,
        '--out', str(out), '--runtime-grant', str(grant_path),
        '--min-warmup', '12', '--max-warmup', '90', '--seed', '20261020',
    ]
    print(json.dumps({'task': args.task, 'command': command, 'grant': str(grant_path)}), flush=True)
    os.execv(sys.executable, command)


if __name__ == '__main__':
    main()
