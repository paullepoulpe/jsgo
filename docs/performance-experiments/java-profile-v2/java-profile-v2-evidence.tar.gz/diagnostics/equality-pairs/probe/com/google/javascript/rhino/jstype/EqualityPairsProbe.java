package com.google.javascript.rhino.jstype;

import com.google.javascript.rhino.ErrorReporter;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/** Same-source semantic probe for stock, rebuilt control, and equality entry diagnostic. */
public final class EqualityPairsProbe {
  private record Case(String label, JSType type) {}
  private static final Reporter REPORTER = new Reporter();
  private static final JSTypeRegistry REGISTRY = new JSTypeRegistry(REPORTER);

  public static void main(String[] args) {
    boolean requireDiagnostic = args.length == 1 && args[0].equals("--require-diagnostic");
    check(args.length == 0 || requireDiagnostic, "unexpected arguments");
    for (JSTypeNative nativeType : JSTypeNative.values()) {
      JSType type = REGISTRY.getNativeType(nativeType);
      check(type != null, "native type initialized: " + nativeType);
      checkSelf(nativeType.name(), type);
    }

    JSType number = REGISTRY.getNativeType(JSTypeNative.NUMBER_TYPE);
    JSType string = REGISTRY.getNativeType(JSTypeNative.STRING_TYPE);
    JSType unknown = REGISTRY.getNativeType(JSTypeNative.UNKNOWN_TYPE);
    JSType checkedUnknown = REGISTRY.getNativeType(JSTypeNative.CHECKED_UNKNOWN_TYPE);
    List<Case> cases = new ArrayList<>();
    cases.add(new Case("number", number));
    cases.add(new Case("string", string));
    cases.add(new Case("unknown", unknown));
    cases.add(new Case("checked-unknown", checkedUnknown));
    cases.add(new Case("record-a", REGISTRY.createRecordType(Map.of("x", number))));
    cases.add(new Case("record-b", REGISTRY.createRecordType(Map.of("x", number))));
    cases.add(new Case("record-different", REGISTRY.createRecordType(Map.of("x", string))));
    cases.add(new Case("function-a", REGISTRY.createFunctionType(number, string)));
    cases.add(new Case("function-b", REGISTRY.createFunctionType(number, string)));
    cases.add(new Case("function-different", REGISTRY.createFunctionType(string, string)));
    cases.add(new Case("union-a", REGISTRY.createUnionType(number, string)));
    cases.add(new Case("union-b", REGISTRY.createUnionType(string, number)));
    cases.add(new Case("template-a", REGISTRY.createTemplateType("T")));
    cases.add(new Case("template-b", REGISTRY.createTemplateType("T")));
    ObjectType array = REGISTRY.getNativeObjectType(JSTypeNative.ARRAY_TYPE);
    cases.add(new Case("array-number-a", REGISTRY.createTemplatizedType(array, number)));
    cases.add(new Case("array-number-b", REGISTRY.createTemplatizedType(array, number)));
    cases.add(new Case("array-string", REGISTRY.createTemplatizedType(array, string)));
    cases.add(new Case("symbol-a", new KnownSymbolType(REGISTRY, "same-display-name")));
    cases.add(new Case("symbol-b", new KnownSymbolType(REGISTRY, "same-display-name")));

    for (Case item : cases) {
      checkSelf(item.label(), item.type());
      StringBuilder row = new StringBuilder(item.label()).append(':');
      for (Case other : cases) {
        boolean expectedDifference = referenceDiffers(item.type(), other.type());
        check(item.type().differsFrom(other.type()) == expectedDifference,
            item.label() + "/" + other.label() + " differsFrom");
        check(JSType.areSimilar(item.type(), other.type()) == !expectedDifference,
            item.label() + "/" + other.label() + " areSimilar");
        row.append(expectedDifference ? '1' : '0');
      }
      System.out.println(row);
    }
    check(!number.differsFrom(number), "identity number");
    check(number.differsFrom(string), "distinct primitive");
    check(!unknown.differsFrom(checkedUnknown), "DATA_FLOW unknown equivalence");
    check(!cases.get(4).type().differsFrom(cases.get(5).type()), "distinct equal records");
    check(!cases.get(7).type().differsFrom(cases.get(8).type()), "distinct equal functions");
    check(JSType.areSimilar(null, null), "null/null");
    check(!JSType.areSimilar(number, null) && !JSType.areSimilar(null, number), "one null");

    unresolvedAndRecursive();
    ArmedObject armed = new ArmedObject();
    armed.armed = true;
    checkSelf("armed-predicates", armed);
    check(armed.predicateCalls == 0, "identity comparison must not invoke type predicates");
    check(REPORTER.diagnostics == 0, "probe must not emit type diagnostics");
    if (requireDiagnostic) { checkDiagnosticCounters(number, string); }
    System.out.println("EqualityPairsProbe OK");
  }

  private static void checkDiagnosticCounters(JSType number, JSType string) {
    try {
      Class<?> diagnostic = Class.forName(EqualityChecker.class.getName() + "$EntryDiagnostic");
      java.lang.reflect.Field total = diagnostic.getDeclaredField("total");
      total.setAccessible(true);
      long before = total.getLong(null);
      check(new EqualityChecker().setEqMethod(EqualityChecker.EqMethod.IDENTITY)
          .check(number, number), "diagnostic identity");
      check(!new EqualityChecker().setEqMethod(EqualityChecker.EqMethod.IDENTITY)
          .check(number, string), "diagnostic distinct primitive");
      check(new EqualityChecker().setEqMethod(EqualityChecker.EqMethod.DATA_FLOW)
          .check(null, null), "diagnostic two nulls");
      check(!new EqualityChecker().setEqMethod(EqualityChecker.EqMethod.DATA_FLOW)
          .check(null, number), "diagnostic one null");
      check(total.getLong(null) == before + 4, "exact four entry counter increments");
    } catch (ReflectiveOperationException exception) {
      throw new AssertionError("diagnostic instrumentation must be loaded", exception);
    }
  }

  private static void unresolvedAndRecursive() {
    NamedType unresolved;
    JSType recursive;
    try (JSTypeResolver.Closer closer = REGISTRY.getResolver().openForDefinition()) {
      unresolved = REGISTRY.createNamedType(null, "Pending", "probe.js", 1, 0);
      check(!unresolved.isResolved(), "named fixture starts unresolved");
      JSType referencedBefore = unresolved.getReferencedType();
      int diagnosticsBefore = REPORTER.diagnostics;
      checkSelf("unresolved-named", unresolved);
      check(!unresolved.isResolved(), "identity comparison preserves unresolved state");
      check(unresolved.getReferencedType() == referencedBefore,
          "identity comparison preserves referenced type");
      check(REPORTER.diagnostics == diagnosticsBefore, "identity comparison emits no diagnostic");

      NamedType forward = NamedType.builder(REGISTRY, "RecursiveRecord")
          .setResolutionKind(NamedType.ResolutionKind.NONE).build();
      recursive = REGISTRY.createRecordType(Map.of("next", forward));
      forward.setReferencedType(recursive);
      check(!recursive.isResolved(), "recursive fixture starts unresolved");
      checkSelf("recursive-before-resolution", recursive);
      check(!recursive.isResolved(), "recursive identity comparison does not resolve");
    }
    check(unresolved.isResolved(), "closer resolves named fixture");
    check(recursive.isResolved(), "closer resolves recursive fixture");
    checkSelf("named-after-resolution", unresolved);
    checkSelf("recursive-after-resolution", recursive);
  }

  private static void checkSelf(String label, JSType type) {
    boolean resolved = type.isResolved();
    check(!referenceDiffers(type, type), label + " direct checker reflexivity");
    for (int i = 0; i < 3; i++) {
      check(!type.differsFrom(type), label + " differsFrom reflexivity");
      check(JSType.areSimilar(type, type), label + " areSimilar reflexivity");
    }
    check(type.isResolved() == resolved, label + " self comparison resolution state");
    check(type.differsFrom(null), label + " null argument");
    System.out.println("self=" + label + ":resolved=" + resolved);
  }

  private static boolean referenceDiffers(JSType left, JSType right) {
    // This directly invokes the exact checker used by the pinned implementation.
    return !new EqualityChecker().setEqMethod(EqualityChecker.EqMethod.DATA_FLOW).check(left, right);
  }

  private static final class ArmedObject extends PrototypeObjectType {
    boolean armed;
    int predicateCalls;

    ArmedObject() { super(PrototypeObjectType.builder(REGISTRY).setName("Armed")); }

    @Override public boolean isNoResolvedType() {
      if (armed) { predicateCalls++; throw new AssertionError("unexpected isNoResolvedType"); }
      return super.isNoResolvedType();
    }

    @Override public boolean isUnknownType() {
      if (armed) { predicateCalls++; throw new AssertionError("unexpected isUnknownType"); }
      return super.isUnknownType();
    }
  }

  private static final class Reporter implements ErrorReporter {
    int diagnostics;
    @Override public void warning(String message, String source, int line, int column) {
      diagnostics++;
    }
    @Override public void error(String message, String source, int line, int column) {
      diagnostics++;
    }
  }

  private static void check(boolean condition, String message) {
    if (!condition) { throw new AssertionError(message); }
  }
}
