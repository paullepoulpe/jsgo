EqualityChecker entry-pair diagnostic (not an optimization)

Status: source and probe prepared; no Java compilation or execution performed.
The untouched control is copied from the pinned extracted Closure v20261015
source. The normalized patch targets src/com/google/javascript/rhino/jstype/
EqualityChecker.java in an upstream source checkout. This directory is separate
from the production performance candidates.

Question
The diagnostic CPU/allocation profile attributes 3.5167% of sampled allocation to
EqualityChecker, with roughly 2.6983 percentage points in the shown JSType.equals
calls from SubtypeChecker. It does not expose the actual compared type pairs.
A broad primitive shortcut can add work while covering few calls. This diagnostic
counts runtime classes to assess that opportunity before changing semantics.

Instrumentation
One call is inserted in check(left, right), after the existing checkHasNotRun()
and hasRun=true and before the unchanged areEqualCaching() call. The counter reads
only the EqMethod field, final Object.getClass(), Class.getName(), and reference
identity. It does not call JSType.toString(), hashCode(), equals(), type predicates,
getTemplateTypeMap(), resolution helpers, or other overridable type behavior.
In particular, template-map emptiness is deliberately not measured by calling the
public overridable getter.

Counts are keyed by method, left runtime class name, right runtime class name, and
left==right. Null values have an explicit marker. Class names may aggregate equal
names from different class loaders; the intended pinned CLI uses one class loader.
The map retains at most 4096 keys, with overflow calls explicitly counted. Updates
and reporting share one monitor, so threads cannot race the map or counters.
At graceful JVM shutdown the hook sorts the bounded map and prints up to 128 keys
by descending call count, then method/classes/identity. It reports tracked, printed,
omitted and overflow counts. Every line is prefixed JSGO_EQUALITY_ENTRY_DIAGNOSTIC.
The hook writes only System.err, with no source text, paths, environment values,
JSType values or other user data. Normal compiler stdout is untouched.

Interpretation limits
- This adds synchronization, key allocation and hashing. Never use its elapsed,
  CPU, allocated-byte or RSS values as an optimization result.
- Counts cover top-level check() entries, not recursive areEqualCaching() calls
  and not checkParameters(). They are call counts, not allocation-byte weights.
- Counts aggregate the process lifetime. Use one compiler request for a one-build
  distribution; repeated requests are cumulative. JVM/class initialization work
  is included if it invokes check().
- The hook requires normal JVM exit/STOP. SIGKILL or abrupt container removal can
  suppress its output. Preserve the driver exit/teardown receipt.
- Class-pair frequencies alone do not prove a primitive shortcut is sound. Public
  mergeSupertypeTemplateTypes() can populate even a final primitive's template
  map; the earlier shortcut audit still applies. No optimization is nominated yet.
- Profiling adds observable diagnostic output and resource costs by design. Its
  claim is preservation of the original compiler computation and normal output
  artifacts in the controlled harness, not transparent arbitrary-library identity
  or resource-exhaustion behavior.

Build/probe plan (root owns execution when the benchmark machine is idle)

python3 /workspace/jsgo-java-experiments/profile-v2/build-candidate.py equality-pairs \
  --source-root /workspace/jsgo-java-experiments/profile-v2/diagnostics/equality-pairs/src

python3 /workspace/jsgo-java-experiments/profile-v2/run-probes.py \
  --manifest /workspace/jsgo-java-experiments/profile-v2/build/equality-pairs/manifest.json \
  --probe-source /workspace/jsgo-java-experiments/profile-v2/diagnostics/equality-pairs/probe/com/google/javascript/rhino/jstype/EqualityPairsProbe.java \
  --probe-class com.google.javascript.rhino.jstype.EqualityPairsProbe \
  --candidate-arg=--require-diagnostic --compare-stdout \
  --out /workspace/jsgo-java-experiments/profile-v2/results/equality-pairs-probes-attempt-1

The probe retains the identity-differs oracle matrix, native/recursive/unresolved/
armed-predicate checks. On the instrumented variant it additionally verifies four
explicit checker invocations add exactly four to the counter, including self,
distinct primitive, two-null and one-null cases. Cross-variant stdout must match;
only candidate process stderr receives the prefixed shutdown report. Inspect that
report for coherent total=sum(printed)+omitted+overflow and no overflow.

Diagnostic workload plan
Use the frozen CliFactors driver with only one request and a graceful STOP under
the same 4 GiB/no-swap/two-CPU harness, capturing driver stderr separately. The
compiler already writes its six normal artifacts via explicit PrintStreams;
System.err is not redirected into the per-request compiler stderr artifact. Check
all six artifacts against the stock oracle and loaded EqualityChecker provenance.
Do not run the full warmup benchmark controller just to gather counts, and do not
filter or rewrite normal compiler stderr. Retain the exact argv, class/source pins,
raw prefixed report, artifact checks and teardown proof. A single diagnostic run
is not a settled timing test or proof of workload generality.

Next decision
If a small set of final scalar pairs dominates and has low template-map risk, a
separate candidate can test a narrow proven guard (including the necessary map
condition). If structured/object/function pairs dominate, this result may instead
rule out a cheap primitive guard and motivate a more involved lazy-checker design.
Keep that source/design choice separate from this instrumentation.
